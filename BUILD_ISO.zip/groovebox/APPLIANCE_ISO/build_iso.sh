#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${1:-$ROOT/dist/sOS-installer-x86_64.iso}"
OUT_DIR="$(dirname "$OUT")"

# If this script was launched with sudo, prefer ownership by the invoking desktop user.
BUILD_USER="${SUDO_USER:-${USER:-$(id -un)}}"
BUILD_GROUP="$(id -gn "$BUILD_USER" 2>/dev/null || printf '%s' "$BUILD_USER")"

log() { printf '[sOS] %s\n' "$*"; }
die() { printf '[sOS] ERROR: %s\n' "$*" >&2; exit 1; }

GRUB_RESCUE=""
if command -v grub2-mkrescue >/dev/null 2>&1; then
    GRUB_RESCUE="$(command -v grub2-mkrescue)"
elif command -v grub-mkrescue >/dev/null 2>&1; then
    GRUB_RESCUE="$(command -v grub-mkrescue)"
fi

if [[ -z "$GRUB_RESCUE" ]] || ! command -v xorriso >/dev/null 2>&1; then
    cat >&2 <<'MSG'
[sOS] Missing ISO host tools.
[sOS] Fedora:        sudo dnf install -y grub2-tools-extra xorriso
[sOS] Debian/Ubuntu: sudo apt install -y grub-pc-bin grub-common xorriso
MSG
    exit 2
fi

[[ -d "$ROOT/iso-root" ]] || die "Missing ISO tree: $ROOT/iso-root"

# Create the destination directory. Previous sudo builds can leave dist/ root-owned,
# so repair ownership automatically when the destination is inside this sOS tree.
mkdir -p "$OUT_DIR" 2>/dev/null || true

case "$OUT_DIR/" in
    "$ROOT"/*)
        if [[ ! -w "$OUT_DIR" ]]; then
            log "Destination is not writable by $BUILD_USER; repairing ownership of $OUT_DIR"
            if [[ $EUID -eq 0 ]]; then
                chown -R "$BUILD_USER:$BUILD_GROUP" "$OUT_DIR"
            elif command -v sudo >/dev/null 2>&1; then
                sudo chown -R "$BUILD_USER:$BUILD_GROUP" "$OUT_DIR"
            else
                die "$OUT_DIR is not writable and sudo is unavailable"
            fi
        fi
        ;;
    *)
        [[ -d "$OUT_DIR" ]] || mkdir -p "$OUT_DIR"
        [[ -w "$OUT_DIR" ]] || die "Output directory is not writable: $OUT_DIR"
        ;;
esac

# Remove stale/partial artifacts from previous failed or sudo builds.
for stale in "$OUT" "$OUT.sha256"; do
    if [[ -e "$stale" || -L "$stale" ]]; then
        if rm -f -- "$stale" 2>/dev/null; then
            :
        elif [[ $stale == "$ROOT"/* ]] && command -v sudo >/dev/null 2>&1; then
            log "Removing root-owned stale artifact: $stale"
            sudo rm -f -- "$stale"
        else
            die "Cannot remove stale artifact: $stale"
        fi
    fi
done

# Prove xorriso can create files here before doing the expensive rescue-image build.
PROBE="$OUT_DIR/.sos-write-test.$$"
if ! : > "$PROBE" 2>/dev/null; then
    die "Cannot write to $OUT_DIR. Check ownership/permissions."
fi
rm -f "$PROBE"

log "Building bootable ISO"
log "Source: $ROOT/iso-root"
log "Output: $OUT"

"$GRUB_RESCUE" -o "$OUT" -iso-level 3 "$ROOT/iso-root"

[[ -s "$OUT" ]] || die "grub-mkrescue returned without producing a non-empty ISO"
sha256sum "$OUT" > "$OUT.sha256"

# If invoked via sudo, give the completed artifacts back to the invoking user.
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    chown "$BUILD_USER:$BUILD_GROUP" "$OUT" "$OUT.sha256" 2>/dev/null || true
fi

log "Built: $OUT"
log "SHA-256: $(cut -d' ' -f1 "$OUT.sha256")"
