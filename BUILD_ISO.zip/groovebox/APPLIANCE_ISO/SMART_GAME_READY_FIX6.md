# sOS / sCode Smart Game-Ready Fix 6

This release adds first-class sCode logic↔numeric casting, deterministic pooling,
coalescing/scheduling helpers, game entity/world/tick routing, and a safe compiler
optimization vocabulary. First-party smart policy is sCode; kernel, firmware,
drivers and third-party packages remain upstream native code.

Builder fixes:
- native-transfer SHA→Finite-Infinity routing no longer uses fragile Bash `0x...` arithmetic;
- `/proc`, `/sys`, `/dev`, and `/run` are mounted in the installroot during Fedora DNF transactions and unwound on exit;
- Fedora usr-merge and `/var/tmp` fixes remain included;
- game-ready images install `sos-smart` and all sCode growth/hardware handles.
