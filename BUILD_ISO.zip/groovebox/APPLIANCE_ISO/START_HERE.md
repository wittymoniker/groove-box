# START HERE

1. Build the ISO with `./build_iso.sh`.
2. Test it with `./scripts/test_qemu.sh dist/sOS-installer-x86_64.iso`.
3. Boot it from USB/DVD/VM.
4. Choose Live, Install, or Recovery.
5. Before installation, use `sos-backup` if the target contains data you need.
6. Run `sos-install`; it requires two destructive confirmations.

All current default sOS applications are already included in the image.

## Continuum / reverse-grep / protection

The installer now includes `scontinuum`, `sos-continuum`, `sos-rgrep-wrap`, `sos-meum-pack`, `sos-protect`, `sos-extend`, and `sos-simplify`.

- `sos-continuumd` automatically classifies running processes into combinable math/logic continuums.
- `sos-rgrep-wrap COMMAND ...` attempts compatible adapters and reverse-greps failure evidence.
- `sos-extend import PATH` always produces a compatibility-transfer plan for imported materials.
- `sos-protect watch FILE` enables automatic SHA-verified segment repair using a Meum/FI routing index.
- `sos-health-optimize PATH` automatically generates a Meum-grep simplification plan.
- Applying simplification is never automatic: run `sos-simplify apply PLAN` and type `APPLY-MEUM-SIMPLIFICATION`.
