# sOS — GitHub Source Repository

sOS is the experimental Math-First operating-system/workstation project. **This repository includes the complete sCode GitHub tree in `sCode/`.**

Start with `START_HERE.md`.

## Hardware modality and installed sCode completion
The fat x86_64 sOS build installs the trusted sCode bootstrap as `/usr/bin/scode`, the complete sCode library/source tree under `/opt/sos/sCode`, and `sos-hardware-modality` for persistent device semantics. Unknown hardware is queued or interactively named/purposed; generated adapters remain separate from the trusted base library and carry provenance. Use `sos-scode-build check` and `sos-scode-build groovebox`.


FULL-GRAPH SCRIPT COMPATIBILITY (2026-09-09)
---------------------------------------------
This build carries graph_script_context.py and the full_graph_v1 runtime contract.
Seed/Instrument/Algorithm/Domain programs can share the same t/x/y/z graph context,
and the resulting named channels are consumed by audio, video/scenograph, and
generated-game paths. RAND PARAM uses a pre-evaluated row cache in realtime.
Canonical and heuristic/random writers can author the richer scripts while preserving
user-authored Instrument Scripts. Keep graph_script_context.py beside groovebox.py
on every platform/appliance install. See HELP_TEXT.md for the public variable list.
