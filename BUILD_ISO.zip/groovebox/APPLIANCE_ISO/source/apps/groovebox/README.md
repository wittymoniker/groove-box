# Mathematician's Groovebox — native sCode

The authoritative native application entry is `groovebox_native_full.sC` on sCode 10.

It generates project state, deterministic PCM audio, a deterministic visual frame, MIDI, deterministic game/world data, and a cross-media bundle manifest without requiring Python, Julia, or C++.

Run from the repository root:

```sh
./run_groovebox_native.sh
```

Batch export:

```sh
GROOVEBOX_BATCH=1 GROOVEBOX_OUT_PREFIX=my_project ./run_groovebox_native.sh
```

Native defaults are Math Symbols ON and EQR 0.4014.

The older `groovebox.sC` and `groovebox_full_target.sC` are retained as compatibility examples; new work should target `groovebox_native_full.sC` and the modules under `scode/libs/groovebox/`.


FULL-GRAPH SCRIPT COMPATIBILITY (2026-09-09)
---------------------------------------------
This build carries graph_script_context.py and the full_graph_v1 runtime contract.
Seed/Instrument/Algorithm/Domain programs can share the same t/x/y/z graph context,
and the resulting named channels are consumed by audio, video/scenograph, and
generated-game paths. RAND PARAM uses a pre-evaluated row cache in realtime.
Canonical and heuristic/random writers can author the richer scripts while preserving
user-authored Instrument Scripts. Keep graph_script_context.py beside groovebox.py
on every platform/appliance install. See HELP_TEXT.md for the public variable list.
