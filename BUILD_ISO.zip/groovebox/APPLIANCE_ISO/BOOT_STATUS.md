# Boot artifact status

- kernel bundled: /boot/vmlinuz-6.12.96+deb13-amd64
- refreshed initramfs: built successfully
- current sCode stage-0 Linux x86-64 seed: embedded at /usr/bin/scode
- current sCode source tree: embedded at /opt/sCode
- current sOS apps/config/docs: embedded at /opt/sOS
- GRUB menu: Live / Safe Mode / Installer Hint
- destructive disk partitioning: none
- final ISO generation in this environment: NOT completed (missing grub-mkrescue/xorriso)
- QEMU boot test in this environment: NOT completed (qemu-system-x86_64 unavailable)
