# Safe-to-try defaults

This release was changed specifically to avoid expensive self-recalculation on first boot.

Default boot behavior:
1. mount basic virtual filesystems;
2. run the installer profile wizard only in installer mode;
3. run `sos-ready-check`, which checks the precomputed release manifest and core commands;
4. start the normal sOS supervisor/console.

It does **not** automatically run full structural convergence, deep reverse-grep, source simplification, package add/remove, or global recompilation.

Those operations require explicit maintenance commands. `sos-deep-maintenance` additionally requires the phrase `RUN-DEEP-MAINTENANCE`.

The current ISO remains an x86-64 build kit; a final ISO still needs to be built and boot-tested on a machine with the required GRUB/xorriso tooling before it should be installed on important hardware.
