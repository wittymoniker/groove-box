#!/usr/bin/env bash
set -euo pipefail
ROOT=${1:?rootfs required}
VMLINUX=${2:?vmlinuz required}
KVER=${3:?kernel release required}
fail(){ echo "[sOS] LIVE-KERNEL FAIL: $*" >&2; exit 1; }
ok(){ echo "[sOS] LIVE-KERNEL OK: $*"; }
[ -s "$VMLINUX" ] || fail "missing live vmlinuz"
MOD="$ROOT/usr/lib/modules/$KVER"
[ -d "$MOD" ] || fail "missing module tree $MOD"
COUNT=$(find "$MOD" -type f \( -name '*.ko' -o -name '*.ko.xz' -o -name '*.ko.zst' -o -name '*.ko.gz' \) | wc -l)
[ "$COUNT" -ge 100 ] || fail "only $COUNT kernel modules present"
findmod(){ find "$MOD" -type f \( -name "$1.ko" -o -name "$1.ko.xz" -o -name "$1.ko.zst" -o -name "$1.ko.gz" \) -print -quit | grep -q .; }
for m in ahci xhci-pci i915 snd-hda-intel; do
  case "$m" in
    xhci-pci) findmod xhci-pci || findmod xhci_pci || fail "missing xHCI USB module";;
    snd-hda-intel) findmod snd-hda-intel || findmod snd_hda_intel || fail "missing Intel HDA module";;
    *) findmod "$m" || fail "missing $m module";;
  esac
done
if findmod iwlwifi; then ok 'Intel Wi-Fi module'; else echo '[sOS] WARN: iwlwifi module absent'; fi
if findmod e1000e || findmod r8169; then ok 'wired Ethernet module'; else echo '[sOS] WARN: common Ethernet modules absent'; fi
FWDIRS=("$ROOT/usr/lib/firmware" "$ROOT/lib/firmware")
FWCOUNT=0
for d in "${FWDIRS[@]}"; do [ -d "$d" ] && FWCOUNT=$((FWCOUNT + $(find "$d" -type f | wc -l))); done
[ "$FWCOUNT" -gt 0 ] || fail 'linux-firmware payload is empty'
for c in python3 ffmpeg modprobe; do
  chroot "$ROOT" /usr/bin/env sh -lc "command -v $c >/dev/null" || fail "missing runtime command $c"
done
chroot "$ROOT" /usr/bin/python3 -c 'import numpy, PyQt6.QtCore, PIL, sounddevice' || fail 'Python/Qt/audio imports'
chroot "$ROOT" /usr/bin/python3 -m py_compile /opt/groovebox/groovebox.py /opt/groovebox/run_groovebox.py || fail 'Groovebox Python compile'
ok "kernel=$KVER modules=$COUNT firmware=$FWCOUNT"
