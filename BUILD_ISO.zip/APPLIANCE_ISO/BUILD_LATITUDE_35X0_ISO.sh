#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT=${1:-$ROOT/dist/sOS-Groovebox-Latitude-3560-3570-x86_64.iso}
[ "$(id -u)" -eq 0 ] || { echo 'Run with sudo/root.' >&2; exit 3; }
echo '[sOS] Latitude 3560/3570 appliance profile: x86_64, UEFI+BIOS, AHCI, Intel i915, HDA, common Intel/Realtek network'
"$ROOT/BUILD_GAME_READY_ISO.sh" --profile game-ready --output "$OUT"
echo '[sOS] Running final ISO-tree hardware contract checks...'
[ -s "$ROOT/iso-root/boot/vmlinuz" ]
[ -s "$ROOT/iso-root/boot/initramfs.img" ]
[ -s "$ROOT/iso-root/boot/kernel.release" ]
sha256sum "$OUT" > "$OUT.sha256"
echo "[sOS] Latitude appliance ISO ready: $OUT"
