# EQR Groovebox — Complete V1

## Run
```bash
pip install PyQt6 numpy sounddevice scipy
./launch_eqr.sh
# or: python3 groovebox.py
```

## What to look for

| Control | Where |
|---------|--------|
| **Visual objects 1–64** | Own row under transport (cyan “Visual objects:”) |
| **EQR** | Global slider (default 42%) — drives tensor + P/E/D path |
| **Random / Elaborate / Prev Seed** | Seed panel — complex scripts with P,E,D |
| **Step algorithm** | Prime / Square / Coprime / … → Apply |
| **Engine path / Unison blend** | Under seed panel |

## Visualizer HUD (left scope)

- Bottom: voices · seed values · **ENG:** active engines  
- Right strip: **EQR, Frac, BPM, BaseHz, VisN, EngStr, Unison, Vol** + mini meters  

## Render path

- Sequence panels blend 50/50 with master  
- EQR tensor + P/E/D modulation on mixdown  
- Scenograph item count + engine-linked fades  
- Failures stay in the status line / console — no spam popups on play  

## Spectrum
5.2 Hz – 27.5 kHz design window · preferred 96 kHz  

## Package
`groovebox.py` · `launch_eqr.sh` · `launch_eqr.py` · this README · `eqr-v1-complete.zip`
