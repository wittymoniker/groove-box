#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
PYTHON="${PYTHON:-python3}"
VENV="${VENV:-$ROOT/.venv-build}"
$PYTHON -m venv "$VENV"
# shellcheck disable=SC1091
source "$VENV/bin/activate"
pip install -U pip wheel
pip install -r requirements.txt -r requirements-build.txt
export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-offscreen}"
pyinstaller --noconfirm --clean \
  --name EQR-Groovebox \
  --windowed \
  --onedir \
  --paths . \
  --collect-all PyQt6 \
  --hidden-import sounddevice \
  --hidden-import numpy \
  --hidden-import scipy \
  --hidden-import scipy.io.wavfile \
  --hidden-import groovebox \
  run_groovebox.py
echo "Output: $ROOT/dist/EQR-Groovebox"
