#!/usr/bin/env python3
"""Regression tests for seed / script input variables (no Qt required)."""
from __future__ import annotations

import ast
import math
import random
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
src = (ROOT / "groovebox.py").read_text(encoding="utf-8", errors="replace")

ns: dict = {
    "math": math,
    "random": random,
    "np": __import__("numpy"),
    "ast": ast,
    "struct": struct,
    "hashlib": __import__("hashlib"),
}

const_start = src.find("MEUM = 1.1975807343385265188")
const_end = src.find("PAINT_INSTANCE_LIMIT")
if const_start < 0 or const_end < 0:
    print("Could not locate Meum constants in groovebox.py")
    sys.exit(2)
exec(src[const_start:const_end], ns)

funcs = [
    "_parse_if_elif_shorthand",
    "_safe_int_seed",
    "_seed_to_pitch_ratio",
    "_seed_to_fundamental_hz",
    "_coerce_numeric_values",
    "_seed_script_env",
    "_normalize_seed_script_text",
    "_eval_seed_python",
    "evaluate_seed_expression_at_time",
    "parse_seed_numeric_list",
    "seed_script_is_viable",
    "evaluate_seed_component",
    "_split_seed_list_parts",
]
for fname in funcs:
    m = re.search(rf"^def {fname}\(", src, re.M)
    if not m:
        print("MISSING", fname)
        sys.exit(2)
    start = m.start()
    m2 = re.search(r"^(def |class )", src[start + 1 :], re.M)
    end = start + 1 + m2.start() if m2 else len(src)
    exec(src[start:end], ns)

tests: list[tuple[str, bool, object]] = []


def T(name: str, cond: bool, detail: object = "") -> None:
    tests.append((name, bool(cond), detail))
    print(("OK  " if cond else "FAIL"), name, detail)


T("plain number", abs(ns["evaluate_seed_expression_at_time"]("432", 0.0) - 432) < 1e-9)
T("list parse", ns["parse_seed_numeric_list"]("10, 20, 30") == [10.0, 20.0, 30.0])
T("sin(t)@0", abs(ns["evaluate_seed_expression_at_time"]("sin(t) * 100", 0.0)) < 1e-6)
T(
    "sin(t)@pi/2",
    abs(ns["evaluate_seed_expression_at_time"]("sin(t) * 100", math.pi / 2) - 100) < 1e-6,
)
T("MEUM", abs(ns["evaluate_seed_expression_at_time"]("MEUM * 100", 0.0) - ns["MEUM"] * 100) < 1e-6)
T(
    "if/elif +",
    ns["evaluate_seed_expression_at_time"]("if(sin(t) >= 0) 111 elif 222", 0.1) == 111.0,
)
T(
    "if/elif -",
    ns["evaluate_seed_expression_at_time"]("if(sin(t) >= 0) 111 elif 222", 4.0) == 222.0,
)
T("lerp", abs(ns["evaluate_seed_expression_at_time"]("lerp(10, 20, 0.5)", 0.0) - 15) < 1e-9)
T("clamp", abs(ns["evaluate_seed_expression_at_time"]("clamp(999, 0, 50)", 0.0) - 50) < 1e-9)
T("return", abs(ns["evaluate_seed_expression_at_time"]("return 77", 0.0) - 77) < 1e-9)
T("isn", math.isfinite(ns["evaluate_seed_expression_at_time"]("isn(0)", 0.0)))
T(
    "canonical ctx",
    abs(ns["evaluate_seed_expression_at_time"]("canonical_count + 5", 0.0, {"canonical_count": 3}) - 8)
    < 1e-9,
)
T(
    "pitch diversity",
    ns["_seed_to_pitch_ratio"](7, 0, 0) != ns["_seed_to_pitch_ratio"](99, 0, 0),
)
T(
    "list t-sample",
    ns["evaluate_seed_expression_at_time"]("100, 200, 300", 0.0) == 100.0,
)
vals2 = ns["_eval_seed_python"]("sqrt(t-1)*100", t_value=2.0, allow_scrape=False)
T("domain retry", len(vals2) > 0 and vals2[0] > 0, vals2)
T("viable num", ns["seed_script_is_viable"]("256"))
T("viable expr", ns["seed_script_is_viable"]("sin(t)*10+MEUM"))
parts = ns["_split_seed_list_parts"]("lerp(1, 2, 0.5), 99")
T("paren split", len(parts) == 2 and "lerp" in parts[0], parts)

# Variables exposed to scripts
env = ns["_seed_script_env"](t_scalar=1.25, canonical_context={"canonical_unison": 1})
required = [
    "t", "x", "y", "z", "MEUM", "PHI", "pi", "e", "sin", "cos", "isn", "ics",
    "P", "E", "D", "clamp", "lerp", "choose", "canonical_unison",
]
missing = [k for k in required if k not in env]
T("env variables", not missing, missing or "all present")

failed = [t for t in tests if not t[1]]
print("---")
print(f"{len(tests) - len(failed)}/{len(tests)} passed")
sys.exit(1 if failed else 0)
