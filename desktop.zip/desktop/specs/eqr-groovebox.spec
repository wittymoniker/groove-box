# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec — EQR Groovebox (desktop Linux / Windows / macOS)
# Build on the TARGET OS:
#   pyinstaller specs/eqr-groovebox.spec
#
# One-dir is more reliable for Qt plugins than --onefile on some hosts;
# switch to onefile by setting EXE(..., exclude_binaries=False) patterns below.

import sys
from pathlib import Path

block_cipher = None
ROOT = Path(SPECPATH).resolve().parent  # specs/ -> project root
# When SPECPATH is specs/, parent is project root
if ROOT.name == "specs":
    ROOT = ROOT.parent

a = Analysis(
    [str(ROOT / "run_groovebox.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=[],
    hiddenimports=[
        "PyQt6",
        "PyQt6.QtCore",
        "PyQt6.QtGui",
        "PyQt6.QtWidgets",
        "numpy",
        "sounddevice",
        "scipy",
        "scipy.io",
        "scipy.io.wavfile",
        "groovebox",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter",
        "matplotlib",
        "pytest",
        "IPython",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# Collect Qt platform plugins (required for windowed apps)
try:
    from PyInstaller.utils.hooks import collect_all
    datas_qt, binaries_qt, hidden_qt = collect_all("PyQt6")
    a.datas += datas_qt
    a.binaries += binaries_qt
    a.hiddenimports += hidden_qt
except Exception as exc:
    print(f"[spec] collect_all(PyQt6) skipped: {exc}")

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="EQR-Groovebox",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # windowed GUI
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(ROOT / "assets" / "icon.ico") if (ROOT / "assets" / "icon.ico").exists() else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="EQR-Groovebox",
)

# macOS .app bundle (only meaningful when building on macOS)
if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="EQR-Groovebox.app",
        icon=str(ROOT / "assets" / "icon.icns") if (ROOT / "assets" / "icon.icns").exists() else None,
        bundle_identifier="com.eqr.groovebox",
        info_plist={
            "NSHighResolutionCapable": True,
            "NSMicrophoneUsageDescription": "Audio input for the groovebox engine.",
        },
    )
