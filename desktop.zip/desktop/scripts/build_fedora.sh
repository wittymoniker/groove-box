#!/usr/bin/env bash
# Fedora-oriented build: system packages + PyInstaller onedir
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if command -v dnf >/dev/null 2>&1; then
  echo "==> Installing Fedora build/runtime packages (needs sudo)"
  sudo dnf install -y \
    python3 python3-pip python3-devel \
    portaudio-devel alsa-lib-devel \
    mesa-libGL mesa-libEGL \
    ffmpeg \
    gcc gcc-c++ make \
    || true
else
  echo "==> dnf not found; install portaudio, ALSA, Mesa, ffmpeg manually"
fi

exec "$ROOT/scripts/build_linux.sh"
