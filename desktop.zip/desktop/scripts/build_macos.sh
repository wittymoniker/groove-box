#!/usr/bin/env bash
# Build EQR Groovebox on macOS (run on a Mac with Xcode CLT)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PYTHON="${PYTHON:-python3}"
VENV="${VENV:-$ROOT/.venv-build}"

echo "==> Creating venv at $VENV"
$PYTHON -m venv "$VENV"
# shellcheck disable=SC1091
source "$VENV/bin/activate"
pip install -U pip wheel
pip install -r requirements.txt -r requirements-build.txt

echo "==> PyInstaller (onedir + .app when on Darwin)"
pyinstaller --noconfirm --clean specs/eqr-groovebox.spec

echo "==> Output under dist/"
echo "    For distribution outside your Mac: codesign + notarize the .app"
echo "    Example (replace identity):"
echo "      codesign --deep --force --options runtime --sign \"Developer ID Application: …\" dist/EQR-Groovebox.app"
echo "    Video export needs ffmpeg (brew install ffmpeg)."
