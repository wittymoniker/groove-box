# Build EQR Groovebox on Windows (run in PowerShell on a Windows host)
# Requires: Python 3.10+, pip, Visual C++ redistributable at runtime
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

$Python = if ($env:PYTHON) { $env:PYTHON } else { "python" }
$Venv = Join-Path $Root ".venv-build"

Write-Host "==> Creating venv at $Venv"
& $Python -m venv $Venv
& "$Venv\Scripts\Activate.ps1"
pip install -U pip wheel
pip install -r requirements.txt -r requirements-build.txt

Write-Host "==> PyInstaller (onedir)"
pyinstaller --noconfirm --clean specs\eqr-groovebox.spec

Write-Host "==> Output: $Root\dist\EQR-Groovebox\EQR-Groovebox.exe"
Write-Host "    Ship the entire dist\EQR-Groovebox folder (Qt plugins included)."
Write-Host "    Optional: install ffmpeg and place ffmpeg.exe on PATH for video export."
