#!/usr/bin/env bash
# Build EQR Groovebox for Linux (Fedora / Ubuntu / generic)
# Run on the Linux machine that will own the binary.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PYTHON="${PYTHON:-python3}"
VENV="${VENV:-$ROOT/.venv-build}"

echo "==> Creating venv at $VENV"
$PYTHON -m venv "$VENV"
# shellcheck disable=SC1091
source "$VENV/bin/activate"
pip install -U pip wheel
pip install -r requirements.txt -r requirements-build.txt

echo "==> PyInstaller (onedir)"
pyinstaller --noconfirm --clean specs/eqr-groovebox.spec

OUT="$ROOT/dist/EQR-Groovebox"
echo "==> Output: $OUT"
echo "    Launch: $OUT/EQR-Groovebox"
echo "    System deps often needed: portaudio (libportaudio), ALSA/Pulse, libGL, ffmpeg (video export)"

# Optional AppImage skeleton note
if command -v appimagetool >/dev/null 2>&1; then
  echo "==> appimagetool found — you can wrap dist/ into an AppImage separately"
else
  echo "==> Tip: install appimagetool to produce a portable AppImage for Fedora+"
fi
