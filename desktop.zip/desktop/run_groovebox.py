#!/usr/bin/env python3
"""Entry point for EQR Groovebox (PyInstaller / desktop launchers)."""
from __future__ import annotations

import sys


def main() -> int:
    from PyQt6.QtWidgets import QApplication
    # Import after QApplication-friendly path setup
    from groovebox import MathematiciansGrooveboxApp

    app = QApplication(sys.argv)
    player = MathematiciansGrooveboxApp()
    player.show()
    return int(app.exec())


if __name__ == "__main__":
    raise SystemExit(main())
