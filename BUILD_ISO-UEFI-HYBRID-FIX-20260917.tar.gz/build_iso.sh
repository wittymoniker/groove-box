#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${1:-$ROOT/dist/sOS-Groovebox-UEFI-HYBRID-x86_64.iso}"
OUT_DIR="$(dirname "$OUT")"
VALIDATOR="$ROOT/scripts/validate_iso.py"
VOLID="GROOVEBOX_SOS"

BUILD_USER="${SUDO_USER:-${USER:-$(id -un)}}"
BUILD_GROUP="$(id -gn "$BUILD_USER" 2>/dev/null || printf '%s' "$BUILD_USER")"

log() { printf '[sOS ISO] %s\n' "$*"; }
die() { printf '[sOS ISO] ERROR: %s\n' "$*" >&2; exit 1; }

GRUB_RESCUE=""
if command -v grub2-mkrescue >/dev/null 2>&1; then
    GRUB_RESCUE="$(command -v grub2-mkrescue)"
elif command -v grub-mkrescue >/dev/null 2>&1; then
    GRUB_RESCUE="$(command -v grub-mkrescue)"
fi

platform_dir() {
    local platform="$1" d
    for d in /usr/lib/grub/$platform /usr/lib/grub2/$platform /usr/share/grub/$platform; do
        [[ -d "$d" ]] && { printf '%s\n' "$d"; return 0; }
    done
    return 1
}

BIOS_DIR="$(platform_dir i386-pc || true)"
EFI_DIR="$(platform_dir x86_64-efi || true)"

if [[ -z "$GRUB_RESCUE" ]] || ! command -v xorriso >/dev/null 2>&1 || ! command -v python3 >/dev/null 2>&1 \
   || [[ -z "$BIOS_DIR" ]] || [[ -z "$EFI_DIR" ]]; then
    cat >&2 <<MSG
[sOS ISO] Missing host components for a *dual-firmware hybrid* ISO.
[sOS ISO]
[sOS ISO] Required:
[sOS ISO]   grub-mkrescue/grub2-mkrescue
[sOS ISO]   GRUB i386-pc modules         (legacy BIOS)
[sOS ISO]   GRUB x86_64-efi modules      (UEFI)
[sOS ISO]   xorriso, python3
[sOS ISO]
[sOS ISO] Fedora:
[sOS ISO]   sudo dnf install -y grub2-tools-extra grub2-pc-modules grub2-efi-x64-modules xorriso mtools dosfstools
[sOS ISO]
[sOS ISO] Debian/Ubuntu:
[sOS ISO]   sudo apt install -y grub-common grub-pc-bin grub-efi-amd64-bin xorriso mtools dosfstools
[sOS ISO]
[sOS ISO] The build intentionally aborts rather than silently creating another BIOS-only ISO.
MSG
    exit 2
fi

[[ -d "$ROOT/iso-root" ]] || die "Missing ISO tree: $ROOT/iso-root"
[[ -f "$ROOT/iso-root/boot/vmlinuz" ]] || die "Missing kernel: iso-root/boot/vmlinuz"
[[ -f "$ROOT/iso-root/boot/initramfs.img" ]] || die "Missing initramfs: iso-root/boot/initramfs.img"
[[ -f "$ROOT/iso-root/boot/grub/grub.cfg" ]] || die "Missing GRUB config: iso-root/boot/grub/grub.cfg"
[[ -x "$VALIDATOR" || -f "$VALIDATOR" ]] || die "Missing validator: $VALIDATOR"

grep -Fq '/boot/vmlinuz' "$ROOT/iso-root/boot/grub/grub.cfg" || die "grub.cfg does not reference /boot/vmlinuz"
grep -Fq '/boot/initramfs.img' "$ROOT/iso-root/boot/grub/grub.cfg" || die "grub.cfg does not reference /boot/initramfs.img"

mkdir -p "$OUT_DIR" 2>/dev/null || true
case "$OUT_DIR/" in
    "$ROOT"/*)
        if [[ ! -w "$OUT_DIR" ]]; then
            log "Repairing output ownership for $BUILD_USER"
            if [[ $EUID -eq 0 ]]; then
                chown -R "$BUILD_USER:$BUILD_GROUP" "$OUT_DIR"
            elif command -v sudo >/dev/null 2>&1; then
                sudo chown -R "$BUILD_USER:$BUILD_GROUP" "$OUT_DIR"
            else
                die "$OUT_DIR is not writable and sudo is unavailable"
            fi
        fi
        ;;
    *)
        [[ -d "$OUT_DIR" ]] || mkdir -p "$OUT_DIR"
        [[ -w "$OUT_DIR" ]] || die "Output directory is not writable: $OUT_DIR"
        ;;
esac

# Generate build metadata from the payload actually being shipped. This prevents
# the stale BUILD.TXT hashes that were present in the previous appliance ISO.
KERNEL_SHA="$(sha256sum "$ROOT/iso-root/boot/vmlinuz" | awk '{print $1}')"
INITRAMFS_SHA="$(sha256sum "$ROOT/iso-root/boot/initramfs.img" | awk '{print $1}')"
GRUBCFG_SHA="$(sha256sum "$ROOT/iso-root/boot/grub/grub.cfg" | awk '{print $1}')"
BUILD_UTC="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
cat > "$ROOT/iso-root/BUILD.TXT" <<EOF
Mathematician's Groovebox / sOS ISO
Build: UEFI_HYBRID_RELEASE
Built UTC: $BUILD_UTC
Firmware: legacy BIOS + x86-64 UEFI
USB layout: MBR + GPT + EFI System Partition required
Secure Boot: unsigned development/release image; disable Secure Boot
Kernel SHA256: $KERNEL_SHA
Initramfs SHA256: $INITRAMFS_SHA
GRUB config SHA256: $GRUBCFG_SHA
EOF

cat > "$ROOT/iso-root/README.TXT" <<'EOF'
Mathematician's Groovebox / sOS x86-64 appliance

This image is built as a dual-firmware raw-USB hybrid:
  - legacy BIOS El Torito boot
  - x86-64 UEFI El Torito boot
  - MBR + GPT system area
  - EFI System Partition for UEFI USB boot

USB: write the ISO as an image (Fedora Media Writer, GNOME Disks, Rufus DD mode,
or scripts/write_usb.sh). Do not copy the .iso file onto a formatted USB drive.

Secure Boot: disable it for this unsigned build.

Boot modes: Live, Install, Recovery, Safe Mode.
EOF

for stale in "$OUT" "$OUT.sha256" "$OUT.validation.txt"; do
    if [[ -e "$stale" || -L "$stale" ]]; then
        rm -f -- "$stale" 2>/dev/null || {
            if [[ $stale == "$ROOT"/* ]] && command -v sudo >/dev/null 2>&1; then
                sudo rm -f -- "$stale"
            else
                die "Cannot remove stale artifact: $stale"
            fi
        }
    fi
done

PROBE="$OUT_DIR/.sos-write-test.$$"
: > "$PROBE" 2>/dev/null || die "Cannot write to $OUT_DIR"
rm -f "$PROBE"

TMP_OUT="$OUT.partial.$$"
TMP_REPORT="$OUT.validation.partial.$$"
cleanup() { rm -f -- "$TMP_OUT" "$TMP_REPORT" 2>/dev/null || true; }
trap cleanup EXIT INT TERM

log "BIOS GRUB modules: $BIOS_DIR"
log "UEFI GRUB modules: $EFI_DIR"
log "Building: $TMP_OUT"

# grub-mkrescue includes every installed GRUB target. Requiring both module
# directories above prevents the old silent BIOS-only output. -V is passed
# through to xorriso in mkisofs-emulation mode.
"$GRUB_RESCUE" -o "$TMP_OUT" -V "$VOLID" "$ROOT/iso-root"
[[ -s "$TMP_OUT" ]] || die "grub-mkrescue returned without a non-empty ISO"

log "Running release-blocking structural validation"
if ! python3 "$VALIDATOR" "$TMP_OUT" > "$TMP_REPORT"; then
    cat "$TMP_REPORT" >&2 || true
    die "ISO failed BIOS+UEFI+MBR+GPT+ESP validation; refusing to publish it"
fi

{
    printf '\n--- xorriso El Torito report ---\n'
    xorriso -indev "$TMP_OUT" -report_el_torito plain 2>&1 || true
    printf '\n--- xorriso system area report ---\n'
    xorriso -indev "$TMP_OUT" -report_system_area plain 2>&1 || true
} >> "$TMP_REPORT"

mv -f "$TMP_OUT" "$OUT"
mv -f "$TMP_REPORT" "$OUT.validation.txt"
sha256sum "$OUT" > "$OUT.sha256"

if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    chown "$BUILD_USER:$BUILD_GROUP" "$OUT" "$OUT.sha256" "$OUT.validation.txt" 2>/dev/null || true
fi
trap - EXIT INT TERM

log "PASS: BIOS + UEFI + raw-USB hybrid validation"
log "Built: $OUT"
log "SHA-256: $(awk '{print $1}' "$OUT.sha256")"
log "Validation: $OUT.validation.txt"
