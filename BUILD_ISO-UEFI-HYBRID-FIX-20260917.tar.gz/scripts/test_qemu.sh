#!/usr/bin/env bash
set -euo pipefail

MODE=both
if [[ ${1:-} == --bios-only ]]; then MODE=bios; shift; fi
if [[ ${1:-} == --uefi-only ]]; then MODE=uefi; shift; fi
[[ $# -eq 1 ]] || { echo "Usage: $0 [--bios-only|--uefi-only] IMAGE.iso" >&2; exit 2; }
ISO="$(readlink -f "$1")"
[[ -f "$ISO" ]] || { echo "ISO not found: $ISO" >&2; exit 2; }
command -v qemu-system-x86_64 >/dev/null 2>&1 || { echo "qemu-system-x86_64 is required" >&2; exit 3; }

find_ovmf() {
  local f
  for f in \
    /usr/share/edk2/ovmf/OVMF_CODE.fd \
    /usr/share/edk2/ovmf/OVMF_CODE_4M.fd \
    /usr/share/OVMF/OVMF_CODE.fd \
    /usr/share/OVMF/OVMF_CODE_4M.fd; do
    [[ -f "$f" ]] && { printf '%s\n' "$f"; return 0; }
  done
  return 1
}

COMMON=(-m 2048 -boot d -cdrom "$ISO" -no-reboot)
if [[ "$MODE" == bios || "$MODE" == both ]]; then
  echo "Starting legacy BIOS test. Close QEMU after the Groovebox/sOS boot menu appears."
  qemu-system-x86_64 "${COMMON[@]}"
fi
if [[ "$MODE" == uefi || "$MODE" == both ]]; then
  OVMF="$(find_ovmf || true)"
  if [[ -z "$OVMF" ]]; then
    echo "OVMF not found; cannot test UEFI." >&2
    echo "Fedora: sudo dnf install -y edk2-ovmf" >&2
    echo "Debian/Ubuntu: sudo apt install -y ovmf" >&2
    exit 4
  fi
  echo "Starting UEFI test with $OVMF. Close QEMU after the Groovebox/sOS boot menu appears."
  qemu-system-x86_64 "${COMMON[@]}" -bios "$OVMF"
fi
