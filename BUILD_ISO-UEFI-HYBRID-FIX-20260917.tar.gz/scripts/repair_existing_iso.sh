#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
VALIDATOR="$HERE/validate_iso.py"

usage() {
  cat <<'EOF'
Usage:
  scripts/repair_existing_iso.sh OLD.iso [NEW.iso]

Rebuilds the payload from an older Groovebox/sOS ISO through the corrected
BIOS+UEFI hybrid builder. This is intended for the earlier BIOS-only appliance
images. It does not modify the source ISO.
EOF
}

[[ $# -ge 1 && $# -le 2 ]] || { usage; exit 2; }
SRC="$(readlink -f "$1")"
[[ -f "$SRC" ]] || { echo "missing source ISO: $SRC" >&2; exit 2; }
OUT="${2:-$ROOT/dist/$(basename "${SRC%.iso}")-UEFI-HYBRID.iso}"

command -v xorriso >/dev/null 2>&1 || {
  echo "xorriso is required to extract the old ISO" >&2
  exit 3
}
[[ -x "$ROOT/build_iso.sh" ]] || { echo "missing $ROOT/build_iso.sh" >&2; exit 3; }

TMP="$(mktemp -d -t sos-iso-repair.XXXXXX)"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT INT TERM
mkdir -p "$TMP/extracted" "$TMP/normalized/boot/grub"

# Keep a diagnostic of the old image. Failure is expected for BIOS-only media.
python3 "$VALIDATOR" "$SRC" > "$TMP/old-validation.txt" 2>&1 || true

xorriso -osirrox on -indev "$SRC" -extract / "$TMP/extracted" >/dev/null 2>&1

find_one() {
  local pattern="$1"
  find "$TMP/extracted" -type f -iname "$pattern" -print -quit
}
VMLINUX="$(find_one 'vmlinuz*')"
INITRAMFS="$(find_one 'initramf*.img*')"
GRUBCFG="$(find_one 'grub.cfg*')"
[[ -n "$VMLINUX" && -f "$VMLINUX" ]] || { echo "could not locate vmlinuz in old ISO" >&2; exit 4; }
[[ -n "$INITRAMFS" && -f "$INITRAMFS" ]] || { echo "could not locate initramfs image in old ISO" >&2; exit 4; }
[[ -n "$GRUBCFG" && -f "$GRUBCFG" ]] || { echo "could not locate grub.cfg in old ISO" >&2; exit 4; }

cp -f "$VMLINUX" "$TMP/normalized/boot/vmlinuz"
cp -f "$INITRAMFS" "$TMP/normalized/boot/initramfs.img"
cp -f "$GRUBCFG" "$TMP/normalized/boot/grub/grub.cfg"

# Reuse this package's corrected builder while pointing it at a temporary tree.
REPAIR_ROOT="$TMP/rebuilder"
mkdir -p "$REPAIR_ROOT/scripts" "$REPAIR_ROOT/dist"
cp -a "$TMP/normalized/." "$REPAIR_ROOT/iso-root/"
cp -f "$ROOT/build_iso.sh" "$REPAIR_ROOT/build_iso.sh"
cp -f "$VALIDATOR" "$REPAIR_ROOT/scripts/validate_iso.py"
chmod +x "$REPAIR_ROOT/build_iso.sh" "$REPAIR_ROOT/scripts/validate_iso.py"

"$REPAIR_ROOT/build_iso.sh" "$(readlink -m "$OUT")"

echo
cat "$TMP/old-validation.txt"
echo
echo "Repaired image: $OUT"
echo "The source ISO was left unchanged."
