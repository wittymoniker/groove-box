#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 IMAGE.iso /dev/sdX" >&2
  exit 2
fi
ISO="$(readlink -f "$1")"
DEV="$2"
[[ -f "$ISO" ]] || { echo "ISO not found: $ISO" >&2; exit 2; }
[[ -b "$DEV" ]] || { echo "Target is not a block device: $DEV" >&2; exit 2; }

TYPE="$(lsblk -dn -o TYPE "$DEV" 2>/dev/null || true)"
[[ "$TYPE" == disk ]] || { echo "Refusing to write to non-disk device: $DEV ($TYPE)" >&2; exit 3; }

ROOTSRC="$(findmnt -n -o SOURCE / 2>/dev/null || true)"
ROOTDISK=""
if [[ -n "$ROOTSRC" ]]; then
  PK="$(lsblk -no PKNAME "$ROOTSRC" 2>/dev/null | head -n1 || true)"
  [[ -n "$PK" ]] && ROOTDISK="/dev/$PK"
fi
if [[ -n "$ROOTDISK" && "$DEV" == "$ROOTDISK" ]]; then
  echo "Refusing to overwrite the disk that contains the running root filesystem: $DEV" >&2
  exit 4
fi

printf 'About to ERASE and image %s with:\n  %s\n\n' "$DEV" "$ISO"
lsblk -o NAME,MODEL,SIZE,TYPE,MOUNTPOINTS "$DEV" || true
printf '\nType exactly: WRITE %s\n> ' "$DEV"
read -r CONFIRM
[[ "$CONFIRM" == "WRITE $DEV" ]] || { echo "Cancelled."; exit 1; }

while read -r p; do
  [[ -n "$p" ]] && sudo umount "$p" 2>/dev/null || true
done < <(lsblk -ln -o PATH "$DEV" | tail -n +2)

sudo dd if="$ISO" of="$DEV" bs=4M status=progress conv=fsync
sync
BYTES="$(stat -c '%s' "$ISO")"
echo "Verifying the written image..."
sudo cmp -n "$BYTES" "$ISO" "$DEV"
echo "PASS: USB matches ISO byte-for-byte for $BYTES bytes."
