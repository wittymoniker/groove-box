#!/usr/bin/env python3
"""Structural validator for Mathematician's Groovebox / sOS x86-64 ISO images.

Release images are required to be:
  * ISO9660 with a valid El Torito catalog
  * legacy BIOS bootable
  * x86-64 UEFI bootable (El Torito platform 0xEF)
  * raw-USB hybrid with an MBR and GPT
  * carrying a GPT EFI System Partition (ESP)

No third-party Python modules are required.
"""
from __future__ import annotations

import argparse
import json
import os
import struct
import sys
import uuid
from pathlib import Path

ISO_SECTOR = 2048
DISK_SECTOR = 512
ESP_GUID = uuid.UUID("c12a7328-f81f-11d2-ba4b-00a0c93ec93b")


def fail(msg: str) -> None:
    raise ValueError(msg)


def read_at(f, offset: int, size: int) -> bytes:
    f.seek(offset)
    data = f.read(size)
    if len(data) != size:
        fail(f"short read at byte {offset}: wanted {size}, got {len(data)}")
    return data


def parse_mbr(f):
    mbr = read_at(f, 0, DISK_SECTOR)
    sig = mbr[510:512] == b"\x55\xaa"
    parts = []
    for i in range(4):
        e = mbr[446 + 16 * i : 446 + 16 * (i + 1)]
        ptype = e[4]
        start = struct.unpack_from("<I", e, 8)[0]
        count = struct.unpack_from("<I", e, 12)[0]
        if ptype or start or count:
            parts.append({"index": i + 1, "type": ptype, "start_lba": start, "sectors": count})
    return sig, parts


def parse_gpt(f, file_size: int):
    try:
        hdr = read_at(f, DISK_SECTOR, DISK_SECTOR)
    except ValueError:
        return False, [], False
    if hdr[:8] != b"EFI PART":
        return False, [], False
    header_size = struct.unpack_from("<I", hdr, 12)[0]
    if not (92 <= header_size <= DISK_SECTOR):
        fail(f"invalid GPT header size: {header_size}")
    part_lba = struct.unpack_from("<Q", hdr, 72)[0]
    part_count = struct.unpack_from("<I", hdr, 80)[0]
    entry_size = struct.unpack_from("<I", hdr, 84)[0]
    if entry_size < 128 or entry_size > 4096:
        fail(f"invalid GPT partition-entry size: {entry_size}")
    # Bound reads on corrupt images.
    part_count = min(part_count, 1024)
    total = part_count * entry_size
    if part_lba * DISK_SECTOR + total > file_size:
        fail("GPT partition array extends beyond image")
    table = read_at(f, part_lba * DISK_SECTOR, total)
    parts = []
    esp = False
    for i in range(part_count):
        e = table[i * entry_size : (i + 1) * entry_size]
        type_raw = e[:16]
        if type_raw == b"\x00" * 16:
            continue
        type_guid = uuid.UUID(bytes_le=type_raw)
        first = struct.unpack_from("<Q", e, 32)[0]
        last = struct.unpack_from("<Q", e, 40)[0]
        if type_guid == ESP_GUID:
            esp = True
        parts.append({"index": i + 1, "type_guid": str(type_guid), "first_lba": first, "last_lba": last})
    return True, parts, esp


def parse_el_torito(f, file_size: int):
    pvd = None
    boot_record = None
    volume_id = None
    volume_blocks = None
    # Volume descriptors start at ISO sector 16 and end with type 255.
    for sector in range(16, 128):
        off = sector * ISO_SECTOR
        if off + ISO_SECTOR > file_size:
            break
        d = read_at(f, off, ISO_SECTOR)
        if d[1:6] != b"CD001":
            continue
        dtype = d[0]
        if dtype == 1 and pvd is None:
            pvd = d
            volume_id = d[40:72].decode("ascii", "replace").rstrip(" ")
            volume_blocks = struct.unpack_from("<I", d, 80)[0]
        elif dtype == 0 and d[7:39].rstrip(b" \x00") == b"EL TORITO SPECIFICATION":
            boot_record = d
        elif dtype == 255:
            break
    if pvd is None:
        fail("ISO9660 primary volume descriptor not found")
    if boot_record is None:
        fail("El Torito boot record not found")
    catalog_lba = struct.unpack_from("<I", boot_record, 71)[0]
    if not catalog_lba or catalog_lba * ISO_SECTOR + ISO_SECTOR > file_size:
        fail(f"invalid El Torito catalog LBA: {catalog_lba}")
    cat = read_at(f, catalog_lba * ISO_SECTOR, ISO_SECTOR)
    validation = cat[:32]
    if validation[0] != 0x01:
        fail("El Torito validation entry header is invalid")
    if validation[30:32] != b"\x55\xaa":
        fail("El Torito validation entry signature is invalid")
    checksum = sum(struct.unpack("<16H", validation)) & 0xFFFF
    if checksum != 0:
        fail("El Torito validation entry checksum is invalid")

    platforms = set()
    entries = []
    default_platform = validation[1]
    initial = cat[32:64]
    if initial[0] == 0x88:
        platforms.add(default_platform)
        entries.append({"platform": default_platform, "bootable": True, "lba": struct.unpack_from("<I", initial, 8)[0]})

    pos = 64
    while pos + 32 <= len(cat):
        rec = cat[pos:pos + 32]
        if rec == b"\x00" * 32:
            break
        kind = rec[0]
        if kind in (0x90, 0x91):
            platform = rec[1]
            count = rec[2]
            pos += 32
            for _ in range(count):
                if pos + 32 > len(cat):
                    break
                ent = cat[pos:pos + 32]
                if ent[0] == 0x88:
                    platforms.add(platform)
                    entries.append({"platform": platform, "bootable": True, "lba": struct.unpack_from("<I", ent, 8)[0]})
                pos += 32
            if kind == 0x91:
                break
            continue
        pos += 32

    return {
        "volume_id": volume_id,
        "volume_blocks": volume_blocks,
        "catalog_lba": catalog_lba,
        "platforms": sorted(platforms),
        "entries": entries,
    }


def inspect(path: Path):
    size = path.stat().st_size
    if size < 20 * ISO_SECTOR:
        fail("file is too small to be an ISO image")
    with path.open("rb") as f:
        mbr_sig, mbr_parts = parse_mbr(f)
        gpt, gpt_parts, esp = parse_gpt(f, size)
        elt = parse_el_torito(f, size)
    declared = (elt["volume_blocks"] or 0) * ISO_SECTOR
    return {
        "path": str(path),
        "bytes": size,
        "volume_id": elt["volume_id"],
        "iso9660_extent_within_file": bool(declared and declared <= size),
        "el_torito_catalog_lba": elt["catalog_lba"],
        "el_torito_platform_ids": [f"0x{x:02x}" for x in elt["platforms"]],
        "bios_boot": 0x00 in elt["platforms"],
        "uefi_x86_64_boot": 0xEF in elt["platforms"],
        "mbr_signature": mbr_sig,
        "mbr_partitions": mbr_parts,
        "gpt": gpt,
        "gpt_partitions": gpt_parts,
        "efi_system_partition": esp,
        "raw_usb_hybrid": bool(mbr_sig and mbr_parts and gpt and esp),
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("iso", type=Path)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--no-require-hybrid", action="store_true", help="diagnostic only; release builds must not use this")
    args = ap.parse_args(argv)

    try:
        r = inspect(args.iso)
    except (OSError, ValueError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 2

    required = {
        "ISO9660 extent": r["iso9660_extent_within_file"],
        "Legacy BIOS El Torito": r["bios_boot"],
        "x86-64 UEFI El Torito": r["uefi_x86_64_boot"],
    }
    if not args.no_require_hybrid:
        required.update({
            "MBR system area": r["mbr_signature"] and bool(r["mbr_partitions"]),
            "GPT system area": r["gpt"],
            "EFI System Partition": r["efi_system_partition"],
            "raw USB hybrid": r["raw_usb_hybrid"],
        })

    if args.json:
        r["release_valid"] = all(required.values())
        print(json.dumps(r, indent=2, sort_keys=True))
    else:
        print(f"ISO: {r['path']}")
        print(f"Volume ID: {r['volume_id'] or '(blank)'}")
        print(f"El Torito platforms: {', '.join(r['el_torito_platform_ids']) or '(none)'}")
        for name, ok in required.items():
            print(f"{'PASS' if ok else 'FAIL'}: {name}")
        if not r["mbr_signature"]:
            print("INFO: no valid MBR signature/system-area partition table")
        if not r["gpt"]:
            print("INFO: no GPT header at 512-byte LBA 1")
        if r["gpt"] and not r["efi_system_partition"]:
            print("INFO: GPT exists but no EFI System Partition was found")

    return 0 if all(required.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
