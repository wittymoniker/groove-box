# Groovebox / sOS ISO boot compatibility — 2026-09-17

This update fixes the appliance-image layer. The Groovebox application/audio/video/canonical code is not changed by this patch.

## Problems found in the previous x86-64 appliance ISO

The actual `sOS-Groovebox-sCode-FULL-COMPAT-x86_64-20260913.iso` was inspected structurally.

- The El Torito catalog contained only platform `0x00` (legacy BIOS).
- There was no x86-64 EFI (`0xEF`) El Torito boot entry.
- The first disk sector had no valid MBR partition table/signature.
- There was no GPT header and no EFI System Partition.
- Therefore the ISO was not a raw-USB UEFI hybrid image. Fedora Media Writer correctly copied it, but modern UEFI firmware such as the Latitude 3510 had no UEFI USB target to list.
- `BUILD.TXT` was stale: it described an older initramfs hash rather than the initramfs actually present in the current ISO.
- Earlier validation retained the old El Torito catalog byte-for-byte, so it could report the old BIOS boot catalog as preserved without proving UEFI support.
- The old ISO9660 namespace also stored the initramfs under an 8.3-style `INITRAMF.IMG` record while the GRUB configuration referred to `/boot/initramfs.img`. The corrected build stages the real long filename and rebuilds the ISO through GRUB/xorriso rather than carrying forward the old hand-built directory/catalog layout.

See `OLD_ISO_STRUCTURAL_REPORT.json` for the machine-readable diagnosis.

## Corrected release requirements

Every release ISO built by the new `build_iso.sh` must pass all of these gates or the builder refuses to publish it:

- valid ISO9660 primary volume descriptor;
- legacy BIOS El Torito entry (`0x00`);
- x86-64 UEFI El Torito entry (`0xEF`);
- valid MBR system area;
- valid GPT system area;
- GPT EFI System Partition;
- raw-USB hybrid status;
- kernel and initramfs paths referenced by `grub.cfg` actually staged before the build;
- fresh `BUILD.TXT` hashes generated from the exact staged payload.

The build now explicitly requires both GRUB platform module sets. If the host only has BIOS GRUB modules, it stops instead of silently creating another BIOS-only image.

## Fedora build host

Install the build-side requirements:

```bash
sudo dnf install -y grub2-tools-extra grub2-pc-modules grub2-efi-x64-modules xorriso mtools dosfstools
```

For optional UEFI QEMU testing:

```bash
sudo dnf install -y qemu-system-x86 edk2-ovmf
```

Then run:

```bash
./build_iso.sh
```

or for the full game-ready/rootfs path:

```bash
sudo ./BUILD_GAME_READY_ISO.sh --profile game-ready
```

The builder writes three release artifacts next to the ISO:

- the `.iso`;
- `.iso.sha256`;
- `.iso.validation.txt`.

## USB writing

Fedora Media Writer remains valid. You can also use:

```bash
./scripts/write_usb.sh dist/sOS-Groovebox-UEFI-HYBRID-x86_64.iso /dev/sdX
```

The script refuses partition targets/root disks, asks for an exact destructive confirmation, writes with `dd`, and verifies the image bytes afterward.

## Secure Boot

This development/release image is not claimed to be Secure-Boot-signed. Disable Secure Boot in firmware when booting it. UEFI support and Secure Boot signing are separate issues.
