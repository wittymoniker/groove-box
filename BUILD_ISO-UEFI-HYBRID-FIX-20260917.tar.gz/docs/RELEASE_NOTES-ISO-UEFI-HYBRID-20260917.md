# ISO / UEFI hybrid fix — 2026-09-17

Affected layer: Groovebox/sOS appliance packaging and ISO build/test/release tooling.

Unchanged layer: Groovebox application behavior and its canonical/audio/video engine.

## Changes

- Added a hard requirement for both `i386-pc` and `x86_64-efi` GRUB modules.
- Added BIOS + UEFI + MBR + GPT + EFI-System-Partition structural validation.
- Changed the build to create a temporary candidate, validate it, and only then publish/rename it to the requested output path.
- Added generated build metadata so `BUILD.TXT` always matches the exact kernel/initramfs/GRUB configuration in the image.
- Added a normalized UEFI-safe GRUB configuration that searches for the actual `/boot/vmlinuz` payload before loading it.
- Added an existing-ISO repair path that extracts the payload and rebuilds it with the corrected builder.
- Added safer raw USB writer with post-write verification.
- Added separate BIOS and OVMF/UEFI QEMU test paths.
- Added a dependency message for Fedora and Debian/Ubuntu that includes the missing EFI GRUB module packages.

## Release rule

A BIOS-only ISO, an EFI-only ISO, or an image without a raw-USB hybrid system area is now considered a failed build and is not published.
