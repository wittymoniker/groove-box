# BUILD_ISO — BIOS + UEFI raw-USB hybrid fix

This kit contains the boot payload extracted from the latest appliance ISO that was being used (`sOS-Groovebox-sCode-FULL-COMPAT-x86_64-20260913.iso`) and the corrected ISO build toolchain.

It intentionally does **not** contain a prebuilt `APPLIANCE_ISO` file. Run the builder on Fedora/Debian/Ubuntu to produce the corrected ISO.

## Fedora

```bash
sudo dnf install -y grub2-tools-extra grub2-pc-modules grub2-efi-x64-modules xorriso mtools dosfstools
./build_iso.sh
```

The completed image must pass BIOS + UEFI + MBR + GPT + EFI System Partition validation before the script publishes it.

Output defaults to:

```text
dist/sOS-Groovebox-UEFI-HYBRID-x86_64.iso
```

Use Fedora Media Writer normally, or use `scripts/write_usb.sh` for a destructive command-line writer with byte verification.

Secure Boot should be disabled for this unsigned image.
