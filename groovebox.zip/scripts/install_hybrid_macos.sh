#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "=== Groovebox Hybrid installer (macOS) ==="

if [ -f ./install_deps_macos.sh ]; then bash ./install_deps_macos.sh || true; fi
python3 -m pip install --user -U pip numpy scipy sounddevice Pillow PyQt6 juliacall

export PATH="${HOME}/.juliaup/bin:${PATH:-}"
if ! command -v julia >/dev/null 2>&1; then
  curl -fsSL https://install.julialang.org | sh -s -- -y
  export PATH="${HOME}/.juliaup/bin:${PATH}"
  echo 'export PATH="$HOME/.juliaup/bin:$PATH"' >> "${HOME}/.zshrc"
fi
julia --project="$ROOT/julia" -e 'using Pkg; Pkg.instantiate(); using GrooveboxMeumOT; println("Julia kernel OK")'
echo "Done. Launch: ./bin/macos/groovebox_hybrid"
