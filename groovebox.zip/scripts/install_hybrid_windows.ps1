# Groovebox Hybrid installer (Windows)
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
Write-Host "=== Groovebox Hybrid installer (Windows) ==="

if (Test-Path .\install_deps_windows.ps1) { & .\install_deps_windows.ps1 }
python -m pip install --user -U pip numpy scipy sounddevice Pillow PyQt6 juliacall

$julia = Get-Command julia -ErrorAction SilentlyContinue
if (-not $julia) {
    Write-Host "Installing Julia via winget..."
    try { winget install --id Julialang.Juliaup -e --accept-source-agreements --accept-package-agreements } catch {}
    $env:Path = "$env:USERPROFILE\.juliaup\bin;$env:Path"
}

julia --project="$Root\julia" -e 'using Pkg; Pkg.instantiate(); using GrooveboxMeumOT; println("Julia kernel OK")'
Write-Host "Done. Launch: bin\windows\groovebox_hybrid.bat"
