#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/native"
MODE="${1:-canonical}"
case "$MODE" in
  canonical) FLAGS=(-std=c++17 -O3 -DNDEBUG -flto -fPIC -fvisibility=hidden) ;;
  performance) FLAGS=(-std=c++17 -O3 -DNDEBUG -flto -fPIC -fvisibility=hidden -march=native -mtune=native) ;;
  *) echo "Usage: $0 [canonical|performance]" >&2; exit 2 ;;
esac
c++ "${FLAGS[@]}" -dynamiclib "$ROOT/cpp/groovebox_accel.cpp" -o "$ROOT/native/libgroovebox_accel.dylib"
echo "Built native/libgroovebox_accel.dylib ($MODE)"
