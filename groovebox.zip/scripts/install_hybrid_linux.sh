#!/usr/bin/env bash
# Install Python deps + Julia + juliacall for Groovebox hybrid (Fedora/Ubuntu/Debian)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "=== Groovebox Hybrid installer (Linux) ==="

# System packages
if command -v dnf >/dev/null 2>&1; then
  sudo dnf install -y python3 python3-pip python3-devel curl 2>/dev/null || true
elif command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -qq
  sudo apt-get install -y -qq python3 python3-pip python3-venv curl 2>/dev/null || true
fi

# Groovebox Python deps (existing script if present)
if [ -f ./install_deps_linux.sh ]; then
  bash ./install_deps_linux.sh || true
fi

python3 -m pip install --user -U pip numpy scipy sounddevice Pillow PyQt6 juliacall 2>/dev/null || \
  python3 -m pip install -U pip numpy scipy sounddevice Pillow PyQt6 juliacall

# Julia
export PATH="${HOME}/.juliaup/bin:${PATH:-}"
if ! command -v julia >/dev/null 2>&1; then
  echo "Installing Julia (juliaup)..."
  curl -fsSL https://install.julialang.org | sh -s -- -y
  export PATH="${HOME}/.juliaup/bin:${PATH}"
  echo 'export PATH="$HOME/.juliaup/bin:$PATH"' >> "${HOME}/.bashrc"
fi
julia --version

# Activate Julia package
julia --project="$ROOT/julia" -e 'using Pkg; Pkg.instantiate(); using GrooveboxMeumOT; println("Julia kernel OK")'

echo ""
echo "Hybrid install complete."
echo "  Launch:  ./bin/linux-x86_64/groovebox_hybrid"
echo "  Or:      GROOVEBOX_JULIA=1 python3 run_groovebox.py"
echo "  Disable Julia: GROOVEBOX_JULIA=0 python3 run_groovebox.py"
