# Mathematician's Groovebox Deployment Kit

This kit turns a Groovebox source/build tree into a Linux appliance for tablets,
mini-PCs, and Raspberry Pi-class ARM64 systems.

## What is included

- `install_on_existing_linux.sh` — recommended universal installer for Debian,
  Ubuntu, Raspberry Pi OS, and closely related distributions.
- `builders/build_x86_64_live_iso.sh` — builds a bootable Debian Live x86_64 ISO
  containing Groovebox and the appliance installer.
- `builders/build_pi_image.sh` — builds/customizes a Raspberry Pi OS 64-bit image
  using Raspberry Pi's `rpi-image-gen` or `pi-gen` when available.
- `builders/build_arm64_uefi_iso.sh` — experimental generic ARM64 UEFI live ISO.
  ARM tablets are often device-specific; an ARM64 ISO cannot boot every Android
  tablet. Use a Linux-capable UEFI tablet or the existing-Linux installer.
- `make_payload.sh` — stages the current Groovebox project into the kit payload.
- `systemd/` — user/system services for appliance launch and optional auto-start.
- `desktop/` — desktop/menu and fullscreen launcher entries.
- `bin/groovebox-appliance` — architecture-aware launcher.
- `bin/groovebox-hardware-profile` — writes a JSON hardware profile.

## Recommended routes

### Mini-PC / x86_64 tablet

The most reliable path is to install Debian 13/Ubuntu on the device and then run:

```bash
sudo ./DEPLOYMENT_KIT/install_on_existing_linux.sh
```

For a bootable live/install ISO, on a Debian/Ubuntu build machine:

```bash
sudo ./DEPLOYMENT_KIT/builders/build_x86_64_live_iso.sh
```

The ISO is written to `DEPLOYMENT_KIT/out/`.

### Raspberry Pi 5 / ARM64 SBC

Fastest/reliable:
1. Flash Raspberry Pi OS 64-bit.
2. Copy the Groovebox project to the Pi.
3. Run `sudo ./DEPLOYMENT_KIT/install_on_existing_linux.sh`.

To produce a customized SD image instead:

```bash
sudo ./DEPLOYMENT_KIT/builders/build_pi_image.sh
```

### ARM64 Linux tablet

If the tablet exposes standard UEFI firmware, try:

```bash
sudo ./DEPLOYMENT_KIT/builders/build_arm64_uefi_iso.sh
```

Many Android tablets require a device-specific bootloader/kernel/device tree;
no universal ISO can safely cover those. On such hardware, use a supported Linux
port for that tablet first, then run `install_on_existing_linux.sh`.

## Appliance behavior

The installer creates `/opt/mathematicians-groovebox`, an isolated Python venv,
a `/usr/local/bin/groovebox-appliance` launcher, desktop entries, and an optional
systemd user auto-start unit. The launcher detects architecture, RAM, CPU count,
video/audio environment, and writes `~/.config/mathematicians-groovebox/machine_profile.json`.

Environment switches:

- `GROOVEBOX_FULLSCREEN=1` — start in fullscreen/appliance intent.
- `GROOVEBOX_PERFORMANCE=1` — prefer Performance UI intent.
- `GROOVEBOX_SAFE_PREVIEW=1` — conservative preview settings for low-memory hardware.
- `GROOVEBOX_AUDIO_FIRST=1` — preserve audio/event timing before visual quality.

The application can inspect these variables without changing canonical project data.

## Offline installs

Use `builders/make_wheelhouse.sh` on the SAME target architecture to download Python
wheels into `DEPLOYMENT_KIT/wheelhouse/`. Re-run the installer with that directory
present and it will prefer the local wheelhouse.


## GOAVA Radio responsive UI + LAN radio (2026-09-05)

- The configurable Radio identity header sits **above GLOBAL PROCESSOR CONTROLS**. Station name and logo are stored in Groovebox application data (`radio_identity.json` plus a copied `radio_logo.*`), so changing radio branding does not alter Program ID, Composition ID, or `.MG` artifact identity.
- GLOBAL PLAY remains red and LOCAL CONTEXT remains white, but the selector footprint is reduced by about 17% from the earlier oversized playtest control.
- PLAYLIST, RANDOMIZE, PHASE-LOCK and GOAVA are equal-footprint primary canonical controls designed to expand across the available row.
- Performance uses a softer rounded control palette and a vertical tab/navigation rail so tabs do not overflow the right margin.
- Performance → Live Broadcast can start **GOAVA LAN Radio**. The station serves a browser page and a continuous **192 kbps MP3** stream on TCP 8780; it cycles local project/render/sample audio and emits low-level 432-Hz-family bleeps when no suitable audio exists.
- Nearby Groovebox radios announce/listen over local UDP discovery; discovered station names and web URLs are shown in-app and on the station web page. Discovery works only across network segments that permit local broadcast; Wi-Fi radio range alone is not sufficient unless devices are associated with the same reachable LAN.
- For an appliance where `http://device/` is desired, `DEPLOYMENT_KIT/enable_radio_port80.sh` (installed as `groovebox-radio-port80`) can create a root-owned TCP/80 redirect to the unprivileged radio service. This avoids running the GUI as root.

## OS hardware dependency preflight

`DEPLOYMENT_KIT/bin/groovebox-hardware-preflight` reports Wi-Fi, Bluetooth, ALSA/PipeWire, MIDI, touch/input, USB, video/VLC and Python runtime readiness. `DEPLOYMENT_KIT/install_detected_hardware.sh` installs common host packages when Internet access is available and falls back to an offline report when it is not. The normal existing-Linux appliance installer invokes this best-effort preflight automatically.
