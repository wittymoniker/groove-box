#!/usr/bin/env bash
# Optional safe LAN redirect: public TCP/80 -> unprivileged GOAVA Radio TCP/8780.
set -euo pipefail
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then exec sudo "$0" "$@"; fi
PORT=${1:-8780}
if command -v nft >/dev/null 2>&1; then
  nft list table ip groovebox_radio >/dev/null 2>&1 || nft add table ip groovebox_radio
  nft list chain ip groovebox_radio prerouting >/dev/null 2>&1 || nft 'add chain ip groovebox_radio prerouting { type nat hook prerouting priority dstnat; policy accept; }'
  nft add rule ip groovebox_radio prerouting tcp dport 80 redirect to :$PORT 2>/dev/null || true
  echo "Port 80 redirects to GOAVA Radio :$PORT (nftables)."
elif command -v iptables >/dev/null 2>&1; then
  iptables -t nat -C PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports "$PORT" 2>/dev/null || iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports "$PORT"
  echo "Port 80 redirects to GOAVA Radio :$PORT (iptables)."
else
  echo 'Neither nft nor iptables is available.' >&2; exit 1
fi
