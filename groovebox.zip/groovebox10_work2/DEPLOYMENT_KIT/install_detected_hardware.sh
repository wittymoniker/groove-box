#!/usr/bin/env bash
# Detect common Groovebox hardware capability and install the host packages when online.
set -euo pipefail
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then exec sudo "$0" "$@"; fi
ONLINE=0
if command -v curl >/dev/null 2>&1 && curl -fsS --max-time 4 https://pypi.org/ >/dev/null 2>&1; then ONLINE=1; fi
if [[ $ONLINE -eq 0 ]]; then
  echo 'No usable Internet connection. Running offline hardware report only.'
  "$(dirname "$0")/bin/groovebox-hardware-preflight" || true
  exit 0
fi
if command -v apt-get >/dev/null 2>&1; then
  apt-get update
  apt-get install -y network-manager wireless-tools iw wpasupplicant rfkill bluez bluez-tools \
    alsa-utils pipewire pipewire-audio pipewire-pulse wireplumber pulseaudio-utils \
    libportaudio2 portaudio19-dev libsndfile1-dev libinput-tools evtest joystick \
    usbutils pciutils v4l-utils ffmpeg vlc curl ca-certificates python3-pip python3-venv
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y NetworkManager iw wireless-tools wpa_supplicant rfkill bluez bluez-tools \
    alsa-utils pipewire pipewire-alsa pipewire-pulseaudio wireplumber portaudio portaudio-devel \
    libsndfile libsndfile-devel libinput-utils evtest joystick-support usbutils pciutils v4l-utils ffmpeg vlc curl python3-pip || true
else
  echo 'Unsupported package manager; hardware report follows.'
fi
"$(dirname "$0")/bin/groovebox-hardware-preflight" || true
