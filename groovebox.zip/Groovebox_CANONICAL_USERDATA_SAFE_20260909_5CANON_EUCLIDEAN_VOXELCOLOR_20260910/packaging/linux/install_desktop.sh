#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
APPID=io.github.wittymoniker.MathematiciansGroovebox
PREFIX="${PREFIX:-$HOME/.local}"
APPROOT="$PREFIX/share/mathematicians-groovebox"
mkdir -p "$PREFIX/bin" "$PREFIX/share/applications" "$PREFIX/share/metainfo" "$PREFIX/share/mime/packages"
rm -rf "$APPROOT"
mkdir -p "$APPROOT"
# Install the self-contained source/runtime tree while excluding transient build products.
( cd "$ROOT" && tar --exclude='./.groovebox-build-venv' --exclude='./build' --exclude='./dist' --exclude='./__pycache__' --exclude='*.pyc' -cf - . ) | ( cd "$APPROOT" && tar -xf - )
cat > "$PREFIX/bin/mathematicians-groovebox" <<RUN
#!/usr/bin/env bash
exec python3 "$APPROOT/groovebox.py" "\$@"
RUN
chmod +x "$PREFIX/bin/mathematicians-groovebox"
install -m 0644 "$APPROOT/packaging/linux/$APPID.desktop" "$PREFIX/share/applications/$APPID.desktop"
install -m 0644 "$APPROOT/packaging/linux/$APPID.metainfo.xml" "$PREFIX/share/metainfo/$APPID.metainfo.xml"
install -m 0644 "$APPROOT/packaging/linux/application-x-mathematicians-groovebox.xml" "$PREFIX/share/mime/packages/$APPID.xml"
for s in 64 128 256 512; do
  d="$PREFIX/share/icons/hicolor/${s}x${s}/apps"; mkdir -p "$d"
  install -m 0644 "$APPROOT/packaging/linux/icons/hicolor/${s}x${s}/apps/$APPID.png" "$d/$APPID.png"
done
command -v update-mime-database >/dev/null && update-mime-database "$PREFIX/share/mime" || true
command -v update-desktop-database >/dev/null && update-desktop-database "$PREFIX/share/applications" || true
echo "Installed Groovebox under $APPROOT"
echo "Run: $PREFIX/bin/mathematicians-groovebox"
