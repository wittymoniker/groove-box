#!/usr/bin/env bash
set -euo pipefail
APPID=io.github.wittymoniker.MathematiciansGroovebox
PREFIX="${PREFIX:-$HOME/.local}"
rm -rf "$PREFIX/share/mathematicians-groovebox"
rm -f "$PREFIX/bin/mathematicians-groovebox" "$PREFIX/share/applications/$APPID.desktop" "$PREFIX/share/metainfo/$APPID.metainfo.xml" "$PREFIX/share/mime/packages/$APPID.xml"
for s in 64 128 256 512; do rm -f "$PREFIX/share/icons/hicolor/${s}x${s}/apps/$APPID.png"; done
command -v update-mime-database >/dev/null && update-mime-database "$PREFIX/share/mime" || true
command -v update-desktop-database >/dev/null && update-desktop-database "$PREFIX/share/applications" || true
