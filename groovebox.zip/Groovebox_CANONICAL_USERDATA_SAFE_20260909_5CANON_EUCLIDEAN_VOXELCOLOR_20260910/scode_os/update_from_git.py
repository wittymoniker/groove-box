#!/usr/bin/env python3
"""Transactional repository updater for a future sCode OS install.
Builds/tests a new commit in an immutable release dir, then atomically switches current.
No update occurs unless explicitly invoked by the user/admin.
"""
import argparse, json, os, subprocess, tempfile
from pathlib import Path

def run(cmd,cwd=None): return subprocess.run(cmd,cwd=cwd,check=True,text=True)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('config'); ap.add_argument('--remote',required=True); ap.add_argument('--activate',action='store_true'); a=ap.parse_args()
    cfg=json.loads(Path(a.config).read_text())
    root=Path(cfg['release_root']); root.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='scode-update-') as td:
        run(['git','clone','--filter=blob:none','--branch',cfg.get('branch','main'),'--',a.remote,td])
        commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=td,text=True).strip()
        dest=root/commit
        if not dest.exists():
            run(['cp','-a',td+'/.',str(dest)])
        for command in cfg.get('verify_tests',[]): run(['/bin/sh','-lc',command],cwd=dest)
        if a.activate:
            link=Path(cfg['active_link']); tmp=link.with_name(link.name+'.new')
            try: tmp.unlink()
            except FileNotFoundError: pass
            os.symlink(dest,tmp); os.replace(tmp,link)
        print(commit)
if __name__=='__main__': main()
