$ErrorActionPreference = 'Stop'
$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Kit

if (-not (Get-Command python -ErrorAction SilentlyContinue) -and -not (Get-Command py -ErrorAction SilentlyContinue)) {
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
  } else {
    throw 'Install Python 3.11 or 3.12, then rerun this script.'
  }
}
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -and (Get-Command winget -ErrorAction SilentlyContinue)) {
  winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
}
Set-Location $Root
if (Get-Command py -ErrorAction SilentlyContinue) { $Py = 'py'; $PyArgs = @('-3') } else { $Py = 'python'; $PyArgs = @() }
& $Py @PyArgs -m venv .groovebox-build-venv
$Vpy = Join-Path $Root '.groovebox-build-venv\Scripts\python.exe'
& $Vpy -m pip install --upgrade pip setuptools wheel
& $Vpy -m pip install -r requirements.txt
& $Vpy -m pip install 'pyinstaller>=6.10,<7'
& $Vpy "$Kit\build.py" --doctor
Write-Host "`nDependencies ready. Build with:`n  .\BUILD_KIT\build_windows.ps1 -Console"
Write-Host 'The C++ accelerator is optional. Install Visual Studio Build Tools C++ workload if you want it bundled.'
