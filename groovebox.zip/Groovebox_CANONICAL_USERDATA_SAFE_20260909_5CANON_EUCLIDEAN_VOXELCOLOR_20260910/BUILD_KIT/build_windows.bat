@echo off
setlocal
set "KIT=%~dp0"
cd /d "%KIT%.."
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%KIT%build.py" %*
) else (
  python "%KIT%build.py" %*
)
exit /b %errorlevel%
