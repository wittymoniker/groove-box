#!/usr/bin/env bash
set -Eeuo pipefail
KIT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$KIT/.." && pwd)"

if [[ -r /etc/os-release ]]; then . /etc/os-release; fi
FAMILY="${ID:-} ${ID_LIKE:-}"
if [[ "$FAMILY" == *fedora* || "$FAMILY" == *rhel* || "$FAMILY" == *centos* ]]; then
  sudo dnf install -y python3 python3-pip python3-devel gcc gcc-c++ ffmpeg ffmpeg-libs portaudio portaudio-devel alsa-lib-devel libffi-devel openssl-devel \
    pipewire wireplumber pipewire-alsa pipewire-pulseaudio mesa-dri-drivers mesa-vulkan-drivers \
    SDL2 SDL2_mixer openal-soft gamescope mpv qt6-qtwayland xorg-x11-server-Xwayland || true
elif [[ "$FAMILY" == *ubuntu* || "$FAMILY" == *debian* ]]; then
  sudo apt-get update
  sudo apt-get install -y python3 python3-pip python3-venv python3-dev build-essential ffmpeg mpv pipewire wireplumber \
    libportaudio2 portaudio19-dev libasound2-dev libffi-dev libssl-dev libsdl2-2.0-0 libsdl2-mixer-2.0-0 libopenal1
elif command -v pacman >/dev/null 2>&1; then
  sudo pacman -S --needed python python-pip gcc ffmpeg portaudio alsa-lib libffi openssl
else
  echo "Unsupported package manager. Install Python 3 + venv, a C++ compiler, FFmpeg, PortAudio and ALSA development libraries, then rerun the build."
  exit 3
fi

cd "$ROOT"
python3 -m venv .groovebox-build-venv
. .groovebox-build-venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip install 'pyinstaller>=6.10,<7'
python "$KIT/build.py" --doctor
printf '\nDependencies ready. Build with:\n  ./BUILD_KIT/build_linux.sh --console\n'
