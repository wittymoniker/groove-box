"""Deterministic sCode -> sIR compiler. sIR is JSON-safe and stable-hashable."""
from __future__ import annotations
from dataclasses import asdict
import hashlib, json
from .parser import parse_program

def _node(n):
    return {'kind':n.kind,'name':n.name,'args':list(n.args),'attrs':dict(sorted(n.attrs.items())),'children':[_node(c) for c in n.children]}

def compile_text(text):
    ir={'scode_ir_version':1,'radix':16,'nodes':[_node(n) for n in parse_program(text).nodes]}
    raw=json.dumps(ir,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')
    return ir, hashlib.sha256(raw).hexdigest()

def compile_file(path):
    from pathlib import Path
    p=Path(path); ir,digest=compile_text(p.read_text(encoding='utf-8'))
    ir['source']=p.name; ir['sha256']=digest
    return ir
