"""Capability-scoped local sCode agent base; no implicit shell/network authority."""
from __future__ import annotations
from dataclasses import dataclass, field
import json, subprocess
from pathlib import Path

@dataclass
class AgentPolicy:
    allowed: set[str]=field(default_factory=lambda:{'project.read','scode.compile','model.infer'})
    confirm: set[str]=field(default_factory=lambda:{'project.write','shell','network','git.push','model.train'})
    denied: set[str]=field(default_factory=lambda:{'credential.read','permission.bypass'})
    def decision(self,cap):
        if cap in self.denied: return 'deny'
        if cap in self.allowed: return 'allow'
        return 'confirm' if cap in self.confirm else 'deny'

class LocalLLM:
    """Thin backend for a local GGUF model via llama.cpp CLI; training stays a separate explicit capability."""
    def __init__(self, model_path, llama_cli='llama-cli'):
        self.model_path=str(model_path); self.llama_cli=llama_cli
    def infer(self,prompt,max_tokens=512):
        cmd=[self.llama_cli,'-m',self.model_path,'-p',prompt,'-n',str(int(max_tokens)),'--no-display-prompt']
        p=subprocess.run(cmd,capture_output=True,text=True,check=True)
        return p.stdout

class StudioAgent:
    def __init__(self, model, policy=None, audit_path='scode-agent-audit.jsonl'):
        self.model=model; self.policy=policy or AgentPolicy(); self.audit_path=Path(audit_path)
    def _audit(self,event):
        with self.audit_path.open('a',encoding='utf-8') as f: f.write(json.dumps(event,sort_keys=True)+'\n')
    def require(self,cap,approved=False):
        d=self.policy.decision(cap); self._audit({'capability':cap,'decision':d,'approved':bool(approved)})
        if d=='allow' or (d=='confirm' and approved): return
        raise PermissionError(f'agent capability {cap}: {d}')
    def ask(self,prompt):
        self.require('model.infer'); return self.model.infer(prompt)
