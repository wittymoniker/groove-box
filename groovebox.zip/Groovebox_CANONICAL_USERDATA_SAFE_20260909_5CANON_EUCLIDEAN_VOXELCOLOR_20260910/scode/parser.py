"""Small deterministic sCode parser. It parses declarations/blocks, never evals host code."""
from __future__ import annotations
from dataclasses import dataclass, field
import shlex

@dataclass
class Node:
    kind: str
    name: str=''
    args: list[str]=field(default_factory=list)
    attrs: dict[str,str]=field(default_factory=dict)
    children: list['Node']=field(default_factory=list)

@dataclass
class Program:
    nodes: list[Node]

def _strip_comment(line):
    quote=None
    for i,c in enumerate(line):
        if c in "\"'" and (i==0 or line[i-1] != '\\'):
            quote = None if quote==c else (c if quote is None else quote)
        if c=='#' and quote is None: return line[:i]
    return line

def parse_program(text: str) -> Program:
    root=[]; stack=[root]
    for lineno,raw in enumerate(text.splitlines(),1):
        line=_strip_comment(raw).strip()
        if not line: continue
        if line=='}':
            if len(stack)==1: raise SyntaxError(f'unmatched }} at line {lineno}')
            stack.pop(); continue
        opens=line.endswith('{')
        if opens: line=line[:-1].rstrip()
        toks=shlex.split(line,posix=True)
        if not toks: continue
        kind=toks.pop(0); name=''; attrs={}; args=[]
        if toks and '=' not in toks[0] and toks[0] not in {'on','off'}:
            name=toks.pop(0)
        for t in toks:
            if '=' in t:
                k,v=t.split('=',1); attrs[k]=v
            else: args.append(t)
        n=Node(kind,name,args,attrs,[]); stack[-1].append(n)
        if opens: stack.append(n.children)
    if len(stack)!=1: raise SyntaxError('unclosed sCode block')
    return Program(root)
