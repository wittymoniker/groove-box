param([ValidateSet('canonical','performance')][string]$Mode='canonical')
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
New-Item -ItemType Directory -Force "$Root\native" | Out-Null
$src = "$Root\cpp\groovebox_accel.cpp"
$out = "$Root\native\groovebox_accel.dll"
if ($Mode -eq 'performance') {
  Write-Host 'MSVC performance mode uses /O2; no /fp:fast is enabled.'
}
cl /std:c++17 /O2 /DNDEBUG /LD $src /Fe:$out
Write-Host "Built native/groovebox_accel.dll ($Mode)"
