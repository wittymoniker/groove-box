#!/usr/bin/env sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
"$root/scripts/check-source-purity.sh"
scode0=$($root/scripts/find-scode0.sh)
if [ ! -x "$scode0" ]; then
  echo "SKIP runtime tests: no stage-0 executable for this platform"
  exit 0
fi

run_test() {
  rel=$1
  echo "[sCode] $rel"
  "$scode0" run "$root/$rel"
}

run_test examples/hello.sC
run_test tests/math_kernel_test.sC
run_test tests/finite_grep_test.sC
run_test tests/hardware_modality_test.sC
run_test tests/logic_math_duality_test.sC
run_test tests/groovebox_optimizer_test.sC
run_test tests/pool_formats_test.sC
run_test tests/completion_policy_test.sC
run_test tests/groovebox_optimizer_abi7_test.sC
run_test tests/groovebox_optimizer_abi9_test.sC
run_test tests/symbol_plan_test.sC
compiler_out=$("$scode0" run "$root/tests/compiler_optimizer_test.sC")
echo "[sCode] tests/compiler_optimizer_test.sC"
printf '%s\n' "$compiler_out"
printf '%s\n' "$compiler_out" | grep -qx '103' || { echo "FAIL compiler optimizer dependency propagation" >&2; exit 1; }
printf '%s\n' "$compiler_out" | grep -qx '4' || { echo "FAIL compiler optimizer cost contract" >&2; exit 1; }
run_test tests/symbol_codec_test.sC
run_test tests/symbol_fraction_test.sC
run_test tests/native_groovebox/parity.sC

# ABI-9 optimizer must return a fully concrete host plan on the bundled stage-0.
out=$(GB_OPT_ID=123 GB_OPT_DIRTY=64 GB_OPT_FRAME=17 GB_OPT_LANES=8 GB_OPT_POOL=64 GB_OPT_SHAPE=33 GB_OPT_EDITING=1 GB_OPT_LOW_POWER=0 GB_OPT_BUDGET=999 GB_OPT_DEP_READY=1 \
  "$scode0" run "$root/apps/groovebox/groovebox_optimizer.sC")
printf '%s\n' "$out"
require_line() {
  printf '%s\n' "$out" | grep -qx "$1" || { echo "FAIL missing optimizer contract: $1" >&2; exit 1; }
}
require_line 'scode_optimizer_abi=9'
require_line 'pool_abi=3'
require_line 'pool_format_abi=1'
require_line 'pool_format_count=18'
require_line 'scheduler_abi=2'
require_line 'completion_abi=1'
require_line 'completion_policy_count=5'
require_line 'symbol_abi=4'
require_line 'dirty=103'
require_line 'run_audio=1'
require_line 'run_visual=1'
require_line 'run_game=1'
require_line 'run_canonical=1'
require_line 'symbol_variant_count=5188'
require_line 'symbol_crossbar_count=4'
require_line 'symbol_crossbar_state_count=3'
require_line 'symbol_full_cycle_dividers=4'
require_line 'symbol_full_cycle_main_strokes=12'
require_line 'symbol_full_cycle_main_strokes_solid=12'
require_line 'symbol_full_cycle_solid_mask=15'
require_line 'symbol_full_cycle_dotted_mask=0'
require_line 'symbol_divider_full_milli=1000'
require_line 'symbol_divider_dotted_milli=500'

# Every host-consumed numeric field must be concrete (never null/blank).
for key in identity dirty generation pool_slot coalesce_bucket parallel_width background_cadence \
  audio_lane visual_lane game_lane media_lane ui_lane canonical_lane symbol_lane project_lane \
  audio_pool_format visual_pool_format game_pool_format media_pool_format ui_pool_format canonical_pool_format symbol_pool_format project_pool_format \
  audio_pool_slot visual_pool_slot game_pool_slot media_pool_slot ui_pool_slot canonical_pool_slot symbol_pool_slot project_pool_slot \
  audio_generation visual_generation game_generation media_generation ui_generation canonical_generation symbol_generation project_generation \
  audio_result_slot visual_result_slot game_result_slot media_result_slot ui_result_slot canonical_result_slot symbol_result_slot project_result_slot \
  audio_buffer_slot visual_buffer_slot game_buffer_slot media_buffer_slot ui_buffer_slot canonical_buffer_slot symbol_buffer_slot project_buffer_slot \
  audio_cadence visual_cadence game_cadence media_cadence ui_cadence canonical_cadence symbol_cadence project_cadence; do
  val=$(printf '%s\n' "$out" | sed -n "s/^${key}=//p" | head -n 1)
  case "$val" in
    ''|null|None|nan|NaN) echo "FAIL non-concrete optimizer field: $key=$val" >&2; exit 1 ;;
  esac
done

# Every completion-policy method must be exercised by its contract test.
for fn in $(sed -n 's/^func \(completion_[A-Za-z0-9_]*\)(.*/\1/p' "$root/scode/libs/runtime/completion.sC"); do
  grep -q "${fn}(" "$root/tests/completion_policy_test.sC" || { echo "FAIL untested completion method: $fn" >&2; exit 1; }
done

# Every universal pool-format/request method must be exercised by the pool test.
for fn in $(sed -n 's/^func \(pool_format_[A-Za-z0-9_]*\)(.*/\1/p; s/^func \(pool_request_[A-Za-z0-9_]*\)(.*/\1/p' "$root/scode/libs/runtime/pool.sC"); do
  grep -q "${fn}(" "$root/tests/pool_formats_test.sC" || { echo "FAIL untested universal pool method: $fn" >&2; exit 1; }
done
pool_out=$("$scode0" run "$root/tests/pool_formats_test.sC")
printf '%s\n' "$pool_out" | grep -qx 'pool_abi=3' || { echo "FAIL pool ABI" >&2; exit 1; }
printf '%s\n' "$pool_out" | grep -qx 'pool_format_count=18' || { echo "FAIL pool format count" >&2; exit 1; }
probe_count=$(printf '%s\n' "$pool_out" | grep -c '^format_probe=')
[ "$probe_count" -eq 18 ] || { echo "FAIL not every pool format was probed: $probe_count" >&2; exit 1; }
printf '%s\n' "$pool_out" | grep -qx 'request_same_skip=0' || { echo "FAIL pool request reuse skip" >&2; exit 1; }
printf '%s\n' "$pool_out" | grep -qx 'request_dirty_run=1' || { echo "FAIL pool request dirty run" >&2; exit 1; }
printf '%s\n' "$pool_out" | grep -qx 'request_side_effect_no_reuse=0' || { echo "FAIL side-effect pooling guard" >&2; exit 1; }


full_symbol_out=$("$scode0" run "$root/tests/symbol_codec_test.sC")
plan_symbol_out=$("$scode0" run "$root/tests/symbol_plan_test.sC")
# Contract constants must agree between the compact live planner and full codec.
[ "$(printf '%s\n' "$plan_symbol_out" | sed -n '1p')" = "4" ] || { echo "FAIL compact symbol ABI" >&2; exit 1; }
[ "$(printf '%s\n' "$plan_symbol_out" | sed -n '2p')" = "16" ] || { echo "FAIL compact symbol base" >&2; exit 1; }
[ "$(printf '%s\n' "$plan_symbol_out" | sed -n '6p')" = "5188" ] || { echo "FAIL compact symbol variants" >&2; exit 1; }
[ "$(printf '%s\n' "$plan_symbol_out" | sed -n '10p')" = "15" ] || { echo "FAIL compact symbol solid16" >&2; exit 1; }
[ "$(printf '%s\n' "$plan_symbol_out" | sed -n '11p')" = "0" ] || { echo "FAIL compact symbol dotted16" >&2; exit 1; }
[ "$(printf '%s\n' "$plan_symbol_out" | sed -n '15p')" = "12" ] || { echo "FAIL compact symbol main16" >&2; exit 1; }
[ "$(printf '%s\n' "$plan_symbol_out" | sed -n '16p')" = "12" ] || { echo "FAIL compact symbol main16 solid" >&2; exit 1; }

completion_out=$("$scode0" run "$root/tests/completion_policy_test.sC")
printf '%s\n' "$completion_out" | grep -qx 'completion_abi=1' || { echo "FAIL completion ABI" >&2; exit 1; }
printf '%s\n' "$completion_out" | grep -qx 'policy_count=5' || { echo "FAIL completion policy count" >&2; exit 1; }
printf '%s\n' "$completion_out" | grep -qx 'generation_drop=0' || { echo "FAIL stale generation publication guard" >&2; exit 1; }
printf '%s\n' "$completion_out" | grep -qx 'frame_drop=0' || { echo "FAIL stale frame publication guard" >&2; exit 1; }
printf '%s\n' "$completion_out" | grep -qx 'side_effect_coalesce=0' || { echo "FAIL side-effect coalescing guard" >&2; exit 1; }
printf '%s\n' "$completion_out" | grep -qx 'streaming=1' || { echo "FAIL stream completion policy" >&2; exit 1; }

echo "PASS: sCode optimizer/runtime contract ABI 9"
