#!/usr/bin/env sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
bad=$(find "$root" -type f \( -name '*.c' -o -name '*.h' -o -name '*.cc' -o -name '*.cpp' -o -name '*.cxx' -o -name '*.py' -o -name '*.jl' \) -print)
if [ -n "$bad" ]; then echo "Forbidden implementation-source dependencies found:"; echo "$bad"; exit 1; fi
echo "PASS: sCode source tree contains no C/C++/Python/Julia source."
