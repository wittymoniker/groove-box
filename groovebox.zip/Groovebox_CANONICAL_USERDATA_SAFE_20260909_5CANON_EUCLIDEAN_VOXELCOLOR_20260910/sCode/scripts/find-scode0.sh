#!/usr/bin/env sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
os=$(uname -s 2>/dev/null || echo unknown)
arch=$(uname -m 2>/dev/null || echo unknown)
case "$os:$arch" in
 Linux:x86_64|Linux:amd64) echo "$root/bootstrap/linux-x86_64/scode0" ;;
 Darwin:x86_64) echo "$root/bootstrap/macos-x86_64/scode0" ;;
 Darwin:arm64|Darwin:aarch64) echo "$root/bootstrap/macos-arm64/scode0" ;;
 MINGW*:x86_64|MSYS*:x86_64|CYGWIN*:x86_64) echo "$root/bootstrap/windows-x86_64/scode0.exe" ;;
 *) echo "$root/bootstrap/UNAVAILABLE" ;;
esac
