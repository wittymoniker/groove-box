#!/usr/bin/env bash
set -euo pipefail
OUT=${1:-build/native}; ROOT=$(cd "$(dirname "$0")/.." && pwd)
mkdir -p "$OUT"
BOOT="$ROOT/bootstrap/linux-x86_64/scode0"
[ -x "$BOOT" ] || { echo "missing trusted bootstrap: $BOOT" >&2; exit 2; }
install -m755 "$BOOT" "$OUT/scode"
echo "bootstrap-installed sCode -> $OUT/scode"
