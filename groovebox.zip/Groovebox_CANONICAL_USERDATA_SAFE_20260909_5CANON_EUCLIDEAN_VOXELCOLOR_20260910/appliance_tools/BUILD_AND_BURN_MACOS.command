#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "$0")/.." && pwd)"
ISO="$ROOT/dist/Groovebox-sCode-Appliance-x86_64.iso"
RAWDEV=""
MODE="build"
usage(){ cat <<TXT
Usage:
  ./appliance_tools/BUILD_AND_BURN_MACOS.command
  ./appliance_tools/BUILD_AND_BURN_MACOS.command --burn /dev/diskN
  ./appliance_tools/BUILD_AND_BURN_MACOS.command --iso /path/out.iso [--burn /dev/diskN]

macOS builds the Linux appliance inside an amd64 Fedora 43 container. Docker
Desktop or Podman is required. Burning uses macOS diskutil + dd and requires sudo.
TXT
}
while [ $# -gt 0 ]; do
 case "$1" in
  --burn) RAWDEV=${2:?device required}; MODE=burn; shift 2;;
  --iso) ISO=${2:?iso required}; shift 2;;
  -h|--help) usage; exit 0;;
  *) echo "Unknown option: $1" >&2; usage; exit 2;;
 esac
done
mkdir -p "$(dirname "$ISO")"
# Container output must be inside the project mount; use a project-local path and
# copy to a custom external destination afterwards if requested.
LOCAL_ISO="$ROOT/dist/Groovebox-sCode-Appliance-x86_64.iso"
ENGINE=""
if command -v docker >/dev/null 2>&1; then ENGINE=docker
elif command -v podman >/dev/null 2>&1; then ENGINE=podman
else
  echo "Docker Desktop or Podman is required to build the Fedora appliance on macOS." >&2
  exit 4
fi
COMMON=(run --rm --privileged --platform linux/amd64 -e SOS_RELEASEVER=43 -v "$ROOT:/src" -w /src fedora:43)
CMD='dnf -y install dnf5 rpm cpio gzip xorriso grub2-tools-extra grub2-pc-modules coreutils findutils gawk tar python3 && chmod +x ./BUILD_GROOVEBOX_APPLIANCE_ISO.sh ./APPLIANCE_ISO/BUILD_GAME_READY_ISO.sh ./APPLIANCE_ISO/build_iso.sh ./APPLIANCE_ISO/scripts/fat/*.sh && ./BUILD_GROOVEBOX_APPLIANCE_ISO.sh /src/dist/Groovebox-sCode-Appliance-x86_64.iso'
"$ENGINE" "${COMMON[@]}" bash -lc "$CMD"
[ -s "$LOCAL_ISO" ] || { echo "Container did not produce the ISO." >&2; exit 5; }
if [ "$ISO" != "$LOCAL_ISO" ]; then cp -f "$LOCAL_ISO" "$ISO"; cp -f "$LOCAL_ISO.sha256" "$ISO.sha256" 2>/dev/null || true; fi
if [ "$MODE" = burn ]; then
  case "$RAWDEV" in /dev/disk[0-9]* ) ;; *) echo "Expected whole disk like /dev/disk4, not $RAWDEV" >&2; exit 6;; esac
  INFO=$(diskutil info "$RAWDEV" 2>/dev/null || true)
  echo "$INFO" | grep -q 'Device / Media Name' || { echo "Cannot inspect $RAWDEV" >&2; exit 7; }
  echo "$INFO" | grep -Eq 'Internal:[[:space:]]+No|Removable Media:[[:space:]]+Removable' || {
    echo "Refusing a disk that macOS does not identify as external/removable." >&2; exit 8; }
  echo "THIS WILL ERASE $RAWDEV using $ISO"
  read -r -p "Type BURN $RAWDEV to continue: " ANSWER
  [ "$ANSWER" = "BURN $RAWDEV" ] || { echo "Cancelled."; exit 1; }
  diskutil unmountDisk "$RAWDEV"
  RDEV="/dev/r${RAWDEV#/dev/}"
  sudo dd if="$ISO" of="$RDEV" bs=4m
  sync
  diskutil eject "$RAWDEV" || true
  echo "Burn complete."
else
  echo "Build complete: $ISO"
fi
