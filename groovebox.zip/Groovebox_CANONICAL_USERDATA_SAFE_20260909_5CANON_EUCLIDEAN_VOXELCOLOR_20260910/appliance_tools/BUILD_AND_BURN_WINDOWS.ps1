[CmdletBinding()]
param(
    [string]$IsoPath = "",
    [int]$DiskNumber = -1,
    [switch]$Burn,
    [ValidateSet("Auto","Docker","Podman")][string]$ContainerEngine = "Auto"
)
$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
if (-not $IsoPath) { $IsoPath = Join-Path $Root "dist\Groovebox-sCode-Appliance-x86_64.iso" }
$LocalIso = Join-Path $Root "dist\Groovebox-sCode-Appliance-x86_64.iso"
New-Item -ItemType Directory -Force -Path (Split-Path $LocalIso) | Out-Null

function Require-Admin {
    $id=[Security.Principal.WindowsIdentity]::GetCurrent()
    $p=New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Run PowerShell as Administrator."
    }
}
function Find-Engine {
    param([string]$Preference)
    if ($Preference -eq "Docker") { if (Get-Command docker -ErrorAction SilentlyContinue) { return "docker" }; throw "Docker not found" }
    if ($Preference -eq "Podman") { if (Get-Command podman -ErrorAction SilentlyContinue) { return "podman" }; throw "Podman not found" }
    if (Get-Command docker -ErrorAction SilentlyContinue) { return "docker" }
    if (Get-Command podman -ErrorAction SilentlyContinue) { return "podman" }
    throw "Docker Desktop or Podman Desktop is required for the Fedora 43 ISO build on Windows."
}
$Engine = Find-Engine $ContainerEngine
$Mount = $Root.Replace('\','/')
$ContainerCmd = @'
dnf -y install dnf5 rpm cpio gzip xorriso grub2-tools-extra grub2-pc-modules coreutils findutils gawk tar python3 && chmod +x ./BUILD_GROOVEBOX_APPLIANCE_ISO.sh ./APPLIANCE_ISO/BUILD_GAME_READY_ISO.sh ./APPLIANCE_ISO/build_iso.sh ./APPLIANCE_ISO/scripts/fat/*.sh && ./BUILD_GROOVEBOX_APPLIANCE_ISO.sh /src/dist/Groovebox-sCode-Appliance-x86_64.iso
'@
& $Engine run --rm --privileged --platform linux/amd64 -e SOS_RELEASEVER=43 -v "${Mount}:/src" -w /src fedora:43 bash -lc $ContainerCmd
if ($LASTEXITCODE -ne 0) { throw "Container ISO build failed with exit code $LASTEXITCODE" }
if (-not (Test-Path $LocalIso)) { throw "ISO was not produced: $LocalIso" }
if ((Resolve-Path $IsoPath -ErrorAction SilentlyContinue) -ne (Resolve-Path $LocalIso)) {
    New-Item -ItemType Directory -Force -Path (Split-Path $IsoPath) | Out-Null
    Copy-Item -Force $LocalIso $IsoPath
    if (Test-Path "$LocalIso.sha256") { Copy-Item -Force "$LocalIso.sha256" "$IsoPath.sha256" }
}
Write-Host "Built: $IsoPath"
if (-not $Burn) { return }
Require-Admin
if ($DiskNumber -lt 0) { throw "Use -Burn -DiskNumber N and choose the USB disk number from Get-Disk." }
$Disk = Get-Disk -Number $DiskNumber
if ($Disk.IsBoot -or $Disk.IsSystem) { throw "REFUSING boot/system disk $DiskNumber" }
$Allowed = @('USB','SD','MMC')
if ($Allowed -notcontains [string]$Disk.BusType) { throw "REFUSING disk $DiskNumber: BusType=$($Disk.BusType), expected USB/SD/MMC." }
$IsoLen = (Get-Item $IsoPath).Length
if ($IsoLen -gt $Disk.Size) { throw "ISO is larger than target disk." }
Write-Host "Target: Disk $DiskNumber  $($Disk.FriendlyName)  $([math]::Round($Disk.Size/1GB,2)) GiB  $($Disk.BusType)"
Write-Host "THIS WILL DESTROY ALL DATA ON DISK $DiskNumber."
$Confirm = Read-Host "Type BURN DISK $DiskNumber to continue"
if ($Confirm -ne "BURN DISK $DiskNumber") { throw "Cancelled." }
# Offline the disk so volumes stop competing for handles, then stream the image
# directly to the whole physical drive. Restore online state afterward.
Set-Disk -Number $DiskNumber -IsOffline $true
$Target = "\\.\PhysicalDrive$DiskNumber"
try {
    $src = [System.IO.File]::Open($IsoPath,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::Read)
    $dst = [System.IO.FileStream]::new($Target,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Write,[System.IO.FileShare]::ReadWrite,4194304,[System.IO.FileOptions]::WriteThrough)
    try {
        $buf = New-Object byte[] 4194304
        $total = 0L
        while (($n = $src.Read($buf,0,$buf.Length)) -gt 0) {
            $dst.Write($buf,0,$n); $total += $n
            $pct = [math]::Floor(($total / $IsoLen) * 100)
            Write-Progress -Activity "Writing Groovebox appliance" -Status "$pct%" -PercentComplete $pct
        }
        $dst.Flush($true)
    } finally { if ($dst) { $dst.Dispose() }; if ($src) { $src.Dispose() } }
} finally {
    Set-Disk -Number $DiskNumber -IsOffline $false -ErrorAction SilentlyContinue
}
Write-Progress -Activity "Writing Groovebox appliance" -Completed
Write-Host "Burn complete. Re-scan/eject the USB before removal."
