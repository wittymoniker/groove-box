#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ISO="${GROOVEBOX_APPLIANCE_ISO:-$ROOT/dist/Groovebox-sCode-Appliance-x86_64.iso}"
DEV=""
NO_BURN=1
usage(){ cat <<TXT
Usage:
  sudo ./appliance_tools/BUILD_AND_BURN_LINUX.sh
  sudo ./appliance_tools/BUILD_AND_BURN_LINUX.sh --burn /dev/sdX
  sudo ./appliance_tools/BUILD_AND_BURN_LINUX.sh --iso /path/out.iso [--burn /dev/sdX]

Builds the Fedora-43 game-ready Groovebox+sCode appliance ISO. USB writing is
optional and requires an explicit whole-disk target plus a typed BURN confirmation.
TXT
}
while [ $# -gt 0 ]; do
  case "$1" in
    --burn) DEV=${2:?device required}; NO_BURN=0; shift 2;;
    --iso) ISO=${2:?iso path required}; shift 2;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown option: $1" >&2; usage; exit 2;;
  esac
done
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo/root." >&2; exit 3; }
"$ROOT/BUILD_GROOVEBOX_APPLIANCE_ISO.sh" "$ISO"
[ -s "$ISO" ] || { echo "ISO was not produced: $ISO" >&2; exit 4; }
if [ "$NO_BURN" -eq 0 ]; then
  "$ROOT/BURN_GROOVEBOX_APPLIANCE_USB.sh" "$ISO" "$DEV"
else
  echo "Build complete. ISO: $ISO"
  echo "To write it later: sudo ./BURN_GROOVEBOX_APPLIANCE_USB.sh '$ISO' /dev/sdX"
fi
