include("GrooveboxHybrid.jl")
using .GrooveboxHybrid
x=[-3.2,-1.5,-0.2,0.4,2.5]
@assert ot_band_tensor(x) == [1.0,2.0,1.0,1.0,3.0]
C=reshape(collect(1.0:6.0),2,3); W=ones(2,2,3)
@assert canonical_contract(C,W) == [21.0,21.0]
println("Groovebox Julia tensor smoke: PASS")
