module GrooveboxHybrid

using Libdl

const TAU = 2π
const DEFAULT_MEUM = 1.1975807343385265188
const DEFAULT_MEUM_INV = 1.0 / DEFAULT_MEUM
const DEFAULT_MEUM_NORM = (DEFAULT_MEUM - 1.0) * DEFAULT_MEUM_INV

"Locate the bundled C++ accelerator shared library."
function cpp_library()
    root = normpath(joinpath(@__DIR__, ".."))
    candidates = Sys.iswindows() ? [joinpath(root,"native","groovebox_accel.dll")] :
                 Sys.isapple()  ? [joinpath(root,"native","libgroovebox_accel.dylib")] :
                                  [joinpath(root,"native","libgroovebox_accel.so")]
    for p in candidates
        isfile(p) && return p
    end
    return nothing
end

"Julia implementation of the canonical Meum AM/FM/PM vector kernel."
function meum_modulation(t::AbstractVector{<:Real};
    meum_norm=DEFAULT_MEUM_NORM, meum_inv=DEFAULT_MEUM_INV,
    phase_shift=0.0, am_depth=0.0, am_rate=0.0,
    fm_depth=0.0, fm_rate=0.0, pm_depth=0.0, pm_rate=0.0,
    pm_feedback=0.0, meum_depth=0.0)
    n = length(t)
    freq = Vector{Float32}(undef,n); phase = Vector{Float32}(undef,n); am = Vector{Float32}(undef,n)
    am_depth=clamp(am_depth,0.0,1.0); am_rate=max(0.0,am_rate)
    fm_depth=clamp(fm_depth,-0.95,0.95); fm_rate=max(0.0,fm_rate)
    pm_depth=clamp(pm_depth,-π,π); pm_rate=max(0.0,pm_rate)
    pm_feedback=clamp(pm_feedback,-1.0,1.0); meum_depth=clamp(meum_depth,0.0,1.0)
    @inbounds for i in eachindex(t)
        tt=Float64(t[i])
        field(r)=0.5*(sin(TAU*tt*r)+meum_norm*sin(TAU*tt*r*meum_inv))
        fm=sin(TAU*tt*fm_rate+phase_shift)
        freq[i]=Float32(max(0.0,1.0+fm_depth*(fm+meum_depth*field(fm_rate))))
        pm=sin(TAU*tt*pm_rate+phase_shift)
        phase[i]=Float32(phase_shift+pm_depth*pm+pm_feedback*meum_depth*field(pm_rate))
        amv=sin(TAU*tt*am_rate+phase_shift)
        am[i]=Float32(max(0.0,1.0+am_depth*(amv+meum_depth*field(am_rate))))
    end
    return freq, phase, am
end

"Call the C++ voice kernel from Julia via ccall. This keeps Julia as the numerical orchestration layer and C++ as the tight inner kernel."
function cpp_voice(phase::Vector{Float64}, entropy, k1, k3, k4, n_harm, n_inh,
                   waveform_code, goava, pm_depth, seed_int, voice_index;
                   meum=DEFAULT_MEUM, meum_norm=DEFAULT_MEUM_NORM)
    lib=cpp_library()
    lib === nothing && error("C++ accelerator not found; build native/libgroovebox_accel first")
    out=Vector{Float32}(undef,length(phase))
    ccall((:gb_voice_synth_f32,lib), Cvoid,
        (Ptr{Cdouble},Csize_t,Cdouble,Cdouble,Cdouble,Cdouble,Cint,Cint,Cint,Cint,Cdouble,Clonglong,Cint,Cdouble,Cdouble,Ptr{Cfloat}),
        phase,length(phase),entropy,k1,k3,k4,n_harm,n_inh,waveform_code,goava,pm_depth,seed_int,voice_index,meum,meum_norm,out)
    return out
end

"Pure Julia canonical voice kernel, useful for benchmarking and CPU portability."
function voice_synth(phase::AbstractVector{<:Real}, entropy, k1, k3, k4, n_harm, n_inh,
                     waveform_code, goava, pm_depth, seed_int, voice_index;
                     meum=DEFAULT_MEUM, meum_norm=DEFAULT_MEUM_NORM)
    out=Vector{Float32}(undef,length(phase)); tau=TAU
    @inbounds for i in eachindex(phase)
        ph=Float64(phase[i]); harm=0.0
        if goava != 0
            harm=sin(ph); abs(pm_depth)>0.05 && (harm += 0.08*abs(pm_depth)*sin(2ph))
        elseif waveform_code != 0
            u=ph/tau-floor(ph/tau)
            wf(x)=begin
                z=x/tau-floor(x/tau)
                waveform_code==1 ? 2z-1 : waveform_code==2 ? (z<0.5 ? 1.0 : -1.0) :
                waveform_code==3 ? 4abs(z-0.5)-1 : waveform_code==4 ? cos(x)*meum_norm+cos(x*meum)*(1-meum_norm) : sin(x)*meum_norm+sin(x*meum)*(1-meum_norm)
            end
            harm=wf(ph)
            for h in 2:min(n_harm,5); harm += (0.12/h)*wf(ph*h); end
        else
            harm=sin(ph)
            for h in 2:n_harm
                roll=1+(1-entropy)*1.2
                amp_h=(0.35+0.55*(1-entropy))/(h^roll)
                mod=mod(seed_int,97); det=1+1e-4*(mod-48)*(h-1)*(0.3+0.7*entropy)
                q=mod(seed_int*h*13+voice_index*7,1000); ph0=(q/1000)*tau
                harm += amp_h*sin(ph*h*det+ph0)
            end
        end
        inh=0.0
        for h in 1:n_inh
            ratio=1+h*(1+0.37*sin((seed_int+h*17)*meum_norm))
            ratio=1+(ratio-1)*(0.4+0.6*entropy)
            amp_i=(0.25+0.6*entropy)/(h^(0.9+0.4*entropy))
            q=mod(seed_int*h*31+voice_index*11,1000); ph0=(q/1000)*tau
            inh += amp_i*sin(ph*ratio+ph0)
        end
        if entropy>0.1
            q=mod(seed_int,19); fm_ratio=1+(q/19)*3*entropy
            fm_depth=(0.05+0.55*entropy)*(0.5+0.5*k1)
            harm *= cos(fm_depth*sin(ph*fm_ratio))
        end
        v=(1-entropy)*harm+entropy*inh
        out[i]=Float32(clamp(v,-1.5,1.5))
    end
    return out
end

"Explicit tensor contraction used as a reference for Canonical Trio projections."
function canonical_contract(C::Array{Float64,2}, W::Array{Float64,3})
    size(W,2)==size(C,1) && size(W,3)==size(C,2) || error("shape mismatch")
    out=zeros(Float64,size(W,1))
    @inbounds for t in axes(W,1), r in axes(W,2), k in axes(W,3)
        out[t] += W[t,r,k]*C[r,k]
    end
    return out
end

"First-match indicator contraction for the OT band selector."
function ot_band_tensor(x::AbstractVector{<:Real})
    bands=(1.0,2.0,3.0); out=zeros(Float64,length(x))
    @inbounds for n in eachindex(x)
        ax=abs(Float64(x[n]))
        out[n]=ax<=bands[1] ? bands[1] : ax<=bands[2] ? bands[2] : ax<=bands[3] ? bands[3] : bands[1]
    end
    return out
end

end # module
