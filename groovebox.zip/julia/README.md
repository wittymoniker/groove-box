# Julia layer

`GrooveboxHybrid.jl` makes the project a deliberate three-language stack:

- **Python** — UI, sequencing, composition state, project I/O, orchestration and high-level DSP/effects.
- **Julia** — numerical orchestration, batch DSP, experimentation/optimization and a readable reference implementation.
- **C++17** — tight inner-loop kernels exposed through a stable C ABI.

Julia can call the C++ accelerator directly with `ccall`, so the hot path can remain native without copying data through a subprocess.

The Julia layer is optional: the Python application continues to run with C++ only, or with the original NumPy fallback if neither native layer is available.
