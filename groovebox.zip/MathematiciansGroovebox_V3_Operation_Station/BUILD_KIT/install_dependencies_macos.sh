#!/usr/bin/env bash
set -Eeuo pipefail
KIT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$KIT/.." && pwd)"
if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew is required for this installer: https://brew.sh"
  exit 3
fi
brew install python ffmpeg portaudio || true
# Xcode Command Line Tools provide clang++; prompt if absent.
if ! xcrun --find clang++ >/dev/null 2>&1; then
  xcode-select --install || true
fi
cd "$ROOT"
python3 -m venv .groovebox-build-venv
. .groovebox-build-venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip install 'pyinstaller>=6.10,<7'
python "$KIT/build.py" --doctor
printf '\nDependencies ready. Build with:\n  ./BUILD_KIT/build_macos.sh --console\n'
