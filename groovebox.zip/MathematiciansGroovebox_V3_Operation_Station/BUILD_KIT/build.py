#!/usr/bin/env python3
"""Cross-platform executable builder for Mathematician's Groovebox.

This file intentionally lives in BUILD_KIT/ and resolves the application root
as its parent, so the kit can stay in a subfolder.
"""
from __future__ import annotations

import argparse
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent
ROOT = KIT.parent
ENTRY = ROOT / "groovebox.py"
VENV = ROOT / ".groovebox-build-venv"
BUILD = ROOT / "build_executable"
DIST = ROOT / "dist"
APPNAME = "MathematiciansGroovebox"


def run(cmd, *, cwd=ROOT, env=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run([str(x) for x in cmd], cwd=str(cwd), env=env, check=True)


def venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def ensure_venv() -> Path:
    py = venv_python()
    if not py.exists():
        print(f"Creating build environment: {VENV}")
        run([sys.executable, "-m", "venv", str(VENV)])
    return py


def install_python_deps(py: Path):
    req = ROOT / "requirements.txt"
    run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    if req.exists():
        run([py, "-m", "pip", "install", "-r", req])
    run([py, "-m", "pip", "install", "pyinstaller>=6.10,<7"])


def valid_local_modules():
    mods = []
    skip_prefix = ("test_", "tests", "benchmark_")
    for p in sorted(ROOT.glob("*.py")):
        stem = p.stem
        if p.name == ENTRY.name or stem.startswith(skip_prefix):
            continue
        if re.fullmatch(r"[A-Za-z_]\w*", stem):
            mods.append(stem)
    return mods


def compile_native():
    system = platform.system().lower()
    native = ROOT / "native"
    native.mkdir(exist_ok=True)
    src = ROOT / "cpp" / "groovebox_accel.cpp"
    if not src.exists():
        return
    try:
        if system == "linux":
            compiler = shutil.which("g++") or shutil.which("c++")
            if not compiler:
                print("WARNING: no C++ compiler found; executable will use Python fallback.")
                return
            run([compiler, "-std=c++17", "-O3", "-DNDEBUG", "-fPIC", "-fvisibility=hidden",
                 "-shared", str(src), "-o", str(native / "libgroovebox_accel.so")])
        elif system == "darwin":
            compiler = shutil.which("c++") or shutil.which("clang++")
            if not compiler:
                print("WARNING: no C++ compiler found; executable will use Python fallback.")
                return
            run([compiler, "-std=c++17", "-O3", "-DNDEBUG", "-fPIC", "-fvisibility=hidden",
                 "-dynamiclib", str(src), "-o", str(native / "libgroovebox_accel.dylib")])
        elif system == "windows":
            cl = shutil.which("cl")
            gxx = shutil.which("g++")
            if cl:
                run([cl, "/nologo", "/std:c++17", "/O2", "/DNDEBUG", "/LD", str(src),
                     f"/Fe:{native / 'groovebox_accel.dll'}"])
            elif gxx:
                run([gxx, "-std=c++17", "-O3", "-DNDEBUG", "-shared", str(src),
                     "-o", str(native / "groovebox_accel.dll")])
            else:
                print("WARNING: MSVC/MinGW C++ compiler not found; executable will use Python fallback.")
    except subprocess.CalledProcessError:
        print("WARNING: native accelerator build failed; continuing with Python fallback.")


def add_arg(cmd, kind: str, source: Path, dest: str):
    # PyInstaller's add-data/add-binary syntax is platform dependent.
    sep = ";" if os.name == "nt" else ":"
    cmd.extend([kind, f"{source}{sep}{dest}"])


def build(onefile=False, console=False, clean=True, install=True, native=True):
    if not ENTRY.exists():
        raise SystemExit(f"Cannot find {ENTRY}")
    py = ensure_venv()
    if install:
        install_python_deps(py)
    if native:
        compile_native()

    cmd = [py, "-m", "PyInstaller", str(ENTRY),
           "--name", APPNAME,
           "--noconfirm",
           "--distpath", str(DIST),
           "--workpath", str(BUILD / "work"),
           "--specpath", str(BUILD / "spec"),
           "--paths", str(ROOT)]
    if clean:
        cmd.append("--clean")
    cmd.append("--onefile" if onefile else "--onedir")
    cmd.append("--console" if console else "--windowed")

    # Local modules include dynamically loaded/optional Groovebox components.
    for mod in valid_local_modules():
        cmd.extend(["--hidden-import", mod])

    # These packages have platform/native hooks, but explicit collection makes
    # the build resilient to optional submodule imports inside Groovebox.
    for pkg in ("PyQt6", "numpy", "scipy", "sounddevice", "PIL"):
        cmd.extend(["--collect-submodules", pkg])

    # Runtime resources that are intentionally external to Python imports.
    for dirname in ("native", "julia"):
        p = ROOT / dirname
        if p.exists():
            add_arg(cmd, "--add-data", p, dirname)
    for filename in ("README.md", "PERFORMANCE_BOX.md"):
        p = ROOT / filename
        if p.exists():
            add_arg(cmd, "--add-data", p, ".")

    # If the user has provisioned project-local ffmpeg/ffprobe, bundle them.
    local_bin = ROOT / "bin"
    if local_bin.exists():
        for base in ("ffmpeg", "ffprobe"):
            candidates = [local_bin / base, local_bin / f"{base}.exe"]
            for p in candidates:
                if p.exists():
                    add_arg(cmd, "--add-binary", p, "bin")
                    break

    run(cmd)
    exe = DIST / (f"{APPNAME}.exe" if onefile and os.name == "nt" else APPNAME)
    print("\nBUILD COMPLETE")
    print(f"Output: {exe if onefile else DIST / APPNAME}")
    if platform.system().lower() == "linux":
        print(f"Run:    {DIST / APPNAME / APPNAME if not onefile else DIST / APPNAME}")


def doctor():
    print("Mathematician's Groovebox build doctor")
    print("ROOT:", ROOT)
    print("Python:", sys.executable, sys.version.replace("\n", " "))
    print("OS:", platform.platform())
    print("Entry:", ENTRY, "OK" if ENTRY.exists() else "MISSING")
    for tool in ("ffmpeg", "ffprobe", "g++", "c++", "clang++", "cl"):
        print(f"{tool:10s}", shutil.which(tool) or "not found")
    for lib in ("native/libgroovebox_accel.so", "native/libgroovebox_accel.dylib", "native/groovebox_accel.dll"):
        p = ROOT / lib
        if p.exists():
            print("native:", p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--onefile", action="store_true", help="single executable; slower startup, less debuggable")
    ap.add_argument("--console", action="store_true", help="keep console visible for diagnostics")
    ap.add_argument("--no-install", action="store_true", help="do not pip-install/refresh build dependencies")
    ap.add_argument("--no-native", action="store_true", help="skip C++ accelerator compilation")
    ap.add_argument("--no-clean", action="store_true")
    ap.add_argument("--doctor", action="store_true")
    args = ap.parse_args()
    if args.doctor:
        doctor()
        return 0
    build(args.onefile, args.console, not args.no_clean, not args.no_install, not args.no_native)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
