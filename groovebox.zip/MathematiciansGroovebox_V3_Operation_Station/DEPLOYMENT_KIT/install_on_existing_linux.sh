#!/usr/bin/env bash
set -euo pipefail
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then echo "Run with sudo/root." >&2; exit 2; fi
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$KIT_DIR/.." && pwd)"
DEST=/opt/mathematicians-groovebox
TARGET_USER="${SUDO_USER:-${GROOVEBOX_USER:-}}"
if [[ -z "$TARGET_USER" || "$TARGET_USER" == root ]]; then TARGET_USER=$(logname 2>/dev/null || true); fi
if [[ -z "$TARGET_USER" ]]; then echo "Set GROOVEBOX_USER to the desktop user." >&2; exit 3; fi
TARGET_HOME=$(getent passwd "$TARGET_USER" | cut -d: -f6)
export DEBIAN_FRONTEND=noninteractive
if command -v apt-get >/dev/null 2>&1; then
  apt-get update
  apt-get install -y python3 python3-venv python3-pip python3-dev build-essential cmake pkg-config \
    ffmpeg mpv libportaudio2 portaudio19-dev libsndfile1 libgl1 libegl1 libxkbcommon-x11-0 \
    libxcb-cursor0 libxcb-xinerama0 libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-render-util0 \
    pipewire pipewire-pulse wireplumber pulseaudio-utils bluez x11-xserver-utils curl ca-certificates rsync
fi
mkdir -p "$DEST"
rsync -a --delete --exclude '.venv' --exclude '__pycache__' --exclude 'dist' --exclude 'build' "$PROJECT_ROOT/" "$DEST/"
python3 -m venv "$DEST/.venv"
"$DEST/.venv/bin/python" -m pip install --upgrade pip wheel setuptools
if [[ -d "$KIT_DIR/wheelhouse" ]] && compgen -G "$KIT_DIR/wheelhouse/*" >/dev/null; then
  "$DEST/.venv/bin/pip" install --no-index --find-links "$KIT_DIR/wheelhouse" -r "$DEST/requirements.txt" || true
else
  "$DEST/.venv/bin/pip" install -r "$DEST/requirements.txt" || true
fi
# Runtime packages that may not be declared in older requirements.txt builds.
"$DEST/.venv/bin/pip" install PyQt6 numpy scipy sounddevice soundfile pillow psutil || true
install -m 0755 "$DEST/DEPLOYMENT_KIT/bin/groovebox-appliance" /usr/local/bin/groovebox-appliance
install -m 0755 "$DEST/DEPLOYMENT_KIT/bin/groovebox-hardware-profile" /usr/local/bin/groovebox-hardware-profile
install -m 0644 "$DEST/DEPLOYMENT_KIT/desktop/mathematicians-groovebox.desktop" /usr/share/applications/mathematicians-groovebox.desktop
install -m 0644 "$DEST/DEPLOYMENT_KIT/desktop/mathematicians-groovebox-fullscreen.desktop" /usr/share/applications/mathematicians-groovebox-fullscreen.desktop
mkdir -p "$TARGET_HOME/.config/systemd/user"
install -m 0644 "$DEST/DEPLOYMENT_KIT/systemd/groovebox-appliance.service" "$TARGET_HOME/.config/systemd/user/groovebox-appliance.service"
chown -R "$TARGET_USER":"$(id -gn "$TARGET_USER")" "$DEST" "$TARGET_HOME/.config/systemd/user/groovebox-appliance.service"
su - "$TARGET_USER" -c '/usr/local/bin/groovebox-hardware-profile' || true
cat <<EOF
Installed Mathematician's Groovebox to $DEST
Launch: /usr/local/bin/groovebox-appliance
Enable login auto-start (as $TARGET_USER):
  systemctl --user enable --now groovebox-appliance.service
EOF
