#!/usr/bin/env bash
set -euo pipefail
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$KIT_DIR/.." && pwd)"
OUT="$KIT_DIR/payload/groovebox"
rm -rf "$OUT"; mkdir -p "$OUT"
rsync -a --exclude 'DEPLOYMENT_KIT/payload' --exclude '.venv' --exclude '__pycache__' --exclude 'build' --exclude 'dist' "$ROOT/" "$OUT/"
echo "Payload staged at $OUT"
