#!/usr/bin/env bash
set -euo pipefail
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$(cd "$KIT_DIR/.." && pwd)"
mkdir -p "$KIT_DIR/wheelhouse"
python3 -m pip download --dest "$KIT_DIR/wheelhouse" -r "$ROOT/requirements.txt"
python3 -m pip download --dest "$KIT_DIR/wheelhouse" PyQt6 numpy scipy sounddevice soundfile pillow psutil
echo "Wheelhouse created for $(uname -m) at $KIT_DIR/wheelhouse"
