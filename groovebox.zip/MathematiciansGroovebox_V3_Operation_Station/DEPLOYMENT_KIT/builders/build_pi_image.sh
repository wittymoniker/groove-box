#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Run with sudo/root." >&2; exit 2; }
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$(cd "$KIT_DIR/.." && pwd)"
OUT="$KIT_DIR/out"; mkdir -p "$OUT"
cat <<'EOF'
Raspberry Pi images are hardware/firmware specific. This builder prefers an
installed Raspberry Pi `rpi-image-gen`; if unavailable it can use a checked-out
`pi-gen`. It injects the Groovebox project and first-boot installer rather than
inventing firmware blobs.
EOF
"$KIT_DIR/make_payload.sh"
if command -v rpi-image-gen >/dev/null 2>&1; then
  echo "rpi-image-gen detected. Its CLI/config format varies by release."
  echo "Use the generated overlay at: $KIT_DIR/payload/groovebox"
  echo "and configure a first-boot command: sudo /opt/mathematicians-groovebox/DEPLOYMENT_KIT/install_on_existing_linux.sh"
  rpi-image-gen --help || true
  exit 0
fi
PIGEN="${PIGEN_DIR:-$ROOT/pi-gen}"
if [[ ! -d "$PIGEN" ]]; then
  echo "pi-gen not found. Clone Raspberry Pi pi-gen into $PIGEN, then rerun:" >&2
  echo "  git clone https://github.com/RPi-Distro/pi-gen.git '$PIGEN'" >&2
  exit 4
fi
STAGE="$PIGEN/stage2/99-groovebox"
rm -rf "$STAGE"; mkdir -p "$STAGE/files"
rsync -a "$KIT_DIR/payload/groovebox/" "$STAGE/files/groovebox/"
cat > "$STAGE/00-run.sh" <<'EOF'
#!/bin/bash -e
install -d "${ROOTFS_DIR}/opt/mathematicians-groovebox"
cp -a files/groovebox/. "${ROOTFS_DIR}/opt/mathematicians-groovebox/"
on_chroot <<'CHROOT'
apt-get update
apt-get install -y python3 python3-venv python3-pip ffmpeg mpv pipewire wireplumber libportaudio2 libsndfile1 libgl1 libegl1
python3 -m venv /opt/mathematicians-groovebox/.venv
/opt/mathematicians-groovebox/.venv/bin/pip install -r /opt/mathematicians-groovebox/requirements.txt || true
/opt/mathematicians-groovebox/.venv/bin/pip install PyQt6 numpy scipy sounddevice soundfile pillow psutil || true
install -m 0755 /opt/mathematicians-groovebox/DEPLOYMENT_KIT/bin/groovebox-appliance /usr/local/bin/groovebox-appliance
CHROOT
EOF
chmod +x "$STAGE/00-run.sh"
cd "$PIGEN"
./build.sh
IMG=$(find deploy -maxdepth 1 -type f \( -name '*.img' -o -name '*.img.xz' -o -name '*.zip' \) | sort | tail -1)
[[ -n "$IMG" ]] || { echo "pi-gen completed without a deploy image" >&2; exit 5; }
cp "$IMG" "$OUT/"
echo "Pi image copied to $OUT/$(basename "$IMG")"
