#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Run with sudo/root." >&2; exit 2; }
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "EXPERIMENTAL: generic ARM64 UEFI only; this is not a universal Android-tablet image." >&2
command -v lb >/dev/null || { apt-get update; apt-get install -y live-build qemu-user-static binfmt-support rsync; }
"$KIT_DIR/make_payload.sh"
WORK="$KIT_DIR/.iso-arm64"; OUT="$KIT_DIR/out"; rm -rf "$WORK"; mkdir -p "$WORK" "$OUT"; cd "$WORK"
lb config --architectures arm64 --distribution trixie --archive-areas 'main contrib non-free-firmware' --bootappend-live 'boot=live components quiet splash'
mkdir -p config/package-lists config/includes.chroot/opt/mathematicians-groovebox config/hooks/live
cat > config/package-lists/groovebox.list.chroot <<EOF
python3
python3-venv
python3-pip
ffmpeg
mpv
pipewire
wireplumber
libportaudio2
libsndfile1
libgl1
libegl1
rsync
EOF
rsync -a "$KIT_DIR/payload/groovebox/" config/includes.chroot/opt/mathematicians-groovebox/
cat > config/hooks/live/0500-groovebox.hook.chroot <<'EOF'
#!/bin/sh
set -e
python3 -m venv /opt/mathematicians-groovebox/.venv
/opt/mathematicians-groovebox/.venv/bin/pip install -r /opt/mathematicians-groovebox/requirements.txt || true
/opt/mathematicians-groovebox/.venv/bin/pip install PyQt6 numpy scipy sounddevice soundfile pillow psutil || true
EOF
chmod +x config/hooks/live/0500-groovebox.hook.chroot
lb build
ISO=$(find . -maxdepth 1 -name '*.iso' -type f | head -1)
[[ -n "$ISO" ]] || { echo "No ARM64 ISO produced; firmware/bootloader support varies by device." >&2; exit 5; }
cp "$ISO" "$OUT/MathematiciansGroovebox-arm64-uefi.iso"
echo "$OUT/MathematiciansGroovebox-arm64-uefi.iso"
