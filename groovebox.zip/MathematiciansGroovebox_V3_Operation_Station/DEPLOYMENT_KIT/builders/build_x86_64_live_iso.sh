#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Run with sudo/root." >&2; exit 2; }
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$(cd "$KIT_DIR/.." && pwd)"
command -v lb >/dev/null || { apt-get update; apt-get install -y live-build rsync; }
"$KIT_DIR/make_payload.sh"
WORK="$KIT_DIR/.iso-x86_64"; OUT="$KIT_DIR/out"; rm -rf "$WORK"; mkdir -p "$WORK" "$OUT"
cd "$WORK"
lb config --architectures amd64 --distribution trixie --debian-installer live \
  --archive-areas 'main contrib non-free-firmware' --bootappend-live 'boot=live components quiet splash'
mkdir -p config/package-lists config/includes.chroot/opt/mathematicians-groovebox
cat > config/package-lists/groovebox.list.chroot <<EOF
python3
python3-venv
python3-pip
python3-dev
build-essential
cmake
ffmpeg
mpv
pipewire
pipewire-pulse
wireplumber
pulseaudio-utils
bluez
libportaudio2
portaudio19-dev
libsndfile1
libgl1
libegl1
libxkbcommon-x11-0
libxcb-cursor0
x11-xserver-utils
rsync
curl
ca-certificates
EOF
rsync -a "$KIT_DIR/payload/groovebox/" config/includes.chroot/opt/mathematicians-groovebox/
mkdir -p config/includes.chroot/usr/local/bin config/hooks/live
cp "$KIT_DIR/bin/groovebox-appliance" config/includes.chroot/usr/local/bin/groovebox-appliance
chmod +x config/includes.chroot/usr/local/bin/groovebox-appliance
cat > config/hooks/live/0500-groovebox.hook.chroot <<'EOF'
#!/bin/sh
set -e
python3 -m venv /opt/mathematicians-groovebox/.venv
/opt/mathematicians-groovebox/.venv/bin/pip install --upgrade pip wheel setuptools
/opt/mathematicians-groovebox/.venv/bin/pip install -r /opt/mathematicians-groovebox/requirements.txt || true
/opt/mathematicians-groovebox/.venv/bin/pip install PyQt6 numpy scipy sounddevice soundfile pillow psutil || true
EOF
chmod +x config/hooks/live/0500-groovebox.hook.chroot
lb build
ISO=$(find . -maxdepth 1 -name '*.iso' -type f | head -1)
[[ -n "$ISO" ]] || { echo "live-build completed without an ISO" >&2; exit 5; }
cp "$ISO" "$OUT/MathematiciansGroovebox-x86_64.iso"
echo "$OUT/MathematiciansGroovebox-x86_64.iso"
