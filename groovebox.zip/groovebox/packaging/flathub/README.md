# Flatpak / Flathub integration

App ID: `app.wasmer.eski19758.Groovebox`

This directory is upstream metadata used by the Flathub manifest. The launcher keeps Groovebox's project-local FFmpeg contract by packaging wrappers in `/app/lib/groovebox/bin` which dispatch to the Flatpak runtime FFmpeg; it does not download FFmpeg at runtime.

The initial manifest is x86_64-only because the required sCode stage-0 bundled by the current source tree is Linux x86_64. A source-buildable or architecture-complete sCode bootstrap is needed before widening architectures.
