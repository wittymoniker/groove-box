# Required sCode bootstrap and Flathub

Groovebox deliberately treats the bundled sCode optimizer as required. The current Linux stage-0 file is `sCode/bootstrap/linux-x86_64/scode0`, and the current native-build helper copies that trusted bootstrap rather than recreating stage-0 from source.

That is acceptable for local Flatpak testing, but it is a likely Flathub review blocker because source-available applications are generally expected to build their components from source. Do not silently remove sCode just to get a store build: either provide a reproducible source route for stage-0, or discuss the bootstrap model explicitly with Flathub reviewers.

The manifest therefore starts x86_64-only and the submission preflight requires explicit acknowledgement of this item.
