#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/sCode/bootstrap_source/scode0_groovebox.c"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64|aarch64) DEST="$ROOT/sCode/bootstrap/macos-arm64/scode0" ;;
  x86_64|amd64) DEST="$ROOT/sCode/bootstrap/macos-x86_64/scode0" ;;
  *) echo "[sCode] unsupported macOS architecture: $ARCH" >&2; exit 2 ;;
esac
if [ ! -f "$SRC" ]; then echo "[sCode] missing stage-0 source: $SRC" >&2; exit 2; fi
CC="${CC:-}"
if [ -z "$CC" ]; then
  if command -v clang >/dev/null 2>&1; then CC="$(command -v clang)";
  elif xcrun --find clang >/dev/null 2>&1; then CC="$(xcrun --find clang)";
  else
    echo "[sCode] Apple Command Line Tools are required to build the native stage-0." >&2
    echo "[sCode] Opening Apple's installer now; after it finishes, launch Groovebox again." >&2
    xcode-select --install >/dev/null 2>&1 || true
    exit 3
  fi
fi
mkdir -p "$(dirname "$DEST")"
echo "[sCode] building native macOS stage-0 with $CC"
"$CC" -std=c11 -O2 -DNDEBUG "$SRC" -o "$DEST"
chmod 755 "$DEST"
if command -v codesign >/dev/null 2>&1; then codesign --force --sign - "$DEST" >/dev/null 2>&1 || true; fi
OUT="$($DEST --probe 2>&1 || true)"
echo "$OUT" | grep -q 'scode_stage0_native=1' || { echo "[sCode] native probe failed" >&2; exit 4; }
echo "$OUT" | grep -q 'scode_optimizer_abi=9' || { echo "[sCode] ABI-9 probe failed" >&2; exit 4; }
echo "[sCode] native macOS stage-0 ready: $DEST"
