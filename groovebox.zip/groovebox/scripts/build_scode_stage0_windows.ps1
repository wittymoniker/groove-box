$ErrorActionPreference = "Stop"
$ROOT = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$SRC = Join-Path $ROOT "sCode\bootstrap_source\scode0_groovebox.c"
$DESTDIR = Join-Path $ROOT "sCode\bootstrap\windows-x86_64"
$DEST = Join-Path $DESTDIR "scode0.exe"
New-Item -ItemType Directory -Force -Path $DESTDIR | Out-Null
if (-not (Test-Path $SRC)) { throw "Missing stage-0 source: $SRC" }

function Test-Stage0([string]$Path) {
    if (-not (Test-Path $Path)) { return $false }
    try {
        $o = & $Path --probe 2>&1 | Out-String
        return ($LASTEXITCODE -eq 0 -and $o -match 'scode_stage0_native=1' -and $o -match 'scode_optimizer_abi=9')
    } catch { return $false }
}
if (Test-Stage0 $DEST) { Write-Host "[sCode] bundled native Windows stage-0 OK"; exit 0 }

$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path $vswhere)) {
    Write-Host "[sCode] Visual C++ Build Tools not found; installing the native compiler toolchain..."
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw "winget is required to provision Visual C++ Build Tools automatically." }
    winget install --id Microsoft.VisualStudio.2022.BuildTools -e --silent --accept-package-agreements --accept-source-agreements --override "--wait --passive --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
}
if (-not (Test-Path $vswhere)) { throw "Visual Studio Build Tools installation did not provide vswhere.exe." }
$install = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $install) { throw "Could not locate the Visual C++ x64 toolchain." }
$devcmd = Join-Path $install "Common7\Tools\VsDevCmd.bat"
if (-not (Test-Path $devcmd)) { throw "Missing VsDevCmd.bat: $devcmd" }
$cmd = '"' + $devcmd + '" -no_logo -arch=x64 -host_arch=x64 && cl /nologo /O2 /DNDEBUG /std:c11 "' + $SRC + '" /Fe:"' + $DEST + '"'
Write-Host "[sCode] building native Windows stage-0..."
& cmd.exe /d /s /c $cmd
if ($LASTEXITCODE -ne 0) { throw "Native sCode stage-0 compilation failed with exit code $LASTEXITCODE" }
if (-not (Test-Stage0 $DEST)) { throw "Built Windows stage-0 failed ABI-9 probe." }
Write-Host "[sCode] native Windows stage-0 ready: $DEST"
