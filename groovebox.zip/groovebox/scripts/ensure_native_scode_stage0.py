#!/usr/bin/env python3
from __future__ import annotations
import os, platform, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from platform_runtime import find_scode_stage0, stage0_binary_matches_host

def run(cmd):
    return subprocess.run(cmd,cwd=str(ROOT),capture_output=True,text=True,timeout=1800,check=False)

def ensure():
    p=find_scode_stage0(ROOT)
    if p and stage0_binary_matches_host(p):
        return verify(p)
    system=platform.system().lower()
    if system=='windows':
        r=run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'scripts'/'build_scode_stage0_windows.ps1')])
    elif system=='darwin':
        r=run(['/bin/bash',str(ROOT/'scripts'/'build_scode_stage0_macos.sh')])
    else:
        print(f'[sCode] native stage-0 missing for {platform.system()} {platform.machine()}',file=sys.stderr); return 2
    if r.returncode:
        print((r.stdout or '')+(r.stderr or ''),file=sys.stderr); return r.returncode
    p=find_scode_stage0(ROOT)
    return verify(p) if p else 2

def verify(p:Path):
    if not stage0_binary_matches_host(p):
        print(f'[sCode] wrong executable format for host: {p}',file=sys.stderr); return 3
    system=platform.system().lower()
    if system in ('windows','darwin'):
        r=run([str(p),'--probe'])
        text=(r.stdout or '')+'\n'+(r.stderr or '')
        if r.returncode or 'scode_stage0_native=1' not in text or 'scode_optimizer_abi=9' not in text:
            print('[sCode] stage-0 native/ABI probe failed:\n'+text,file=sys.stderr); return 4
    env=os.environ.copy(); env.update(GB_OPT_ID='123456789',GB_OPT_DIRTY='255',GB_OPT_FRAME='17',GB_OPT_LANES='8',GB_OPT_POOL='64',GB_OPT_SHAPE='33',GB_OPT_EDITING='0',GB_OPT_LOW_POWER='0',GB_OPT_BUDGET='999',GB_OPT_DEP_READY='1')
    r=subprocess.run([str(p),'run','apps/groovebox/groovebox_optimizer.sC'],cwd=str(ROOT/'sCode'),env=env,capture_output=True,text=True,timeout=15,check=False)
    text=(r.stdout or '')+'\n'+(r.stderr or '')
    if r.returncode or 'scode_optimizer_abi=9' not in text:
        print('[sCode] Groovebox optimizer ABI-9 execution failed:\n'+text,file=sys.stderr); return 5
    print(f'[sCode] native stage-0 verified: {p}')
    return 0
if __name__=='__main__': raise SystemExit(ensure())
