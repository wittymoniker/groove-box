#!/usr/bin/env python3
from __future__ import annotations
import re
import sys
from pathlib import Path

MARKER = "GROOVEBOX_V34F_TOUCHPAD_PRIORITY_20260919"

POINTER_BLOCK = r'''# GROOVEBOX_V34F_TOUCHPAD_PRIORITY_20260919
# Prefer an actual touchpad over a companion mouse/trackpoint device.  Some Dell
# laptops expose both "... Mouse" and "... Touchpad" on adjacent event nodes;
# selecting the first mouse handler can bind Qt to the wrong node.
find_pointer_event_by_name() {
  rx="$1"
  awk -v rx="$rx" '
    /^N: Name=/ {name=tolower($0)}
    /^H: Handlers=/ {
      if (name ~ rx) {
        for (i=1;i<=NF;i++) if ($i ~ /^event[0-9]+$/) {print "/dev/input/" $i; exit}
      }
    }' /proc/bus/input/devices 2>/dev/null
}
find_pointer_event_by_handler() {
  awk '
    /^H: Handlers=/ {
      if ($0 ~ /mouse[0-9]+/) {
        for (i=1;i<=NF;i++) if ($i ~ /^event[0-9]+$/) {print "/dev/input/" $i; exit}
      }
    }' /proc/bus/input/devices 2>/dev/null
}
find_pointer_event() {
  # Highest priority first.  On the photographed Dell this selects event2
  # (DELL... Touchpad) instead of event1 (DELL... Mouse).
  for rx in 'touchpad|synaptics|elan|alps' 'trackpoint|pointing stick' 'mouse'; do
    ev="$(find_pointer_event_by_name "$rx")"
    if [ -n "$ev" ]; then printf '%s\n' "$ev"; return 0; fi
  done
  find_pointer_event_by_handler
}
find_pointer_name() {
  ev="$(basename "${PTR_EVENT:-}")"
  [ -n "$ev" ] || return 0
  awk -v want="$ev" '
    /^N: Name=/ {name=$0}
    /^H: Handlers=/ {
      for (i=1;i<=NF;i++) if ($i == want) {print name; exit}
    }' /proc/bus/input/devices 2>/dev/null
}
'''

FUNC_RE = re.compile(
    r"find_pointer_event\(\) \{\n.*?\n\}\nfind_pointer_name\(\) \{\n.*?\n\}\n",
    re.S,
)


def patch_launcher(path: Path) -> tuple[bool, str]:
    text = path.read_text(errors="strict")
    if MARKER in text:
        return False, "already patched"
    if "find_pointer_event()" not in text or "QT_QPA_EVDEV_MOUSE_PARAMETERS" not in text:
        return False, "not an input launcher"
    new, n = FUNC_RE.subn(POINTER_BLOCK, text, count=1)
    if n != 1:
        raise RuntimeError(f"could not locate pointer selection block in {path}")

    needle = 'PTR_NAME="$(find_pointer_name)"\n'
    if needle in new:
        new = new.replace(
            needle,
            needle + "echo '[v34f] pointer priority: touchpad/synaptics/elan/alps > trackpoint/pointing-stick > generic mouse'\n",
            1,
        )
    path.write_text(new)
    return True, "patched"


def patch_builder_hook(path: Path) -> tuple[bool, str]:
    text = path.read_text(errors="strict")
    hook_marker = "GROOVEBOX_V34F_PATCH_HOOK"
    if hook_marker in text:
        return False, "hook already present"
    install_re = re.compile(r'^(\s*)install -m 0755 "\$HERE/groovebox-appliance-direct-v32t" ', re.M)
    m = install_re.search(text)
    if not m:
        return False, "no active v32t install line"
    indent = m.group(1)
    hook = (
        f'{indent}# {hook_marker}\n'
        f'{indent}python3 "$HERE/patch_input_priority_v34f.py" "$HERE"\n'
    )
    text = text[:m.start()] + hook + text[m.start():]
    path.write_text(text)
    return True, "hook inserted"


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    if root.name != "BUILD_ISO" and (root / "BUILD_ISO").is_dir():
        root = root / "BUILD_ISO"
    if not root.is_dir():
        print(f"FAIL: BUILD_ISO directory not found: {root}", file=sys.stderr)
        return 3

    candidates = sorted(p for p in root.rglob("groovebox-appliance-direct-*") if p.is_file() and p.stat().st_size < 1024 * 1024)
    patched = 0
    seen = 0
    for p in candidates:
        try:
            changed, msg = patch_launcher(p)
        except UnicodeDecodeError:
            continue
        if msg != "not an input launcher":
            seen += 1
            print(f"[v34f] {p.relative_to(root)}: {msg}")
            patched += int(changed)

    # Keep the fix alive at the exact point where v32x copies the launcher into
    # the staged rootfs.  The patcher is idempotent, so the hook is safe.
    builder = root / "build_from_v31c_layered_cache_v32x.sh"
    if builder.is_file():
        changed, msg = patch_builder_hook(builder)
        print(f"[v34f] {builder.name}: {msg}")

    if seen == 0:
        print("FAIL: no Groovebox evdev launcher was found to patch", file=sys.stderr)
        return 4

    active = root / "groovebox-appliance-direct-v32t"
    if active.is_file() and MARKER not in active.read_text(errors="ignore"):
        print("FAIL: active v32t launcher did not receive v34f pointer priority", file=sys.stderr)
        return 5

    print(f"PASS: v34f dynamic input priority applied ({patched} newly patched launcher(s))")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
