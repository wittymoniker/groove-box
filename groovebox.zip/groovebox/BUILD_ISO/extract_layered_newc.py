#!/usr/bin/env python3
"""Extract every concatenated newc cpio layer from a gzip initramfs.

Later archive entries overwrite earlier entries, matching the effective
initramfs view used by the Groovebox verifiers.
"""
from pathlib import Path
import gzip, os, stat, sys, shutil

def a4(n): return (n + 3) & ~3

def safe_rel(name: str):
    while name.startswith("./"):
        name = name[2:]
    name = name.lstrip("/")
    parts = [p for p in name.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise RuntimeError(f"unsafe cpio path: {name!r}")
    return Path(*parts) if parts else Path(".")

def ensure_parent(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)

def remove_existing(path: Path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return
    if stat.S_ISDIR(st.st_mode) and not path.is_symlink():
        # Keep directories when the replacement is also a directory; caller
        # handles that case. Otherwise remove recursively.
        shutil.rmtree(path)
    else:
        path.unlink()

def apply_entry(root: Path, rel: Path, mode: int, uid: int, gid: int,
                mtime: int, body: bytes, rdevmaj: int, rdevmin: int):
    if str(rel) == ".":
        return
    out = root / rel
    typ = stat.S_IFMT(mode)
    perm = stat.S_IMODE(mode)

    if typ == stat.S_IFDIR:
        if out.exists() and not out.is_dir():
            remove_existing(out)
        out.mkdir(parents=True, exist_ok=True)
    elif typ == stat.S_IFLNK:
        ensure_parent(out)
        remove_existing(out)
        out.symlink_to(body.decode("utf-8", "surrogateescape"))
    elif typ == stat.S_IFREG:
        ensure_parent(out)
        if out.exists() and out.is_dir() and not out.is_symlink():
            shutil.rmtree(out)
        elif out.exists() or out.is_symlink():
            try: out.unlink()
            except IsADirectoryError: shutil.rmtree(out)
        with open(out, "wb") as fh:
            fh.write(body)
    elif typ in (stat.S_IFCHR, stat.S_IFBLK):
        ensure_parent(out)
        remove_existing(out)
        try:
            os.mknod(out, mode, os.makedev(rdevmaj, rdevmin))
        except PermissionError:
            # Builder is normally run under sudo. If a device node cannot be
            # created, fail rather than silently produce a damaged initramfs.
            raise
    elif typ == stat.S_IFIFO:
        ensure_parent(out)
        remove_existing(out)
        os.mkfifo(out, perm)
    elif typ == stat.S_IFSOCK:
        # Sockets are runtime objects and should not be persisted.
        return
    else:
        raise RuntimeError(f"unsupported cpio mode {mode:o} for {rel}")

    if typ != stat.S_IFLNK:
        try: os.chmod(out, perm, follow_symlinks=False)
        except (PermissionError, NotImplementedError): pass
    try: os.chown(out, uid, gid, follow_symlinks=False)
    except (PermissionError, NotImplementedError): pass
    if typ != stat.S_IFLNK:
        try: os.utime(out, (mtime, mtime), follow_symlinks=False)
        except (PermissionError, NotImplementedError, OSError): pass

def main():
    if len(sys.argv) != 3:
        print("usage: extract_layered_newc.py INITRAMFS_GZ DEST", file=sys.stderr)
        return 2
    src = Path(sys.argv[1])
    root = Path(sys.argv[2])
    root.mkdir(parents=True, exist_ok=True)

    data = gzip.open(src, "rb").read()
    pos = 0
    entries = 0
    trailers = 0

    while pos + 110 <= len(data):
        while pos < len(data) and data[pos] == 0:
            pos += 1
        if pos + 110 > len(data):
            break
        if data[pos:pos+6] not in (b"070701", b"070702"):
            hits = [x for x in (data.find(b"070701", pos+1),
                                data.find(b"070702", pos+1)) if x >= 0]
            if not hits:
                break
            pos = min(hits)
            continue

        h = data[pos:pos+110]
        mode = int(h[14:22], 16)
        uid = int(h[22:30], 16)
        gid = int(h[30:38], 16)
        mtime = int(h[46:54], 16)
        size = int(h[54:62], 16)
        rdevmaj = int(h[78:86], 16)
        rdevmin = int(h[86:94], 16)
        namesz = int(h[94:102], 16)
        pos += 110

        nb = data[pos:pos+namesz]
        if len(nb) != namesz:
            raise RuntimeError("truncated cpio filename")
        name = nb[:-1].decode("utf-8", "surrogateescape")
        pos = a4(pos + namesz)

        body = data[pos:pos+size]
        if len(body) != size:
            raise RuntimeError(f"truncated cpio body: {name}")
        pos = a4(pos + size)

        if name == "TRAILER!!!":
            trailers += 1
            continue

        rel = safe_rel(name)
        apply_entry(root, rel, mode, uid, gid, mtime, body, rdevmaj, rdevmin)
        entries += 1

    if entries == 0 or trailers == 0:
        raise RuntimeError("no usable newc archive entries/trailers found")

    print(f"PASS: layered initramfs extracted: {entries} entries across {trailers} cpio layer(s)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
