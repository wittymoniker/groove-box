#!/usr/bin/env python3
# GROOVEBOX_R22_LIVE_BOOT_VERIFIER_V32W_20260918
from __future__ import annotations
import gzip, pathlib, sys

def a4(n): return (n + 3) & ~3

def parse_newc_bytes(data: bytes):
    pos=0; last={}
    while pos+110 <= len(data):
        while pos < len(data) and data[pos] == 0: pos += 1
        if pos+110 > len(data): break
        if data[pos:pos+6] not in (b'070701', b'070702'):
            hits=[x for x in (data.find(b'070701',pos+1), data.find(b'070702',pos+1)) if x>=0]
            if not hits: break
            pos=min(hits); continue
        h=data[pos:pos+110]
        try:
            ns=int(h[94:102],16); fs=int(h[54:62],16)
        except ValueError: break
        pos+=110
        nb=data[pos:pos+ns]; name=nb[:-1].decode('utf-8','replace'); pos=a4(pos+ns)
        body=data[pos:pos+fs]; pos=a4(pos+fs)
        key=name[2:] if name.startswith('./') else name
        last[key]=body
        if key == 'TRAILER!!!':
            continue
    return last

def verify_map(files):
    init=files.get('init', b'')
    req=(
        b'GROOVEBOX_R22_LIVE_INIT_GUI_V32W_20260918',
        b'/usr/bin/groovebox-appliance',
        b'exec /usr/bin/sos-recovery-shell',
    )
    for x in req:
        if x not in init: raise SystemExit(f'FAIL: v32w live /init missing {x!r}')
    for bad in (b'exec /bin/sh', b'/bin/sh -i', b' sh -i', b'cttyhack', b'/usr/bin/sos-console'):
        if bad in init: raise SystemExit(f'FAIL: v32w live /init still contains legacy shell/console path {bad!r}')
    if init.find(b'/usr/bin/groovebox-appliance') > init.find(b'exec /usr/bin/sos-recovery-shell'):
        raise SystemExit('FAIL: recovery precedes Groovebox in live /init')
    rec=files.get('usr/bin/sos-recovery-shell', b'')
    if b'GROOVEBOX_R22_NOJOB_RECOVERY_MENU_V32W_20260918' not in rec:
        raise SystemExit('FAIL: v32w recovery menu missing')
    for bad in (b'/bin/sh -i', b' sh -i', b'cttyhack'):
        if bad in rec: raise SystemExit(f'FAIL: recovery still contains {bad!r}')
    # No auto-start service may still invoke the legacy console or an interactive shell.
    offenders=[]
    for k,v in files.items():
        if not k.startswith('etc/sos/services/') or not v: continue
        if b'sos-console' in v or b'/bin/sh -i' in v or b'cttyhack' in v:
            offenders.append(k)
    if offenders: raise SystemExit('FAIL: legacy auto-console service still active: '+', '.join(offenders))
    marker=files.get('opt/sos/live-boot-v32w.txt', b'')
    if b'automatic_sos_console=disabled' not in marker:
        raise SystemExit('FAIL: v32w boot-state marker missing')
    con=files.get('usr/bin/sos-console', b'')
    if con and b'GROOVEBOX_R22_LEGACY_CONSOLE_DISABLED_V32W_20260918' not in con:
        raise SystemExit('FAIL: active legacy sos-console binary was not neutralized')
    print('PASS: v32w live /init boots Groovebox directly; legacy sos-console autostart and interactive-shell fallbacks are absent')

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: verify_live_boot_v32w.py ROOTFS_OR_INITRAMFS')
    p=pathlib.Path(sys.argv[1])
    if p.is_dir():
        files={}
        for rel in ('init','usr/bin/sos-recovery-shell','usr/bin/sos-console','opt/sos/live-boot-v32w.txt'):
            q=p/rel
            if q.exists(): files[rel]=q.read_bytes()
        sd=p/'etc/sos/services'
        if sd.is_dir():
            for q in sd.iterdir():
                if q.is_file(): files[str(q.relative_to(p))]=q.read_bytes()
        verify_map(files); return
    data=gzip.open(p,'rb').read()
    verify_map(parse_newc_bytes(data))
if __name__=='__main__': main()
