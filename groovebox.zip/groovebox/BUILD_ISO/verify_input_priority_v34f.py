#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, tempfile

MARKER='GROOVEBOX_V34F_TOUCHPAD_PRIORITY_20260919'
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
if root.name!='BUILD_ISO' and (root/'BUILD_ISO').is_dir(): root=root/'BUILD_ISO'
active=root/'groovebox-appliance-direct-v32t'
if not active.is_file(): raise SystemExit('FAIL: active groovebox-appliance-direct-v32t missing')
s=active.read_text(errors='strict')
need=[
    MARKER,
    "'touchpad|synaptics|elan|alps' 'trackpoint|pointing stick' 'mouse'",
    'find_pointer_event_by_name',
    'find_pointer_event_by_handler',
    'QT_QPA_EVDEV_MOUSE_PARAMETERS',
    'QT_QPA_EVDEV_KEYBOARD_PARAMETERS',
]
for tok in need:
    if tok not in s: raise SystemExit('FAIL: missing v34f token: '+tok)
# Ensure the touchpad priority token occurs before generic mouse in the priority loop.
pos_touch=s.index("'touchpad|synaptics|elan|alps'")
pos_mouse=s.index("'mouse'", pos_touch)
if pos_touch >= pos_mouse: raise SystemExit('FAIL: pointer priority order is wrong')
rc=subprocess.run(['/bin/sh','-n',str(active)]).returncode
if rc: raise SystemExit('FAIL: patched active launcher fails POSIX shell syntax')

# Regression model of the user's photographed Dell /proc ordering.
sample=[
    ('AT Translated Set 2 keyboard','event0'),
    ('DELL0EED:00 27C6:01E0 Mouse','event1'),
    ('DELL0EED:00 27C6:01E0 Touchpad','event2'),
    ('PS/2 Generic Mouse','event3'),
]
def score(name):
    n=name.lower()
    if any(k in n for k in ('touchpad','synaptics','elan','alps')): return 0
    if any(k in n for k in ('trackpoint','pointing stick')): return 1
    if 'mouse' in n: return 2
    return 99
picked=min(sample, key=lambda x: score(x[0]))
if picked[1] != 'event2': raise SystemExit('FAIL: regression model did not select Dell touchpad event2')
print('PASS: v34f active launcher is shell-clean and prioritizes Dell touchpad event2 over event1/event3')
