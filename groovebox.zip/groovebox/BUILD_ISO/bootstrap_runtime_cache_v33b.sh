#!/usr/bin/env bash
set -euo pipefail
[[ $# -ge 1 ]] || { echo 'usage: bootstrap_runtime_cache_v33b.sh GROOVEBOX_ROOT' >&2; exit 2; }
ROOT="$(cd "$1" && pwd)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BI="$ROOT/BUILD_ISO"
CACHE="$BI/dist/runtime-cache/initramfs.full.img"
VERIFY="$HERE/verify_v31c.py"
PATCHER="$HERE/patch_bridge_v31c.py"

[[ -d "$BI" ]] || { echo "FAIL: BUILD_ISO directory missing under $ROOT" >&2; exit 3; }
mkdir -p "$BI/dist/runtime-cache"

cache_ok() {
    [[ -s "$1" ]] || return 1
    gzip -t "$1" >/dev/null 2>&1 || return 1
    python3 "$VERIFY" "$1" >/dev/null 2>&1 || return 1
}

runtime_ok() {
    local f="$1"
    [[ -s "$f" ]] || return 1
    gzip -t "$f" >/dev/null 2>&1 || return 1
    python3 - "$f" <<'PY' >/dev/null 2>&1
from pathlib import Path
import gzip,sys
p=Path(sys.argv[1])
data=gzip.open(p,'rb').read()
def a4(n): return (n+3)&~3
pos=0; last={}
while pos+110<=len(data):
    while pos<len(data) and data[pos]==0: pos+=1
    if pos+110>len(data): break
    if data[pos:pos+6] not in (b'070701',b'070702'):
        hs=[x for x in (data.find(b'070701',pos+1),data.find(b'070702',pos+1)) if x>=0]
        if not hs: break
        pos=min(hs); continue
    h=data[pos:pos+110]
    ns=int(h[94:102],16); fs=int(h[54:62],16)
    pos+=110; nb=data[pos:pos+ns]
    name=nb[:-1].decode('utf-8','replace')
    pos=a4(pos+ns); body=data[pos:pos+fs]; pos=a4(pos+fs)
    key=name[2:] if name.startswith('./') else name
    last[key]=body
need=[
 'opt/groovebox/scode_optimizer_bridge.py',
 'usr/bin/groovebox-appliance',
 'opt/pyvenv/bin/python3',
 'opt/groovebox/sCode/bootstrap/linux-x86_64/scode0',
]
missing=[x for x in need if x not in last]
if missing:
    raise SystemExit('missing: '+', '.join(missing))
PY
}

if cache_ok "$CACHE"; then
    echo "PASS: v33b runtime cache already present and clean v31c: $CACHE"
    exit 0
fi

# Prefer the long-lived runtime foundation. Then accept a usable staged cache or
# the initrd currently referenced by iso-root. Never overwrite the source file.
candidates=()
add_candidate() { [[ -n "${1:-}" ]] && candidates+=("$1"); }
add_candidate "$BI/runtime-base/initramfs.img"
add_candidate "$BI/runtime-base/initramfs.full.img"
add_candidate "$BI/initramfs.img"
add_candidate "$BI/dist/runtime-cache/initramfs.img"

for f in "$BI"/dist/runtime-cache/initramfs.v31c*.img \
         "$BI"/dist/runtime-cache/initramfs.v31*.img \
         "$BI"/dist/runtime-cache/initramfs.full*.img; do
    [[ -e "$f" ]] && add_candidate "$f"
done

for tree in "$BI/iso-root" "$ROOT/iso-root"; do
    cfg="$tree/boot/grub/grub.cfg"
    if [[ -f "$cfg" ]]; then
        rel="$(awk '/^[[:space:]]*initrd([[:space:]]|$)/ {for(i=2;i<=NF;i++) if($i !~ /^--/){print $i; exit}}' "$cfg")"
        [[ -n "$rel" ]] && add_candidate "$tree/${rel#/}"
    fi
done

SRC=''
seen='|'
for f in "${candidates[@]}"; do
    [[ -n "$f" ]] || continue
    case "$seen" in *"|$f|"*) continue ;; esac
    seen+="$f|"
    if runtime_ok "$f"; then SRC="$f"; break; fi
done

if [[ -z "$SRC" ]]; then
    echo 'FAIL: no usable full Groovebox runtime initramfs was found.' >&2
    echo 'Checked the persistent runtime foundation, runtime-cache, and iso-root initrd.' >&2
    echo "Expected first-choice source: $BI/runtime-base/initramfs.img" >&2
    exit 4
fi

echo "[v33b] seeding runtime cache from: $SRC"
cp -f "$SRC" "$CACHE"
gzip -t "$CACHE"

# If the source predates clean v31c, repair only the active sCode bridge via a
# tiny later cpio overlay. This preserves the rest of the runtime byte-for-byte.
if ! python3 "$VERIFY" "$CACHE" >/dev/null 2>&1; then
    echo '[v33b] runtime source predates clean v31c; repairing sCode bridge overlay'
    WORK="$BI/dist/.v33b-cache-bootstrap"
    rm -rf "$WORK"; mkdir -p "$WORK/original" "$WORK/overlay/opt/groovebox"
    trap 'rm -rf "$WORK" 2>/dev/null || true' EXIT
    python3 - "$CACHE" "$WORK/original/scode_optimizer_bridge.py" <<'PY'
from pathlib import Path
import gzip,sys
data=gzip.open(sys.argv[1],'rb').read()
def a4(n): return (n+3)&~3
pos=0; found=None
while pos+110<=len(data):
    while pos<len(data) and data[pos]==0: pos+=1
    if pos+110>len(data): break
    if data[pos:pos+6] not in (b'070701',b'070702'):
        hs=[x for x in (data.find(b'070701',pos+1),data.find(b'070702',pos+1)) if x>=0]
        if not hs: break
        pos=min(hs); continue
    h=data[pos:pos+110]; ns=int(h[94:102],16); fs=int(h[54:62],16)
    pos+=110; nb=data[pos:pos+ns]; name=nb[:-1].decode('utf-8','replace')
    pos=a4(pos+ns); body=data[pos:pos+fs]; pos=a4(pos+fs)
    key=name[2:] if name.startswith('./') else name
    if key=='opt/groovebox/scode_optimizer_bridge.py': found=body
if found is None: raise SystemExit('FAIL: active sCode bridge not found')
Path(sys.argv[2]).write_bytes(found)
PY
    cp "$WORK/original/scode_optimizer_bridge.py" "$WORK/overlay/opt/groovebox/scode_optimizer_bridge.py"
    python3 "$PATCHER" "$WORK/overlay/opt/groovebox/scode_optimizer_bridge.py"
    python3 -m py_compile "$WORK/overlay/opt/groovebox/scode_optimizer_bridge.py"
    ( cd "$WORK/overlay" && find . -print0 | LC_ALL=C sort -z | cpio --null -o --quiet -H newc --owner=0:0 ) > "$WORK/v31c-overlay.cpio"
    {
      gzip -dc "$CACHE"
      cat "$WORK/v31c-overlay.cpio"
    } | gzip -9n > "$WORK/initramfs.full.v31c.img"
    gzip -t "$WORK/initramfs.full.v31c.img"
    python3 "$VERIFY" "$WORK/initramfs.full.v31c.img"
    mv -f "$WORK/initramfs.full.v31c.img" "$CACHE"
fi

python3 "$VERIFY" "$CACHE"
sha256sum "$CACHE" > "$CACHE.sha256"
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    u="$SUDO_USER"; g="$(id -gn "$u" 2>/dev/null || printf '%s' "$u")"
    chown "$u:$g" "$CACHE" "$CACHE.sha256" 2>/dev/null || true
fi
echo "PASS: v33b runtime cache ready: $CACHE"
