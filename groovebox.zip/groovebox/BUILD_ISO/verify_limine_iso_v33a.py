#!/usr/bin/env python3
from pathlib import Path
import struct,hashlib,sys
if len(sys.argv)!=3: raise SystemExit('usage: verify_limine_iso_v33a.py ISO OFFICIAL_UEFI_IMAGE')
p=Path(sys.argv[1]); b=p.read_bytes(); sec=2048
assert b[16*sec+1:16*sec+6]==b'CD001','PVD missing'
assert b[17*sec+1:17*sec+6]==b'CD001','El Torito boot record missing'
cat_lba=struct.unpack('<I',b[17*sec+71:17*sec+75])[0]; cat=b[cat_lba*sec:(cat_lba+1)*sec]
assert cat[0]==1 and cat[30:32]==b'\x55\xaa','boot catalog validation entry bad'
assert sum(struct.unpack('<16H',cat[:32]))&0xffff==0,'boot catalog checksum bad'
assert cat[32]==0x88,'BIOS default entry not bootable'
assert cat[64] in (0x90,0x91) and cat[65]==0xEF,'UEFI section missing'
uefi_lba=struct.unpack('<I',cat[104:108])[0]
uefi_count=struct.unpack('<H',cat[102:104])[0]
o=Path(sys.argv[2]).read_bytes(); region=b[uefi_lba*sec:uefi_lba*sec+len(o)]
assert region==o,'embedded UEFI FAT image differs from official Limine payload'
ent=b[446:462]; start=struct.unpack('<I',ent[8:12])[0]; count=struct.unpack('<I',ent[12:16])[0]
assert ent[4]==0xEF and start==uefi_lba*4 and count==len(o)//512,'MBR EFI partition does not map UEFI image'
assert b[510:512]==b'\x55\xaa','MBR signature missing'
# Confirm required names are visible in ISO directory bytes.
for token in (b'LIMINE.CONF;1',b'LIMINE-BIOS.SYS;1',b'VMLINUZ;1',b'INITRAMF.IMG;1',b'BOOTX64.EFI;1'):
    assert token in b, f'missing ISO record {token!r}'
print('PASS: ISO9660 PVD')
print('PASS: El Torito BIOS + UEFI catalog')
print('PASS: official Limine UEFI FAT image byte-exact')
print('PASS: MBR EFI partition maps embedded FAT image')
print('PASS: required Limine/kernel/initramfs records present')
print('SHA256',hashlib.sha256(b).hexdigest())
