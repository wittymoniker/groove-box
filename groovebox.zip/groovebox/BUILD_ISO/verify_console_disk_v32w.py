#!/usr/bin/env python3
# GROOVEBOX_R23_VERIFY_CONSOLE_IO_V32X_20260918
from pathlib import Path
import gzip, sys

def a4(n): return (n + 3) & ~3

def parse_newc(blob: bytes):
    out={}; pos=0
    while pos+110<=len(blob):
        while pos < len(blob) and blob[pos] == 0: pos += 1
        if pos+110>len(blob): break
        magic=blob[pos:pos+6]
        if magic not in (b'070701',b'070702'):
            hits=[x for x in (blob.find(b'070701',pos+1),blob.find(b'070702',pos+1)) if x>=0]
            if not hits: break
            pos=min(hits); continue
        hdr=blob[pos:pos+110]
        try:
            namesz=int(hdr[94:102],16); size=int(hdr[54:62],16)
        except ValueError: break
        pos+=110
        raw=blob[pos:pos+namesz]
        name=raw[:-1].decode('utf-8','replace') if namesz else ''
        pos=a4(pos+namesz)
        data=blob[pos:pos+size]
        pos=a4(pos+size)
        key=name[2:] if name.startswith('./') else name
        if key != 'TRAILER!!!': out[key]=data
    return out

def verify(files):
    need={
      'usr/bin/groovebox-appliance':b'GROOVEBOX_R19_CONSOLE_IO_GUI_RESTORE_V32T_20260918',
      'usr/bin/sos-install-appliance':b'GROOVEBOX_R19_CONSOLE_IO_DISK_V32T_20260918',
      'usr/bin/sos-recovery-shell':b'GROOVEBOX_R22_NOJOB_RECOVERY_MENU_V32W_20260918',
      'usr/lib/sos/sos-install-appliance.real-v32q':b'GROOVEBOX_R16_DISK_BACKEND_V32Q_20260918',
    }
    for name,mark in need.items():
        data=files.get(name)
        if not data: raise SystemExit(f'FAIL: v32x file missing: {name}')
        if mark not in data: raise SystemExit(f'FAIL: v32x marker missing: {name}')
    for name in ('usr/bin/groovebox-appliance','usr/bin/sos-install-appliance','usr/bin/sos-recovery-shell'):
        data=files[name]
        for bad in (b'cttyhack', b'/bin/sh -i', b' sh -i'):
            if bad in data: raise SystemExit(f'FAIL: job-control shell path remains in {name}: {bad!r}')
    install=files['usr/bin/sos-install-appliance']
    if b'<"$CONSOLE" >"$CONSOLE" 2>&1' not in install:
        raise SystemExit('FAIL: v32x Copy-to-Disk is not wired directly to console stdio')
    rec=files['usr/bin/sos-recovery-shell']
    if b'sOS recovery menu v32w' not in rec or b'while :' not in rec:
        raise SystemExit('FAIL: v32x v32w recovery menu missing')
    app=files['usr/bin/groovebox-appliance']
    for x in (b'GROOVEBOX_R14_CURSOR_SYNC_V32O_20260918',b'nocompress:grab=0',b'GROOVEBOX_SOFTWARE_CURSOR=1'):
        if x not in app: raise SystemExit(f'FAIL: v32x known-good v32o GUI path missing {x!r}')
    print('PASS: v32x accepts v32w non-shell recovery menu and retains direct-console disk + known-good v32o GUI path')

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: verify_console_disk_v32w.py INITRAMFS_OR_ROOTFS')
    p=Path(sys.argv[1])
    if p.is_dir():
        files={}
        for name in ('usr/bin/groovebox-appliance','usr/bin/sos-install-appliance','usr/bin/sos-recovery-shell','usr/lib/sos/sos-install-appliance.real-v32q'):
            q=p/name
            if q.exists() or q.is_symlink():
                files[name]=q.read_bytes()
        verify(files); return
    with gzip.open(p,'rb') as f: files=parse_newc(f.read())
    verify(files)
if __name__=='__main__': main()
