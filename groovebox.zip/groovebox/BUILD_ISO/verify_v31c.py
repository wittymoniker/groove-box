#!/usr/bin/env python3
from pathlib import Path
import gzip, sys

MARK = "GROOVEBOX_R5_SCODE_POOL_FALLBACK_V31C_20260918"

def a4(n): return (n+3)&~3

def parse_last(path):
    data=gzip.open(path,"rb").read()
    pos=0
    last={}
    while pos+110 <= len(data):
        while pos < len(data) and data[pos] == 0:
            pos += 1
        if pos+110 > len(data):
            break
        if data[pos:pos+6] not in (b"070701",b"070702"):
            hits=[x for x in (data.find(b"070701",pos+1),data.find(b"070702",pos+1)) if x>=0]
            if not hits:
                break
            pos=min(hits)
            continue
        h=data[pos:pos+110]
        ns=int(h[94:102],16); fs=int(h[54:62],16)
        pos+=110
        nb=data[pos:pos+ns]
        name=nb[:-1].decode("utf-8","replace")
        pos=a4(pos+ns)
        body=data[pos:pos+fs]
        pos=a4(pos+fs)
        key=name[2:] if name.startswith("./") else name
        last[key]=body
    return last

def main():
    if len(sys.argv)!=2:
        print("usage: verify_v31c.py INITRAMFS",file=sys.stderr); return 2
    last=parse_last(Path(sys.argv[1]))
    bridge=last.get("opt/groovebox/scode_optimizer_bridge.py")
    if not bridge:
        raise SystemExit("FAIL: bridge missing")
    txt=bridge.decode("utf-8","replace")
    checks=[
        MARK,
        "def _builtin_pool_catalog():",
        'if "usage:" in msg or "groovebox_optimizer.sc" in msg:',
        "return self._builtin_pool_catalog()",
    ]
    bad=[x for x in checks if x not in txt]
    if bad:
        raise SystemExit("FAIL: v31c bridge checks missing: "+", ".join(bad))
    if r'\"\"\"Exact host mirror' in txt:
        raise SystemExit("FAIL: malformed escaped v31 docstring still active")
    print("PASS: active initramfs bridge is clean v31c")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
