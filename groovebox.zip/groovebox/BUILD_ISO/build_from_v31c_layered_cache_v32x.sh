#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$(pwd)}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BI="$ROOT/BUILD_ISO"
CACHE="$BI/dist/runtime-cache/initramfs.full.img"
NEWCACHE="$BI/dist/runtime-cache/initramfs.v32x-recovery-verifier-fix.img"
OUT="${GROOVEBOX_ISO_OUT:-$BI/dist/Groovebox-sOS-x86_64-20260918-RECOVERY-VERIFIER-FIX-v32x.iso}"
[[ $EUID -eq 0 ]] || { echo 'FAIL: run with sudo' >&2; exit 2; }
for x in gzip find sha256sum python3 cpio readelf ldconfig file depmod modinfo ar tar; do
  command -v "$x" >/dev/null 2>&1 || { echo "FAIL: required host tool missing: $x" >&2; exit 2; }
done
[[ -s "$CACHE" ]] || { echo "FAIL: source cache missing: $CACHE" >&2; exit 3; }

echo '[v32x] validating clean full runtime cache'
gzip -t "$CACHE"
python3 "$HERE/verify_v31c.py" "$CACHE"

WORK="$BI/dist/.v32x-cache-patch"
rm -rf "$WORK"; mkdir -p "$WORK/root"
trap 'rm -rf "$WORK" 2>/dev/null || true' EXIT
python3 "$HERE/extract_layered_newc.py" "$CACHE" "$WORK/root"
ROOTFS="$WORK/root"
[[ -x "$ROOTFS/usr/bin/groovebox-appliance" ]] || { echo 'FAIL: launcher missing' >&2; exit 4; }
[[ -x "$ROOTFS/opt/pyvenv/bin/python3" ]] || { echo 'FAIL: guest Python missing' >&2; exit 4; }
[[ -f "$ROOTFS/opt/groovebox/scode_optimizer_bridge.py" ]] || { echo 'FAIL: sCode bridge missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_R5_SCODE_POOL_FALLBACK_V31C_20260918' "$ROOTFS/opt/groovebox/scode_optimizer_bridge.py" || { echo 'FAIL: effective bridge is not clean v31c' >&2; exit 4; }

if [[ -f "$BI/iso-root/boot/grub/grub.cfg" ]]; then
  ISO_TREE="$BI/iso-root"
elif [[ -f "$ROOT/iso-root/boot/grub/grub.cfg" ]]; then
  ISO_TREE="$ROOT/iso-root"
else
  echo 'FAIL: iso-root/boot/grub/grub.cfg not found' >&2; exit 5
fi
CFG="$ISO_TREE/boot/grub/grub.cfg"
KERNEL_IMG="$(find "$ISO_TREE/boot" -maxdepth 2 -type f \( -name 'vmlinuz*' -o -name 'bzImage*' -o -name 'linux-*' \) -print | head -1 || true)"
TARGET_KVER=''
if [[ -n "$KERNEL_IMG" && -f "$KERNEL_IMG" ]]; then
  TARGET_KVER="$(file -b "$KERNEL_IMG" | sed -nE 's/.*[Vv]ersion[[:space:]]+([^[:space:]]+).*/\1/p' | head -1)"
  echo "[v32x] ISO kernel image: $KERNEL_IMG"
  [[ -n "$TARGET_KVER" ]] && echo "[v32x] ISO kernel release: $TARGET_KVER"
fi
if [[ -z "$TARGET_KVER" && -d "$ROOTFS/lib/modules" ]]; then
  mapfile -t KDIRS < <(find "$ROOTFS/lib/modules" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort)
  if [[ ${#KDIRS[@]} -eq 1 ]]; then TARGET_KVER="${KDIRS[0]}"; fi
fi
if [[ -z "$TARGET_KVER" ]]; then
  TARGET_KVER="$(uname -r)"
  echo "[v32x] WARNING: could not read ISO kernel release; falling back to host kernel $TARGET_KVER"
fi
if [[ -n "$KERNEL_IMG" && -s "$KERNEL_IMG" ]]; then
  mkdir -p "$ROOTFS/boot" "$ROOTFS/opt/sos/lib"
  cp -f "$KERNEL_IMG" "$ROOTFS/boot/vmlinuz-$TARGET_KVER"
  printf 'kernel_release=%s\nsource=%s\n' "$TARGET_KVER" "$KERNEL_IMG" > "$ROOTFS/opt/sos/lib/copy-to-disk-kernel-v32q.txt"
else
  echo 'FAIL: v32q Copy-to-Disk requires the ISO kernel image to be discoverable.' >&2
  exit 5
fi

MODULE_TREE=''
if [[ -d "/lib/modules/$TARGET_KVER" ]]; then
  MODULE_TREE="/lib/modules/$TARGET_KVER"
elif [[ -d "/usr/lib/modules/$TARGET_KVER" ]]; then
  MODULE_TREE="/usr/lib/modules/$TARGET_KVER"
else
  echo '[v32x] exact module tree is not installed on Fedora; preparing it automatically from the Debian .deb'
  MODULE_TREE="$("$HERE/prepare_debian_kernel_modules_v32n.sh" "$TARGET_KVER" "$ROOT" "$BI")"
fi
[[ -d "$MODULE_TREE" ]] || { echo "FAIL: exact module tree preparation failed: $MODULE_TREE" >&2; exit 5; }
echo "[v32x] exact module tree: $MODULE_TREE"

if [[ ! -x "$ROOTFS/usr/bin/groovebox-appliance.real" ]]; then
  cp -a "$ROOTFS/usr/bin/groovebox-appliance" "$ROOTFS/usr/bin/groovebox-appliance.real"
fi
sed -i \
  -e 's/export QT_QPA_PLATFORM=xcb/export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-xcb}"/g' \
  -e 's/QT_QPA_PLATFORM=xcb/QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-xcb}"/g' \
  -e 's/export LANG=C$/export LANG=C.UTF-8/g' \
  -e 's/export LC_ALL=C$/export LC_ALL=C.UTF-8/g' \
  "$ROOTFS/usr/bin/groovebox-appliance.real" || true

# GROOVEBOX_V34O_GUI_RUNTIME_HOOK_20260919
# GROOVEBOX_V34P_RUNTIME_CHECK_STAGING_20260919
# The QPA probe uses /opt/pyvenv, so the real GUI must use the same Python and
# must not overwrite the QPA backend selected by the successful probe.
python3 "$HERE/patch_gui_runtime_v34o.py" "$ROOTFS"
install -m 0755 "$HERE/groovebox-runtime-check-v34p" "$ROOTFS/usr/bin/groovebox-runtime-check"

# Keep the working v32p cursor/trackpad path.
# GROOVEBOX_V34F_PATCH_HOOK
python3 "$HERE/patch_input_priority_v34f.py" "$HERE"
install -m 0755 "$HERE/groovebox-appliance-direct-v32t" "$ROOTFS/usr/bin/groovebox-appliance"
mkdir -p "$ROOTFS/opt/sos/qt-cursor-fix"
install -m 0644 "$HERE/qt_cursor_sync_sitecustomize_v32p.py" "$ROOTFS/opt/sos/qt-cursor-fix/sitecustomize.py"
install -m 0755 "$HERE/sos-recovery-shell-v32w" "$ROOTFS/usr/bin/sos-recovery-shell"
# v32w fixes the actual live PID-1 path as well as the recovery helper. The old
# sOS core-console service could own tty1 before Groovebox launched, and /init
# could still fall through to an interactive BusyBox shell.
python3 "$HERE/patch_live_boot_v32w.py" "$ROOTFS"
python3 "$HERE/verify_live_boot_v32w.py" "$ROOTFS"
install -m 0755 "$HERE/groovebox-display-check-v32m" "$ROOTFS/usr/bin/groovebox-display-check"
install -m 0755 "$HERE/groovebox-input-check-v32m" "$ROOTFS/usr/bin/groovebox-input-check"
install -m 0755 "$HERE/groovebox-kernel-input-prep-v32m" "$ROOTFS/usr/bin/groovebox-kernel-input-prep"

echo '[v32x] bundling Qt bare-metal graphics dependencies'
python3 "$HERE/bundle_qt_graphics_libs_v32l.py" "$ROOTFS"
echo '[v32x] validating/bundling Qt embedded input plugins'
python3 "$HERE/bundle_qt_input_plugins_v32l.py" "$ROOTFS"
echo '[v32x] installing local font fallback'
python3 "$HERE/install_fonts_v32l.py" "$ROOTFS"
echo '[v32x] bundling exact-kernel evdev + touchpad driver dependency closure'
python3 "$HERE/bundle_kernel_input_modules_v32n.py" "$ROOTFS" "$TARGET_KVER" "$MODULE_TREE"

# v32q does NOT require a desktop-Linux installer stack inside the live image.
# It brings only the two filesystem formatters from Debian, creates GPT itself
# with the bundled Python runtime, copies the root with Python, and uses a
# prebuilt removable-UEFI GRUB loader + a tiny installed-root initramfs.
mkdir -p "$ROOTFS/usr/lib/sos" "$ROOTFS/opt/sos/install-v32q"
if [[ -x "$ROOTFS/usr/bin/sos-install-appliance" ]]; then
  cp -a "$ROOTFS/usr/bin/sos-install-appliance" "$ROOTFS/usr/lib/sos/sos-install-appliance.previous-v32q" 2>/dev/null || true
fi
install -m 0755 "$HERE/gpt_disk_v32q.py" "$ROOTFS/usr/lib/sos/gpt_disk_v32q.py"
install -m 0755 "$HERE/copy_root_v32q.py" "$ROOTFS/usr/lib/sos/copy_root_v32q.py"
install -m 0755 "$HERE/sos-install-appliance-real-v32q" "$ROOTFS/usr/lib/sos/sos-install-appliance.real-v32q"
install -m 0755 "$HERE/sos-appliance-preflight-fallback-v32q" "$ROOTFS/usr/bin/sos-appliance-preflight"
rm -f "$ROOTFS/usr/lib/sos/tty_exec_v32s.py" 2>/dev/null || true
install -m 0755 "$HERE/sos-install-appliance-v32t" "$ROOTFS/usr/bin/sos-install-appliance"
ln -sf sos-install-appliance "$ROOTFS/usr/bin/sos-copy-to-disk"
ln -sf sos-install-appliance "$ROOTFS/usr/bin/copy-to-disk"

# GROOVEBOX_V34G_INSTALLER_STAGE_NOHANG_20260919
# Avoid re-entering the Debian formatter staging helper when the staged rootfs
# already has executable mkfs.ext4 and mkfs.vfat.  v32t's helper already makes
# that determination internally, but on the user's Dell build the parent build
# stopped immediately after the helper printed its no-download message.  This
# shell-side fast path removes that redundant process and the following cache
# hash when no mutation is possible.
guest_has_tool_v34g() {
  local n="$1" p
  for p in "usr/sbin/$n" "usr/bin/$n" "sbin/$n" "bin/$n"; do
    [[ -x "$ROOTFS/$p" ]] && return 0
  done
  return 1
}

echo '[v34g] checking staged Copy-to-Disk formatters'
if guest_has_tool_v34g mkfs.ext4 && guest_has_tool_v34g mkfs.vfat; then
  echo '[v34g] mkfs.ext4 + mkfs.vfat already executable in staged ROOTFS; skipping redundant v32t tool helper'
else
  echo '[v34g] staging mkfs.ext4 + mkfs.vfat without touching the live loader cache'
  LDCACHE_BEFORE=missing
  if [[ -f "$ROOTFS/etc/ld.so.cache" ]]; then
    LDCACHE_BEFORE="$(sha256sum "$ROOTFS/etc/ld.so.cache" | awk '{print $1}')"
  fi
  if command -v timeout >/dev/null 2>&1; then
    timeout 600s python3 -u "$HERE/prepare_debian_copy_tools_v32t.py" "$ROOTFS" "$BI" amd64
  else
    python3 -u "$HERE/prepare_debian_copy_tools_v32t.py" "$ROOTFS" "$BI" amd64
  fi
  LDCACHE_AFTER=missing
  if [[ -f "$ROOTFS/etc/ld.so.cache" ]]; then
    LDCACHE_AFTER="$(sha256sum "$ROOTFS/etc/ld.so.cache" | awk '{print $1}')"
  fi
  [[ "$LDCACHE_BEFORE" == "$LDCACHE_AFTER" ]] || { echo 'FAIL: v34g installer staging changed the live ld.so.cache' >&2; exit 4; }
fi
echo '[v34g] formatter stage complete; continuing to installed-root initramfs'

# GROOVEBOX_V34N_BUSYBOX_STAGE_HOOK_20260919
echo '[v34n] ensuring static BusyBox is available for installed-root initramfs'
python3 "$HERE/prepare_debian_busybox_v34n.py" "$ROOTFS" "$BI" amd64

echo '[v32x] building installed-root boot initramfs from exact storage modules'
python3 "$HERE/build_installed_initramfs_v32t.py" "$ROOTFS" "$TARGET_KVER" "$MODULE_TREE" "$ROOTFS/opt/sos/install-v32q/initramfs-sos-$TARGET_KVER.img"
printf '%s\n' "$TARGET_KVER" > "$ROOTFS/opt/sos/install-v32q/kernel-release"

echo '[v32x] building removable UEFI loader for Copy-to-Disk'
"$HERE/build_efi_boot_v32q.sh" "$ROOTFS" "$TARGET_KVER"

echo '[v32x] validating self-contained Copy-to-Disk payload'
python3 "$HERE/verify_installer_payload_v32v.py" "$ROOTFS" "$TARGET_KVER"

/bin/sh -n "$ROOTFS/init"
/bin/sh -n "$ROOTFS/usr/bin/groovebox-appliance"
/bin/sh -n "$ROOTFS/usr/bin/groovebox-appliance.real"
/bin/sh -n "$ROOTFS/usr/bin/sos-recovery-shell"
/bin/sh -n "$ROOTFS/usr/bin/sos-recovery"
/bin/sh -n "$ROOTFS/usr/bin/sos-install-appliance"
/bin/sh -n "$ROOTFS/usr/lib/sos/sos-install-appliance.real-v32q"
/bin/sh -n "$ROOTFS/usr/bin/sos-appliance-preflight"
/bin/sh -n "$ROOTFS/usr/bin/groovebox-display-check"
/bin/sh -n "$ROOTFS/usr/bin/groovebox-input-check"
/bin/sh -n "$ROOTFS/usr/bin/groovebox-kernel-input-prep"
/bin/sh -n "$ROOTFS/usr/bin/groovebox-runtime-check"
[[ -L "$ROOTFS/usr/bin/sos-copy-to-disk" ]] || { echo 'FAIL: sos-copy-to-disk alias missing' >&2; exit 4; }
[[ -L "$ROOTFS/usr/bin/copy-to-disk" ]] || { echo 'FAIL: copy-to-disk alias missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_R19_CONSOLE_IO_DISK_V32T_20260918' "$ROOTFS/usr/bin/sos-install-appliance" || { echo 'FAIL: v32t console-I/O disk wrapper missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_R22_NOJOB_RECOVERY_MENU_V32W_20260918' "$ROOTFS/usr/bin/sos-recovery-shell" || { echo 'FAIL: v32w no-job recovery menu missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_R19_CONSOLE_IO_GUI_RESTORE_V32T_20260918' "$ROOTFS/usr/bin/groovebox-appliance" || { echo 'FAIL: v32t GUI restore launcher missing' >&2; exit 4; }
[[ -s "$ROOTFS/usr/lib/x86_64-linux-gnu/libdrm.so.2" ]] || { echo 'FAIL: libdrm.so.2 missing' >&2; exit 4; }
find "$ROOTFS/usr/share/fonts/truetype/groovebox" -maxdepth 1 -type f \( -name '*.ttf' -o -name '*.otf' -o -name '*.ttc' \) | grep -q . || { echo 'FAIL: font fallback missing' >&2; exit 4; }
find "$ROOTFS/opt/pyvenv" -path '*/plugins/generic/*' -type f -name '*evdevkeyboard*.so' | grep -q . || { echo 'FAIL: Qt evdev keyboard plugin missing' >&2; exit 4; }
find "$ROOTFS/opt/pyvenv" -path '*/plugins/generic/*' -type f -name '*evdevmouse*.so' | grep -q . || { echo 'FAIL: Qt evdev mouse plugin missing' >&2; exit 4; }
[[ -s "$ROOTFS/opt/sos/lib/kernel-input-modules-v32m.txt" ]] || { echo 'FAIL: kernel input manifest missing' >&2; exit 4; }
[[ -s "$ROOTFS/opt/sos/qt-cursor-fix/sitecustomize.py" ]] || { echo 'FAIL: v32p software cursor hook missing' >&2; exit 4; }
grep -Eq '^evdev=(file|builtin)$' "$ROOTFS/opt/sos/lib/kernel-input-modules-v32m.txt" || { echo 'FAIL: evdev was not bundled/builtin' >&2; exit 4; }
grep -Eq '^(psmouse|i2c_hid|i2c_hid_acpi)=(file|builtin)$' "$ROOTFS/opt/sos/lib/kernel-input-modules-v32m.txt" || { echo 'FAIL: no pointer transport was bundled/builtin' >&2; exit 4; }

rm -f "$NEWCACHE" "$NEWCACHE.sha256"
( cd "$ROOTFS" && find . -xdev -print0 | cpio --null -o -H newc --quiet | gzip -9n ) > "$NEWCACHE"
gzip -t "$NEWCACHE"
python3 "$HERE/verify_v31c.py" "$NEWCACHE"
python3 "$HERE/verify_cursor_sync_v32t.py" "$NEWCACHE"
python3 "$HERE/verify_console_disk_v32w.py" "$NEWCACHE"
python3 "$HERE/verify_kernel_input_v32m.py" "$NEWCACHE"
python3 "$HERE/verify_live_boot_v32w.py" "$NEWCACHE"
sha256sum "$NEWCACHE" > "$NEWCACHE.sha256"

INITRD_REL="$(awk '/^[[:space:]]*initrd([[:space:]]|$)/ {for(i=2;i<=NF;i++) if($i !~ /^--/){print $i; exit}}' "$CFG")"
[[ -n "$INITRD_REL" ]] || { echo 'FAIL: no initrd path in grub.cfg' >&2; exit 6; }
INITRD_DST="$ISO_TREE/${INITRD_REL#/}"
mkdir -p "$(dirname "$INITRD_DST")"
cp -f "$NEWCACHE" "$INITRD_DST"

if command -v grub2-mkrescue >/dev/null 2>&1; then GRUB="$(command -v grub2-mkrescue)"
elif command -v grub-mkrescue >/dev/null 2>&1; then GRUB="$(command -v grub-mkrescue)"
else echo 'FAIL: grub2-mkrescue/grub-mkrescue missing' >&2; exit 7; fi
command -v xorriso >/dev/null 2>&1 || { echo 'FAIL: xorriso missing' >&2; exit 7; }
rm -f "$OUT" "$OUT.sha256"
echo '[v32x] assembling ISO'
"$GRUB" -o "$OUT" "$ISO_TREE"
[[ -s "$OUT" ]] || { echo 'FAIL: ISO not produced' >&2; exit 8; }
mkdir -p "$WORK/final"
xorriso -osirrox on -indev "$OUT" -extract "/${INITRD_REL#/}" "$WORK/final/initramfs.img" >/dev/null 2>&1
gzip -t "$WORK/final/initramfs.img"
python3 "$HERE/verify_v31c.py" "$WORK/final/initramfs.img"
python3 "$HERE/verify_cursor_sync_v32t.py" "$WORK/final/initramfs.img"
python3 "$HERE/verify_console_disk_v32w.py" "$WORK/final/initramfs.img"
python3 "$HERE/verify_kernel_input_v32m.py" "$WORK/final/initramfs.img"
python3 "$HERE/verify_live_boot_v32w.py" "$WORK/final/initramfs.img"
sha256sum "$OUT" > "$OUT.sha256"

u="${SUDO_USER:-}"
if [[ -n "$u" ]]; then
  g="$(id -gn "$u" 2>/dev/null || printf '%s' "$u")"
  chown "$u:$g" "$NEWCACHE" "$NEWCACHE.sha256" "$OUT" "$OUT.sha256" 2>/dev/null || true
fi

echo
echo 'PASS: v32x RECOVERY-VERIFIER + LIVE-INIT + CONSOLE-SERVICE + CONSOLE-IO + SELF-CONTAINED-DISK + GUI ISO VERIFIED'
echo "ISO: $OUT"
echo "SHA-256: $(cut -d' ' -f1 "$OUT.sha256")"
echo
echo 'v32x keeps the v32w live PID-1 /init route, disables the legacy auto-start sos-console service, and keeps recovery non-interactive; the GUI launcher is now the only automatic foreground application.'
