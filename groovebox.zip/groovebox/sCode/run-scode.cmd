@echo off
setlocal
set "ROOT=%~dp0"
for /f "usebackq delims=" %%I in (`py -3 "%ROOT%scripts\ensure-stage0.py"`) do set "SCODE0=%%I"
if not defined SCODE0 for /f "usebackq delims=" %%I in (`python "%ROOT%scripts\ensure-stage0.py"`) do set "SCODE0=%%I"
if not defined SCODE0 exit /b 1
"%SCODE0%" %*
exit /b %errorlevel%
