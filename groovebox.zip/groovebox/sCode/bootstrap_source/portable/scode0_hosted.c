#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
typedef long long i64; typedef unsigned long long u64;
static void os_out(const char *s){fputs(s,stdout);fflush(stdout);} static void os_err(const char*s){fputs(s,stderr);fflush(stderr);} static int os_env(const char*name,char*buf,int cap){const char*v=getenv(name);size_t n;if(!v||cap<=0)return 0;n=strlen(v);if(n>=(size_t)cap)n=(size_t)cap-1;memcpy(buf,v,n);buf[n]=0;return 1;}
#include "../native/scode0_core.h"
int main(int argc,char**argv){return scode_entry(argc,argv);}
