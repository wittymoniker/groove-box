.text
.globl _start
.p2align 2
_start:
    ldr x0, [sp]
    add x1, sp, #8
    add x2, x1, x0, lsl #3
    add x2, x2, #8
    bl _scode_boot_main
1:  b 1b
