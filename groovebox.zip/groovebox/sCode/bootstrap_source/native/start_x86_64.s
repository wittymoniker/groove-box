.text
.globl _start
.p2align 4, 0x90
_start:
    movq (%rsp), %rdi
    leaq 8(%rsp), %rsi
    leaq 16(%rsp,%rdi,8), %rdx
    andq $-16, %rsp
    callq _scode_boot_main
1:  jmp 1b
