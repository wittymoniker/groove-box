typedef unsigned long long u64; typedef long long i64; typedef unsigned char u8;
static char **g_envp;
void *memset(void*d,int c,u64 n){u8*p=(u8*)d;while(n--)*p++=(u8)c;return d;} void *memcpy(void*d,const void*s,u64 n){u8*a=d;const u8*b=s;while(n--)*a++=*b++;return d;}
#if defined(__x86_64__)
static long sys_write(long fd,const void*buf,unsigned long n){long r; register long a __asm__("rax")=0x2000004; register long d __asm__("rdi")=fd; register const void*b __asm__("rsi")=buf; register unsigned long z __asm__("rdx")=n; __asm__ volatile("syscall":"=a"(r):"a"(a),"D"(d),"S"(b),"d"(z):"rcx","r11","memory");return r;}
static void sys_exit(int c){register long a __asm__("rax")=0x2000001;register long d __asm__("rdi")=c;__asm__ volatile("syscall"::"a"(a),"D"(d):"rcx","r11","memory");for(;;){}}
#elif defined(__aarch64__)
static long sys_write(long fd,const void*buf,unsigned long n){register long x0 __asm__("x0")=fd;register const void*x1 __asm__("x1")=buf;register unsigned long x2 __asm__("x2")=n;register long x16 __asm__("x16")=4;__asm__ volatile("svc #0x80":"+r"(x0):"r"(x1),"r"(x2),"r"(x16):"memory");return x0;}
static void sys_exit(int c){register long x0 __asm__("x0")=c;register long x16 __asm__("x16")=1;__asm__ volatile("svc #0x80"::"r"(x0),"r"(x16):"memory");for(;;){}}
#endif
static void os_out(const char*s){int n=0;while(s[n])n++;sys_write(1,s,(unsigned long)n);}static void os_err(const char*s){int n=0;while(s[n])n++;sys_write(2,s,(unsigned long)n);}static int os_env(const char*name,char*buf,int cap){int nl=0,i,j;char**e=g_envp;while(name[nl])nl++;if(!e)return 0;for(i=0;e[i];i++){for(j=0;j<nl&&e[i][j]==name[j];j++);if(j==nl&&e[i][j]=='='){int k=0;j++;while(e[i][j]&&k<cap-1)buf[k++]=e[i][j++];buf[k]=0;return 1;}}return 0;}
#include "scode0_core.h"
int scode_boot_main(long argc,char**argv,char**envp){g_envp=envp;int rc=scode_entry((int)argc,argv);sys_exit(rc);return rc;}
