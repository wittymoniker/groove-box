# sCode Unified Desktop Distribution — 2026-09-13

One archive supports the six primary 64-bit desktop targets: Linux x86-64, Linux ARM64/AArch64, Windows x86-64, Windows ARM64, macOS Intel x86-64, and macOS Apple Silicon ARM64.

sCode stage-0 is native on every target. Python is only a provisioning coordinator and does not substitute for stage-0. Linux x86-64 and Windows x86-64 prebuilt stage-0 executables are included; other targets build natively on first launch from the bundled portable C source and shared ABI-9 core. Every executable must run and report `scode_stage0_native=1` and `scode_optimizer_abi=9` before use.

Linux/macOS: `./run-scode --probe` or `./run-scode run apps/groovebox/groovebox_optimizer.sC`

Windows: `run-scode.cmd --probe` or `run-scode.cmd run apps\groovebox\groovebox_optimizer.sC`

First-build compiler requirements: Linux C11 cc/gcc/clang; macOS Apple clang (`xcode-select --install`); Windows MSVC Build Tools C++, LLVM/clang, or MinGW gcc. Generated native binaries are cached in `bootstrap/<platform-arch>/`.

This package supplies the Groovebox-required ABI-9 native optimizer/planner stage-0 plus the broader sCode source/app tree. It does not falsely label stage-0 as the final arbitrary `.sC` native compiler/runtime.
