$ErrorActionPreference="Stop"
$Root=Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Arch=[System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString().ToLowerInvariant()
if($Arch -eq "x64"){$Target="windows-x86_64"}elseif($Arch -eq "arm64"){$Target="windows-arm64"}else{throw "Unsupported Windows architecture: $Arch"}
$OutDir=Join-Path $Root "bootstrap\$Target"; $Exe=Join-Path $OutDir "scode0.exe"; $Src=Join-Path $Root "bootstrap_source\portable\scode0_hosted.c"; New-Item -ItemType Directory -Force -Path $OutDir|Out-Null
$Built=$false; $cl=Get-Command cl.exe -ErrorAction SilentlyContinue
if($cl){Push-Location $OutDir; try{& $cl.Source /nologo /O2 /TC $Src "/Fe:$Exe"; if($LASTEXITCODE -eq 0){$Built=$true}}finally{Pop-Location}}
if(-not $Built){$cc=Get-Command clang.exe -ErrorAction SilentlyContinue; if(-not $cc){$cc=Get-Command gcc.exe -ErrorAction SilentlyContinue}; if($cc){& $cc.Source -O2 -std=c11 $Src -o $Exe; if($LASTEXITCODE -eq 0){$Built=$true}}}
if(-not $Built){throw "No native Windows C compiler found. Install Visual Studio Build Tools C++ or LLVM/clang."}
$probe=& $Exe --probe 2>&1; if($LASTEXITCODE -ne 0 -or ($probe -notmatch "scode_optimizer_abi=9")){throw "Native sCode stage-0 ABI-9 probe failed: $probe"}; Write-Host $Exe
