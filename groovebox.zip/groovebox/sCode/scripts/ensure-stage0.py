#!/usr/bin/env python3
import platform, subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[1]; s=platform.system().lower(); m=platform.machine().lower()
if s=='linux': t='linux-arm64' if m in ('aarch64','arm64') else 'linux-x86_64' if m in ('x86_64','amd64') else None; n='scode0'
elif s=='darwin': t='macos-arm64' if m in ('aarch64','arm64') else 'macos-x86_64' if m=='x86_64' else None; n='scode0'
elif s=='windows': t='windows-arm64' if m in ('aarch64','arm64') else 'windows-x86_64' if m in ('x86_64','amd64') else None; n='scode0.exe'
else: t=None; n='scode0'
if not t: raise SystemExit(f'Unsupported desktop target: {s}/{m}')
e=R/'bootstrap'/t/n
def ok(p):
    try:
        q=subprocess.run([str(p),'--probe'],text=True,capture_output=True,timeout=15); return q.returncode==0 and 'scode_optimizer_abi=9' in q.stdout+q.stderr
    except Exception:return False
if not ok(e):
    cmd=['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(R/'scripts'/'build-stage0-windows.ps1')] if s=='windows' else [str(R/'scripts'/('build-stage0-macos.sh' if s=='darwin' else 'build-stage0-linux.sh'))]
    if subprocess.run(cmd).returncode or not ok(e): raise SystemExit(f'Failed to provision native sCode stage-0 for {t}')
print(e)
