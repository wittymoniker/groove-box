#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd); ARCH=$(uname -m)
case "$ARCH" in x86_64) T=macos-x86_64;; arm64|aarch64) T=macos-arm64;; *) echo "Unsupported macOS architecture: $ARCH" >&2; exit 2;; esac
CC=${CC:-clang}; command -v "$CC" >/dev/null 2>&1 || { echo "Apple clang is required. Run: xcode-select --install" >&2; exit 1; }
mkdir -p "$ROOT/bootstrap/$T"; "$CC" -O2 -std=c11 "$ROOT/bootstrap_source/portable/scode0_hosted.c" -o "$ROOT/bootstrap/$T/scode0"; chmod +x "$ROOT/bootstrap/$T/scode0"; if command -v codesign >/dev/null 2>&1; then codesign --force --sign - "$ROOT/bootstrap/$T/scode0" >/dev/null 2>&1 || true; fi; "$ROOT/bootstrap/$T/scode0" --probe | grep -q 'scode_optimizer_abi=9'; echo "$ROOT/bootstrap/$T/scode0"
