#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd); ARCH=$(uname -m)
case "$ARCH" in x86_64|amd64) T=linux-x86_64;; aarch64|arm64) T=linux-arm64;; *) echo "Unsupported Linux architecture: $ARCH" >&2; exit 2;; esac
CC=${CC:-cc}; command -v "$CC" >/dev/null 2>&1 || { echo "A native C11 compiler is required." >&2; exit 1; }
mkdir -p "$ROOT/bootstrap/$T"; "$CC" -O2 -std=c11 "$ROOT/bootstrap_source/portable/scode0_hosted.c" -o "$ROOT/bootstrap/$T/scode0"; chmod +x "$ROOT/bootstrap/$T/scode0"; "$ROOT/bootstrap/$T/scode0" --probe | grep -q 'scode_optimizer_abi=9'; echo "$ROOT/bootstrap/$T/scode0"
