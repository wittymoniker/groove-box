# Native sCode stage-0 — Windows x86-64

`scode0.exe` is a native PE32+ first-stage sCode runtime for the Groovebox ABI-9 optimizer.
It is bundled and verified before Groovebox starts. If it is removed or fails validation,
`scripts/build_scode_stage0_windows.ps1` rebuilds it natively on Windows from the public-domain C bootstrap source.
