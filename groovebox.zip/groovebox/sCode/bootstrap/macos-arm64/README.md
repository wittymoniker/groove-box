# Native sCode stage-0 — macOS Apple Silicon

The launcher creates `scode0` here on first launch by compiling the public-domain C stage-0 source with the host macOS clang toolchain, then ad-hoc signs and ABI-9 probes it before Groovebox starts.
