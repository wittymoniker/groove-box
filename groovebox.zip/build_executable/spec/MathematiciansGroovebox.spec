# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules

hiddenimports = ['audio_os_backend', 'build', 'canonical_authority', 'canonical_cross_media', 'canonical_edit_list', 'canonical_engine_bridge', 'canonical_event_algebra', 'canonical_triad', 'composition_state', 'decentralized_mesh', 'dj_effects', 'engine_auditor', 'fast_widgets', 'finite_infinity', 'fractal_spatial_engine', 'groovebox_paths', 'hardware_hub', 'julia_bridge', 'mcc_filetype', 'mcc_integrity', 'media_cutup_engine', 'media_output_router', 'meum_compression', 'meum_constants', 'meum_ot_math', 'mg_artifacts', 'operation_station_transfer', 'ot_symbol_notation', 'performance', 'performance_box', 'performance_modules', 'pi_media_hub', 'program_identity', 'radio_station', 'relativity_projection', 'reverse_engineer', 'run_groovebox', 'scode_cli', 'scode_selfbuild', 'scode_update', 'signal_lab', 'standalone_import_audit', 'teach_scode', 'universal_field', 'user_synth_library', 'videogame_engine', 'visual_determinism']
hiddenimports += collect_submodules('PyQt6')
hiddenimports += collect_submodules('numpy')
hiddenimports += collect_submodules('sounddevice')
hiddenimports += collect_submodules('PIL')


a = Analysis(
    ['/home/eski/Desktop/groovebox/groovebox.py'],
    pathex=['/home/eski/Desktop/groovebox'],
    binaries=[],
    datas=[('/home/eski/Desktop/groovebox/native', 'native'), ('/home/eski/Desktop/groovebox/julia', 'julia'), ('/home/eski/Desktop/groovebox/assets', 'assets'), ('/home/eski/Desktop/groovebox/scode', 'scode'), ('/home/eski/Desktop/groovebox/scode_models', 'scode_models'), ('/home/eski/Desktop/groovebox/scode_os', 'scode_os'), ('/home/eski/Desktop/groovebox/modules', 'modules'), ('/home/eski/Desktop/groovebox/README.md', '.'), ('/home/eski/Desktop/groovebox/HELP_TEXT.md', '.'), ('/home/eski/Desktop/groovebox/PERFORMANCE_BOX.md', '.'), ('/home/eski/Desktop/groovebox/CURRENT_FEATURES_AND_MATH.md', '.'), ('/home/eski/Desktop/groovebox/DEPENDENCIES.md', '.')],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='MathematiciansGroovebox',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['/home/eski/Desktop/groovebox/assets/logo.png'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='MathematiciansGroovebox',
)
