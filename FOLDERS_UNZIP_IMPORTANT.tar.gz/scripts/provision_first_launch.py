#!/usr/bin/env python3
"""Best-effort first-launch provisioning for export-ready Groovebox packages."""
from __future__ import annotations
import os, platform, shutil, subprocess, sys, urllib.request, zipfile, tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BIN=ROOT/'bin'; NATIVE=ROOT/'native'; BIN.mkdir(exist_ok=True); NATIVE.mkdir(exist_ok=True)

def exe(name):
    p=BIN/(name + ('.exe' if os.name=='nt' else ''))
    if p.is_file():
        # ZIP extraction can lose executable bits. Repair local codec payloads
        # before trying to execute them.
        if os.name != 'nt' and not os.access(p, os.X_OK):
            try: p.chmod(p.stat().st_mode | 0o111)
            except OSError: pass
        if os.name == 'nt' or os.access(p, os.X_OK):
            return str(p)
    return shutil.which(name)

def run(cmd):
    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    except (PermissionError, FileNotFoundError, OSError) as e:
        class R: returncode = 126
        print(f'[provision] cannot execute {cmd[0]}: {e}', file=sys.stderr)
        return R()

def verify():
    f=exe('ffmpeg'); p=exe('ffprobe')
    if not f or not p: return False
    return run([f,'-hide_banner','-version']).returncode==0 and run([p,'-hide_banner','-version']).returncode==0

def install_system():
    sysname=platform.system().lower()
    cmds=[]
    if sysname=='linux':
        if shutil.which('apt-get'): cmds=[['sudo','apt-get','update'],['sudo','apt-get','install','-y','ffmpeg','python3','python3-pip','python3-venv','g++','cmake']]
        elif shutil.which('dnf'): cmds=[['sudo','dnf','install','-y','ffmpeg','python3','python3-pip','gcc-c++','cmake']]
    elif sysname=='darwin' and shutil.which('brew'):
        cmds=[['brew','install','ffmpeg','python','cmake']]
    elif sysname=='windows' and shutil.which('winget'):
        cmds=[['winget','install','--accept-source-agreements','--accept-package-agreements','Gyan.FFmpeg'],['winget','install','--accept-source-agreements','--accept-package-agreements','Python.Python.3.12']]
    for c in cmds:
        try: subprocess.run(c, check=False)
        except Exception: pass
    return verify()

def install_local_linux():
    # Static builds are only fetched when no system ffmpeg exists.
    if platform.system().lower()!='linux': return False
    arch=platform.machine().lower()
    if arch not in ('x86_64','amd64'): return False
    url='https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz'
    tmp=ROOT/'.ffmpeg-download.tar.xz'
    try:
        urllib.request.urlretrieve(url,tmp)
        with tarfile.open(tmp,'r:xz') as tf:
            members=tf.getmembers(); top=next((m.name.split('/')[0] for m in members if '/ffmpeg' in m.name),None)
            tf.extractall(ROOT/'.ffmpeg_extract')
        if top:
            src=ROOT/'.ffmpeg_extract'/top
            for name in ('ffmpeg','ffprobe'):
                s=src/name
                if s.exists(): shutil.copy2(s,BIN/name); os.chmod(BIN/name,0o755)
        return verify()
    except Exception as e:
        print(f'[provision] local ffmpeg download skipped: {e}', file=sys.stderr); return False
    finally:
        for q in (tmp, ROOT/'.ffmpeg_extract'):
            try:
                if q.is_dir(): shutil.rmtree(q)
                elif q.exists(): q.unlink()
            except Exception: pass

def main():
    if verify(): return 0
    if install_system(): return 0
    if install_local_linux(): return 0
    print('Groovebox provisioning could not install ffmpeg/ffprobe automatically. Place both binaries in ./bin/ or install them system-wide.', file=sys.stderr)
    return 2
if __name__=='__main__': raise SystemExit(main())
