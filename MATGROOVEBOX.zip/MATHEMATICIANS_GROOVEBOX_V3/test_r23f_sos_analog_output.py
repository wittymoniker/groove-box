#!/usr/bin/env python3
# R23F1_HOST_NUMPY_INDEPENDENT_TEST_20261002
import os, sys, types
from pathlib import Path

# This verifier exercises routing/scoring only.  The host Python used by the
# ISO builder is not required to have Groovebox runtime packages installed.
# audio_os_backend references NumPy inside WAV/DSP functions, but none of those
# functions are executed here, so provide an inert import shim when NumPy is
# absent (for example Fedora system Python during zero-state verification).
try:
    import numpy  # noqa: F401
except ModuleNotFoundError:
    sys.modules["numpy"] = types.ModuleType("numpy")
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import media_output_router as m
import audio_os_backend as a

# Simulate a Latitude where PipeWire has a valid HDMI sink, but internal analog
# is card PCH device 0. System default must still choose PCH on sOS.
os.environ['GROOVEBOX_SOS']='1'
commands=[]
batch_inputs=[]
orig_which=m.shutil.which; orig_run_text=m._run_text; orig_run=m.subprocess.run
try:
    m.shutil.which=lambda name: f'/usr/bin/{name}' if name in {'aplay','amixer','alsactl','alsaucm','pactl'} else orig_which(name)
    def fake_text(cmd, timeout=2.0):
        if cmd[:2]==['aplay','-l']:
            return '''**** List of PLAYBACK Hardware Devices ****\ncard 0: PCH [HDA Intel PCH], device 0: ALC3204 Analog [ALC3204 Analog]\ncard 0: PCH [HDA Intel PCH], device 3: HDMI 0 [HDMI 0]\n'''
        if cmd[:2]==['amixer','-c'] and cmd[-1]=='scontrols':
            return "Simple mixer control 'Master',0\nSimple mixer control 'Speaker',0\nSimple mixer control 'Auto-Mute Mode',0\n"
        if cmd[:4]==['pactl','list','short','sinks']:
            return '42\talsa_output.pci-hdmi-stereo\tmodule-alsa-card.c\ts16le\tRUNNING\n'
        return ''
    m._run_text=fake_text
    class R: returncode=0; stdout=''; stderr=''
    def fake_run(cmd, **kwargs):
        commands.append(list(cmd)); batch_inputs.append(str(kwargs.get('input') or '')); return R()
    m.subprocess.run=fake_run
    m._real_alsa_playback_available=lambda: True
    m._real_pulse_sink_available=lambda: True
    # This test models a laptop with an HDMI PCM enumerated but no external
    # HDMI/DP display connected.  Never let the build host's /sys/class/drm
    # state influence the simulated routing decision.
    m._drm_hdmi_connected=lambda: False
    dev=m._preferred_alsa_output_device()
    assert dev=='alsa/plughw:CARD=PCH,DEV=0',dev
    args,env=m.player_routing(None,m.AudioTarget('', 'System default', kind='default',backend='default'),False)
    assert '--ao=alsa' in args,args
    assert '--audio-device=alsa/plughw:CARD=PCH,DEV=0' in args,args
    assert 'PULSE_SINK' not in env,env
    assert any(c[:4]==['amixer','-c','0','sset'] and 'Speaker' in c for c in commands),commands
    assert any('Auto-Mute Mode' in c and 'Disabled' in c for c in commands),commands
    assert any(c and c[0]=='alsaucm' and '-b' in c for c in commands),commands
    assert any('set _verb HiFi' in x and 'set _enadev Speaker' in x for x in batch_inputs),batch_inputs
finally:
    m.shutil.which=orig_which; m._run_text=orig_run_text; m.subprocess.run=orig_run

# PortAudio scoring must prefer the physical analog endpoint over PipeWire/HDMI on sOS.
a.HAS_SOUNDDEVICE=True
a.__dict__.setdefault('_device_snapshot_orig', a._device_snapshot)   # other suites test the real one
a._device_snapshot=lambda force=False:[
    {'name':'pipewire','max_output_channels':2,'max_input_channels':2,'default_samplerate':48000},
    {'name':'HDA Intel PCH: ALC3204 Analog (hw:0,0)','max_output_channels':2,'max_input_channels':2,'default_samplerate':48000},
    {'name':'HDA Intel PCH: HDMI 0 (hw:0,3)','max_output_channels':2,'max_input_channels':0,'default_samplerate':48000},
]
class FakeSD: default=type('D',(),{'device':(-1,0)})()
a.sd=FakeSD()
idx=a.resolve_output_device_index()
assert idx==1,idx
print('PASS: R23f sOS default routes physical PCH analog despite healthy HDMI/PipeWire sink')
print('PASS: R23f playback preparation enables UCM Speaker, disables Auto-Mute, and unmutes playback controls')
print('PASS: R23f PortAudio scoring prefers physical analog output over PipeWire/HDMI on sOS')
