"""GROOVEBOX_THREAD_BUDGET_20261102: one CPU budget for every thread pool and math library.

Laptop CPUs such as the Dell Latitude 3510 (2-4 cores, 4-8 threads) were being
oversubscribed: NumPy's BLAS and the OpenMP voice kernel each defaulted to every
core, and the app added 16+ Python worker threads on top. Competing with the
PortAudio callback and the Qt UI thread shows up as clicks and late buffers.

The budget uses every usable logical thread (cpu affinity aware) for the maths, plus one
spare, and twice that for the helper pools, in one place, so the math libraries, OpenMP kernel and Python pools agree
instead of each assuming it owns the machine. Nothing here changes any DSP maths. Explicit environment variables always win,
and GROOVEBOX_THREADS=<n> overrides the computed compute-thread count.
"""
import os

_VARS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
         "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")


def usable_cores():
    try:
        return max(1, len(os.sched_getaffinity(0)))
    except Exception:
        return max(1, int(os.cpu_count() or 1))


def compute_threads():
    """Threads for heavy maths: every usable logical thread plus one spare (cap 16).

    The spare keeps a math worker running when one is descheduled by the audio callback
    or the UI thread. It stays modest because oversubscribed BLAS/OpenMP loses speed."""
    try:
        forced = int(os.environ.get("GROOVEBOX_THREADS", "0") or 0)
    except ValueError:
        forced = 0
    if forced > 0:
        return forced
    n = usable_cores()
    return max(1, min(16, n + 1 if n >= 2 else n))


def lane_workers():
    """Workers for the app's helper pools (playlist, sequencer, fx, analysis, video objects).

    These tasks wait on disk, devices and the GIL much of the time, so twice the logical
    thread count keeps every core busy (floor 8, cap 32)."""
    return max(8, min(32, 2 * usable_cores()))


def apply():
    """Set the math-library thread counts. Call before NumPy is imported."""
    n = str(compute_threads())
    for name in _VARS:
        os.environ.setdefault(name, n)
    # Idle OpenMP workers sleep instead of spinning, so they never burn a core the
    # audio callback needs on a small laptop CPU.
    os.environ.setdefault("OMP_WAIT_POLICY", "PASSIVE")
    return int(n)
