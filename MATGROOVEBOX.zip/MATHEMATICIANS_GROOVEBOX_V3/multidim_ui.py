"""GROOVEBOX_R23R_MULTIDIM_UI_20261103 — 🌀 Multidimensional synth window with a live 3-D view.

The 3-D scene (drag to orbit, wheel to zoom) shows the four dimensions of the selected
instrument's multidimensional synth as they evolve:

  * the CELLULAR automaton as a stack of generations receding in depth (lit cells = sounding partials)
  * the BOUNCING BALL rising and falling inside the cube (its height drives pitch / level)
  * the VECTOR as a rotating arrow from the cube centre
  * the WAVETABLE as a ring of partial bars around the floor (bar height = script amplitude)
  * the FIXED RESONATORS as horizontal rings at heights set by the harmonic-geometric rule

Controls edit the instrument's user values; while canonical engines are active each control you
set mixes 50 / 50 with the canonical programme (shown as U50), like the sequencer.
"""
from __future__ import annotations

import math

import numpy as np
from PyQt6.QtCore import Qt, QTimer, QPointF
from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QPolygonF, QRadialGradient, QFont
from PyQt6.QtWidgets import (QDialog, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QComboBox, QLineEdit,
                             QSpinBox, QSlider, QLabel, QPushButton, QScrollArea, QSplitter, QGroupBox)

import multidim_synth as md

NUM_CONTROLS = (  # key, label, lo, hi, scale (slider int → value)
    ("gravity", "Ball gravity", 0, 400, 0.1), ("restitution", "Ball restitution", 0, 99, 0.01),
    ("rot_hz", "Vector rotation Hz", 0, 200, 0.005), ("lo", "Quiet threshold", 0, 100, 0.01),
    ("hi", "Loud threshold", 0, 100, 0.01), ("up", "Loud → freq ×", 50, 400, 0.01),
    ("down", "Quiet → freq ×", 10, 200, 0.01), ("phase_shift", "Phase turn (rad)", 0, 628, 0.01),
    ("block_ms", "Block ms", 2, 200, 1.0), ("res_q", "Resonator Q", 1, 200, 1.0),
    ("res_mix", "Resonator mix", 0, 100, 0.01),
)


class MD3DView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(420, 380)
        self.yaw, self.pitch, self.dist = 0.7, 0.45, 4.2
        self._drag = None
        self.params = md.preset_params("Prism")
        self.seed_int, self.slot = 0, 0
        self.t = 0.0
        self._rebuild()

    def set_params(self, p, seed_int=0, slot=0):
        self.params, self.seed_int, self.slot = p, int(seed_int), int(slot)
        self._rebuild()

    def _rebuild(self):
        p = self.params
        try:
            self.amps = md.table_amplitudes(p.get("script", "1/k"))
        except Exception:
            self.amps = np.zeros(md.H)
        m = float(np.max(np.abs(self.amps))) if self.amps.size else 0.0
        self.amps_n = self.amps / m if m > 0 else self.amps
        cells = np.array([((self.seed_int >> (k % 31)) & 1) ^ ((self.slot + k) % 2) for k in range(md.H)], dtype=np.uint8)
        if not cells.any():
            cells[md.H // 2] = 1
        self.ca = md._ca_rows(p.get("ca_rule", 90), 64, cells)
        self.ball = md._ball(400, 0.02, p.get("gravity", 9.8), p.get("restitution", 0.8))
        ratios = ()
        for part in str(p.get("resonators", "harmonic")).split("+"):
            ratios = ratios + tuple(r for r in md.RESONATOR_RULES.get(part.strip(), ()) if r not in ratios)
        self.res = ratios
        self.update()

    def tick(self, dt):
        self.t += dt
        self.update()

    # camera
    def mousePressEvent(self, e):
        self._drag = e.position()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            d = e.position() - self._drag
            self._drag = e.position()
            self.yaw += d.x() * 0.01
            self.pitch = max(-1.4, min(1.4, self.pitch + d.y() * 0.01))
            self.update()

    def mouseReleaseEvent(self, _e):
        self._drag = None

    def wheelEvent(self, e):
        self.dist = max(2.2, min(9.0, self.dist * (0.9 if e.angleDelta().y() > 0 else 1.1)))
        self.update()

    def _proj(self, P):
        """(N,3) world → (N,2) screen + depth (perspective; exact, behind-camera points dropped)."""
        P = np.asarray(P, dtype=np.float64).reshape(-1, 3)
        cy, sy, cp, sp = math.cos(self.yaw), math.sin(self.yaw), math.cos(self.pitch), math.sin(self.pitch)
        x = cy * P[:, 0] - sy * P[:, 2]
        z = sy * P[:, 0] + cy * P[:, 2]
        y = cp * P[:, 1] - sp * z
        z = sp * P[:, 1] + cp * z + self.dist
        f = min(self.width(), self.height()) * 0.9
        ok = z > 0.05
        zs = np.where(ok, z, 1.0)
        sx = self.width() / 2 + f * x / zs
        sy_ = self.height() / 2 - f * y / zs
        return np.stack([sx, sy_], axis=1), z, ok

    def paintEvent(self, _e):
        qp = QPainter(self)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        g = QRadialGradient(QPointF(w / 2, h / 2), max(w, h) * 0.7)
        g.setColorAt(0.0, QColor("#4a4b50")); g.setColorAt(1.0, QColor("#2a2b2f"))
        qp.fillRect(self.rect(), QBrush(g))
        p = self.params
        # cube
        c = np.array([[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)], dtype=float)
        S, Z, ok = self._proj(c)
        qp.setPen(QPen(QColor(170, 190, 220, 90), 1.2))
        for i in range(8):
            for j in range(i + 1, 8):
                if np.sum(np.abs(c[i] - c[j])) == 2 and ok[i] and ok[j]:
                    qp.drawLine(QPointF(*S[i]), QPointF(*S[j]))
        # fixed resonators: rings at heights by ratio (log scale), fixed while everything moves
        if self.res:
            rmax = max(self.res)
            for r in self.res:
                yy = -1.0 + 2.0 * (math.log(r) / math.log(rmax) if rmax > 1 else 0.5)
                ang = np.linspace(0, math.tau, 48)
                ring = np.stack([1.15 * np.cos(ang), np.full_like(ang, yy), 1.15 * np.sin(ang)], axis=1)
                Sr, _z, okr = self._proj(ring)
                qp.setPen(QPen(QColor(255, 209, 102, 150), 1.6))
                for i in range(len(ang) - 1):
                    if okr[i] and okr[i + 1]:
                        qp.drawLine(QPointF(*Sr[i]), QPointF(*Sr[i + 1]))
        # wavetable: partial bars around the floor
        for k in range(md.H):
            ang = math.tau * k / md.H + self.t * 0.2
            x, z = 0.95 * math.cos(ang), 0.95 * math.sin(ang)
            hgt = 1.6 * float(abs(self.amps_n[k])) if k < len(self.amps_n) else 0.0
            Sb, _z, okb = self._proj([[x, -1.0, z], [x, -1.0 + hgt, z]])
            if okb.all():
                col = QColor.fromHsv(int(200 + 12 * k) % 360, 180, 255)
                qp.setPen(QPen(col, 5.0, cap=Qt.PenCapStyle.RoundCap))
                qp.drawLine(QPointF(*Sb[0]), QPointF(*Sb[1]))
        # cellular automaton: generations receding in depth (current generation in front)
        gen = int(self.t * 1000.0 / max(2.0, float(p.get("block_ms", 12.0)))) % max(1, len(self.ca))
        depth_n = 16
        for d in range(depth_n):
            row = self.ca[(gen - d) % len(self.ca)]
            zz = -0.9 + 1.8 * d / depth_n
            for k in range(md.H):
                if not row[k]:
                    continue
                xx = -0.9 + 1.8 * k / (md.H - 1)
                Sc, Zc, okc = self._proj([[xx, 0.85, zz]])
                if okc[0]:
                    a = int(230 * (1.0 - d / depth_n)) + 20
                    s = max(3.0, 26.0 / float(Zc[0]))
                    qp.setPen(Qt.PenStyle.NoPen)
                    qp.setBrush(QColor(120, 255, 200, a))
                    qp.drawRect(int(Sc[0][0] - s / 2), int(Sc[0][1] - s / 2), int(s), int(s))
        # bouncing ball
        hb = float(self.ball[int(self.t / 0.02) % len(self.ball)])
        Sb, Zb, okb = self._proj([[0.0, -1.0 + 1.8 * hb, 0.0], [0.0, -1.0, 0.0]])
        if okb.all():
            rad = max(6.0, 64.0 / float(Zb[0]))
            qp.setPen(QPen(QColor(0, 0, 0, 90), 1)); qp.setBrush(QColor(0, 0, 0, 70))
            qp.drawEllipse(QPointF(*Sb[1]), rad * 0.9, rad * 0.3)          # shadow on the floor
            gg = QRadialGradient(QPointF(Sb[0][0] - rad / 3, Sb[0][1] - rad / 3), rad * 1.4)
            gg.setColorAt(0.0, QColor("#ffffff")); gg.setColorAt(1.0, QColor("#ff6b9a"))
            qp.setPen(Qt.PenStyle.NoPen); qp.setBrush(QBrush(gg))
            qp.drawEllipse(QPointF(*Sb[0]), rad, rad)
        # vector arrow (rotating)
        vx, vy, vz = (list(p.get("vector") or [0.5, 0.5, 0.5]) + [0.5] * 3)[:3]
        rot = float(p.get("rot_hz", 0.1)) * math.tau * self.t
        v = np.array([vx * math.cos(rot) - vy * math.sin(rot), vz * math.cos(0.5 * rot),
                      vx * math.sin(rot) + vy * math.cos(rot)])
        nv = float(np.linalg.norm(v))
        if nv > 0:
            v = v / nv * 0.9
            Sv, _z, okv = self._proj([[0, 0, 0], v])
            if okv.all():
                qp.setPen(QPen(QColor("#7dd3fc"), 3.0, cap=Qt.PenCapStyle.RoundCap))
                qp.drawLine(QPointF(*Sv[0]), QPointF(*Sv[1]))
                qp.setBrush(QColor("#7dd3fc")); qp.drawEllipse(QPointF(*Sv[1]), 4, 4)
        qp.setPen(QColor(230, 235, 245))
        qp.setFont(QFont("Sans", 9))
        qp.drawText(10, 18, f"{p.get('preset', '')} · {p.get('_mode', 'canonical')} · CA rule {int(p.get('ca_rule', 0)) & 255}"
                            f" · resonators: {p.get('resonators', '')}")
        qp.drawText(10, h - 10, "drag = orbit · wheel = zoom")
        qp.end()


class MultidimWindow(QDialog):
    def __init__(self, host):
        super().__init__(host)
        self.host = host
        self.setWindowTitle("🌀 Multidimensional synth — wavetable · vector · bouncing ball · cellular")
        self.setModal(False)
        self.resize(1080, 720)
        self._loading = False
        outer = QVBoxLayout(self)
        top = QHBoxLayout()
        self.cmb_inst = QComboBox(); self.cmb_inst.addItems(list(getattr(host, "instrument_names_48", []) or []))
        try:
            self.cmb_inst.setCurrentText(host.instrument_selector_dropdown.currentText())
        except Exception:
            pass
        self.cmb_inst.currentTextChanged.connect(lambda *_a: self._load())
        self.lbl_owner = QLabel("")
        self.sld_mix = QSlider(Qt.Orientation.Horizontal); self.sld_mix.setRange(33, 66); self.sld_mix.setFixedWidth(160)
        self.sld_mix.setValue(int(round(host._md_mix() * 100)))
        self.lbl_mix = QLabel(f"{self.sld_mix.value()}%")
        self.sld_mix.valueChanged.connect(self._mix_changed)
        b_aud = QPushButton("▶ Audition"); b_aud.clicked.connect(self._audition)
        b_reset = QPushButton("Reset to canonical"); b_reset.clicked.connect(self._reset)
        for wdg in (QLabel("Instrument"), self.cmb_inst, self.lbl_owner, QLabel("   Mix in every voice"),
                    self.sld_mix, self.lbl_mix, b_aud, b_reset):
            top.addWidget(wdg)
        top.addStretch(1)
        outer.addLayout(top)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.view = MD3DView()
        split.addWidget(self.view)
        sc = QScrollArea(); sc.setWidgetResizable(True)
        panel = QWidget(); form = QFormLayout(panel)
        self.cmb_preset = QComboBox(); self.cmb_preset.addItem("(canonical programme)", "")
        for n in md.PRESET_NAMES:
            self.cmb_preset.addItem(n, n)
        self.cmb_preset.currentIndexChanged.connect(lambda *_a: self._set("preset", self.cmb_preset.currentData() or None))
        form.addRow("Preset", self.cmb_preset)
        self.ed_script = QLineEdit(); self.ed_script.setToolTip("Wavetable script: amplitude of partial k (1 … 12)")
        self.ed_script.editingFinished.connect(lambda: self._set("script", self.ed_script.text().strip() or None))
        form.addRow("Script (k)", self.ed_script)
        self.ed_domain = QLineEdit(); self.ed_domain.setToolTip("Domain equation per block in t, b, h, a, x, y, z, live: "
                                                                "1 = CA-gated structure, 0 = full table")
        self.ed_domain.editingFinished.connect(lambda: self._set("domain", self.ed_domain.text().strip() or None))
        form.addRow("Domain equation", self.ed_domain)
        self.spin_rule = QSpinBox(); self.spin_rule.setRange(0, 255)
        self.spin_rule.valueChanged.connect(lambda v: self._set("ca_rule", int(v)))
        form.addRow("CA rule", self.spin_rule)
        self.cmb_res = QComboBox(); self.cmb_res.addItems(list(md.RESONATOR_RULES))
        self.cmb_res.currentTextChanged.connect(lambda v: self._set("resonators", v))
        form.addRow("Fixed resonators", self.cmb_res)
        gpatch = QGroupBox("Modular patch"); fp = QFormLayout(gpatch)
        self.patch_sl = {}
        for k in md.PATCH_KEYS:
            s = QSlider(Qt.Orientation.Horizontal); s.setRange(0, 100)
            s.valueChanged.connect(lambda v, kk=k: self._set_patch(kk, v / 100.0))
            fp.addRow(k, s); self.patch_sl[k] = s
        form.addRow(gpatch)
        gvec = QGroupBox("Vector"); fv = QFormLayout(gvec)
        self.vec_sl = []
        for i, a in enumerate("xyz"):
            s = QSlider(Qt.Orientation.Horizontal); s.setRange(-100, 100)
            s.valueChanged.connect(lambda _v, ii=i: self._set_vector())
            fv.addRow(a, s); self.vec_sl.append(s)
        form.addRow(gvec)
        self.num_sl = {}
        for key, label, lo, hi, sc_ in NUM_CONTROLS:
            s = QSlider(Qt.Orientation.Horizontal); s.setRange(lo, hi)
            s.valueChanged.connect(lambda v, kk=key, f=sc_: self._set(kk, v * f))
            form.addRow(label, s); self.num_sl[key] = (s, sc_)
        sc.setWidget(panel)
        split.addWidget(sc)
        split.setSizes([620, 440])
        outer.addWidget(split, 1)
        note = QLabel("Every voice = (panel × geometrics) against this synth. Controls you set mix 50 / 50 with the "
                      "canonical programme while canonical engines are active (U50), like the sequencer.")
        note.setWordWrap(True); note.setStyleSheet("color:#8da5b8;")
        outer.addWidget(note)
        self._timer = QTimer(self); self._timer.setInterval(33)
        self._timer.timeout.connect(lambda: self.view.tick(0.033))
        self._timer.start()
        self._load()

    # data
    def _name(self):
        return self.cmb_inst.currentText()

    def _user(self, create=False):
        ps = self.host.instrument_param_state
        st = ps.setdefault(self._name(), {}) if create else (ps.get(self._name()) or {})
        u = st.get("multidim")
        if u is None and create:
            u = st["multidim"] = {}
        return u if isinstance(u, dict) else {}

    def _merged(self):
        try:
            slot = self.host._instance_slot(self._name())
        except Exception:
            slot = 0
        p, seed_int = self.host._md_params(self._name(), slot)
        return p, seed_int, slot

    def _load(self):
        self._loading = True
        try:
            p, seed_int, slot = self._merged()
            u = self._user()
            self.cmb_preset.setCurrentIndex(max(0, self.cmb_preset.findData(u.get("preset", ""))))
            self.ed_script.setText(str(u.get("script", p.get("script", ""))))
            self.ed_domain.setText(str(u.get("domain", p.get("domain", ""))))
            self.spin_rule.setValue(int(u.get("ca_rule", p.get("ca_rule", 90))) & 255)
            self.cmb_res.setCurrentText(str(u.get("resonators", p.get("resonators", "harmonic"))).split("+")[0])
            patch = dict(p.get("patch") or {}); patch.update(u.get("patch") or {})
            for k, s in self.patch_sl.items():
                s.setValue(int(round(float(patch.get(k, 0.0)) * 100)))
            vec = list(u.get("vector", p.get("vector") or [0.5, 0.5, 0.5]))
            for i, s in enumerate(self.vec_sl):
                s.setValue(int(round(float(vec[i]) * 100)))
            for key, (s, f) in self.num_sl.items():
                s.setValue(int(round(float(u.get(key, p.get(key, 0.0))) / f)))
            self._refresh(p, seed_int, slot)
        finally:
            self._loading = False

    def _refresh(self, p=None, seed_int=None, slot=None):
        if p is None:
            p, seed_int, slot = self._merged()
        self.view.set_params(p, seed_int, slot)
        mode = p.get("_mode", "canonical")
        if str(mode).startswith("U"):
            txt = f"🟣 {mode} ({mode[1:]} % yours · {100 - int(mode[1:] or 50)} % canonical)"
        else:
            txt = {"canonical": "🔵 canonical", "user": "🟢 yours (no canonical engine active)"}.get(mode, mode)
        engines = ", ".join(p.get("_engines") or []) if isinstance(p, dict) else ""
        self.lbl_owner.setText(txt + (f" · engines: {engines}" if engines else ""))

    def _changed(self):
        try:
            self.host._on_live_source_changed()
        except Exception:
            pass
        self._refresh()

    def _set(self, key, val):
        if self._loading:
            return
        u = self._user(create=True)
        if val is None:
            u.pop(key, None)
        else:
            u[key] = val
        self._changed()

    def _set_patch(self, key, val):
        if self._loading:
            return
        u = self._user(create=True)
        u.setdefault("patch", {})[key] = float(val)
        self._changed()

    def _set_vector(self):
        if self._loading:
            return
        self._user(create=True)["vector"] = [s.value() / 100.0 for s in self.vec_sl]
        self._changed()

    def _reset(self):
        st = self.host.instrument_param_state.get(self._name()) or {}
        st.pop("multidim", None)
        self._load()
        self._changed()

    def _mix_changed(self, v):
        self.lbl_mix.setText(f"{v}%")
        sl = getattr(self.host, "slider_multidim_mix", None)
        if sl is not None:
            sl.setValue(int(v))           # the canonical-mixer slider owns the value (and marks it yours)
        else:
            self.host._on_multidim_slider("multidim", v, None)

    def _audition(self):
        try:
            self.host.instrument_selector_dropdown.setCurrentText(self._name())
            self.host.trigger_selected_note()
        except Exception:
            pass

    def closeEvent(self, e):
        self._timer.stop()
        super().closeEvent(e)


def open_multidim_window(host):
    w = getattr(host, "_multidim_window", None)
    try:
        if w is not None:
            w.isVisible()
    except RuntimeError:
        w = None
    if w is None:
        w = MultidimWindow(host)
        host._multidim_window = w
    else:
        w._load()
        w._timer.start()
    w.show(); w.raise_(); w.activateWindow()
    return w
