# Existing navbar (do not add another)

The navbar is `_GrooveboxWindowStrip` in `groovebox.py`:
- Title: "Groovebox Windows"
- Object name: `grooveboxExternalWindowStrip`
- Already frameless + `WindowStaysOnTopHint`
- Tabs for open windows, **Quit Groovebox** on the bar
- **Relaunch Main** is the button `_MainWindowRelaunchFilter` adds on subwindows

On the ISO, Labwc often ignores client-side always-on-top. `iso_wm/labwc/rc.xml` pins the real strip by title so it stays above hosted windows.

## Install into the appliance

```bash
mkdir -p /etc/xdg/labwc
cp iso_wm/labwc/rc.xml /etc/xdg/labwc/rc.xml
```

The strip is created by the app (`ensure_window_strip`). Do not start a second bar.

## Hosting windows below the bar

The strip places itself at the top (`_place_on_screen`, height ~40). Other Groovebox windows are session-managed under it. If a window covers the bar, the labwc always-on-top rule keeps the strip clickable.
