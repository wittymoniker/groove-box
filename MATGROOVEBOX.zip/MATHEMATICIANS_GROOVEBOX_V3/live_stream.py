"""Live camera + microphone streaming between Grooveboxes.

GROOVEBOX_R23R_LIVE_AV_20261101

One FFmpeg process captures the local camera and/or microphone and encodes a
low-latency MPEG-TS stream (H.264 + AAC; MPEG-4 + MP2 when x264 is missing).
The bytes are fanned out to every viewer by the Nearby share server at
/api/v1/live, so it works over the same LAN / Wi-Fi / ad hoc / Direct / IPv6
links as file sharing. Viewers play the URL; recorders store it with stream
copy (no re-encode). Blocked Grooveboxes are refused by the server.
"""
from __future__ import annotations

import os
import platform
import queue
import re
import shutil
import subprocess
import threading
import time
from typing import Dict, List, Optional

CHUNK = 188 * 64            # whole MPEG-TS packets
MAX_VIEWER_BACKLOG = 256    # chunks (~3 MB); slow viewers are dropped, never block the encoder


def _ffmpeg() -> Optional[str]:
    try:
        from groovebox_media_tools import resolve_local_tool
        p = resolve_local_tool("ffmpeg", False)
        if p:
            return p
    except Exception:
        pass
    return shutil.which("ffmpeg")


def _encoders(ff: str) -> str:
    try:
        return subprocess.run([ff, "-hide_banner", "-encoders"], capture_output=True, text=True, timeout=8).stdout
    except Exception:
        return ""


def list_devices() -> Dict[str, List[str]]:
    """Best-effort camera / microphone names for the capture backends FFmpeg uses."""
    ff = _ffmpeg(); sysname = platform.system().lower()
    cams: List[str] = []; mics: List[str] = []
    if sysname == "linux":
        import glob
        cams = sorted(glob.glob("/dev/video*"))
        mics = ["default"]
    elif sysname == "windows" and ff:
        try:
            out = subprocess.run([ff, "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
                                 capture_output=True, text=True, timeout=10).stderr
            for ln in out.splitlines():
                m = re.search(r'"([^"]+)"\s+\((video|audio)\)', ln)
                if m:
                    (cams if m.group(2) == "video" else mics).append(m.group(1))
        except Exception:
            pass
    elif sysname == "darwin" and ff:
        try:
            out = subprocess.run([ff, "-hide_banner", "-f", "avfoundation", "-list_devices", "true", "-i", ""],
                                 capture_output=True, text=True, timeout=10).stderr
            section = None
            for ln in out.splitlines():
                if "video devices" in ln.lower():
                    section = "v"; continue
                if "audio devices" in ln.lower():
                    section = "a"; continue
                m = re.search(r"\[(\d+)\]\s+(.+)$", ln)
                if m and section:
                    (cams if section == "v" else mics).append(f"{m.group(1)}:{m.group(2).strip()}")
        except Exception:
            pass
    return {"cameras": cams, "microphones": mics}


class LiveBroadcaster:
    """Owns the capture/encode process and the viewer fan-out."""

    def __init__(self):
        self.proc: Optional[subprocess.Popen] = None
        self.viewers: List[queue.Queue] = []
        self.lock = threading.Lock()
        self.mode = ""
        self.started = 0.0
        self.error = ""
        self._reader = None
        self._err_tail: List[str] = []

    @property
    def live(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def status(self) -> Dict:
        return {"live": self.live, "mode": self.mode, "since": self.started, "viewers": len(self.viewers),
                "error": self.error}

    def _input_args(self, video: bool, audio: bool, camera: str, mic: str, test: bool) -> List[str]:
        sysname = platform.system().lower(); args: List[str] = []
        if test:
            if video:
                args += ["-re", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=24"]
            if audio:
                args += ["-re", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000"]
            return args
        if sysname == "linux":
            if video:
                args += ["-f", "v4l2", "-framerate", "24", "-video_size", "640x360", "-i", camera or "/dev/video0"]
            if audio:
                if shutil.which("pactl") or os.environ.get("PULSE_SERVER") or os.environ.get("PIPEWIRE_RUNTIME_DIR"):
                    args += ["-f", "pulse", "-i", mic or "default"]
                else:
                    args += ["-f", "alsa", "-i", mic or "default"]
        elif sysname == "windows":
            devs = list_devices()
            cam = camera or (devs["cameras"][0] if devs["cameras"] else "")
            m = mic or (devs["microphones"][0] if devs["microphones"] else "")
            spec = []
            if video and cam:
                spec.append(f"video={cam}")
            if audio and m:
                spec.append(f"audio={m}")
            if not spec:
                raise RuntimeError("no camera/microphone found (DirectShow)")
            args += ["-f", "dshow", "-rtbufsize", "64M", "-i", ":".join(spec)]
        elif sysname == "darwin":
            v = (camera.split(":")[0] if camera else "0") if video else "none"
            a = (mic.split(":")[0] if mic else "0") if audio else "none"
            args += ["-f", "avfoundation", "-framerate", "24", "-video_size", "640x360", "-i", f"{v}:{a}"]
        else:
            raise RuntimeError("live capture is not implemented for this OS")
        return args

    def start(self, video=True, audio=True, camera="", mic="", test=False) -> Dict:
        if self.live:
            return self.status()
        if not (video or audio):
            raise ValueError("choose camera and/or microphone")
        ff = _ffmpeg()
        if not ff:
            raise RuntimeError("Groovebox-local FFmpeg is not available")
        enc = _encoders(ff)
        vcodec = (["-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency", "-g", "48",
                   "-b:v", "900k", "-maxrate", "1200k", "-bufsize", "600k", "-pix_fmt", "yuv420p"]
                  if " libx264 " in enc else ["-c:v", "mpeg4", "-q:v", "6", "-g", "48", "-pix_fmt", "yuv420p"])
        acodec = (["-c:a", "aac", "-b:a", "96k", "-ar", "48000", "-ac", "1"] if " aac " in enc
                  else ["-c:a", "mp2", "-b:a", "128k", "-ar", "48000", "-ac", "1"])
        cmd = [ff, "-hide_banner", "-loglevel", "error", "-nostdin", "-fflags", "nobuffer"]
        cmd += self._input_args(video, audio, camera, mic, test)
        if video:
            cmd += ["-vf", "scale=640:-2,fps=24"] + vcodec
        else:
            cmd += ["-vn"]
        if audio:
            cmd += acodec
        else:
            cmd += ["-an"]
        cmd += ["-f", "mpegts", "-muxdelay", "0.1", "pipe:1"]
        kw = {}
        if os.name == "nt":
            kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        self.error = ""; self._err_tail = []
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kw)
        self.mode = ("test pattern " if test else "") + "+".join(x for x, on in (("camera", video), ("mic", audio)) if on)
        self.started = time.time()
        self._reader = threading.Thread(target=self._pump, daemon=True, name="groovebox-live-pump"); self._reader.start()
        threading.Thread(target=self._stderr, daemon=True, name="groovebox-live-err").start()
        time.sleep(0.6)
        if not self.live:
            self.error = " ".join(self._err_tail)[-600:] or "capture device could not be opened"
            raise RuntimeError(self.error)
        return self.status()

    def _stderr(self):
        p = self.proc
        try:
            for ln in iter(p.stderr.readline, b""):
                self._err_tail = (self._err_tail + [ln.decode("utf-8", "replace").strip()])[-8:]
        except Exception:
            pass

    def _pump(self):
        p = self.proc
        try:
            while True:
                b = p.stdout.read(CHUNK)
                if not b:
                    break
                with self.lock:
                    viewers = list(self.viewers)
                for q in viewers:
                    try:
                        q.put_nowait(b)
                    except queue.Full:
                        self.remove_viewer(q)       # too slow: drop rather than stall everyone
        except Exception:
            pass
        with self.lock:
            for q in self.viewers:
                try:
                    q.put_nowait(None)
                except Exception:
                    pass

    def add_viewer(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=MAX_VIEWER_BACKLOG)
        with self.lock:
            self.viewers.append(q)
        return q

    def remove_viewer(self, q):
        with self.lock:
            if q in self.viewers:
                self.viewers.remove(q)
        try:
            q.put_nowait(None)
        except Exception:
            pass

    def stop(self):
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.terminate(); p.wait(timeout=3)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        self.mode = ""


class StreamRecorder:
    """Record a live URL (any Groovebox, including this one) to .mkv by stream copy."""

    def __init__(self, url: str, out_path: str):
        self.url = url; self.out = out_path; self.proc = None

    def start(self):
        ff = _ffmpeg()
        if not ff:
            raise RuntimeError("Groovebox-local FFmpeg is not available")
        kw = {}
        if os.name == "nt":
            kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        self.proc = subprocess.Popen([ff, "-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", self.url,
                                      "-map", "0", "-c", "copy", self.out],
                                     stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
        return self.out

    @property
    def active(self):
        return self.proc is not None and self.proc.poll() is None

    def stop(self):
        p, self.proc = self.proc, None
        if p is None:
            return self.out
        try:
            p.stdin.write(b"q"); p.stdin.flush()      # graceful: finalises the container
            p.wait(timeout=6)
        except Exception:
            try:
                p.terminate(); p.wait(timeout=3)
            except Exception:
                pass
        return self.out
