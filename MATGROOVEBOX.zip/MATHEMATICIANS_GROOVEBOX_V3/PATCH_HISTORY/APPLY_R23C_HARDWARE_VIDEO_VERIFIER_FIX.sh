#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ -d "$PWD/BUILD_ISO" ]]; then ROOT="$PWD"
elif [[ "$(basename "$PWD")" == "BUILD_ISO" && -f "$PWD/RUN_ME_v35_22.sh" ]]; then ROOT="$(dirname "$PWD")"
elif [[ -d "$HERE/BUILD_ISO" ]]; then ROOT="$HERE"
elif [[ "$(basename "$HERE")" == "BUILD_ISO" ]]; then ROOT="$(dirname "$HERE")"
else echo "FAIL: run this from the Groovebox root or BUILD_ISO directory" >&2; exit 4; fi
export ROOT
python3 - <<'PY'
from pathlib import Path
import os,re
root=Path(os.environ['ROOT']).resolve(); bi=root/'BUILD_ISO'

# Preserve the R23 runtime while normalizing the Hardware VIDEO report label in
# both project root and final initramfs overlay.
for rel in ['performance.py','BUILD_ISO/app-overlay-v35.22zz/performance.py']:
    p=root/rel
    s=p.read_text(errors='strict')
    if 'GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' not in s:
        raise SystemExit(f'FAIL: {rel} is not the R23 playback lineage')
    has_binding=('rr.get("video_devices"' in s or "rr.get('video_devices'" in s)
    has_heading=('VIDEO / CAMERAS' in s or '["", "VIDEO"]' in s)
    if has_binding and not has_heading:
        # Rename the heading on the existing video_devices report line when possible.
        lines=s.splitlines()
        changed=False
        for i,line in enumerate(lines):
            if ('rr.get("video_devices"' in line or "rr.get('video_devices'" in line) and 'lines +=' in line:
                lines[i]=re.sub(r'lines \+= \["",\s*"[^"]*"\]', 'lines += ["", "VIDEO / CAMERAS"]', line, count=1)
                changed=True
                break
        s='\n'.join(lines)+'\n'
        has_heading='VIDEO / CAMERAS' in s or '["", "VIDEO"]' in s
    if not has_binding:
        anchor='        lines += ["", "MIDI"] + ([f"  • {x}" for x in rr.get("midi_inputs",[])[:24]] or ["  • none detected"])\n'
        add='        lines += ["", "VIDEO / CAMERAS"] + ([f"  • {x}" for x in rr.get("video_devices",[])[:24]] or ["  • none detected"])\n'
        if anchor not in s:
            raise SystemExit(f'FAIL: cannot repair Hardware VIDEO section in {rel}; MIDI anchor absent')
        s=s.replace(anchor,add+anchor,1)
    p.write_text(s)

perf=(root/'performance.py').read_text(); ov=(bi/'app-overlay-v35.22zz/performance.py').read_text()
if perf != ov:
    raise SystemExit('FAIL: root/overlay performance.py differ after VIDEO normalization; refusing unsafe overwrite')

# Replace the brittle source-string-only v35.22zy check with semantic binding + heading checks.
p=bi/'verify_v35_22zy.py'; s=p.read_text(); lines=s.splitlines(); out=[]
for line in lines:
    if line.startswith('has_video_binding =') or line.startswith('has_video_heading =') or line.startswith('has_video_report ='):
        continue
    if "'Hardware VIDEO section':" in line:
        out.append(" 'Hardware VIDEO section':has_video_report,")
    else:
        out.append(line)
s='\n'.join(out)+'\n'
needle="h=(root/'hardware_hub.py').read_text(encoding='utf-8')\n"
insert=("has_video_binding = ('rr.get(\"video_devices\"' in p or \"rr.get('video_devices'\" in p)\n"
        "has_video_heading = ('VIDEO / CAMERAS' in p or '[\"\", \"VIDEO\"]' in p)\n"
        "has_video_report = has_video_binding and has_video_heading\n")
if needle not in s: raise SystemExit('FAIL: verify_v35_22zy.py layout changed')
s=s.replace(needle,needle+insert,1)
p.write_text(s)

# Keep the later R9 verifier from repeating the same exact-label false negative.
p=bi/'verify_v35_22zz_r9.py'; s=p.read_text(); lines=s.splitlines(); out=[]
for line in lines:
    if line.startswith('has_video_binding =') or line.startswith('has_video_heading =') or line.startswith('has_video_report ='):
        continue
    if "'separate audio/video UI':" in line:
        out.append(" 'separate audio/video UI':'AUDIO OUTPUTS' in perf and 'AUDIO INPUTS / MICROPHONES' in perf and has_video_report,")
    else:
        out.append(line)
s='\n'.join(out)+'\n'
needle="stamp=(bi/'stamp_final_initramfs_v35_22zz.sh').read_text(errors='replace')\n"
insert=("has_video_binding = ('rr.get(\"video_devices\"' in perf or \"rr.get('video_devices'\" in perf)\n"
        "has_video_heading = ('VIDEO / CAMERAS' in perf or '[\"\", \"VIDEO\"]' in perf)\n"
        "has_video_report = has_video_binding and has_video_heading\n")
if needle not in s: raise SystemExit('FAIL: verify_v35_22zz_r9.py layout changed')
s=s.replace(needle,needle+insert,1)
p.write_text(s)

vr=bi/'verify_v35_22zz_r23c.py'
vr.write_text(r'''#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve(); bi=root/'BUILD_ISO'
perf=(root/'performance.py').read_text(errors='replace'); hw=(root/'hardware_hub.py').read_text(errors='replace')
op=(bi/'app-overlay-v35.22zz/performance.py').read_text(errors='replace')
zy=(bi/'verify_v35_22zy.py').read_text(errors='replace'); r9=(bi/'verify_v35_22zz_r9.py').read_text(errors='replace')
checks={
 'Qt video enumeration':'QMediaDevices.videoInputs()' in hw,
 'Hardware report consumes video devices':('rr.get("video_devices"' in perf or "rr.get('video_devices'" in perf),
 'Hardware VIDEO/CAMERAS heading':('VIDEO / CAMERAS' in perf or '["", "VIDEO"]' in perf),
 'root/overlay Performance sync':perf==op,
 'zy semantic VIDEO verifier':'has_video_binding' in zy and 'has_video_heading' in zy and 'has_video_report' in zy,
 'R9 semantic VIDEO verifier':'has_video_binding' in r9 and 'has_video_heading' in r9 and 'has_video_report' in r9,
 'R23 playback retained':'GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in perf,
}
bad=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
if bad: raise SystemExit(4)
print('PASS: v35.22zz-R23c Hardware VIDEO semantic verifier + root/overlay sync contracts')
'''); vr.chmod(0o755)

for rel,var in [('BUILD_ISO/RUN_ME_ZERO_STATE.sh','HERE'),('BUILD_ISO/RUN_ME_v35_22.sh','BI')]:
    p=root/rel; s=p.read_text()
    anchor=f'python3 "${var}/verify_v35_22zz_r23b.py" "$ROOT"\n'
    add=f'python3 "${var}/verify_v35_22zz_r23c.py" "$ROOT"\n'
    if add not in s:
        if anchor not in s: raise SystemExit('FAIL: R23b runner anchor missing: '+rel)
        s=s.replace(anchor,anchor+add,1)
    p.write_text(s)
(root/'RELEASE-v35.22zz-R23c-HARDWARE-VIDEO-SEMANTIC-VERIFIER-20261001.txt').write_text(
    'Groovebox/sOS v35.22zz-R23c — Hardware VIDEO semantic verifier sync — 2026-10-01\n\n'
    'Fixes the v35.22zy/R9 false negative at Hardware VIDEO section. Runtime playback remains R23.\n')
print('PASS: R23c in-place Hardware VIDEO verifier fix applied to',root)
PY
python3 -m py_compile "$ROOT/BUILD_ISO/verify_v35_22zy.py" "$ROOT/BUILD_ISO/verify_v35_22zz_r9.py" "$ROOT/BUILD_ISO/verify_v35_22zz_r23c.py"
python3 "$ROOT/BUILD_ISO/verify_v35_22zy.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r9.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23b.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23c.py" "$ROOT"
echo 'PASS: R23c hotfix verified. Re-run ./RUN_ME_ZERO_STATE.sh from BUILD_ISO.'
