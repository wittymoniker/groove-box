#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -d "$PWD/BUILD_ISO" ]]; then ROOT="$PWD"
elif [[ "$(basename "$PWD")" == "BUILD_ISO" && -f "$PWD/RUN_ME_v35_22.sh" ]]; then ROOT="$(dirname "$PWD")"
elif [[ -d "$HERE/BUILD_ISO" ]]; then ROOT="$HERE"
elif [[ "$(basename "$HERE")" == "BUILD_ISO" ]]; then ROOT="$(dirname "$HERE")"
else echo "FAIL: run this from the Groovebox root or BUILD_ISO directory" >&2; exit 4; fi
export ROOT
python3 - <<'PY'
from pathlib import Path
import os
root=Path(os.environ['ROOT']).resolve()

def rep(rel, old, new):
    p=root/rel; s=p.read_text()
    if new in s:
        return
    if old not in s:
        raise SystemExit(f'FAIL: {rel}: expected R23a text not found')
    p.write_text(s.replace(old,new))

for rel in ['performance.py','BUILD_ISO/app-overlay-v35.22zz/performance.py']:
    p=root/rel; s=p.read_text(); p.write_text(s.replace('# Historical R6 verifier token only (R23 does NOT launch this mode): --audio-fallback-to-null=yes\n',''))

rep('BUILD_ISO/verify_v35_22.py',
'''if 'GROOVEBOX_V35_22ZZ_R2_PERSISTENT_PLAYLIST_PLAYER' in perf:\n    for token in ('--keep-open=yes', '["loadfile", path, "replace"]',\n                  'GROOVEBOX_V35_22ZZ_R2_PERSISTENT_PLAYLIST_EOF',\n                  '--audio-fallback-to-null=yes'):\n        if token not in perf:\n            raise SystemExit('FAIL: current persistent Player/DJ contract missing: '+token)\nelse:\n''',
'''if 'GROOVEBOX_V35_22ZZ_R2_PERSISTENT_PLAYLIST_PLAYER' in perf:\n    for token in ('--keep-open=yes', '["loadfile", path, "replace"]',\n                  'GROOVEBOX_V35_22ZZ_R2_PERSISTENT_PLAYLIST_EOF'):\n        if token not in perf:\n            raise SystemExit('FAIL: current persistent Player/DJ contract missing: '+token)\n    if 'GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in perf:\n        for token in ('--audio-fallback-to-null=no', 'def _recover_player_output',\n                      'hardware recovery exhausted', '["set_property", "aid", "no"]'):\n            if token not in perf:\n                raise SystemExit('FAIL: R23 real-audio-first Player recovery missing: '+token)\n    elif '--audio-fallback-to-null=yes' not in perf:\n        raise SystemExit('FAIL: historical Player/DJ null-audio fallback missing')\nelse:\n''')
rep('BUILD_ISO/verify_v35_22zz.py',
'''    "silent-video fallback": "--audio-fallback-to-null=yes" in p,\n''',
'''    "real-audio-first video recovery": (\n        ("GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001" in p\n         and "--audio-fallback-to-null=no" in p\n         and "def _recover_player_output" in p\n         and "hardware recovery exhausted" in p\n         and '["set_property", "aid", "no"]' in p)\n        or "--audio-fallback-to-null=yes" in p\n    ),\n''')
rep('BUILD_ISO/verify_v35_22zz_r14.py',
"need(B/'app-overlay-v35.22zz/media_output_router.py','R14_MEDIA_PLAYBACK_RESILIENCE','--audio-fallback-to-null=yes')",
'''router=(B/'app-overlay-v35.22zz/media_output_router.py').read_text(errors='replace')\nif 'R14_MEDIA_PLAYBACK_RESILIENCE' not in router:\n    raise SystemExit('FAIL: media_output_router.py missing R14_MEDIA_PLAYBACK_RESILIENCE')\nlegacy='--audio-fallback-to-null=yes' in router\nr23=('GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in router\n     and '--audio-fallback-to-null=no' in router\n     and '--audio-samplerate=48000' in router\n     and '_preferred_alsa_output_device' in router\n     and 'args.append("--ao=null")' not in router)\nif not (legacy or r23):\n    raise SystemExit('FAIL: media_output_router.py missing legacy null fallback or superseding R23 real-audio-first recovery')\nprint('PASS: media_output_router.py')''')
rep('BUILD_ISO/verify_v35_22zz_r17.py',
" 'video playback retains null fallback':'--audio-fallback-to-null=yes' in perf,\n",
''' 'video playback has recoverable audio fallback':(\n     '--audio-fallback-to-null=yes' in perf\n     or ('GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in perf\n         and '--audio-fallback-to-null=no' in perf\n         and 'def _recover_player_output' in perf\n         and 'hardware recovery exhausted' in perf\n         and '["set_property", "aid", "no"]' in perf)),\n''')
rep('BUILD_ISO/verify_v35_22zz_r22.py',
" 'real audio/null fallback':'--audio-fallback-to-null=yes' in perf and 'PLAYER_CLOCK_STALLED' in perf,\n",
''' 'real audio/recovery fallback':(\n     ('--audio-fallback-to-null=yes' in perf and 'PLAYER_CLOCK_STALLED' in perf)\n     or ('GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in perf\n         and '--audio-fallback-to-null=no' in perf\n         and 'def _recover_player_output' in perf\n         and 'PLAYER_CLOCK_STALLED' in perf\n         and 'hardware recovery exhausted' in perf)),\n''')
rep('BUILD_ISO/verify_v35_22zz_r22.py',
" 'R22 final stamp':'R22_ISOLATED_DEVICE_PROBE_STREAMING|PASS' in stamp and 'GROOVEBOX_SOS_VERSION=v35.22zz-R22' in stamp,\n",
''' 'R22 final stamp':('R22_ISOLATED_DEVICE_PROBE_STREAMING|PASS' in stamp and\n     ('GROOVEBOX_SOS_VERSION=v35.22zz-R22' in stamp or 'GROOVEBOX_SOS_VERSION=v35.22zz-R23' in stamp)),\n''')
rep('BUILD_ISO/verify_v35_22zz_r22.py',
" 'R22 ISO name':'v35.22zz-R22-ISOLATED-DEVICE-PROBE-LOW-LATENCY-STREAMING' in master,\n",
''' 'R22 ISO lineage':('v35.22zz-R22-ISOLATED-DEVICE-PROBE-LOW-LATENCY-STREAMING' in master or\n     'v35.22zz-R23-PLAYBACK-OUTPUT-RECOVERY-LOW-LATENCY-STREAMING' in master),\n''')
rep('test_performance_event_loop_r6.py',
"    assert '--audio-fallback-to-null=yes' in p\n",
'''    assert ('--audio-fallback-to-null=yes' in p or\n            ('GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in p\n             and '--audio-fallback-to-null=no' in p\n             and 'def _recover_player_output' in p\n             and 'hardware recovery exhausted' in p))\n''')
rep('test_r14_audio_video_performance_microsd.py',
"checks['video audio-fallback']='R14_MEDIA_PLAYBACK_RESILIENCE' in m and '--audio-fallback-to-null=yes' in m\n",
'''checks['video audio-fallback']=('R14_MEDIA_PLAYBACK_RESILIENCE' in m and\n    ('--audio-fallback-to-null=yes' in m or\n     ('GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in m\n      and '--audio-fallback-to-null=no' in m\n      and '--audio-samplerate=48000' in m\n      and '_preferred_alsa_output_device' in m\n      and 'args.append("--ao=null")' not in m)))\n''')
rep('test_r22_isolated_device_probe_streaming.py',
"""    for token in ('--hwdec=auto-safe','--cache-secs=1','--demuxer-readahead-secs=1','--cache-pause=no','--audio-fallback-to-null=yes','PLAYER_CLOCK_STALLED'):\n        assert token in p\n""",
"""    for token in ('--hwdec=auto-safe','--cache-secs=1','--demuxer-readahead-secs=1','--cache-pause=no','PLAYER_CLOCK_STALLED'):\n        assert token in p\n    assert ('--audio-fallback-to-null=yes' in p or\n            ('GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in p\n             and '--audio-fallback-to-null=no' in p\n             and 'def _recover_player_output' in p\n             and 'hardware recovery exhausted' in p))\n""")
# Cosmetic labels only.
for rel, old, new in [
 ('BUILD_ISO/verify_v35_22zz_r6.py',"'null-audio fallback':","'recoverable audio fallback':"),
 ('BUILD_ISO/verify_v35_22zz_r19.py',"'video null AO only fallback':","'video output recovery fallback':")]:
    p=root/rel; s=p.read_text(); p.write_text(s.replace(old,new))

vr=root/'BUILD_ISO/verify_v35_22zz_r23b.py'
vr.write_text(r'''#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve(); bi=root/'BUILD_ISO'
perf=(root/'performance.py').read_text(errors='replace'); router=(root/'media_output_router.py').read_text(errors='replace')
op=(bi/'app-overlay-v35.22zz/performance.py').read_text(errors='replace'); om=(bi/'app-overlay-v35.22zz/media_output_router.py').read_text(errors='replace')
need={
 'R23 runtime marker':'GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in perf and 'GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in router,
 'root/overlay playback sync':perf==op and router==om,
 'no eager null output':'--ao=null' not in perf and 'args.append("--ao=null")' not in router,
 'no accidental stale-token comment':'Historical R6 verifier token only' not in perf and 'Historical R6 verifier token only' not in op,
 '48k stereo boundary':'--audio-samplerate=48000' in perf and '--audio-samplerate=48000' in router and '--audio-channels=stereo' in perf and '--audio-channels=stereo' in router,
 'real hardware first':'--audio-fallback-to-null=no' in perf and '--audio-fallback-to-null=no' in router and '_preferred_alsa_output_device' in router and '--ao=alsa' in router,
 'two-stage stalled-clock recovery':'def _recover_player_output' in perf and '--ao=alsa,pulse,pipewire' in perf and 'hardware recovery exhausted' in perf and '["set_property", "aid", "no"]' in perf,
}
for rel in ['BUILD_ISO/verify_v35_22.py','BUILD_ISO/verify_v35_22zz.py','BUILD_ISO/verify_v35_22zz_r14.py','BUILD_ISO/verify_v35_22zz_r17.py','BUILD_ISO/verify_v35_22zz_r22.py','BUILD_ISO/verify_v35_22zz_r19.py','test_performance_event_loop_r6.py','test_r14_audio_video_performance_microsd.py','test_r22_isolated_device_probe_streaming.py']:
    need['R23-aware '+rel]='GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001' in (root/rel).read_text(errors='replace')
bad=[k for k,v in need.items() if not v]
for k,v in need.items(): print(('PASS' if v else 'FAIL')+': '+k)
if bad: raise SystemExit(4)
print('PASS: v35.22zz-R23b stale null-audio verifier sweep + real-audio-first recovery contracts')
'''); vr.chmod(0o755)
for rel, anchor, add in [
 ('BUILD_ISO/RUN_ME_ZERO_STATE.sh','python3 "$HERE/verify_v35_22zz_r23.py" "$ROOT"\n','python3 "$HERE/verify_v35_22zz_r23b.py" "$ROOT"\n'),
 ('BUILD_ISO/RUN_ME_v35_22.sh','python3 "$BI/verify_v35_22zz_r23.py" "$ROOT"\n','python3 "$BI/verify_v35_22zz_r23b.py" "$ROOT"\n')]:
    p=root/rel; s=p.read_text()
    if add not in s:
        if anchor not in s: raise SystemExit('FAIL: runner anchor missing: '+rel)
        s=s.replace(anchor,anchor+add)
    if rel.endswith('RUN_ME_v35_22.sh'):
        s=s.replace('# R22a: the v33c ISO is a build intermediate only.','# R23b: the v33c ISO is a build intermediate only.')
        s=s.replace('PASS: R22 single-release-ISO cleanup; final ISO:','PASS: R23b single-release-ISO cleanup; final ISO:')
    p.write_text(s)
(root/'RELEASE-v35.22zz-R23b-STALE-NULL-CONTRACT-SWEEP-20261001.txt').write_text('''Groovebox/sOS v35.22zz-R23b — stale null-audio verifier sweep — 2026-10-01\n\nRuntime playback is unchanged from R23/R23a. Active cumulative verifiers/tests now recognize the R23 real-audio-first 48 kHz recovery path instead of requiring --audio-fallback-to-null=yes.\n''')
print('PASS: R23b in-place verifier sweep applied to',root)
PY
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r14.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r17.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23b.py" "$ROOT"
echo 'PASS: R23b hotfix verified. Re-run ./RUN_ME_ZERO_STATE.sh from BUILD_ISO.'
