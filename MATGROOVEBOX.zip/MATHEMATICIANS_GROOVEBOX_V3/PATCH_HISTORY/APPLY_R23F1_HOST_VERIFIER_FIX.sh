#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
for rel in ('test_r23f_sos_analog_output.py','BUILD_ISO/test_r23f_sos_analog_output.py'):
    p=root/rel
    s=p.read_text()
    if 'R23F1_HOST_NUMPY_INDEPENDENT_TEST_20261002' not in s:
        s=s.replace('#!/usr/bin/env python3\n', '#!/usr/bin/env python3\n# R23F1_HOST_NUMPY_INDEPENDENT_TEST_20261002\n', 1)
        old='import os, sys\nfrom pathlib import Path\n'
        new='''import os, sys, types\nfrom pathlib import Path\n\n# Routing/scoring verifier only: do not require Groovebox runtime site-packages\n# on the Fedora host used to build the appliance. Runtime NumPy remains bundled.\ntry:\n    import numpy  # noqa: F401\nexcept ModuleNotFoundError:\n    sys.modules["numpy"] = types.ModuleType("numpy")\n'''
        if old not in s:
            raise SystemExit(f'FAIL: expected import block not found in {p}')
        s=s.replace(old,new,1)
        p.write_text(s)
p=root/'BUILD_ISO/verify_v35_22zz_r23f.py'
s=p.read_text()
if 'R23F1_HOST_VERIFIER_ISOLATION_20261002' not in s:
    s=s.replace('# GROOVEBOX_V35_22ZZ_R23F_SOS_ANALOG_OUTPUT_PREP_VERIFY_20261002\n', '# GROOVEBOX_V35_22ZZ_R23F_SOS_ANALOG_OUTPUT_PREP_VERIFY_20261002\n# R23F1_HOST_VERIFIER_ISOLATION_20261002\n',1)
    old="subprocess.run([sys.executable,str(root/'test_r23f_sos_analog_output.py')],cwd=root,check=True)"
    new="subprocess.run([sys.executable,'-S',str(root/'test_r23f_sos_analog_output.py')],cwd=root,check=True)"
    if old not in s:
        raise SystemExit('FAIL: expected R23f verifier subprocess line not found')
    s=s.replace(old,new,1)
    s=s.replace("print('PASS: v35.22zz-R23f sOS physical analog default + ALSA/UCM speaker preparation contracts')", "print('PASS: R23f1 host verifier is independent of site-packages/NumPy')\nprint('PASS: v35.22zz-R23f sOS physical analog default + ALSA/UCM speaker preparation contracts')")
    p.write_text(s)
PY
chmod 0755 "$ROOT/test_r23f_sos_analog_output.py" "$HERE/test_r23f_sos_analog_output.py" "$HERE/verify_v35_22zz_r23f.py"
python3 -S "$ROOT/test_r23f_sos_analog_output.py"
python3 "$HERE/verify_v35_22zz_r23f.py" "$ROOT"
echo 'PASS: R23f1 host verifier isolation hotfix applied'
