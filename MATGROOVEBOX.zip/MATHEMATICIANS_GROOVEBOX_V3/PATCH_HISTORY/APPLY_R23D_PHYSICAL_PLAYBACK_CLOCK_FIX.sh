#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ "$(basename "$HERE")" == "BUILD_ISO" ]]; then ROOT="$(cd "$HERE/.." && pwd -P)"; else ROOT="$HERE"; fi
[[ -f "$ROOT/performance.py" && -f "$ROOT/media_output_router.py" && -d "$ROOT/BUILD_ISO" ]] || { echo "FAIL: place this script in Groovebox root or BUILD_ISO" >&2; exit 2; }
if grep -Fq 'GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001' "$ROOT/performance.py" && grep -Fq 'verify_v35_22zz_r23d.py' "$ROOT/BUILD_ISO/RUN_ME_ZERO_STATE.sh"; then
  echo 'PASS: R23d already applied'
  exit 0
fi
python3 - "$ROOT" <<'PYFIX'
from pathlib import Path
root=Path(__import__('sys').argv[1]).resolve()

# Patch media_output_router.py in root and overlay.
for p in [root/'media_output_router.py', root/'BUILD_ISO/app-overlay-v35.22zz/media_output_router.py']:
    s=p.read_text()
    if '# GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001' not in s:
        s=s.replace('# GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001', '# GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001\n# GROOVEBOX_V35_22ZZ_R23_PLAYBACK_OUTPUT_RECOVERY_20261001',1)
    old='''def _preferred_alsa_output_device() -> str:\n    """Return an mpv ALSA device that bypasses a stale Pulse default when possible."""\n    if not _real_alsa_playback_available():\n        return ""\n    txt=_run_text(["aplay","-L"],timeout=2.0)\n    names=[line.strip() for line in txt.splitlines() if line and not line[0].isspace()]\n    clean=[n for n in names if not any(t in n.casefold() for t in ("null","lavrate","samplerate","speexrate","jack"))]\n    for prefixes in (("sysdefault:",), ("front:",), ("plughw:",), ("hw:",), ("default",)):\n        for name in clean:\n            low=name.casefold()\n            if any(low == pre or low.startswith(pre) for pre in prefixes):\n                return "alsa/"+name\n    return "alsa/default"\n'''
    new='''def _physical_alsa_playback_device() -> str:\n    """Return a direct plughw PCM, preferring the internal/analog playback device.\n\n    ``sysdefault`` can still resolve through a Pulse plugin on minimal boots.  The\n    ``plughw`` PCM stays on ALSA while retaining format/rate conversion, which is\n    exactly what the Dell appliance needs for a deterministic 48 kHz boundary.\n    """\n    if not _real_alsa_playback_available():\n        return ""\n    txt=_run_text(["aplay","-l"],timeout=1.5)\n    candidates=[]\n    rx=re.compile(r"^card\\s+(\\d+):\\s*([^\\s\\[]+).*?device\\s+(\\d+):\\s*(.*)$", re.I)\n    for raw in txt.splitlines():\n        m=rx.search(raw.strip())\n        if not m:\n            continue\n        card_i, card_id, dev_i, desc=m.groups()\n        low=(card_id+" "+desc).casefold()\n        score=0\n        if any(t in low for t in ("analog","speaker","pch","sof","hda","alc")): score += 100\n        if any(t in low for t in ("hdmi","displayport","spdif","iec958")): score -= 80\n        if "usb" in low: score += 20\n        try: score -= int(card_i)*2 + int(dev_i)\n        except Exception: pass\n        candidates.append((score, card_id, dev_i))\n    if candidates:\n        _, card_id, dev_i=max(candidates, key=lambda x:x[0])\n        return f"alsa/plughw:CARD={card_id},DEV={dev_i}"\n    return ""\n\ndef _preferred_alsa_output_device() -> str:\n    """Return an mpv ALSA device that bypasses stale Pulse/default plugins."""\n    direct=_physical_alsa_playback_device()\n    if direct:\n        return direct\n    if not _real_alsa_playback_available():\n        return ""\n    txt=_run_text(["aplay","-L"],timeout=2.0)\n    names=[line.strip() for line in txt.splitlines() if line and not line[0].isspace()]\n    clean=[n for n in names if not any(t in n.casefold() for t in ("null","lavrate","samplerate","speexrate","jack"))]\n    # plughw first: it is direct ALSA with conversion. sysdefault is only a later\n    # compatibility fallback because some distributions wire it back to Pulse.\n    for prefixes in (("plughw:",), ("front:",), ("hw:",), ("sysdefault:",), ("default",)):\n        for name in clean:\n            low=name.casefold()\n            if any(low == pre or low.startswith(pre) for pre in prefixes):\n                return "alsa/"+name\n    return "alsa/default"\n'''
    if old not in s:
        raise SystemExit(f'router preferred block not found in {p}')
    s=s.replace(old,new,1)
    s=s.replace('''        if getattr(audio,"backend","pulse") == "alsa":\n            args.append(f"--audio-device={audio.name}")\n''','''        if getattr(audio,"backend","pulse") == "alsa":\n            args.extend(["--ao=alsa", f"--audio-device={audio.name}"])\n''',1)
    p.write_text(s)

# Patch performance.py root and overlay.
for p in [root/'performance.py', root/'BUILD_ISO/app-overlay-v35.22zz/performance.py']:
    s=p.read_text()
    marker='# GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001\n'
    if marker not in s:
        # Insert after imports/header marker nearest beginning.
        s=marker+s
    # Add startup clock state after recovery state init.
    old='''        self.force_safe_audio = False\n        self.resume_position = 0.0\n'''
    new='''        self.force_safe_audio = False\n        self.resume_position = 0.0\n        self.started_at = 0.0\n'''
    if old not in s:
        raise SystemExit(f'deck init block not found {p}')
    s=s.replace(old,new,1)
    # Remove weak recovery AO insertion; safe route will be rebuilt after generic routing.
    old='''            if self.force_safe_audio:\n                # Recovery only: bypass a stale Pulse selection and make mpv try\n                # direct ALSA first, then Pulse/PipeWire. 48 kHz is already pinned\n                # by the normal command builder.\n                extra.append("--ao=alsa,pulse,pipewire")\n'''
    new='''            if self.force_safe_audio:\n                # R23d rebuilds the safe AO after generic destination routing so\n                # an explicit physical ALSA device cannot be accidentally erased.\n                pass\n'''
    if old not in s:
        raise SystemExit(f'force safe extra block not found {p}')
    s=s.replace(old,new,1)
    old='''        if self.force_safe_audio:\n            # Ignore a stale per-sink selection during recovery. The AO chain\n            # above chooses the first physically usable backend.\n            cmd = [a for a in cmd if not str(a).startswith("--audio-device=")]\n            env.pop("PULSE_SINK", None)\n        try:\n            self.proc = subprocess.Popen(cmd + [path], env=env)\n            self.resume_position = 0.0\n            return True, ""\n'''
    new='''        if self.force_safe_audio:\n            # Recovery must not fall back to generic ALSA "default": on the sOS\n            # appliance that alias can still resolve through the failed Pulse\n            # compatibility layer. Strip earlier AO choices, then pin the best\n            # physical plughw PCM discovered from ``aplay -l``.\n            cmd = [a for a in cmd if not (str(a).startswith("--audio-device=") or str(a).startswith("--ao="))]\n            env.pop("PULSE_SINK", None)\n            try:\n                from media_output_router import _preferred_alsa_output_device\n                physical = _preferred_alsa_output_device()\n            except Exception:\n                physical = ""\n            if physical:\n                cmd.extend(["--ao=alsa", f"--audio-device={physical}", "--audio-format=s16"])\n            else:\n                # No ALSA card was visible. Give the two session backends one\n                # final chance without inheriting a stale per-sink selection.\n                cmd.append("--ao=pipewire,pulse,alsa")\n        try:\n            self.proc = subprocess.Popen(cmd + [path], env=env)\n            self.started_at = time.monotonic()\n            self.resume_position = 0.0\n            return True, ""\n'''
    if old not in s:
        raise SystemExit(f'post routing recovery block not found {p}')
    s=s.replace(old,new,1)
    # Set start time for persistent loadfile reuse too.
    old='''                self.send(["set_property", "pause", False])\n                self.send(["set_property", "speed", self.speed])\n'''
    new='''                self.send(["set_property", "pause", False])\n                self.started_at = time.monotonic()\n                self.send(["set_property", "speed", self.speed])\n'''
    if old not in s:
        raise SystemExit(f'persistent loadfile block not found {p}')
    s=s.replace(old,new,1)
    # Reset start time on stop.
    old='''        self.ipc_path = None\n\n    def set_speed(self, speed: float):\n'''
    new='''        self.ipc_path = None\n        self.started_at = 0.0\n\n    def set_speed(self, speed: float):\n'''
    if old not in s:
        raise SystemExit(f'stop tail not found {p}')
    s=s.replace(old,new,1)
    # Replace pos handling with startup no-clock recovery too.
    old='''        pos = status.get("time_pos")\n        if isinstance(pos, (int, float)):\n            now = time.monotonic()\n            previous = self._last_player_time_pos\n            if previous is None or abs(pos - previous) >= 0.03:\n                self._last_player_time_pos = pos\n                self._last_player_progress_at = now\n            elif (not self._safe_audio_recovery_used\n                  and now - self._last_player_progress_at >= 2.5):\n                # First recovery preserves sound: restart at the same position\n                # through a direct safe AO chain at 48 kHz stereo.\n                if self._recover_player_output(pos, "clock-stall"):\n                    return\n            elif (self._safe_audio_recovery_used and not self._video_clock_escape_used\n                  and self._deckA.want_video and now - self._last_player_progress_at >= 3.0):\n                self._video_clock_escape_used = True\n                # Last resort for video only. We never start silently anymore;\n                # audio is detached only after both normal and safe output paths\n                # have been verified not to advance the clock.\n                self._deckA.send(["set_property", "video-sync", "desync"])\n                self._deckA.send(["set_property", "aid", "no"])\n                self._deckA.send(["set_property", "pause", False])\n                self.lbl_status.setText("PLAYER_CLOCK_STALLED · hardware recovery exhausted; video detached from failed audio clock")\n'''
    new='''        pos = status.get("time_pos")\n        now = time.monotonic()\n        if isinstance(pos, (int, float)):\n            previous = self._last_player_time_pos\n            if previous is None or abs(pos - previous) >= 0.03:\n                self._last_player_time_pos = pos\n                self._last_player_progress_at = now\n            elif (not self._safe_audio_recovery_used\n                  and now - self._last_player_progress_at >= 2.5):\n                # First recovery preserves sound: restart at the same position\n                # through a direct physical plughw route at 48 kHz stereo.\n                if self._recover_player_output(pos, "clock-stall"):\n                    return\n            elif (self._safe_audio_recovery_used and not self._video_clock_escape_used\n                  and self._deckA.want_video and now - self._last_player_progress_at >= 3.0):\n                self._video_clock_escape_used = True\n                self._deckA.send(["set_property", "video-sync", "desync"])\n                self._deckA.send(["set_property", "aid", "no"])\n                self._deckA.send(["set_property", "pause", False])\n                self.lbl_status.setText("PLAYER_CLOCK_STALLED · physical audio recovery exhausted; video detached from failed audio clock")\n        elif self._deckA.is_running() and self._deckA.started_at > 0:\n            # R23d: a player that never acquires a clock reports time-pos=None.\n            # The old watchdog ignored this forever, which matched the Dell\n            # symptom: window opens/scrubs, but playback never advances.\n            age = now - self._deckA.started_at\n            if not self._safe_audio_recovery_used and age >= 2.5:\n                if self._recover_player_output(0.0, "startup-no-clock"):\n                    return\n            elif (self._safe_audio_recovery_used and not self._video_clock_escape_used\n                  and self._deckA.want_video and age >= 3.5):\n                self._video_clock_escape_used = True\n                self._deckA.send(["set_property", "video-sync", "desync"])\n                self._deckA.send(["set_property", "aid", "no"])\n                self._deckA.send(["set_property", "pause", False])\n                self.lbl_status.setText("PLAYER_STARTUP_CLOCK_STALLED · physical audio recovery exhausted; video detached from failed audio clock")\n'''
    if old not in s:
        raise SystemExit(f'watchdog block not found {p}')
    s=s.replace(old,new,1)
    p.write_text(s)

# Add verifier.
bi=root/'BUILD_ISO'
ver=bi/'verify_v35_22zz_r23d.py'
ver.write_text('''#!/usr/bin/env python3\nfrom pathlib import Path\nimport sys\nroot=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve(); bi=root/'BUILD_ISO'\np=(root/'performance.py').read_text(errors='replace'); m=(root/'media_output_router.py').read_text(errors='replace')\nop=(bi/'app-overlay-v35.22zz/performance.py').read_text(errors='replace'); om=(bi/'app-overlay-v35.22zz/media_output_router.py').read_text(errors='replace')\nchecks={\n 'R23d Performance marker':'GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001' in p,\n 'R23d router marker':'GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001' in m,\n 'physical plughw parser':'def _physical_alsa_playback_device' in m and 'alsa/plughw:CARD=' in m,\n 'physical device preferred before sysdefault':'(("plughw:",), ("front:",), ("hw:",), ("sysdefault:",)' in m,\n 'safe recovery preserves physical endpoint':'from media_output_router import _preferred_alsa_output_device' in p and 'f"--audio-device={physical}"' in p,\n 'safe recovery strips stale route then repins':'str(a).startswith("--audio-device=") or str(a).startswith("--ao=")' in p,\n 'startup no-clock watchdog':'startup-no-clock' in p and 'time-pos=None' in p,\n '48k stereo boundary retained':'--audio-samplerate=48000' in p and '--audio-channels=stereo' in p,\n 'no eager null output':'--ao=null' not in p and 'args.append("--ao=null")' not in m,\n 'root/overlay Performance sync':p==op,\n 'root/overlay router sync':m==om,\n}\nbad=[k for k,v in checks.items() if not v]\nfor k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)\nif bad: raise SystemExit(4)\nprint('PASS: v35.22zz-R23d physical plughw playback + startup-clock recovery contracts')\n''')
ver.chmod(0o755)
# Wire verifier before build handoff.
z=bi/'RUN_ME_ZERO_STATE.sh'; s=z.read_text()
if 'verify_v35_22zz_r23d.py' not in s:
    s=s.replace('python3 "$HERE/verify_v35_22zz_r23c.py" "$ROOT"\nexec bash', 'python3 "$HERE/verify_v35_22zz_r23c.py" "$ROOT"\npython3 "$HERE/verify_v35_22zz_r23d.py" "$ROOT"\nexec bash')
    s='# GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_ZERO_STATE_20261001\n'+s
z.write_text(s)
# Release note.
(root/'RELEASE-v35.22zz-R23d-PHYSICAL-PLAYBACK-CLOCK-20261001.txt').write_text('''v35.22zz-R23d PHYSICAL PLAYBACK CLOCK — 2026-10-01\n\n- Leaves the now-working recording/capture path unchanged.\n- Fixes the Player/DJ safe-recovery bug that discarded the physical ALSA --audio-device endpoint after discovery.\n- Prefers direct ALSA plughw internal/analog playback parsed from `aplay -l`, retaining 48 kHz stereo conversion while bypassing stale Pulse/default aliases.\n- Treats mpv time-pos=None at startup as a clock failure and automatically restarts once on the physical playback endpoint.\n- Video detaches from audio only after normal and direct-physical recovery both fail.\n''')
(root/'BUILD_ISO/RELEASE-v35.22zz-R23d-PHYSICAL-PLAYBACK-CLOCK-20261001.txt').write_text((root/'RELEASE-v35.22zz-R23d-PHYSICAL-PLAYBACK-CLOCK-20261001.txt').read_text())
# Compatibility verifier wording/contract update for the R23d physical route.
for pp in [root/'performance.py', root/'BUILD_ISO/app-overlay-v35.22zz/performance.py']:
    t=pp.read_text().replace('physical audio recovery exhausted','physical hardware recovery exhausted')
    pp.write_text(t)
pp=root/'BUILD_ISO/verify_v35_22zz_r23.py'; t=pp.read_text()
t=t.replace("'safe AO recovery':'--ao=alsa,pulse,pipewire' in p,", "'safe AO recovery':('--ao=alsa,pulse,pipewire' in p or ('GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001' in p and 'f\"--audio-device={physical}\"' in p)),")
pp.write_text(t)
pp=root/'BUILD_ISO/verify_v35_22zz_r23b.py'; t=pp.read_text()
t=t.replace("'two-stage stalled-clock recovery':'def _recover_player_output' in perf and '--ao=alsa,pulse,pipewire' in perf and 'hardware recovery exhausted' in perf and '[\"set_property\", \"aid\", \"no\"]' in perf,", "'two-stage stalled-clock recovery':'def _recover_player_output' in perf and (('--ao=alsa,pulse,pipewire' in perf) or ('GROOVEBOX_V35_22ZZ_R23D_PHYSICAL_PLAYBACK_CLOCK_20261001' in perf and 'f\"--audio-device={physical}\"' in perf)) and 'hardware recovery exhausted' in perf and '[\"set_property\", \"aid\", \"no\"]' in perf,")
pp.write_text(t)
print('patched')

PYFIX
python3 -m py_compile "$ROOT/performance.py" "$ROOT/media_output_router.py" "$ROOT/BUILD_ISO/verify_v35_22zz_r23d.py"
bash -n "$ROOT/BUILD_ISO/RUN_ME_ZERO_STATE.sh"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23b.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23c.py" "$ROOT"
python3 "$ROOT/BUILD_ISO/verify_v35_22zz_r23d.py" "$ROOT"
echo "PASS: R23d physical playback clock hotfix applied"
