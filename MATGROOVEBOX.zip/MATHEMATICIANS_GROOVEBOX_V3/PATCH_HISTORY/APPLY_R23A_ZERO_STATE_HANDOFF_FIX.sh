#!/usr/bin/env bash
# GROOVEBOX_V35_22ZZ_R23A_ZERO_STATE_BUILD_HANDOFF_20261001
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
# May be launched from project root, BUILD_ISO, or copied next to the project.
if [[ -f "$PWD/RUN_ME_ZERO_STATE.sh" && -f "$PWD/RUN_ME_v35_22.sh" ]]; then
  BI="$PWD"
elif [[ -f "$PWD/BUILD_ISO/RUN_ME_ZERO_STATE.sh" ]]; then
  BI="$PWD/BUILD_ISO"
elif [[ -f "$HERE/BUILD_ISO/RUN_ME_ZERO_STATE.sh" ]]; then
  BI="$HERE/BUILD_ISO"
else
  echo 'FAIL: cannot locate BUILD_ISO/RUN_ME_ZERO_STATE.sh' >&2
  exit 2
fi
F="$BI/RUN_ME_ZERO_STATE.sh"
python3 - "$F" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
bad='exec python3 "$HERE/verify_v35_22zz_r23.py" "$ROOT"'
good='python3 "$HERE/verify_v35_22zz_r23.py" "$ROOT"'
handoff='exec bash "$HERE/RUN_ME_v35_22.sh" "$ROOT"'
marker='# GROOVEBOX_V35_22ZZ_R23A_ZERO_STATE_BUILD_HANDOFF_20261001\n'
if bad in s:
    s=s.replace(bad,good,1)
if 'bash "$HERE/RUN_ME_v35_22.sh" "$ROOT"' in s:
    s=s.replace('bash "$HERE/RUN_ME_v35_22.sh" "$ROOT"',handoff,1)
if marker.strip() not in s:
    s=marker+s
if bad in s or good not in s or handoff not in s:
    raise SystemExit('FAIL: zero-state handoff patch did not reach required state')
p.write_text(s)
PY
bash -n "$F"
echo "PASS: R23a zero-state verifier returns normally and hands off to RUN_ME_v35_22.sh"
echo "Patched: $F"
echo 'Now run: ./RUN_ME_ZERO_STATE.sh'
