#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
# R23j superseded the old WAV-only direct aplay fallback with a universal
# FFmpeg -> 48 kHz stereo PCM -> physical ALSA fallback. Keep historical
# storage/audio verifiers, but verify the stronger current implementation.
p=root/'BUILD_ISO/verify_v35_22zz_r23e.py'
s=p.read_text()
s=s.replace("'direct ALSA WAV fallback':'def play_direct_audio(self, path: str):' in perf and 'shutil.which(\"aplay\")' in perf and 'DIRECT-ALSA-PLAYBACK' in perf,",
            "'universal direct ALSA fallback':'def play_direct_audio(self, path: str, start_s: float = 0.0):' in perf and '_launch_physical_pcm_pipeline(path,start_s=start_s)' in perf and 'DIRECT-ALSA-PLAYBACK' in perf and 'universal physical PCM fallback' in perf,")
s=s.replace('direct ALSA WAV playback contracts','universal direct ALSA playback contracts')
p.write_text(s)

p=root/'BUILD_ISO/verify_v35_22zz_r23g.py'
s=p.read_text()
s=s.replace("'inline WAV uses direct ALSA first':'Inline physical ALSA play:' in p and 'cmd=[tool,\"-q\",\"-D\",dev,path]' in p,",
            "'inline audio uses universal direct ALSA first':'_launch_physical_pcm_pipeline(path)' in p and 'Inline physical audio:' in p and 'FFmpeg decodes' in p,")
s=s.replace('inline physical-ALSA playback + actionable','universal inline physical-ALSA playback + actionable')
p.write_text(s)
PY
python3 "$HERE/verify_v35_22zz_r23e.py" "$ROOT"
python3 "$HERE/verify_v35_22zz_r23g.py" "$ROOT"
python3 "$HERE/verify_v35_22zz_r23h.py" "$ROOT"
python3 "$HERE/verify_v35_22zz_r23i.py" "$ROOT"
python3 "$HERE/verify_v35_22zz_r23j.py" "$ROOT"
echo 'PASS: R23j1 verifier synchronization applied; rerun BUILD_ISO/RUN_ME_ZERO_STATE.sh'
