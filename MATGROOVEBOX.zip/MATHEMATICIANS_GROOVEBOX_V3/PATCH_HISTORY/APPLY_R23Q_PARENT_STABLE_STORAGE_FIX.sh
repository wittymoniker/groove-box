#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -d "$HERE/BUILD_ISO" ]]; then ROOT="$HERE"; elif [[ "$(basename "$HERE")" == BUILD_ISO ]]; then ROOT="$(cd "$HERE/.." && pwd)"; elif [[ -d "$PWD/BUILD_ISO" ]]; then ROOT="$PWD"; elif [[ "$(basename "$PWD")" == BUILD_ISO ]]; then ROOT="$(cd "$PWD/.." && pwd)"; else echo 'FAIL: run this from the R23p Groovebox root or BUILD_ISO directory.' >&2; exit 2; fi
BI="$ROOT/BUILD_ISO"
READY="$BI/v35_18f/sos-storage-ready-v35_18f"
[[ -f "$READY" && -f "$BI/verify_v35_22zz_r23p.py" ]] || { echo 'FAIL: expected R23p BUILD_ISO files not found.' >&2; exit 3; }
python3 - "$READY" "$BI/verify_v35_22zz_r23p.py" <<'PY'
from pathlib import Path
import sys
ready=Path(sys.argv[1]); ver=Path(sys.argv[2])
s=ready.read_text()
# First load uses the safe alternate interrupt policy without detaching the live parent later.
s=s.replace('''  # R23p: first try the kernel default MSI policy. Some RTS525A/RTS5260
  # controllers do not create their MFD SD/MMC child when forced to the wrong
  # interrupt mode. A guarded boot-only msi_en=0 retry is below if no host exists.
  modprobe rtsx_pci >>"$LOG" 2>&1 || true
''','''  # R23q hotfix: select the Realtek interrupt policy before the PCI parent binds.
  # Never detach or unload the live PCI parent later in boot.
  modprobe rtsx_pci msi_en=0 >>"$LOG" 2>&1 || true
''')
old='''if ! ls /sys/class/mmc_host/mmc* >/dev/null 2>&1; then
  ids="$(realtek_reader_ids)"
  for id in $ids; do
    d="/sys/bus/pci/devices/$id"
    drv="$(basename "$(readlink -f "$d/driver" 2>/dev/null)" 2>/dev/null)"
    [ "$drv" = rtsx_pci ] || continue
    reader_has_block_descendant "$id" && { log "MICROSD_BOOT_RESET|REFUSED|$id|block-descendant"; continue; }
    # No host + no block descendant at this pre-daemon point: quiesce only this
    # reader, reload rtsx_pci with the alternate interrupt policy, then reprobe.
    if [ -w /sys/bus/pci/drivers/rtsx_pci/unbind ]; then
      log "MICROSD_BOOT_RESET|BEGIN|$id|alternate-msi"
      echo "$id" >/sys/bus/pci/drivers/rtsx_pci/unbind 2>>"$LOG" || continue
      modprobe -r rtsx_pci_sdmmc >>"$LOG" 2>&1 || true
      modprobe -r rtsx_pci >>"$LOG" 2>&1 || true
      modprobe rtsx_pci msi_en=0 >>"$LOG" 2>&1 || true
      modprobe rtsx_pci_sdmmc >>"$LOG" 2>&1 || true
      [ -w /sys/bus/pci/drivers_probe ] && echo "$id" >/sys/bus/pci/drivers_probe 2>>"$LOG" || true
      boot_bind_children
      log "MICROSD_BOOT_RESET|END|$id|msi_en=$(cat /sys/module/rtsx_pci/parameters/msi_en 2>/dev/null || echo unknown)"
    fi
    ls /sys/class/mmc_host/mmc* >/dev/null 2>&1 && break
  done
fi
'''
new='''if ! ls /sys/class/mmc_host/mmc* >/dev/null 2>&1; then
  # R23q hotfix: parent stays bound. Repair only the SD/MMC platform child.
  log 'MICROSD_BOOT_RECOVERY|CHILD-PROBE-ONLY|parent-stable'
  modprobe rtsx_pci_sdmmc >>"$LOG" 2>&1 || true
  boot_bind_children
  if command -v udevadm >/dev/null 2>&1; then
    udevadm trigger --subsystem-match=mmc --action=add >>"$LOG" 2>&1 || true
    udevadm trigger --subsystem-match=block --action=add >>"$LOG" 2>&1 || true
    udevadm settle --timeout=2 >>"$LOG" 2>&1 || true
  fi
fi
'''
if old in s:
    s=s.replace(old,new)
elif '/sys/bus/pci/drivers/rtsx_pci/unbind' in s or 'modprobe -r rtsx_pci >>' in s:
    raise SystemExit('FAIL: storage helper differs from expected R23p layout; use full R23q archive.')
if 'GROOVEBOX_V35_22ZZ_R23Q_PARENT_STABLE_STORAGE_20261004' not in s:
    lines=s.splitlines(); lines.insert(2,'# GROOVEBOX_V35_22ZZ_R23Q_PARENT_STABLE_STORAGE_20261004'); s='\n'.join(lines)+'\n'
ready.write_text(s)
vs=ver.read_text()
vs=vs.replace("('guarded boot reader reset','reader_has_block_descendant' in storage and 'MICROSD_BOOT_RESET|BEGIN' in storage),",
              "('parent-stable boot recovery','/sys/bus/pci/drivers/rtsx_pci/unbind' not in storage and 'modprobe -r rtsx_pci' not in storage and 'CHILD-PROBE-ONLY' in storage),")
ver.write_text(vs)
PY
sh -n "$READY"
if grep -Eq 'driver/unbind|/sys/bus/pci/drivers/rtsx_pci/unbind|modprobe -r rtsx_pci([[:space:]]|$)' "$READY"; then
  echo 'FAIL: forbidden Realtek PCI parent detach remains.' >&2; exit 4
fi
python3 "$BI/verify_v35_22.py" "$BI"
python3 "$BI/verify_v35_22zz_r23o.py"
python3 "$BI/verify_v35_22zz_r23p.py"
echo 'PASS: R23q parent-stable storage hotfix applied. Re-run BUILD_ISO/RUN_ME_ZERO_STATE.sh.'
