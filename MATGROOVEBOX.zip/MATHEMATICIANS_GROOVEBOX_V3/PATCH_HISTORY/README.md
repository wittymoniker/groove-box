# Preserved Groovebox patch lineage

This directory contains patch artifacts recovered from the project Library for audit/reference.
The base source is R23r, which is already a descendant of the earlier R23 revisions; do not
blindly reapply these scripts over R23r. They are preserved as historical artifacts, not run
as part of this reconstruction. R24-R26 patch payloads were not present in the accessible
Library snapshot, so this release does not claim to reproduce them.
