#!/usr/bin/env python3
"""Verify the frozen runtime hook resolves the actual Windows wheel DLL name."""
from pathlib import Path
import ctypes.util
import importlib.util
import sys
import tempfile

HOOK = Path(__file__).with_name("pyi_rth_groovebox_portaudio.py")
spec = importlib.util.spec_from_file_location("groovebox_portaudio_hook_test", HOOK)
module = importlib.util.module_from_spec(spec)
old_meipass = getattr(sys, "_MEIPASS", None)
old_find = ctypes.util.find_library
try:
    with tempfile.TemporaryDirectory(prefix="groovebox-portaudio-hook-") as td:
        root = Path(td)
        payload = root / "_sounddevice_data" / "portaudio-binaries"
        payload.mkdir(parents=True)
        dll = payload / "libportaudio64bit.dll"
        dll.write_bytes(b"fixture-dll")
        sys._MEIPASS = str(root)
        spec.loader.exec_module(module)
        assert module._first("libportaudio64bit.dll") == dll
        assert module._find_library("portaudio") == str(dll)
        arm = payload / "libportaudioarm64.dll"
        arm.write_bytes(b"arm64-fixture")
        assert module._first("libportaudioarm64.dll") == arm
finally:
    ctypes.util.find_library = old_find
    if old_meipass is None:
        try: del sys._MEIPASS
        except AttributeError: pass
    else:
        sys._MEIPASS = old_meipass
print("PASS: frozen sounddevice hook resolves libportaudio64bit.dll from PyInstaller data")
