$ErrorActionPreference = 'Stop'
$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Kit
Set-Location $Root

function Refresh-ProcessPath {
  $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
  $user = [Environment]::GetEnvironmentVariable('Path', 'User')
  $env:Path = "$machine;$user;$env:Path"
}
function Invoke-Checked([string]$Label, [scriptblock]$Command) {
  Write-Host "==> $Label"
  & $Command
  if ($LASTEXITCODE -ne 0) { throw "$Label failed with exit code $LASTEXITCODE" }
}

if (-not (Get-Command python -ErrorAction SilentlyContinue) -and -not (Get-Command py -ErrorAction SilentlyContinue)) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw 'Python 3.11/3.12 is required; winget is unavailable.' }
  winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
  if ($LASTEXITCODE -ne 0) { throw "Python installation failed with exit code $LASTEXITCODE" }
  Refresh-ProcessPath
}
if (-not (Get-Command python -ErrorAction SilentlyContinue) -and -not (Get-Command py -ErrorAction SilentlyContinue)) {
  throw 'Python was installed but is not visible in this session. Open a new PowerShell and rerun.'
}
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue) -and -not (Get-Command link.exe -ErrorAction SilentlyContinue) -and (Get-Command winget -ErrorAction SilentlyContinue)) {
  Write-Host '==> Installing optional Visual Studio C++ Build Tools'
  winget install --id Microsoft.VisualStudio.2022.BuildTools -e --accept-source-agreements --accept-package-agreements --override '--wait --passive --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended'
  if ($LASTEXITCODE -ne 0) { Write-Warning 'Visual Studio Build Tools installation failed; native C++ acceleration will be omitted.' }
  Refresh-ProcessPath
}
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -and (Get-Command winget -ErrorAction SilentlyContinue)) {
  winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
  if ($LASTEXITCODE -ne 0) { throw "FFmpeg installation failed with exit code $LASTEXITCODE" }
  Refresh-ProcessPath
}

# Resolve FFmpeg even when winget installed it outside the refreshed PATH.
$Bin = Join-Path $Root 'bin'
New-Item -ItemType Directory -Force $Bin | Out-Null
foreach ($tool in @('ffmpeg.exe','ffprobe.exe')) {
  $base = [IO.Path]::GetFileNameWithoutExtension($tool)
  $cmd = Get-Command $base -ErrorAction SilentlyContinue
  $src = if ($cmd) { $cmd.Source } else { $null }
  if (-not $src) {
    $src = Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Recurse -Filter $tool -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
  }
  if ($src -and (Test-Path $src)) { Copy-Item -Force $src (Join-Path $Bin $tool) }
}

if (Get-Command py -ErrorAction SilentlyContinue) { $Py = (Get-Command py).Source; $PyArgs = @('-3') }
else { $Py = (Get-Command python).Source; $PyArgs = @() }
$Venv = Join-Path $Root '.groovebox-build-venv'
$Vpy = Join-Path $Venv 'Scripts\python.exe'
if (-not (Test-Path $Vpy)) { Invoke-Checked 'Create build virtual environment' { & $Py @PyArgs -m venv $Venv } }
Invoke-Checked 'Upgrade pip/setuptools/wheel' { & $Vpy -m pip install --upgrade pip setuptools wheel }
Invoke-Checked 'Install project requirements' { & $Vpy -m pip install -r (Join-Path $Root 'requirements.txt') }
Invoke-Checked 'Install PyInstaller' { & $Vpy -m pip install 'pyinstaller>=6.10,<7' }
Invoke-Checked 'Verify Qt, WebEngine, and Multimedia imports' { & $Vpy -c "from PyQt6 import QtCore; from PyQt6.QtWebEngineWidgets import QWebEngineView; from PyQt6.QtMultimedia import QMediaDevices, QMediaPlayer, QAudioOutput; from PyQt6.QtMultimediaWidgets import QVideoWidget; print('Qt/WebEngine/Multimedia runtime PASS', QtCore.QT_VERSION_STR)" }
Invoke-Checked 'Verify sounddevice wheel contains its Windows PortAudio DLL' { & $Vpy -c "import pathlib, sounddevice; p=pathlib.Path(sounddevice.__file__).resolve().parent; names={'libportaudio64bit.dll','libportaudio32bit.dll','libportaudioarm64.dll','libportaudio.dll','portaudio.dll'}; found=[x for x in p.rglob('*.dll') if x.name.lower() in names]; print('PortAudio DLL candidates:', found); assert found, 'sounddevice wheel contains no Windows PortAudio DLL'" }
Invoke-Checked 'Provision and verify local FFmpeg/ffprobe' { & $Vpy (Join-Path $Root 'scripts\provision_first_launch.py') }
Invoke-Checked 'Verify bundled sCode runtime' { & $Vpy (Join-Path $Root 'scripts\ensure_native_scode_stage0.py') }
try {
  Invoke-Checked 'Optional Rust toolchain setup' { & $Vpy (Join-Path $Root 'scripts\ensure_rust_toolchain.py') --install }
} catch { Write-Warning "Rust toolchain unavailable; executable builder will use supported fallbacks. $($_.Exception.Message)" }
Invoke-Checked 'Build doctor' { & $Vpy (Join-Path $Kit 'build.py') --doctor }
Write-Host "`nDependencies ready. Build with:`n  .\BUILD_KIT\build_windows.ps1 -Console"
Write-Host 'Rust/C++ accelerators are optional; the packaged Python fallback remains available.'
