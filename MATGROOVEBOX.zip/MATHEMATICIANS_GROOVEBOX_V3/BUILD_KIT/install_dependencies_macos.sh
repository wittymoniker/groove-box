#!/usr/bin/env bash
set -Eeuo pipefail
KIT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT="$(cd "$KIT/.." && pwd -P)"
command -v brew >/dev/null 2>&1 || { echo 'FAIL: Homebrew is required for the macOS build installer.' >&2; exit 3; }
# These are required build/runtime tools; do not swallow a failed Homebrew transaction.
brew install python ffmpeg portaudio glm
if ! xcrun --find clang++ >/dev/null 2>&1; then
  echo '[BUILD_KIT] Xcode Command Line Tools are recommended for the optional C++ accelerator.'
  xcode-select --install || echo '[BUILD_KIT] Xcode tools installation was not started; Python fallback remains available.' >&2
fi
cd "$ROOT"
python3 -m venv .groovebox-build-venv
# shellcheck disable=SC1091
. .groovebox-build-venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip install 'pyinstaller>=6.10,<7'
if ! python "$ROOT/scripts/ensure_rust_toolchain.py" --install; then
  echo '[BUILD_KIT] WARNING: Rust toolchain unavailable; executable will use supported fallback acceleration.' >&2
fi
python "$KIT/build.py" --doctor
printf '\nDependencies ready. Build with:\n  ./BUILD_KIT/build_macos.sh --console\n'
