MATHEMATICIAN'S GROOVEBOX — WIN / MAC / LINUX EXECUTABLE BUILD KIT
===================================================================

This BUILD_KIT directory is designed to remain INSIDE the Groovebox project.
Every script resolves the app root as BUILD_KIT/.., so you can invoke it from
any working directory.

LINUX
  chmod +x BUILD_KIT/*.sh
  ./BUILD_KIT/install_dependencies_linux.sh
  ./BUILD_KIT/build_linux.sh --console

  When that works, make the normal GUI build:
  ./BUILD_KIT/build_linux.sh

  Output:
  dist/MathematiciansGroovebox/MathematiciansGroovebox

MACOS
  chmod +x BUILD_KIT/*.sh
  ./BUILD_KIT/install_dependencies_macos.sh
  ./BUILD_KIT/build_macos.sh --console

WINDOWS POWERSHELL
  Set-ExecutionPolicy -Scope Process Bypass
  .\BUILD_KIT\install_dependencies_windows.ps1
  .\BUILD_KIT\build_windows.ps1 -Console

WINDOWS CMD
  BUILD_KIT\build_windows.bat --console

OPTIONS
  --console     Keep terminal output visible. USE THIS FIRST so errors are visible.
  --onefile     Make one executable rather than the recommended onedir bundle.
  --no-native   Do not compile optional Rust/C++ native accelerators.
  --no-install  Reuse the existing build virtual environment without pip refresh.
  --doctor      Print environment/compiler/media-tool diagnostics only.

IMPORTANT
  Build separately on each target OS. PyInstaller does not cross-compile a
  Windows .exe from Linux or a macOS .app from Windows/Linux.

  The default is ONEDIR because Qt + SciPy + audio/native libraries are easier
  to diagnose and usually start faster. Once ONEDIR works, try --onefile.

LINUX FAILURE REPORT
  Run:
      ./BUILD_KIT/BUILD_DIAGNOSTIC.sh
      ./BUILD_KIT/build_linux.sh --console 2>&1 | tee BUILD_KIT/linux_build_error.txt

  Send back linux_build_diagnostic.txt and linux_build_error.txt. Those contain
  the useful compiler/PyInstaller errors without requiring guesswork.

FFMPEG
  The executable build requires a verified project-local bin/ffmpeg + bin/ffprobe pair.
  BUILD_KIT provisions that pair through scripts/provision_first_launch.py when missing,
  then bundles those exact binaries so the executable does not depend on PATH ffmpeg.

C++ ACCELERATOR
  The builder attempts to compile cpp/groovebox_accel.cpp and includes the
  resulting native library. If no compiler is present or compilation fails, the
  build continues using Groovebox's Python fallback so a missing C++ toolchain
  does not block creation of the application executable.


FULL-GRAPH SCRIPT COMPATIBILITY (2026-09-09)
---------------------------------------------
This build carries graph_script_context.py and the full_graph_v1 runtime contract.
Seed/Instrument/Algorithm/Domain programs can share the same t/x/y/z graph context,
and the resulting named channels are consumed by audio, video/scenograph, and
generated-game paths. RAND PARAM uses a pre-evaluated row cache in realtime.
Canonical and heuristic/random writers can author the richer scripts while preserving
user-authored Instrument Scripts. Keep graph_script_context.py beside groovebox.py
on every platform/appliance install. See HELP_TEXT.md for the public variable list.

## Rust first-class support (v35.22z)

Groovebox ships Rust source for its optional native accelerator and the BUILD_ISO bounded-memory newc streamer. The release archive does not bundle the Rust compiler: the normal Linux/macOS/Windows dependency and launch scripts provision the stable rustup/Cargo toolchain and platform linker when needed. `GROOVEBOX_NATIVE_BACKEND=rust` selects the Rust C-ABI accelerator, `cpp` selects C++, and `auto` prefers Rust then C++ then the authoritative Python/NumPy fallback. The sCode ABI-9 optimizer supplies bounded Rust worker/FFT planning, and the Rust build runs its deterministic unit/parity tests before packaging. BUILD_ISO prebuilds the Rust accelerator and embeds it in `/opt/groovebox/native/`.


HARDWARE DIAGNOSTICS (R28.4.33)
-------------------------------
For laptop-specific Linux audio, camera, HDMI, Wi-Fi, and removable-storage
triage, run `./BUILD_KIT/BUILD_DIAGNOSTIC.sh`. It records read-only system and
hardware inventories alongside the executable build diagnostics. The ISO
builder stages optional AMD/Intel/NVIDIA-open-source/virtual DRM paths and a
broader set of common laptop Wi-Fi and SD/MMC modules when the exact target
kernel provides them. A module being bundled does not guarantee firmware or
working support for every device; test the resulting ISO on target hardware.

The ISO and desktop executable builds are distinct. BUILD_KIT builds the
standalone app for the current OS; BUILD_ISO builds the bootable sOS image.
Use BUILD_ISO/RUN_ME_ZERO_STATE.sh for a clean ISO build, not BUILD_KIT/build.py.

RUNTIME/PACKAGING PREFLIGHT (2026-10-30)
---------------------------------------
The builder now executes the active Python/Qt/WebEngine/Multimedia/NumPy/SciPy/
sounddevice runtime gate even with --no-install, verifies the host-native sCode
ABI-9 runtime before packaging, and checks the resulting bundle rather than only
the executable file size. Windows builds must contain the Qt6 Multimedia and
WebEngine runtime DLLs/resources, ffmpeg/ffprobe, and sounddevice's actual
libportaudio64bit.dll (or 32-bit libportaudio.dll). One-file builds are inspected
through PyInstaller's CArchiveReader to prove the payload is inside the EXE.

Fedora 44 Linux build setup uses the Fedora ffmpeg-free package and does not
request the conflicting RPM Fusion ffmpeg/ffmpeg-libs pair. Required package
transactions are fail-fast; optional player/game packages are isolated as an
optional transaction. Rust acceleration remains optional and cannot block the
supported Python/C++ fallback.
