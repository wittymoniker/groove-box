#!/usr/bin/env bash
set -Eeuo pipefail
KIT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT="$(cd "$KIT/.." && pwd -P)"
if [[ -r /etc/os-release ]]; then . /etc/os-release; fi
FAMILY="${ID:-} ${ID_LIKE:-}"
SUDO=(); [[ "$(id -u)" -eq 0 ]] || SUDO=(sudo)

if [[ "$FAMILY" == *fedora* || "$FAMILY" == *rhel* || "$FAMILY" == *centos* ]]; then
  echo '[BUILD_KIT] Installing required Fedora build/runtime packages (Fedora 44-compatible; no RPM Fusion ffmpeg replacement).'
  "${SUDO[@]}" dnf install -y \
    python3 python3-pip python3-devel gcc gcc-c++ glm-devel curl ffmpeg-free \
    portaudio portaudio-devel alsa-lib alsa-lib-devel libffi-devel openssl-devel \
    pipewire wireplumber pipewire-alsa pipewire-pulseaudio \
    mesa-dri-drivers mesa-vulkan-drivers qt6-qtwayland xorg-x11-server-Xwayland
  echo '[BUILD_KIT] Installing optional media/game packages; unavailable optional RPMs do not block the builder.'
  "${SUDO[@]}" dnf install -y --skip-broken --setopt=skip_if_unavailable=True \
    gamescope mpv SDL2 SDL2_mixer openal-soft || \
    echo '[BUILD_KIT] Optional gamescope/mpv/SDL/OpenAL packages were skipped.' >&2
elif [[ "$FAMILY" == *ubuntu* || "$FAMILY" == *debian* ]]; then
  export DEBIAN_FRONTEND=noninteractive
  "${SUDO[@]}" apt-get update -y
  "${SUDO[@]}" apt-get install -y \
    python3 python3-pip python3-venv python3-dev build-essential libglm-dev curl ffmpeg mpv \
    pipewire wireplumber libportaudio2 portaudio19-dev libasound2-dev libffi-dev libssl-dev \
    libsdl2-2.0-0 libsdl2-mixer-2.0-0 libopenal1
elif command -v pacman >/dev/null 2>&1; then
  "${SUDO[@]}" pacman -S --needed python python-pip gcc glm curl ffmpeg portaudio alsa-lib libffi openssl
else
  echo "FAIL: unsupported Linux package manager for BUILD_KIT: ${FAMILY:-unknown}" >&2
  exit 3
fi

cd "$ROOT"
python3 -m venv .groovebox-build-venv
# shellcheck disable=SC1091
. .groovebox-build-venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip install 'pyinstaller>=6.10,<7'
# Rust acceleration is optional: the tested Python/C++ fallback remains valid.
if ! python "$ROOT/scripts/ensure_rust_toolchain.py" --install; then
  echo '[BUILD_KIT] WARNING: Rust toolchain unavailable; executable will use supported fallback acceleration.' >&2
fi
python "$KIT/build.py" --doctor
printf '\nDependencies ready. Build with:\n  ./BUILD_KIT/build_linux.sh --console\n'
