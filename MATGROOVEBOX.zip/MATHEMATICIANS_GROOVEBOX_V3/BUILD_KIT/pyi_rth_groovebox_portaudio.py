"""PyInstaller runtime hook: expose bundled PortAudio before sounddevice imports.

The frozen application ships libportaudio (and its ALSA/JACK/PulseAudio
dependencies) beside the executable.  ctypes.util.find_library() searches the
host loader path, which is not where PyInstaller places those files, so patch it
to return the bundled absolute path.  This keeps the executable self-contained
instead of silently falling back to a system PortAudio that may not exist.
"""
from __future__ import annotations

import ctypes
import ctypes.util
import os
import sys
from pathlib import Path


def _bundle_root() -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))


def _first(*names: str):
    root = _bundle_root()
    for name in names:
        for candidate in (
            root / name,
            root / "lib" / name,
            root / "_sounddevice_data" / "portaudio-binaries" / name,
            root / "sounddevice" / "_sounddevice_data" / "portaudio-binaries" / name,
            root / "PyInstaller" / "_sounddevice_data" / "portaudio-binaries" / name,
        ):
            try:
                if candidate.is_file():
                    return candidate
            except OSError:
                pass
    return None


def _preload(path) -> bool:
    if path is None:
        return False
    try:
        mode = getattr(ctypes, "RTLD_GLOBAL", 0)
        ctypes.CDLL(str(path), mode=mode)
        return True
    except OSError:
        return False


_ORIGINAL_FIND_LIBRARY = ctypes.util.find_library


def _find_library(name: str):
    key = (name or "").lower()
    if key in {
        "portaudio", "libportaudio", "portaudio.2", "libportaudio.so.2",
        "libportaudio64bit.dll", "libportaudio32bit.dll",
        "libportaudioarm64.dll", "libportaudio.dll", "portaudio.dll",
    }:
        bundled = _first(
            "libportaudio.so.2", "libportaudio.so",
            "libportaudio.dylib", "libportaudio64bit.dll",
            "libportaudio32bit.dll", "libportaudioarm64.dll",
            "libportaudio.dll", "portaudio.dll",
        )
        if bundled is not None:
            return str(bundled)
    return _ORIGINAL_FIND_LIBRARY(name)


ctypes.util.find_library = _find_library

if sys.platform.startswith("linux"):
    for _dep in ("libasound.so.2", "libjack.so.0", "libpulse.so.0"):
        _preload(_first(_dep))
    _preload(_first("libportaudio.so.2", "libportaudio.so"))
elif sys.platform == "darwin":
    _preload(_first("libportaudio.dylib"))
elif os.name == "nt":
    _pa = _first("libportaudio64bit.dll", "libportaudioarm64.dll", "libportaudio32bit.dll", "libportaudio.dll", "portaudio.dll")
    # Add both the bundle root and the PortAudio payload directory so dependent
    # DLLs resolve when sounddevice loads the wheel's platform-specific name.
    for _directory in {_bundle_root(), _pa.parent if _pa is not None else _bundle_root()}:
        try:
            os.add_dll_directory(str(_directory))
        except (AttributeError, OSError):
            pass
    if _pa is not None:
        os.environ["PATH"] = str(_pa.parent) + os.pathsep + os.environ.get("PATH", "")
    _preload(_pa)
