#!/usr/bin/env python3
"""
Example seed script that writes VideoAssemblyRules when seeded video plan is active.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from groovebox_fractal.video_assembly import VideoAssemblyRules, apply_seed_script_rules


def seed_script(seed: int, context: dict) -> dict:
    """
    Deterministic seed script. Returns a dict of assembly rule parameters.
    Called when seeded_video_plan is active.
    """
    # Simple deterministic choices based on seed
    transition = "crossfade" if (seed % 3) else "lattice_morph"
    color = "phase" if (seed % 2) else "density"
    parts = 64 if (seed % 4 == 0) else 32

    return {
        "transition_mode": transition,
        "color_map": color,
        "target_part_count": parts,
        "temporal_phase_source": "meum",
        "overlay_opacity": 0.85 + (seed % 10) * 0.01,
        "extra": {"seed_script_version": "1", "note": "written by seed"},
    }


if __name__ == "__main__":
    seed = 42
    base = VideoAssemblyRules(seed=seed, duration_seconds=5.0, fps=30.0)
    written = seed_script(seed, {})
    final = apply_seed_script_rules(base, written)
    print("Seed script wrote assembly rules:")
    print(final.to_dict())
    print("Fingerprint:", final.fingerprint())
