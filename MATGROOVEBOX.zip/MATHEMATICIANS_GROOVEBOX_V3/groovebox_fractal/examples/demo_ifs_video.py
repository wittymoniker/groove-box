#!/usr/bin/env python3
"""
Demo: Abstraction Lattice → Video Success + Reverse Engineer still works.
Run from the package root:
    python examples/demo_ifs_video.py
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from groovebox_fractal import (
    REGISTRY, FieldState, self_procedure, VideoParams,
    export_video_with_receipt, export_audio_with_receipt,
    serialize_lattice_state, save_project,
    accept_reverse_engineered_candidate, VideoIntegrityError, AudioIntegrityError,
)

OUT = Path(__file__).parent / "output"
OUT.mkdir(exist_ok=True)


def main():
    print("=== Groovebox Fractal Finalization Demo ===")
    print(f"Registered methods: {len(REGISTRY.all_methods())}")
    for m in REGISTRY.all_methods():
        print(f"  - {m.id}  tags={m.tags}")

    # 1. Seed field
    field = FieldState(seed=42)

    # 2. self_procedure (video mandatory)
    print("\nRunning self_procedure (video path)...")
    result = self_procedure(field, video_integrity=True)
    print(f"  Correspondence: {result.correspondence_pct}%")
    print(f"  Integrity: {result.integrity_report}")
    print(f"  Seed fingerprint: {result.seed_fingerprint}")

    # 3b. Export audio (streaming + integrity)
    audio_path = OUT / "ifs_sierpinski_demo.wav"
    print(f"\nExporting audio to {audio_path} ...")
    try:
        if result.audio_buffer_preview is None:
            raise AudioIntegrityError("No audio preview from self_procedure")
        areceipt = export_audio_with_receipt(result.audio_buffer_preview, audio_path, format="wav")
        print(f"  AUDIO SUCCESS. RMS={areceipt['rms']:.4f}  samples={areceipt['sample_count']}")
    except AudioIntegrityError as e:
        print(f"  AUDIO INTEGRITY FAILURE: {e}")
        return 1
    video_path = OUT / "ifs_sierpinski_demo.mp4"
    print(f"\nExporting video to {video_path} ...")
    try:
        receipt = export_video_with_receipt(result.video_timeline_preview, video_path)
        print(f"  SUCCESS. Receipt: {receipt['integrity']}  frames={receipt['frame_count']}")
        print(f"  SHA256 prefix: {receipt['sha256']}")
    except VideoIntegrityError as e:
        print(f"  INTEGRITY FAILURE (as designed): {e}")
        return 1

    # 4. Project serialization (MCC-like)
    proj = serialize_lattice_state(
        active_paths=result.active_lattice_paths,
        part_counts=result.part_counts,
        self_result=result,
        video_receipt=receipt,
    )
    proj_path = OUT / "demo_project.mcc.json"
    save_project(proj_path, proj)
    print(f"\nProject saved: {proj_path}")

    # 5. Reverse engineer still works
    print("\nReverse-engineer accept path:")
    candidate = {
        "id": "ifs_recovered_42",
        "kind": "derived_reverse_engineering",
        "recipe": {"method": "ifs_sierpinski", "seed": 42, "points_approx": 1024},
        "confidence": 0.97,
    }
    accepted_id = accept_reverse_engineered_candidate(candidate)
    print(f"  Accepted candidate as lattice node: {accepted_id}")
    print(f"  Reconstructible: {candidate.get('reconstructible')}")

    print("\n=== Demo complete. Video succeeded. Reverse engineer path preserved. ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
