#!/usr/bin/env python3
"""
Minimal Composition UI / Toolset Expansion (CLI Fractal Explorer + Video Composer).
Addresses the insufficiency of the current composition surfaces for lattice-aware work.
"""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from groovebox_fractal import (
    REGISTRY, FieldState, self_procedure, VideoParams,
    export_video_with_receipt, serialize_lattice_state, save_project,
)


def cmd_explore(args):
    print("=== Fractal Explorer (CLI) ===")
    print(f"Registered methods: {len(REGISTRY.all_methods())}")
    for m in REGISTRY.all_methods():
        print(f"  {m.id}")
        print(f"    name: {m.name}")
        print(f"    tags: {', '.join(m.tags)}")
        print(f"    claimed_exact: {m.claimed_exact}")
        print(f"    has project_video: True")
    print("\nUse 'compose' to generate a video from the active lattice path.")


def cmd_compose(args):
    print("=== Video Composition (lattice-aware) ===")
    field = FieldState(seed=args.seed)
    result = self_procedure(
        field,
        preferred_part_counts={"video": args.parts, "visual": args.parts},
        video_integrity=True,
    )
    out = Path(args.output)
    receipt = export_video_with_receipt(result.video_timeline_preview, out)
    print(f"Video written: {out}")
    print(f"Integrity: {receipt['integrity']}  frames={receipt['frame_count']}")
    print(f"Lattice path: {receipt['lattice_path']}")
    print(f"Seed fingerprint: {receipt['seed_fingerprint']}")

    if args.save_project:
        proj = serialize_lattice_state(
            active_paths=result.active_lattice_paths,
            part_counts=result.part_counts,
            self_result=result,
            video_receipt=receipt,
        )
        proj_path = out.with_suffix(".mcc.json")
        save_project(proj_path, proj)
        print(f"Project saved: {proj_path}")


def main():
    p = argparse.ArgumentParser(description="Groovebox Fractal Composition Tools")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("explore", help="List lattice methods (Fractal Explorer)")

    c = sub.add_parser("compose", help="Compose and export a video from lattice")
    c.add_argument("--seed", type=int, default=42)
    c.add_argument("--parts", type=int, default=64, help="Part count (power-of-two preferred)")
    c.add_argument("--output", default="examples/output/composed.mp4")
    c.add_argument("--save-project", action="store_true")

    args = p.parse_args()
    if args.cmd == "explore":
        cmd_explore(args)
    elif args.cmd == "compose":
        cmd_compose(args)


if __name__ == "__main__":
    main()
