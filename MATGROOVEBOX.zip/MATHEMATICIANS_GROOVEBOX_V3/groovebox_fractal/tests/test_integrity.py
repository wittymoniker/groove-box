#!/usr/bin/env python3
"""
Minimal tests: audio + video integrity, correspondence, reverse-engineer reconstructibility.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from groovebox_fractal import (
    FieldState, self_procedure,
    accept_reverse_engineered_candidate, REGISTRY,
)


def test_audio_and_video_integrity():
    field = FieldState(seed=123)
    result = self_procedure(field, video_integrity=True)
    assert result.audio_buffer_preview is not None
    assert result.integrity_report.get("audio_ok") is True
    assert result.integrity_report.get("ok") is True
    assert result.video_timeline_preview is not None
    print("PASS: audio integrity + streaming buffer")
    print("PASS: video integrity")


def test_correspondence():
    field = FieldState(seed=7)
    result = self_procedure(field)
    assert result.correspondence_pct == 100.0
    assert "geometric.points" in field.data
    print("PASS: correspondence")


def test_reverse_engineer_accept():
    cand = {"id": "test_re", "recipe": {"seed": 99}}
    nid = accept_reverse_engineered_candidate(cand)
    assert "derived" in nid.path
    assert cand["reconstructible"] is True
    print("PASS: reverse engineer accept path")


if __name__ == "__main__":
    test_audio_and_video_integrity()
    test_correspondence()
    test_reverse_engineer_accept()
    print("All tests passed.")
