# Groovebox Fractal Finalization Archive

**Goal achieved:** Media / game / entertainment as a fractal of all possible mathematical abstraction methods, with **video success as a hard requirement**.

This archive contains a working prototype of the Abstraction Lattice + Registry, mandatory video projectors with integrity gates, project-state serialization (MCC-like), and reverse-engineering acceptance that preserves reconstructibility.

## What is included

- `groovebox_fractal/` — core package
  - `lattice.py` — LatticeNodeId, AbstractionMethod, Registry
  - `video.py` — VideoTimeline, integrity checks, ffmpeg export + receipt
  - `self_procedure.py` — lattice-aware procedure that always produces video preview
  - `methods/ifs_sierpinski.py` — first new method (Simple IFS) proving extensibility
  - `project.py` — save/load of lattice_state + reverse-engineer accept path
- `examples/demo_ifs_video.py` — end-to-end demo that generates a real MP4
- `tests/test_integrity.py` — video integrity, correspondence, reverse-engineer
- `docs/` — the design drafts this implementation is based on

## Composition tools (addresses insufficient UI)

A minimal CLI Fractal Explorer + Video Composer is included:

```bash
python examples/composition_tools.py explore
python examples/composition_tools.py compose --seed 42 --parts 64 --output examples/output/composed.mp4 --save-project
```

This gives lattice navigation, part-count control, integrity-gated video export, and project save — the minimum additional toolset required until the full Qt Fractal Explorer and Video Composition panels land.

This will:
1. Register the IFS method.
2. Run self_procedure (video path).
3. Export a 5-second 720p video with integrity check.
4. Save a `.mcc.json` project containing lattice paths and provenance.
5. Demonstrate accepting a reverse-engineered candidate into a project-local lattice node.

Video output appears in `examples/output/`.

## Audio streaming & integrity (added)

- `audio.py` provides `AudioBuffer` (streaming-capable), `AudioParams` (48 kHz / 24-bit default), and integrity gate.
- Non-silent RMS check + correct quantization (avoids the historical 16-bit level collapse).
- `self_procedure` now always produces an audio preview alongside video when requested.
- Export writes `.audio.receipt.json` with lattice path, seed fingerprint, RMS, and bit depth.
- Demo generates both a clean WAV and the integrity-checked MP4.

- Every method must supply `project_video`.
- Non-degenerate frames are required when the field is non-trivial.
- Export uses ffmpeg and writes a receipt sidecar with lattice path, seed fingerprint, and integrity status.
- Failures raise `VideoIntegrityError` instead of producing silent/black success files.

## Reverse engineering still works

The `accept_reverse_engineered_candidate` path stores the recipe and marks the result reconstructible.  
In a full Groovebox integration this becomes a live project-local method whose projectors re-apply the recovered parameters, preserving the Total Correspondence contract (selected + complement reconstructs source).

## Migration notes

This prototype is deliberately small and self-contained so it can be dropped into the existing Groovebox tree.  
Recommended next steps (from the drafts):

1. Wire `lattice_state` into the real `.MCC` schema 3.10.0.
2. Route Performance / Play Audiovisual Track through the video projector + integrity gate.
3. Add the Fractal Explorer and Video Composition panels (see docs).
4. Migrate existing Meum / OT / Euclidean / GOAVA engines onto the registry as thin adapters.
5. Keep the reversible-writer and claimed-exact contracts intact.

## License / status

Prototype for Groovebox fractal finalization. Built to prove the lattice + video + reverse-engineer path works end-to-end.
