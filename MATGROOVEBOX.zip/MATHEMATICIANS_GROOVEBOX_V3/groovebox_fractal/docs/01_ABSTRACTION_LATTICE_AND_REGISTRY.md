# Abstraction Lattice + Registry — Design Spec
**Goal:** Media / game / entertainment as a fractal of mathematical abstraction methods  
**Priority constraint:** Video projection must succeed deterministically and report integrity failures instead of silent bad output.

## 1. Core idea

A single **Universal Field** is no longer treated as a flat source. It is the root of an **Abstraction Lattice**.

Every node in the lattice is one mathematical abstraction method (or a composition of methods).  
Audio, Visual, **Video**, Game, UI, and Network are selective, reconstructible projections of lattice nodes (or of sub-lattices).

Self-similarity rule: coarsening a node by a power-of-two part count (or by the node’s own coarsening map) must still produce a valid projection of the same identity. Selected + complement reconstructs the source coordinates (Total Correspondence contract).

## 2. Lattice node schema

```python
@dataclass(frozen=True)
class LatticeNodeId:
    path: tuple[str, ...]          # e.g. ("root", "meum", "phase", "isn")
    version: str = "1"             # registry version of this method

@dataclass
class AbstractionMethod:
    id: LatticeNodeId
    name: str
    description: str
    # Deterministic contribution
    contribute: Callable[[SeedContext, FieldState], FieldDelta]
    # Reversible writer support (OT contract)
    invert: Callable[[FieldDelta], FieldDelta] | None
    # Self-similarity / hierarchical coarsening
    coarsen: Callable[[FieldState, int], FieldState]   # target_part_count
    refine: Callable[[FieldState, int], FieldState] | None
    # Domain projectors — VIDEO is mandatory and must be integrity-checked
    project_audio: Callable[[FieldState, AudioParams], AudioBuffer] | None
    project_visual: Callable[[FieldState, VisualParams], VisualFrame] | None
    project_video: Callable[[FieldState, VideoParams], VideoTimeline]   # REQUIRED
    project_game: Callable[[FieldState, GameParams], GameState] | None
    project_ui: Callable[[FieldState, UIParams], UIControls] | None
    project_network: Callable[[FieldState, NetParams], NetSnapshot] | None
    # Provenance & contracts
    claimed_exact: bool = True
    requires_bake_for_userdata: bool = True
    tags: frozenset[str] = frozenset()   # "rational", "meum", "ot", "euclidean", "ifs", ...
```

Every registered method **must** supply a working `project_video`.  
If a method cannot yet produce video, it is registered only as a draft and cannot be selected for audiovisual or video export paths.

## 3. Registry

```python
class AbstractionRegistry:
    def register(self, method: AbstractionMethod) -> None: ...
    def get(self, node_id: LatticeNodeId) -> AbstractionMethod: ...
    def children(self, node_id: LatticeNodeId) -> list[AbstractionMethod]: ...
    def path_from_root(self, node_id: LatticeNodeId) -> list[AbstractionMethod]: ...
    def find_by_tag(self, tag: str) -> list[AbstractionMethod]: ...
    def validate_video_projectors(self) -> list[str]:  # returns list of failures
```

Built-in methods that must be migrated first (in order):

1. Rational / ℤ-Lattice partitions (exact identity anchors)
2. Meum family + isn/ics
3. Operator Theory reversible writers
4. Euclidean rhythm / timing
5. GOAVA numeric transduction
6. Seeded / RAND / LOCK canonical engines
7. Simple IFS / iterative function system (first “new” method to prove extensibility)
8. 3D Voxel / geometric self-similar generators

## 4. Updated self_procedure signature

```python
def self_procedure(
    field: UniversalField,
    registry: AbstractionRegistry,
    *,
    target_domains: set[str] = frozenset({"audio", "visual", "video", "game"}),
    preferred_part_counts: dict[str, int] | None = None,  # power-of-two preferred
    max_depth: int = 6,
    video_integrity: bool = True,
) -> SelfProcedureResult:
    """
    Recursively selects lattice nodes and refinement levels.
    Returns a SelfProcedureResult that contains:
      - active_lattice_paths: dict[domain, list[LatticeNodeId]]
      - part_counts: dict[domain, int]
      - correspondence_state
      - video_timeline_preview (always present when "video" in target_domains)
      - integrity_report
    """
```

Rules retained and strengthened:

- Representation counts are downstream of canonical identity.
- Powers of two preferred for clean hierarchical coarsening.
- Any positive part count remains a valid factorization.
- Rational scaling for identity / conservation; Meum-family etc. for phase / traversal / differentiation.
- **Video path is never optional when audiovisual export or Performance video is requested.**  
  If `project_video` fails integrity, the procedure aborts with a clear diagnostic instead of producing a silent or attenuated file.

## 5. Video success contract (non-negotiable)

Every `project_video` implementation and the final FFmpeg export path must satisfy:

1. Deterministic frame generation from the same lattice path + seed + clock.
2. Explicit duration / frame-count derived from the canonical clock (no hidden 30-minute ceilings; use bounded-block processing already present).
3. RGB (or RGBA) frames handed to the pinned local `./bin/ffmpeg` with known pixel format.
4. Post-encode integrity probe (same spirit as the 2026-09-13 MP3 level fix):
   - Decode a short sample of the written video.
   - Assert non-zero energy / non-black frames when the source field is non-silent/non-empty.
   - Assert duration matches expected sample count within tolerance.
5. Provenance written into the container (or sidecar): lattice path, self_procedure part counts, correspondence percentage, seed fingerprint.
6. Failure modes raise or return structured errors; they never produce a “successful” empty or near-black video when the field was non-trivial.

Recommended implementation sketch:

```python
def project_video(field: FieldState, params: VideoParams) -> VideoTimeline:
    # 1. Choose visual projection of the same lattice nodes
    frames = []
    for t in canonical_frame_times(params):
        visual = project_visual(field.at(t), params.visual)
        frames.append(visual.to_rgb_frame(params.width, params.height))
    timeline = VideoTimeline(frames=frames, fps=params.fps, audio=optional_audio_track)
    if params.integrity_check:
        timeline.validate_non_degenerate()
    return timeline
```

Final export:

```python
def export_video(timeline: VideoTimeline, path: Path, lattice_path: list[LatticeNodeId]) -> ExportReceipt:
    # write frames → ffmpeg (pinned binary)
    # probe result
    # write receipt with lattice provenance
    ...
```

## 6. Correspondence & fractal invariants (tests)

Must pass:

- `selected + complement == source` for every domain projection, including video frame coordinates.
- Coarsening then refining (where refine exists) returns a field whose projections are within the project’s claimed-exact tolerance.
- Changing only a leaf node changes only the projections that reference that leaf (or its ancestors).
- Video integrity probe fails loudly on deliberately zeroed frames when the field is non-zero.
- Registry rejects any method that claims to be production-ready but lacks a working `project_video`.

## 7. Migration order (practical)

1. Introduce `LatticeNodeId`, `AbstractionMethod`, `AbstractionRegistry` (no behavior change yet).
2. Wrap existing Meum / OT / Euclidean / GOAVA / canonical engines as registered nodes; keep old call sites working via thin adapters.
3. Make `self_procedure` lattice-aware and always produce a video timeline preview when requested.
4. Wire Performance audiovisual export and Main Window “Play Audiovisual Track” through the new video projector + integrity probe.
5. Add the Fractal Explorer and Video Composition panels (see companion UI draft).
6. Register the first purely new method (simple IFS) and demonstrate that the same node produces coherent audio + video + game state.