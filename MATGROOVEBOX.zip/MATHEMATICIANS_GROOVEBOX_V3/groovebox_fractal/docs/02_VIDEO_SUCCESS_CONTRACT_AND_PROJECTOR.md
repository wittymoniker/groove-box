# Video Success Contract & Projector
**Hard requirement:** Video must succeed. Silent, black, truncated, or level-collapsed video is treated as an export failure, never as success.

## 1. Why video is special

Audio already has the 2026-09-13 integrity fix (24-bit vs 16-bit level collapse).  
Video needs the same rigor because:

- Long renders previously had ceilings and full-grid allocation risks (addressed by bounded-block work).
- Frame generation can silently produce black or static frames if a visual projector fails or a lattice path is empty.
- Users judge “does the fractal idea work?” largely by whether the audiovisual result actually moves and matches the seed.

Therefore every path that can produce an `.mp4` (or other video container) must go through the lattice video projector and the integrity gate.

## 2. VideoParams (minimal)

```python
@dataclass
class VideoParams:
    width: int = 1920
    height: int = 1080
    fps: float = 30.0
    duration_beats: float | None = None      # preferred — derived from canonical clock
    duration_seconds: float | None = None
    pixel_format: str = "rgb24"              # or rgba
    include_audio: bool = True
    integrity_check: bool = True
    max_frames_warning: int = 18000          # ~10 min @ 30 fps; soft warning only
    bounded_block_samples: int = 2_000_000   # align with existing long-render policy
```

Duration is always resolved from the canonical clock / playlist when available.  
Never rely on wall-clock or on an implicit 30-minute hard stop.

## 3. VideoTimeline

```python
@dataclass
class VideoTimeline:
    frames: list[np.ndarray] | FrameIterator   # HxWx3 or HxWx4, uint8
    fps: float
    audio: AudioBuffer | None = None
    lattice_path: list[LatticeNodeId] = field(default_factory=list)
    self_procedure_part_counts: dict[str, int] = field(default_factory=dict)
    seed_fingerprint: str = ""
    correspondence_pct: float = 100.0

    def expected_frame_count(self) -> int: ...
    def validate_non_degenerate(self, min_nonzero_ratio: float = 0.02) -> None:
        """
        Raises VideoIntegrityError if:
        - frame count == 0
        - all frames are exactly black / constant when source field was non-trivial
        - audio (if present) is silent while visual is not, or vice-versa under strict mode
        """
```

`FrameIterator` is preferred for long renders so that frames are generated in bounded blocks and streamed to FFmpeg instead of materializing the entire list in RAM.

## 4. Projector implementation requirements

Every `AbstractionMethod.project_video` must:

1. Accept the current `FieldState` (already advanced to the correct canonical time or able to be sampled at frame times).
2. Produce frames whose spatial content is a selective projection of the same lattice coordinates used for audio/game.
3. Use the same seed fingerprint and correspondence rules.
4. Support coarsening: when self_procedure chooses a lower part count, the video remains a valid (lower-resolution or lower-detail) projection of the same identity.
5. Never swallow exceptions; let the integrity layer decide.

Recommended shared helper (to be placed in a common video module):

```python
def render_lattice_video(
    field: UniversalField,
    active_paths: list[LatticeNodeId],
    registry: AbstractionRegistry,
    params: VideoParams,
) -> VideoTimeline:
    # Resolve duration from canonical clock
    # For each frame time t:
    #   state = field.sample(t)
    #   # Composite contributions from active_paths (or use the already-composed state)
    #   frame = composite_visual_projection(state, params)
    # Stream or collect frames
    # Attach audio track if requested (from the audio projector of the same paths)
    # Attach provenance
    # If params.integrity_check: timeline.validate_non_degenerate()
    return timeline
```

## 5. Export path (pinned FFmpeg)

Continue using the project-local `./bin/ffmpeg` + `./bin/ffprobe` (no system-PATH fallback).

```python
def export_video_with_receipt(
    timeline: VideoTimeline,
    output_path: Path,
    *,
    crf: int = 18,
    preset: str = "medium",
) -> ExportReceipt:
    # 1. Write frame stream (rawvideo or image pipe) + optional audio
    # 2. Run pinned ffmpeg
    # 3. ffprobe the result:
    #      - duration
    #      - video stream present
    #      - sample a few frames / compute simple non-black metric if possible
    # 4. If integrity fails → raise, delete partial output, return structured error
    # 5. Write ExportReceipt JSON sidecar or embed in project metadata:
    #      lattice_path, part_counts, seed_fingerprint, correspondence_pct,
    #      ffmpeg_command_digest, output_sha256, frame_count, fps
```

Align with the existing MP3 integrity philosophy: a non-trivial source that collapses to empty/black/silent output is a **failure**, not a success.

## 6. Integration points that must be switched over

| Current entry point                    | Required change                                      |
|----------------------------------------|------------------------------------------------------|
| Play Audiovisual Track                 | Route through lattice video projector                |
| Performance batch render / export      | Same + receipt                                       |
| Draw / Signal Lab → video              | Lab layers become lattice contributions or carriers  |
| 3D Voxel Kit export                    | Voxel scene is a visual projection of lattice nodes  |
| Long-render path                       | Must use FrameIterator + bounded blocks              |
| Project save / load                    | Persist active lattice paths and part counts         |

## 7. Failure diagnostics (user-visible)

When video fails integrity:

- Show the lattice path that was active.
- Show whether the field was non-zero at sample times.
- Show frame count written vs expected.
- Offer “Open in Fractal Explorer” and “Re-run self_procedure with higher part count”.
- Never leave a zero-byte or near-black file marked as a successful export.

## 8. Test matrix (minimum)

1. Non-zero seed → non-black video, correct duration.
2. Zero / cleared field → intentional black/silent video is allowed and marked as such.
3. Coarsen part count by 2× → video still valid, lower detail, same seed fingerprint.
4. Deliberately break a projector → integrity error, no successful file.
5. Long render (> 2 M samples audio equivalent) completes with bounded memory.
6. Round-trip: export → load receipt → lattice path matches.