# Composition UI & Toolset Expansion
**Verdict:** The current Main Window + Performance / GOAVA Radio + Draw/Signal Lab + 3D Voxel Kit is a strong base but is **not yet sufficient** to make “media/game/entertainment as a fractal of all possible mathematical abstraction methods” operable for a user (or for the author while developing new methods).

The lattice is invisible today. Video success depends on that lattice being selectable, inspectable, and debuggable. Therefore the following surfaces are required.

## 1. Fractal Explorer (new primary panel)

A dockable / floating panel (same docking rules as Performance).

**Purpose:** Navigate the Abstraction Lattice and see the same node projected into multiple domains at once.

Minimum controls:

- Tree or radial view of the lattice (root → registered methods → children).
- Select one or more nodes → they become the active contribution set for self_procedure.
- Live previews (small):
  - Audio waveform / spectrum snippet
  - Single visual frame
  - Video strip (first N frames or contact sheet)
  - Game state summary / sprite count / gravity parameters
- Part-count slider per domain (power-of-two snaps + free value).
- “Apply to GLOBAL” / “Apply to LOCAL” (respects existing reversible-writer scope rules).
- Correspondence % and self_procedure diagnostics (already partially present in the visualizer).
- “Why is video black?” one-click integrity diagnosis.

This panel is the main way a user (and the author) experiences the fractal claim.

## 2. Video Composition panel (new or expanded Performance tab)

Current Performance owns playlists, cutups, Draw/Signal Lab, device routing, and batch rendering. It needs an explicit **Video** tab/section that is lattice-aware.

Required tools:

- Timeline of lattice-driven segments (not only media files).
  Each segment stores: lattice path, part counts, seed offset / clock range, visual style.
- Contact-sheet / onion-skin preview generated from the video projector.
- “Render preview (low-res)” and “Render final (integrity-checked)” buttons.
- Direct link to the Export Receipt viewer.
- Ability to drop a Draw/Signal Lab layer or Voxel scene in as a carrier that is still parented to a lattice node (or marked as pure userdata).
- Parametric remix controls that operate on lattice parameters, not only on decoded pixels.

If a segment has no valid video projector path, the UI must show a clear error state instead of a black thumbnail.

## 3. Lattice Path Inspector (status + debug)

A compact always-available readout (status bar or side inspector):

- Active lattice paths for Audio / Visual / Video / Game
- Current part counts
- Correspondence percentage
- Last video integrity result (pass / fail + reason)
- Seed fingerprint (short form)

Clicking any path opens the Fractal Explorer focused on that node.

## 4. Method Registration & Authoring aids (developer + power-user)

Because the goal is “all possible” abstraction methods, the toolset must make adding a method cheap and safe.

- “New Abstraction Method” scaffold (generates a Python stub with the required `project_video`, `contribute`, `coarsen`, and test hooks).
- Validation button: “Check video projector now” (runs a short deterministic render + integrity probe).
- Tag editor and search (rational, meum, ot, ifs, euclidean, …).
- Diff view: two lattice paths side-by-side (audio + video frames) to verify self-similarity under coarsening.

These can live under a Developer / Research menu so they do not clutter the musician-facing UI.

## 5. Draw / Signal Lab & Voxel Kit integration

Keep the existing freehand and voxel tools. Strengthen the contract:

- Every Lab layer and every Voxel scene records whether it is:
  - pure userdata, or
  - a baked contribution from a lattice node, or
  - a live (non-baked) projection of a lattice node.
- “Send to Video Composition” creates a segment whose lattice path is either the originating node or a new “userdata carrier” node.
- Reverse direction: from Fractal Explorer, “Open in Signal Lab” / “Open in Voxel Kit” for methods that support editable geometry or waveforms.

## 6. Main Window changes (minimal but necessary)

- Global / Local scope controls remain the authority for writers.
- Add a single “Lattice / Fractal” button that opens the Fractal Explorer.
- When Play Audiovisual Track is pressed, the status line shows the active video lattice path and the integrity result.
- Export dialog gains a “Include lattice provenance” checkbox (on by default) and surfaces the receipt.

## 7. What can stay as-is (for now)

- Existing synth editor, sequence grid, heuristic write, canonical engine toggles.
- Hardware / device manager.
- Game networking (Host / Join) — only needs to carry the lattice provenance in the identity data (already partially present via self_procedure_state / correspondence_state).
- Project file format (.MCC) — extend, do not replace; store lattice paths and part counts as additional structured fields.

## 8. Implementation priority for UI

1. Lattice Path Inspector (read-only first) — immediate visibility.
2. Video Composition panel with integrity-gated render — makes “video succeeds” observable.
3. Fractal Explorer (tree + dual preview) — makes the fractal claim operable.
4. Method scaffold + validation — enables the “all possible methods” growth path.
5. Deeper Lab / Voxel bidirectional links.

## 9. Success criteria for the UI layer

- A user can select a lattice node, press Play Audiovisual Track, and obtain a non-degenerate video whose receipt points back to that node.
- A user can coarsen the part count and see the video update while the seed fingerprint stays stable.
- A developer can add a new method, run the video validation, and see it appear in the Fractal Explorer without touching the core engines.
- Black / silent / truncated video never appears as a green “success” state.