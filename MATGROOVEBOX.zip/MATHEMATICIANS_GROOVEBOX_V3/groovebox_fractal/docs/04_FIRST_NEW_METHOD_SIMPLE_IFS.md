# First New Abstraction Method — Simple IFS
**Purpose:** Prove that a method written only against the registry produces coherent audio + video + game state and that video integrity holds.

## 1. Method identity

- Path: `("root", "geometric", "ifs", "sierpinski_variant")`
- Tags: `geometric`, `ifs`, `self_similar`
- Claimed exact: under the project’s deterministic contract (finite iterations, fixed affine transforms, fixed escape/plot rules).

## 2. Contribution (sketch)

```python
def contribute_ifs(ctx: SeedContext, state: FieldState) -> FieldDelta:
    # Use seed to choose among a small family of IFS rule sets
    # or to set the number of iterations / point count
    # Write a set of 2D (or 3D) points + optional color/phase attributes
    # into a geometric channel of the field
    ...
```

Coarsen: reduce iteration depth or point count by approximately half (or exact power-of-two) while keeping the same attractor identity.

## 3. Projectors

**Audio**  
Map point density / radial distance / iteration level → amplitude and a simple spectral shape or granular cloud. Deterministic.

**Visual / Video**  
Plot the point set (or a density field) into the frame. Same points drive every frame; optional slow rotation or phase derived from Meum/isn for temporal evolution so the video is not static.  
Must pass `validate_non_degenerate` when the IFS produced points.

**Game**  
Points become sprite positions, attractor basins become gravity wells or portals, or a simple “collect the fractal dust” mechanic. Same seed fingerprint.

## 4. Registration

```python
registry.register(AbstractionMethod(
    id=LatticeNodeId(("root", "geometric", "ifs", "sierpinski_variant")),
    name="Sierpinski-variant IFS",
    description="Classic IFS attractor used as a fractal geometric generator",
    contribute=contribute_ifs,
    invert=None,  # or a best-effort residual
    coarsen=coarsen_ifs,
    project_audio=project_ifs_audio,
    project_visual=project_ifs_visual,
    project_video=project_ifs_video,   # REQUIRED — uses project_ifs_visual + temporal phase
    project_game=project_ifs_game,
    claimed_exact=True,
    tags=frozenset({"geometric", "ifs", "self_similar"}),
))
```

## 5. Minimal acceptance test

1. Register the method.
2. self_procedure selects only this node (or this node + rational anchor).
3. Export a 5-second 720p video with integrity_check=True → must pass.
4. Coarsen part count → second video still passes integrity and shares seed fingerprint.
5. Audio and game state non-trivial and stable under the same seed.

Once this lands, the lattice is demonstrably extensible and video is demonstrably on the critical path.