# Groovebox Fractal Finalization Drafts
Generated for the goal: **media / game / entertainment as a fractal of all possible mathematical abstraction methods**, with **video success as a hard requirement**.

## Files

1. `01_ABSTRACTION_LATTICE_AND_REGISTRY.md`  
   Lattice node schema, registry, updated `self_procedure`, migration order.

2. `02_VIDEO_SUCCESS_CONTRACT_AND_PROJECTOR.md`  
   Non-negotiable video integrity rules, `VideoTimeline`, export receipt, integration points, test matrix.

3. `03_COMPOSITION_UI_AND_TOOLSET_EXPANSION.md`  
   Why current UI is insufficient, Fractal Explorer, Video Composition panel, Lattice Path Inspector, method authoring aids, priority order.

4. `04_FIRST_NEW_METHOD_SIMPLE_IFS.md`  
   Concrete first new method that proves the registry + video path works end-to-end.

5. `05_PROJECT_DATA_AND_REVERSE_ENGINEER_WIRING.md`  
   How lattice / self_procedure / video provenance / reverse-engineering results are stored in `.MCC`, survive save/load, participate in Undo/Redo, and how accepting a reverse-engineered candidate becomes a project-local lattice method (with video projector).

## Recommended implementation sequence

1. Land the data model and registry (no user-visible behavior change).
2. Wire `lattice_state` into project save/load + `mcc_integrity` (schema 3.10.0-lattice-fractal).
3. Make video projector + integrity gate mandatory; write `video_provenance` into the project on export.
4. Connect reverse_engineer accept path → project-local method + active_paths.
5. Add Lattice Path Inspector (read-only).
6. Add Video Composition panel with integrity-gated render.
7. Add Fractal Explorer.
8. Migrate existing engines onto the registry.
9. Register the Simple IFS method and ship the acceptance tests (including project round-trip tests).

These drafts sit alongside the existing Total Correspondence + Self-Procedure work, project-state integration (3.9.0), reverse_engineer.py, and the 2026-09 video/long-render and MP3 integrity improvements. They reuse the reversible-writer, correspondence, pinned-FFmpeg, and .MCC JSON contracts already in the tree.