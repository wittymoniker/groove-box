# Project Data (Save/Load) + Reverse-Engineer Wiring
**Goal:** Lattice, self_procedure, video provenance, and reverse-engineering results are first-class project state. They survive save/load, participate in Undo/Redo where appropriate, and feed the fractal composition path without breaking the existing .MCC JSON contract.

## 0. Baseline (already in tree)

- Canonical document: **`.MCC`** (JSON project snapshot; legacy `.mgpr` / `.mgpr.part` still loadable).
- Schema already carries project-state integration (see `PROJECT_STATE_INTEGRATION_20260909.txt`, schema note `3.9.0-project-state-integrated`).
- `media_workbench_state`, Performance state, canonical/modulation/game families, and visual camera state already participate in history.
- `reverse_engineer.py` produces `SignalDescriptor` + ranked `ReconstructionCandidate` objects with a `recipe` dict (`kind: "derived_reverse_engineering"`, partials, fundamental, etc.).
- Draw/Signal Lab already exposes reverse-engineering, Fundamental Loop detection, Sounds Like / Harmonic Complement / Opposite.
- Runtime buffers (decoded PCM, frames, device handles) are **not** serialized; only authoritative metadata/bindings are.

This draft extends that contract; it does not replace it.

---

## 1. Project snapshot schema extension

Bump schema identifier, e.g.:

```text
schema_version: "3.10.0-lattice-fractal"
```

Add a top-level object (name exact; keep it stable):

```json
"lattice_state": {
  "registry_snapshot": {
    "builtin_method_ids": [["root","meum"], ["root","ot"], ...],
    "project_local_methods": [ /* serialized AbstractionMethod stubs or references */ ]
  },
  "active_paths": {
    "audio":   [["root","meum","phase"], ["root","euclidean"]],
    "visual":  [["root","meum","phase"], ["root","geometric","ifs","sierpinski_variant"]],
    "video":   [["root","meum","phase"], ["root","geometric","ifs","sierpinski_variant"]],
    "game":    [["root","meum"], ["root","geometric","ifs","sierpinski_variant"]],
    "ui":      [],
    "network": []
  },
  "part_counts": {
    "audio": 32,
    "visual": 64,
    "video": 64,
    "game": 16
  },
  "self_procedure": {
    "max_depth": 6,
    "preferred_part_counts": {"video": 64},
    "last_correspondence_pct": 100.0,
    "last_run_fingerprint": "…"
  },
  "video_provenance": {
    "last_export_receipt": { /* see §3 */ },
    "last_integrity": {"ok": true, "reason": null, "frame_count": 150, "expected": 150}
  },
  "reverse_engineering": {
    "descriptors": [ /* SignalDescriptor dicts, keyed or listed */ ],
    "candidates": [ /* ReconstructionCandidate dicts */ ],
    "accepted_candidate_id": null,
    "fundamental_loop": { /* optional detected loop metadata */ },
    "derived_transforms": {
      "sounds_like": null,
      "harmonic_complement": null,
      "opposite": null
    }
  }
}
```

### Rules

1. **Only serializable, authoritative state** goes into `lattice_state`.  
   No live numpy buffers, no open file handles, no Qt widgets.

2. **Active paths** are lists of `LatticeNodeId.path` tuples (JSON arrays of strings).  
   On load, resolve through the live `AbstractionRegistry`. Missing methods → soft warning + skip that path (do not crash load).

3. **Part counts** and **self_procedure** settings restore exactly.  
   After load, optionally re-run `self_procedure` in “restore” mode to re-derive correspondence_pct and video timeline preview without changing the stored paths/counts unless the user asks.

4. **Project-local methods** (user- or reverse-engineer-created) are stored either:
   - as full declarative definitions (preferred for simple methods), or
   - as references + parameter blobs if the method is code-registered and only parameters vary.

5. **Backward compatibility:**  
   Loaders for schema &lt; 3.10.0 synthesize an empty `lattice_state` (or a default built from current canonical engines) so old projects open cleanly.

6. **Undo/Redo:**  
   Include `lattice_state.active_paths`, `part_counts`, `self_procedure` settings, and reverse-engineering *accepted* results in the history families (same policy as media_workbench_state).  
   Do **not** put large candidate lists or export receipts into every undo step; keep those as “last known” project fields, not per-edit history, unless the user action explicitly accepted/changed them.

---

## 2. Save / Load API surface

```python
# On save (project document builder)
def serialize_lattice_state(
    registry: AbstractionRegistry,
    active_paths: dict[str, list[LatticeNodeId]],
    part_counts: dict[str, int],
    self_procedure_result: SelfProcedureResult | None,
    video_receipt: ExportReceipt | None,
    reverse_state: ReverseEngineeringState,
) -> dict:
    ...

# On load
def deserialize_lattice_state(
    data: dict,
    registry: AbstractionRegistry,
) -> LatticeRuntimeState:
    """
    Returns paths, part_counts, restored reverse_engineering state,
    and a list of warnings for unresolved method ids.
    Does not automatically mutate the live field until apply_lattice_state() is called.
    """
    ...

def apply_lattice_state(
    runtime: LatticeRuntimeState,
    field: UniversalField,
    *,
    rerun_self_procedure: bool = True,
) -> None:
    """Install active paths / part counts and optionally refresh correspondence + video preview."""
    ...
```

Wire into the existing project save/load path next to where `media_workbench_state` and game identity data are already written/read.  
Extend `mcc_integrity.py` checks to verify:

- `lattice_state` is a dict when present
- active_paths values are lists of string-lists
- part_counts are positive integers
- unknown keys are tolerated (forward compatible)

---

## 3. Video provenance in the project

Every successful (and every failed-but-attempted) video export should update:

```json
"video_provenance": {
  "last_export_receipt": {
    "path": "exports/….mp4",
    "sha256": "…",
    "lattice_path": [["root","meum"], ["root","geometric","ifs","sierpinski_variant"]],
    "part_counts": {"video": 64},
    "seed_fingerprint": "…",
    "correspondence_pct": 100.0,
    "frame_count": 150,
    "fps": 30.0,
    "integrity_ok": true,
    "created_utc": "…"
  },
  "last_integrity": { "ok": true, "reason": null, ... }
}
```

On load:

- Receipt path is treated as a *reference*; if the file is missing, UI shows “export missing” but project still opens.
- Integrity result is restored for the Lattice Path Inspector / Video Composition panel.
- Re-export with the same lattice paths must be able to reproduce the same seed fingerprint (determinism contract).

Align with existing export integrity tests (`test_mp3_export_integrity_20260913.py`, video/Pillow fixes).

---

## 4. Reverse-engineering → lattice

### 4.1 Descriptor & candidate persistence

`reverse_engineer.analyze()` already returns descriptors and ranked candidates with a `recipe`. Persist under `lattice_state.reverse_engineering`:

- Full list of recent descriptors (cap count, e.g. last 8) so the UI can re-display without re-analyzing.
- Full ranked candidates for the last analysis (or a bounded top-K).
- Which candidate (if any) was **accepted** by the user.
- Fundamental Loop detection result and the three derived transforms (Sounds Like / Harmonic Complement / Opposite) as optional structured blobs.

### 4.2 Accepting a candidate creates lattice contribution

When the user accepts a `ReconstructionCandidate`:

1. Build a **project-local** `AbstractionMethod` (or a parameterized instance of a built-in “reverse_additive” / “reverse_loop” method) whose:
   - `contribute` replays the recipe (partials, fundamental, loop flags) into the field
   - `project_audio` synthesizes from the recipe
   - `project_visual` / `project_video` produce a deterministic visualization of the partials / loop structure (spectrum bars, cycle plot, etc.) so video integrity can pass
   - `project_game` optionally maps partials → simple entity set
2. Register it under a path such as:
   `("project", "reverse", "<short_hash_or_name>")`
3. Add that path to `active_paths` for audio (and visual/video if the user opts in).
4. Mark the recipe with `"userdata": false` still meaning “derived, reversible” unless the user explicitly **Bake / Scribe as User Data** (existing reversible-writer rule).

Reject uniqueness claims: keep the existing policy that reverse-engineering reports approximation/error and only claims a unique inverse when the candidate set supports it.

### 4.3 Signal Lab / Draw Lab integration

- “Analyze reference” → writes into `lattice_state.reverse_engineering` and refreshes the Fractal Explorer / Inspector.
- “Accept candidate” → creates/activates the project-local method as above.
- “Sounds Like / Harmonic Complement / Opposite” → store as derived_transforms; optionally expose each as a one-shot writer that contributes a lattice delta without becoming a permanent method until accepted.
- Layers that originate from reverse-engineering record `source: "reverse_engineering"` and the candidate id in their metadata so save/load and Undo can reason about them.

### 4.4 Reverse video / audiovisual

If the reference was video or an audiovisual export:

- Prefer extracting an audio stem (or using attached audio) for `reverse_engineer.analyze`.
- Optionally run a lightweight visual descriptor (frame histogram / motion energy) stored alongside the audio descriptor; do not block on a full visual inverse.
- Accepted audiovisual candidates must still supply a working `project_video` (even if it is “audio visualization of the reconstructed partials”) so the video success contract holds.

---

## 5. Load-time behavior (safe defaults)

```
load .MCC
  → parse JSON
  → if lattice_state missing: synthesize defaults from current canonical engines
  → resolve active_paths against registry (collect warnings)
  → restore part_counts, self_procedure settings, reverse_engineering blobs
  → restore media_workbench / performance / game state as today
  → apply_lattice_state(rerun_self_procedure=True)  # refreshes correspondence + video preview
  → UI: show warnings if any methods were unresolved
```

Never refuse to open a project because a lattice method is missing; degrade gracefully and surface the gap in the Lattice Path Inspector.

---

## 6. Undo / Redo family

Add a history family, e.g. `lattice_edit`, that records:

- changes to `active_paths`
- changes to `part_counts`
- accept/reject of a reverse-engineering candidate
- bake/scribe of a derived reverse method into userdata

Exclude:

- bulk candidate lists from analyze()
- export receipts (unless you explicitly want “undo export metadata”)
- transient video preview frames

This matches the existing policy: authoritative metadata in history; heavy derived buffers out.

---

## 7. Integrity & tests (project round-trip)

Extend or add tests (names illustrative):

1. **`test_lattice_state_roundtrip`**  
   Save project with non-default active_paths + part_counts → load → paths and counts match.

2. **`test_reverse_candidate_accept_persists`**  
   Run analyze → accept top candidate → save → load → project-local method present and in active_paths; audio projector non-silent.

3. **`test_video_receipt_in_project`**  
   Export video with integrity_ok=True → receipt embedded → load → receipt fields restored; re-export with same seed/paths yields same seed_fingerprint.

4. **`test_old_project_without_lattice_state`**  
   Load a pre-3.10.0 fixture → opens; lattice_state synthesized; no exception.

5. **`test_missing_method_on_load`**  
   active_paths references unknown id → warning, project still loads, path omitted from live set.

6. **`test_mcc_integrity_lattice_keys`**  
   `mcc_integrity` accepts well-formed lattice_state and rejects structurally broken ones without breaking the rest of the document.

Reuse patterns from `test_project_state_integration_20260909.py`, `test_mcc_integrity.py`, `test_project_media_contract.py`.

---

## 8. Minimal code touch list

| Area | Action |
|------|--------|
| Project serializer / deserializer | Read/write `lattice_state`; schema bump |
| `mcc_filetype.py` / `mcc_integrity.py` | Tolerate and lightly validate new keys |
| `reverse_engineer.py` | Add helpers: `candidate_to_method_stub()`, `descriptor_to_dict` already partly via asdict |
| Signal Lab / Performance | On analyze/accept, update `lattice_state.reverse_engineering` and registry |
| Video export path | Write `video_provenance.last_export_receipt` + integrity into project |
| Undo stack | New `lattice_edit` family for path/part-count/accept actions |
| Fractal Explorer / Inspector | Bind to live `lattice_state` so save/load is visible in UI |

---

## 9. Success criteria

- Save → quit → load restores active lattice paths, part counts, accepted reverse-engineering candidate, and last video receipt.
- Accepting a reverse-engineered candidate makes it a selectable lattice node that can drive audio **and** video (integrity-checked).
- Old projects open without lattice data.
- Undo reverses “accept candidate” and path toggles without wiping unrelated media state.
- Video export provenance is visible in the project and in the Video Composition panel after reload.

This closes the loop: the fractal lattice is not only a runtime idea; it is durable project data, and reverse-engineering is one of the ways new lattice nodes are born inside a composition.