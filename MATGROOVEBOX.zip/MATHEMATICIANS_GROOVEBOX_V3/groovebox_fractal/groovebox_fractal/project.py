"""
Project data (MCC-like JSON) + reverse-engineer wiring.
Lattice state survives save/load. Reverse-engineered candidates can become project-local methods.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from dataclasses import asdict, is_dataclass

from .lattice import REGISTRY, LatticeNodeId, FieldState
from .self_procedure import SelfProcedureResult
from .video_assembly import VideoAssemblyRules


SCHEMA_VERSION = "3.10.0-lattice-fractal"


def serialize_lattice_state(
    active_paths: dict[str, list[LatticeNodeId]],
    part_counts: dict[str, int],
    self_result: SelfProcedureResult | None = None,
    video_receipt: dict | None = None,
    reverse_state: dict | None = None,
    assembly_rules: VideoAssemblyRules | None = None,
) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "lattice_state": {
            "registry_snapshot": {
                "builtin_method_ids": [list(m.id.path) for m in REGISTRY.all_methods()],
            },
            "active_paths": {
                d: [list(nid.path) for nid in paths]
                for d, paths in active_paths.items()
            },
            "part_counts": part_counts,
            "self_procedure": {
                "last_correspondence_pct": self_result.correspondence_pct if self_result else 100.0,
                "last_run_fingerprint": self_result.seed_fingerprint if self_result else "",
            },
            "video_provenance": {
                "last_export_receipt": video_receipt or {},
                "last_integrity": self_result.integrity_report if self_result else {},
                "assembly_rules": assembly_rules.to_dict() if assembly_rules else {},
            },
            "reverse_engineering": reverse_state or {
                "descriptors": [],
                "candidates": [],
                "accepted_candidate_id": None,
            },
        },
    }


def save_project(path: Path, state: dict) -> None:
    path = Path(path)
    path.write_text(json.dumps(state, indent=2))


def load_project(path: Path) -> dict:
    return json.loads(Path(path).read_text())


def accept_reverse_engineered_candidate(
    candidate: dict,
    registry=REGISTRY,
) -> LatticeNodeId:
    """
    Accept a reverse-engineered candidate into a project-local lattice method.
    Preserves reconstructibility: the recipe is stored and can be re-projected.
    """
    method_id = LatticeNodeId(("root", "derived", "reverse_engineer", candidate.get("id", "anon")))
    # In a full system this would dynamically create an AbstractionMethod
    # whose project_video re-applies the reconstructed recipe.
    # For this archive we record the acceptance and return the id.
    candidate["accepted_as"] = list(method_id.path)
    candidate["reconstructible"] = True
    return method_id
