"""
Optimized concurrency plan for UI responsiveness, export speed, and live/record paths.
Priorities:
1. Never block the Qt main thread.
2. Overlap CPU projection, I/O, and ffmpeg encode.
3. Keep bounded memory (existing long-render policy).
4. Minimize live playback and recording latency.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, Future
from queue import Queue, Empty
from typing import Callable, Iterator, Optional, Any
import threading
import time


# Recommended pool sizes (tune per machine; these are safe defaults)
UI_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ui-offload")
PROJECT_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="project")
ENCODE_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ffmpeg")


class BoundedFrameQueue:
    """Producer-consumer queue that keeps memory bounded while overlapping work."""
    def __init__(self, maxsize: int = 8):
        self.q: Queue = Queue(maxsize=maxsize)
        self.done = threading.Event()

    def put(self, item: Any, timeout: float = 2.0) -> bool:
        try:
            self.q.put(item, timeout=timeout)
            return True
        except Exception:
            return False

    def get(self, timeout: float = 0.1) -> Optional[Any]:
        try:
            return self.q.get(timeout=timeout)
        except Empty:
            return None

    def close(self):
        self.done.set()


def offload_to_ui(fn: Callable, *args, **kwargs) -> Future:
    """Run non-UI work off the main thread. Result can be delivered via Qt signal."""
    return UI_POOL.submit(fn, *args, **kwargs)


def stream_export_video(
    frame_producer: Callable[[], Iterator],
    ffmpeg_cmd_builder: Callable[[], list],
    on_progress: Optional[Callable[[int], None]] = None,
) -> Future:
    """
    Overlapped export:
    - Producer thread generates frames (lattice projection)
    - Consumer thread feeds ffmpeg (encode)
    - Main/UI thread only receives progress callbacks
    """
    def _run():
        q = BoundedFrameQueue(maxsize=6)
        def producer():
            try:
                for i, frame in enumerate(frame_producer()):
                    if not q.put(frame):
                        break
                    if on_progress and i % 10 == 0:
                        # progress is cheap; real UI update should be queued to main thread
                        pass
            finally:
                q.close()
        prod = PROJECT_POOL.submit(producer)
        # ffmpeg consumer would read from q and write to stdin pipe
        # (placeholder; real impl uses subprocess.Popen with stdin=PIPE)
        prod.result()
        return {"status": "export_complete", "overlapped": True}
    return ENCODE_POOL.submit(_run)


def live_playback_clock(
    sample_callback: Callable[[float], None],
    target_fps: float = 60.0,
) -> threading.Event:
    """
    High-priority clock for live audio/video.
    Separate from project/export pools so UI and live paths stay responsive.
    """
    stop = threading.Event()
    interval = 1.0 / target_fps

    def _loop():
        next_t = time.perf_counter()
        while not stop.is_set():
            now = time.perf_counter()
            if now >= next_t:
                sample_callback(now)
                next_t += interval
                # drift correction
                if next_t < now:
                    next_t = now + interval
            else:
                time.sleep(max(0.0, next_t - now - 0.001))
    t = threading.Thread(target=_loop, name="live-clock", daemon=True)
    t.start()
    return stop


# Recording notes (audio + video):
# - Audio recording: dedicated real-time thread or PortAudio/PipeWire callback;
#   never do lattice work inside the audio callback. Queue raw PCM and process later.
# - Video recording: capture on a timer or vsync thread, queue frames, encode on ENCODE_POOL.
# - Both should use lock-free or bounded queues so a slow encode cannot stall the capture clock.
RECORDING_GUIDELINES = """
Live / recording fast-path checklist:
1. Audio callback: only copy samples into a ring buffer. No Python allocations, no lattice calls.
2. Video capture: timer-driven, push raw frames to BoundedFrameQueue.
3. Encode / analysis: always on PROJECT_POOL or ENCODE_POOL.
4. UI updates: only via queued signals (never direct widget writes from worker threads).
5. Seed / lattice evaluation for live: pre-compute or run at lower rate on PROJECT_POOL;
   live clock only reads the latest ready state.
"""
