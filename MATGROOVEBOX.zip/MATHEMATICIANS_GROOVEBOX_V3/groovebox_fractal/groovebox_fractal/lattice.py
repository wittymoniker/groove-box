"""
Abstraction Lattice + Registry for Groovebox Fractal Finalization.
Media / game / entertainment as a fractal of mathematical abstraction methods.
Video projection is mandatory and integrity-checked.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Any, Optional, FrozenSet
import hashlib
import json
import numpy as np


@dataclass(frozen=True)
class LatticeNodeId:
    path: tuple[str, ...]
    version: str = "1"

    def __str__(self) -> str:
        return "/".join(self.path) + f"@{self.version}"


@dataclass
class FieldState:
    """Canonical field snapshot. Identity-preserving, reconstructible."""
    seed: int
    time: float = 0.0
    data: dict[str, Any] = field(default_factory=dict)
    provenance: list[str] = field(default_factory=list)

    def fingerprint(self) -> str:
        raw = f"{self.seed}:{self.time}:{sorted(self.data.keys())}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


@dataclass
class FieldDelta:
    """Contribution from one method. Must be invertible when claimed."""
    channel: str
    payload: Any
    invertible: bool = False
    inverse_payload: Optional[Any] = None


@dataclass
class AbstractionMethod:
    id: LatticeNodeId
    name: str
    description: str
    contribute: Callable[["SeedContext", FieldState], FieldDelta]
    invert: Optional[Callable[[FieldDelta], FieldDelta]] = None
    coarsen: Callable[[FieldState, int], FieldState] = lambda s, n: s
    refine: Optional[Callable[[FieldState, int], FieldState]] = None
    project_audio: Optional[Callable[[FieldState, dict], np.ndarray]] = None
    project_visual: Optional[Callable[[FieldState, dict], np.ndarray]] = None
    project_video: Callable[[FieldState, "VideoParams"], "VideoTimeline"] = None  # type: ignore
    project_game: Optional[Callable[[FieldState, dict], dict]] = None
    project_ui: Optional[Callable[[FieldState, dict], dict]] = None
    project_network: Optional[Callable[[FieldState, dict], dict]] = None
    claimed_exact: bool = True
    requires_bake_for_userdata: bool = True
    tags: FrozenSet[str] = field(default_factory=frozenset)

    def __post_init__(self):
        if self.project_video is None:
            raise ValueError(f"Method {self.id} must supply project_video")


class AbstractionRegistry:
    def __init__(self):
        self._methods: dict[LatticeNodeId, AbstractionMethod] = {}
        self._by_path: dict[tuple[str, ...], AbstractionMethod] = {}

    def register(self, method: AbstractionMethod) -> None:
        if method.project_video is None:
            raise ValueError("project_video is mandatory")
        self._methods[method.id] = method
        self._by_path[method.id.path] = method

    def get(self, node_id: LatticeNodeId | tuple[str, ...]) -> AbstractionMethod:
        if isinstance(node_id, tuple):
            node_id = LatticeNodeId(node_id)
        if node_id not in self._methods:
            # try path match
            for mid, m in self._methods.items():
                if mid.path == node_id.path:
                    return m
            raise KeyError(f"Method not found: {node_id}")
        return self._methods[node_id]

    def children(self, node_id: LatticeNodeId) -> list[AbstractionMethod]:
        prefix = node_id.path
        return [
            m for mid, m in self._methods.items()
            if mid.path[:len(prefix)] == prefix and len(mid.path) == len(prefix) + 1
        ]

    def path_from_root(self, node_id: LatticeNodeId) -> list[AbstractionMethod]:
        path = []
        for i in range(1, len(node_id.path) + 1):
            p = node_id.path[:i]
            path.append(self.get(p))
        return path

    def find_by_tag(self, tag: str) -> list[AbstractionMethod]:
        return [m for m in self._methods.values() if tag in m.tags]

    def validate_video_projectors(self) -> list[str]:
        failures = []
        for mid, m in self._methods.items():
            if m.project_video is None:
                failures.append(str(mid))
        return failures

    def all_methods(self) -> list[AbstractionMethod]:
        return list(self._methods.values())


@dataclass
class SeedContext:
    seed: int
    clock: float = 0.0
    part_counts: dict[str, int] = field(default_factory=dict)


# Global registry instance
REGISTRY = AbstractionRegistry()
