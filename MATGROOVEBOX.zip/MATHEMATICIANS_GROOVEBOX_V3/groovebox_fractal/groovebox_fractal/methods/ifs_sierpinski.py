"""
Simple IFS (Iterated Function System) — Sierpinski-variant.
First new abstraction method that proves registry + video path works end-to-end.
"""
from __future__ import annotations

import numpy as np
from typing import Any

from ..lattice import (
    AbstractionMethod, LatticeNodeId, FieldState, FieldDelta, SeedContext, REGISTRY
)
from ..video import VideoParams, VideoTimeline


def contribute_ifs(ctx: SeedContext, state: FieldState) -> FieldDelta:
    rng = np.random.default_rng(ctx.seed)
    # Classic Sierpinski IFS points
    n_points = max(256, ctx.part_counts.get("visual", 1024))
    points = np.zeros((n_points, 2), dtype=np.float32)
    x, y = 0.0, 0.0
    transforms = [
        (0.5, 0.0, 0.0, 0.5, 0.0, 0.0),
        (0.5, 0.0, 0.0, 0.5, 0.5, 0.0),
        (0.5, 0.0, 0.0, 0.5, 0.25, 0.5),
    ]
    for i in range(n_points):
        t = transforms[rng.integers(0, 3)]
        a, b, c, d, e, f = t
        nx = a * x + b * y + e
        ny = c * x + d * y + f
        x, y = nx, ny
        points[i] = (x, y)
    return FieldDelta(
        channel="geometric.points",
        payload={"points": points, "n": n_points},
        invertible=True,
        inverse_payload={"method": "ifs_sierpinski"},
    )


def coarsen_ifs(state: FieldState, target_parts: int) -> FieldState:
    # Reduce point count roughly by half (power-of-two friendly)
    if "geometric.points" in state.data:
        pts = state.data["geometric.points"].get("points")
        if pts is not None and len(pts) > target_parts:
            step = max(1, len(pts) // target_parts)
            state.data["geometric.points"]["points"] = pts[::step][:target_parts]
    return state


def project_ifs_visual(state: FieldState, params: dict) -> np.ndarray:
    w = params.get("width", 720)
    h = params.get("height", 720)
    t = params.get("time", 0.0)
    frame = np.zeros((h, w, 3), dtype=np.uint8)
    pts = state.data.get("geometric.points", {}).get("points")
    if pts is None or len(pts) == 0:
        return frame
    # Normalize and plot with slight temporal phase (rotation)
    angle = t * 0.3
    c, s = np.cos(angle), np.sin(angle)
    rot = np.array([[c, -s], [s, c]])
    rotated = pts @ rot.T
    # Map to pixels
    px = ((rotated[:, 0] + 0.1) * (w * 0.8) + w * 0.1).astype(int)
    py = ((rotated[:, 1] + 0.1) * (h * 0.8) + h * 0.1).astype(int)
    mask = (px >= 0) & (px < w) & (py >= 0) & (py < h)
    frame[py[mask], px[mask]] = (180, 220, 255)  # light blue points
    # Density boost for visibility
    for _ in range(2):
        frame = np.maximum(frame, np.roll(frame, 1, axis=0))
        frame = np.maximum(frame, np.roll(frame, 1, axis=1))
    return frame


def project_ifs_video(state: FieldState, params: VideoParams) -> VideoTimeline:
    # Use the shared renderer so integrity is enforced
    from ..video import render_lattice_video
    # Ensure contribution is present
    if "geometric.points" not in state.data:
        ctx = SeedContext(seed=state.seed, part_counts={"visual": 1024})
        delta = contribute_ifs(ctx, state)
        state.data[delta.channel] = delta.payload
    timeline = render_lattice_video(
        state,
        [LatticeNodeId(("root", "geometric", "ifs", "sierpinski_variant"))],
        REGISTRY,
        params,
    )
    return timeline


def project_ifs_audio(state: FieldState, params: dict) -> np.ndarray:
    """Deterministic, non-silent audio from IFS point density + phase."""
    sr = params.get("sample_rate", 48000)
    dur = params.get("duration_seconds", 5.0)
    n = int(sr * dur)
    t = params.get("time_axis", np.linspace(0, dur, n, endpoint=False))
    pts = state.data.get("geometric.points", {}).get("points")
    if pts is None or len(pts) == 0:
        return np.zeros(n, dtype=np.float32)
    # Density + radial mean drive pitch and amplitude (non-silent by construction)
    density = min(1.0, len(pts) / 1024.0)
    radial = float(np.mean(np.linalg.norm(pts, axis=1))) if len(pts) else 0.5
    freq = 110.0 + density * 220.0 + radial * 55.0
    amp = 0.25 + density * 0.4
    # Slow phase from seed for temporal interest
    phase = (state.seed % 360) * np.pi / 180.0
    audio = (amp * np.sin(2 * np.pi * freq * t + phase)).astype(np.float32)
    # Light harmonic for richness
    audio += 0.15 * amp * np.sin(4 * np.pi * freq * t + phase).astype(np.float32)
    return audio


def project_ifs_game(state: FieldState, params: dict) -> dict:
    pts = state.data.get("geometric.points", {}).get("points")
    return {
        "sprites": len(pts) if pts is not None else 0,
        "gravity_wells": 3,
        "seed": state.seed,
        "mechanic": "collect fractal dust",
    }


# Register the method
IFS_METHOD = AbstractionMethod(
    id=LatticeNodeId(("root", "geometric", "ifs", "sierpinski_variant")),
    name="Sierpinski-variant IFS",
    description="Classic IFS attractor used as a fractal geometric generator. Self-similar, deterministic.",
    contribute=contribute_ifs,
    invert=None,
    coarsen=coarsen_ifs,
    project_audio=project_ifs_audio,
    project_visual=project_ifs_visual,
    project_video=project_ifs_video,
    project_game=project_ifs_game,
    claimed_exact=True,
    tags=frozenset({"geometric", "ifs", "self_similar"}),
)

REGISTRY.register(IFS_METHOD)
