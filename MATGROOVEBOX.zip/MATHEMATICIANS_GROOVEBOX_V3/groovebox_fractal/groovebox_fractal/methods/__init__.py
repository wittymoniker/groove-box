# methods package
from . import ifs_sierpinski  # noqa: F401
