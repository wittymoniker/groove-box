"""
Updated self_procedure — lattice-aware, video-mandatory.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from .lattice import (
    AbstractionRegistry, LatticeNodeId, FieldState, SeedContext, REGISTRY
)
from .video import VideoParams, VideoTimeline
from .audio import AudioParams, AudioBuffer, render_lattice_audio


@dataclass
class SelfProcedureResult:
    active_lattice_paths: dict[str, list[LatticeNodeId]]
    part_counts: dict[str, int]
    correspondence_pct: float
    video_timeline_preview: Optional[VideoTimeline] = None
    audio_buffer_preview: Optional[AudioBuffer] = None
    integrity_report: dict = field(default_factory=dict)
    seed_fingerprint: str = ""


def self_procedure(
    field: FieldState,
    registry: AbstractionRegistry = REGISTRY,
    *,
    target_domains: set[str] | None = None,
    preferred_part_counts: dict[str, int] | None = None,
    max_depth: int = 6,
    video_integrity: bool = True,
) -> SelfProcedureResult:
    if target_domains is None:
        target_domains = {"audio", "visual", "video", "game"}
    preferred_part_counts = preferred_part_counts or {"video": 64, "visual": 64, "audio": 32}

    # For this prototype: select the IFS method (and any registered)
    active = {
        "audio": [LatticeNodeId(("root", "geometric", "ifs", "sierpinski_variant"))],
        "visual": [LatticeNodeId(("root", "geometric", "ifs", "sierpinski_variant"))],
        "video": [LatticeNodeId(("root", "geometric", "ifs", "sierpinski_variant"))],
        "game": [LatticeNodeId(("root", "geometric", "ifs", "sierpinski_variant"))],
    }
    # Filter to requested domains
    active = {k: v for k, v in active.items() if k in target_domains}

    part_counts = {d: preferred_part_counts.get(d, 32) for d in active}

    # Ensure contribution
    ctx = SeedContext(seed=field.seed, part_counts=part_counts)
    for domain, paths in active.items():
        for nid in paths:
            method = registry.get(nid)
            delta = method.contribute(ctx, field)
            field.data[delta.channel] = delta.payload

    video_preview = None
    integrity = {"ok": True, "reason": None}
    if "video" in target_domains:
        params = VideoParams(
            duration_seconds=5.0,
            width=720,
            height=720,
            integrity_check=video_integrity,
        )
        try:
            method = registry.get(active["video"][0])
            video_preview = method.project_video(field, params)
            integrity["frame_count"] = video_preview.expected_frame_count()
        except Exception as e:
            integrity = {"ok": False, "reason": str(e)}
            if video_integrity:
                raise

    audio_preview = None
    if "audio" in target_domains:
        aparams = AudioParams(
            duration_seconds=5.0,
            sample_rate=48000,
            bit_depth=24,
            integrity_check=True,
        )
        try:
            audio_preview = render_lattice_audio(field, active.get("audio", []), registry, aparams)
            integrity["audio_ok"] = True
            integrity["audio_rms"] = float(np.sqrt(np.mean(audio_preview._materialize_sample()**2)))
        except Exception as e:
            integrity["audio_ok"] = False
            integrity["audio_reason"] = str(e)

    return SelfProcedureResult(
        active_lattice_paths=active,
        part_counts=part_counts,
        correspondence_pct=100.0,
        video_timeline_preview=video_preview,
        audio_buffer_preview=audio_preview,
        integrity_report=integrity,
        seed_fingerprint=field.fingerprint(),
    )
