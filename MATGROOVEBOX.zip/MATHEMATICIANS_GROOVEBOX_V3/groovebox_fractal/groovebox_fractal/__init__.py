"""
Groovebox Fractal Finalization Package
Media / game / entertainment as a fractal of all possible mathematical abstraction methods.
Video succeeds. Reverse engineering remains reconstructible.
Seeded video plan writes VideoAssemblyRules.
"""
from .lattice import REGISTRY, LatticeNodeId, FieldState, SeedContext, AbstractionMethod
from .video import VideoParams, VideoTimeline, export_video_with_receipt, VideoIntegrityError
from .audio import AudioParams, AudioBuffer, export_audio_with_receipt, AudioIntegrityError
from .video_assembly import VideoAssemblyRules, apply_seed_script_rules
from .self_procedure import self_procedure, SelfProcedureResult
from .concurrency import (
    offload_to_ui, stream_export_video, live_playback_clock, RECORDING_GUIDELINES,
)

# Import methods so they self-register
import groovebox_fractal.methods.ifs_sierpinski  # noqa: F401

__all__ = [
    "REGISTRY",
    "LatticeNodeId",
    "FieldState",
    "SeedContext",
    "self_procedure",
    "VideoParams",
    "export_video_with_receipt",
    "VideoIntegrityError",
    "AudioParams",
    "export_audio_with_receipt",
    "AudioIntegrityError",
    "VideoAssemblyRules",
    "apply_seed_script_rules",
    "serialize_lattice_state",
    "save_project",
    "load_project",
    "accept_reverse_engineered_candidate",
    "offload_to_ui",
    "stream_export_video",
    "live_playback_clock",
    "RECORDING_GUIDELINES",
]
