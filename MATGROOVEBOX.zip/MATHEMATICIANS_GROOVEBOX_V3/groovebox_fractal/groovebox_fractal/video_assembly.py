"""
Video Assembly Rules — declarative parameters for the video instruction editor.
When a seeded video plan is active, a seed script writes these rules instead of
(or in addition to) manual UI edits. Rules are serializable, lattice-aware, and
participate in reverse-engineering / reconstructibility.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Optional
import json


@dataclass
class VideoAssemblyRules:
    """
    Parameter set that fully describes how a video timeline is assembled
    from lattice projections, seed data, and optional carriers.
    Written by seed scripts when seeded_video_plan is active.
    """
    # Identity / provenance
    seed: int
    lattice_paths: list[list[str]] = field(default_factory=list)  # active video paths
    part_counts: dict[str, int] = field(default_factory=dict)

    # Temporal / assembly
    duration_beats: Optional[float] = None
    duration_seconds: float = 5.0
    fps: float = 30.0
    transition_mode: str = "crossfade"          # none | cut | crossfade | lattice_morph
    transition_duration_frames: int = 15
    temporal_phase_source: str = "meum"         # meum | isn | seed | none
    loop_mode: str = "none"                     # none | seamless | bounce

    # Visual assembly
    composite_order: list[str] = field(default_factory=list)  # lattice node ids or "userdata"
    overlay_opacity: float = 1.0
    color_map: str = "default"                  # default | density | phase | seed_hue
    coarsen_on_export: bool = False
    target_part_count: Optional[int] = None

    # Integrity / contract
    integrity_check: bool = True
    claimed_exact: bool = True

    # Free-form extensions a seed script may write
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "VideoAssemblyRules":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        extra = {k: v for k, v in data.items() if k not in known}
        core = {k: v for k, v in data.items() if k in known and k != "extra"}
        obj = cls(**core)
        obj.extra.update(extra)
        return obj

    def fingerprint(self) -> str:
        raw = json.dumps(self.to_dict(), sort_keys=True, default=str)
        import hashlib
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


def apply_seed_script_rules(
    rules: VideoAssemblyRules,
    seed_script_output: dict,
) -> VideoAssemblyRules:
    """
    Merge parameters written by a seed script into the active rules.
    Seed script is authoritative when seeded_video_plan is active.
    """
    if not seed_script_output:
        return rules
    for k, v in seed_script_output.items():
        if hasattr(rules, k):
            setattr(rules, k, v)
        else:
            rules.extra[k] = v
    return rules
