# R28.4.40 — Fractal video shaping and point-visibility correction

## Changes
- Removed the filled center pixel from the 1D, 2D, and 3D `InstrumentVisualObject` render paths. The origin remains defined by the shape geometry but no longer renders as a persistent opaque dot.
- Added a deterministic five-octave golden-ratio-related motion field to the shared instrument visual geometry. It modulates phase, wobble, and orbit placement, avoiding purely linear-feeling trajectories while remaining reproducible from the same state/time/seed.
- Reduced the numeric-fractal point alpha floor from 0.30 to 0.08 so escape depth and iteration count can visibly affect translucency.
- Reduced the instrument point-flag alpha floor from 0.50 to 0.06 so authored graph opacity is respected and overlapping fractal layers are not washed out.
- No RNG was introduced. Audio/composition state is not mutated by these visual changes.

## Validation performed
- `python -m py_compile groovebox.py` passed.
- `pytest -q test_fractal_spatial_engine.py test_video_render_contract.py test_full_cycle_renderer_contract.py`: 7 passed.

## Limitations
This is a source-level visual correction with focused regression coverage. It is not a boot-tested ISO or a full-resolution visual acceptance certification. The phrase “universally encompassing fractal” is treated as a consistent deterministic self-similar shaping rule applied to the shared instrument-visual motion; it is not a mathematical proof that every renderer subsystem is a strict mathematical fractal.
