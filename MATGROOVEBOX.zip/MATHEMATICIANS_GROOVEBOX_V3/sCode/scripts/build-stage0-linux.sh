#!/usr/bin/env sh
# GROOVEBOX_STATIC_STAGE0_SEED_20261030: prefer a fully static musl seed so the
# bootstrap does not depend on the host glibc or dynamic loader. Fall back to
# the native C11 compiler when zig is unavailable.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd); ARCH=$(uname -m)
case "$ARCH" in x86_64|amd64) T=linux-x86_64; ZT=x86_64-linux-musl;; aarch64|arm64) T=linux-arm64; ZT=aarch64-linux-musl;; *) echo "Unsupported Linux architecture: $ARCH" >&2; exit 2;; esac
SRC="$ROOT/bootstrap_source/portable/scode0_hosted.c"; OUT="$ROOT/bootstrap/$T/scode0"
mkdir -p "$ROOT/bootstrap/$T"
ZIG=${ZIG:-zig}
if command -v "$ZIG" >/dev/null 2>&1; then
  if "$ZIG" cc -target "$ZT" -O2 -std=c11 -static -s "$SRC" -o "$OUT"; then
    chmod +x "$OUT"
    if "$OUT" --probe | grep -q 'scode_optimizer_abi=9'; then echo "$OUT"; exit 0; fi
  fi
fi
CC=${CC:-cc}; command -v "$CC" >/dev/null 2>&1 || { echo "A native C11 compiler or zig is required." >&2; exit 1; }
"$CC" -O2 -std=c11 "$SRC" -o "$OUT"; chmod +x "$OUT"
"$OUT" --probe | grep -q 'scode_optimizer_abi=9'; echo "$OUT"
