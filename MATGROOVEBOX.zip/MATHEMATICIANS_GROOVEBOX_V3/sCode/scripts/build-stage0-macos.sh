#!/usr/bin/env sh
# GROOVEBOX_PORTABLE_STAGE0_SEED_20261030: prefer zig for a self-contained
# Mach-O seed, then fall back to the host Apple clang toolchain.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd); ARCH=$(uname -m)
case "$ARCH" in x86_64) T=macos-x86_64; ZT=x86_64-macos;; arm64|aarch64) T=macos-arm64; ZT=aarch64-macos;; *) echo "Unsupported macOS architecture: $ARCH" >&2; exit 2;; esac
SRC="$ROOT/bootstrap_source/portable/scode0_hosted.c"; OUT="$ROOT/bootstrap/$T/scode0"
mkdir -p "$ROOT/bootstrap/$T"
ZIG=${ZIG:-zig}
if command -v "$ZIG" >/dev/null 2>&1; then
  if "$ZIG" cc -target "$ZT" -O2 -std=c11 -s "$SRC" -o "$OUT"; then
    chmod +x "$OUT"
    if command -v codesign >/dev/null 2>&1; then codesign --force --sign - "$OUT" >/dev/null 2>&1 || true; fi
    if "$OUT" --probe | grep -q 'scode_optimizer_abi=9'; then echo "$OUT"; exit 0; fi
  fi
fi
CC=${CC:-clang}; command -v "$CC" >/dev/null 2>&1 || { echo "Apple clang is required. Run: xcode-select --install" >&2; exit 1; }
"$CC" -O2 -std=c11 "$SRC" -o "$OUT"; chmod +x "$OUT"
if command -v codesign >/dev/null 2>&1; then codesign --force --sign - "$OUT" >/dev/null 2>&1 || true; fi
"$OUT" --probe | grep -q 'scode_optimizer_abi=9'; echo "$OUT"
