#!/usr/bin/env sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
# The sCode language/application tree must remain sCode-only. Native stage-0
# bootstrap sources are intentionally C and live under bootstrap_source/;
# provisioning scripts are intentionally Python/shell. Do not confuse those
# bootstrap/tooling layers with implementation dependencies of sCode programs.
bad=$(find "$root/apps" "$root/scode" "$root/examples" "$root/tests" -type f \
  \( -name '*.c' -o -name '*.h' -o -name '*.cc' -o -name '*.cpp' -o -name '*.cxx' -o -name '*.py' -o -name '*.jl' \) -print 2>/dev/null || true)
if [ -n "$bad" ]; then echo "Forbidden implementation-source dependencies found in sCode program tree:"; echo "$bad"; exit 1; fi
echo "PASS: sCode program tree contains no C/C++/Python/Julia implementation source."
