/*
 * Portable hosted build of the sCode stage-0 Groovebox ABI-9 bootstrap.
 * GROOVEBOX_SCODE0_PORTABLE_SELF_CONTAINED_20261031: the previous wrapper
 * included ../native/scode0_core.h, which is not shipped, so every
 * Linux/macOS/Windows stage-0 rebuild failed to compile. The portable target
 * now builds the exact reference implementation (C11 + stdio only).
 */
#include "../scode0_groovebox.c"
