/*
 * sCode stage-0 Groovebox ABI-9 bootstrap runtime.
 * Public domain / Unlicense with the containing Groovebox distribution.
 *
 * This native bootstrap implements the exact deterministic planning surface
 * Groovebox invokes at startup and during authoring:
 *   scode0 run apps/groovebox/groovebox_optimizer.sC
 *
 * It is intentionally small enough to build on a clean Windows/macOS host
 * before the higher sCode toolchain exists.  It does not use Python.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

/* GROOVEBOX_SCODE0_IO_HARDENING_20261031: a stage-0 run whose stdout could not
 * be fully written (full tmpfs, closed pipe, hung-up console) must not report
 * success, otherwise callers parse a truncated ABI record as valid. */
static int scode_finish(int rc){
    if (fflush(stdout) != 0 || ferror(stdout)) {
        fputs("sCode stage0 bootstrap: output write failed\n", stderr);
        return rc ? rc : 74;
    }
    return rc;
}

#define FINITE_INFINITY 134964356LL

static int64_t fi(int64_t x) {
    int64_t r = x % FINITE_INFINITY;
    if (r < 0) r += FINITE_INFINITY;
    return r;
}
static int64_t absn(int64_t x) { return x < 0 ? -x : x; }
static int64_t mix2(int64_t a,int64_t b){ return fi(fi(a)+131LL*fi(b)); }
static int64_t mix3(int64_t a,int64_t b,int64_t c){ return mix2(mix2(a,b),c); }
static int64_t mix4(int64_t a,int64_t b,int64_t c,int64_t d){ return mix2(mix3(a,b,c),d); }
static int64_t mix6(int64_t a,int64_t b,int64_t c,int64_t d,int64_t e,int64_t f){ return mix2(mix4(a,b,c,d),mix2(e,f)); }
static int64_t pslot(int64_t x,int64_t n){ if(n<=0)return 0; return absn(x)%n; }
static int64_t pgen(int64_t x,int64_t n){ int64_t i; if(n<=0)return 0; i=absn(x); return (i-(i%n))/n; }
static int64_t fmt_size(int64_t fmt,int64_t req){
    if(req>0) return req;
    switch((int)fmt){case 1:return 256;case 2:return 128;case 3:return 64;case 4:return 32;case 5:return 64;case 6:return 256;case 7:return 64;case 8:return 32;case 9:return 24;case 10:return 64;case 11:return 128;case 12:return 256;case 13:return 32;case 14:return 128;case 15:return 128;case 16:return 32;case 17:return 48;default:return 64;}
}
static int64_t buf_count(int64_t fmt){ return (fmt==7||fmt==8)?2:((fmt==9||fmt==17)?3:1); }
static int64_t req_key(int64_t fmt,int64_t mod,int64_t id,int64_t shape,int64_t subtype,int64_t bucket){ return mix6(id,fmt,mod,shape,subtype,bucket); }
static int64_t req_slot(int64_t fmt,int64_t mod,int64_t id,int64_t shape,int64_t subtype,int64_t bucket,int64_t pool){ return pslot(req_key(fmt,mod,id,shape,subtype,bucket),fmt_size(fmt,pool)); }
static int64_t req_gen(int64_t fmt,int64_t mod,int64_t id,int64_t shape,int64_t subtype,int64_t pool){ return pgen(mix6(id,fmt,mod,shape,subtype,0),fmt_size(fmt,pool)); }
static int64_t ring_slot(int64_t id,int64_t frame,int64_t count,int64_t n){ int64_t base; if(n<=0)return 0; if(count<=0)count=1; base=pslot(id,n); return base*count+(absn(frame)%count); }
static int64_t req_buf(int64_t fmt,int64_t mod,int64_t id,int64_t shape,int64_t subtype,int64_t frame,int64_t pool){ int64_t n=fmt_size(fmt,pool); return ring_slot(mix6(id,fmt,mod,shape,subtype,0),frame,buf_count(fmt),n); }
static int64_t fmt_result_key(int64_t fmt,int64_t mod,int64_t id,int64_t shape,int64_t subtype,int64_t gen){ return mix6(id,fmt,mod,shape,subtype,gen); }
static int64_t req_result(int64_t fmt,int64_t mod,int64_t id,int64_t shape,int64_t subtype,int64_t gen,int64_t pool){ return pslot(fmt_result_key(fmt,mod,id,shape,subtype,gen),fmt_size(fmt,pool)); }

static int dirty_gate(int64_t mask,int64_t bit){ if(bit<=0)return 0; return ((mask/bit)%2)>=1; }
static int64_t dep_mask(int64_t d){
    int a=dirty_gate(d,1),v=dirty_gate(d,2),g=dirty_gate(d,4),m=dirty_gate(d,8),u=dirty_gate(d,16),p=dirty_gate(d,32),c=dirty_gate(d,64),s=dirty_gate(d,128);
    if(c){a=v=g=p=1;} if(m){a=v=p=1;} if(s){u=p=1;}
    return a+2*v+4*g+8*m+16*u+32*p+64*c+128*s;
}
static int64_t cost_class(int64_t shape){ if(shape<=16)return 1;if(shape<=64)return 2;if(shape<=256)return 3;return 4; }
static int64_t mod_cost(int64_t mod,int64_t shape){ int64_t c=cost_class(shape); switch((int)mod){case 1:return c;case 2:return c+1;case 3:case 4:case 6:return c+2;case 5:case 7:return 1;case 8:return c+1;default:return c;} }
static int64_t qos(int64_t mod,int64_t editing,int64_t low,int64_t shape){ int64_t c=mod_cost(mod,shape); if(mod==1||mod==6)return 1; if(editing){if(mod==5||mod==7)return 1;return 2*c;} if(low){if(mod==5||mod==7)return 1;return c+1;} if(mod==2)return c;if(mod==3)return c+1;if(mod==4)return c;return 1; }
static int64_t admit(int64_t mod,int64_t dirty,int64_t bit,int64_t cost,int64_t budget,int64_t dep){ (void)mod; if(!dirty_gate(dirty,bit))return 0; if(!dep)return 0; if(budget<0||cost<=budget)return 1; return 0; }
static int64_t lane(int64_t kind,int64_t id,int64_t tick,int64_t lanes){ int64_t i=absn(id); if(lanes<=0)return 0; return (i+131*kind+17*tick)%lanes; }
static int64_t rust_workers(int64_t lanes,int64_t shape){ if(shape<32768||lanes<=1)return 1; return lanes>16?16:lanes; }
static int64_t rust_fft_block(int64_t shape){ if(shape<=131072)return 1024; if(shape<=2000000)return 2048; return 4096; }
static int64_t getv(const char *name,int64_t defv){ const char *s=getenv(name); char *e=0; long long v; if(!s||!*s)return defv; v=strtoll(s,&e,10); return (e==s)?defv:(int64_t)v; }
static void kv(const char *k,int64_t v){ printf("%s=%lld\n",k,(long long)v); }

static int fmt_streaming(int64_t f){ return (f==7||f==9||f==17)?1:0; }
static int fmt_persistent(int64_t f){ return (f>=11&&f<=16)?1:0; }
static int run_pool_request_probe(void){
    int64_t f=getv("POOL_FMT",0),m=getv("POOL_MODALITY",0),id=getv("POOL_ID",0),sh=getv("POOL_SHAPE",0),st=getv("POOL_SUBTYPE",0),fr=getv("POOL_FRAME",0),bu=getv("POOL_BUCKET",0),lanes=getv("POOL_LANES",1),pool=getv("POOL_SIZE",0),dep=getv("POOL_DEP",1),side=getv("POOL_SIDE_EFFECT",0);
    int64_t n=fmt_size(f,pool),key=req_key(f,m,id,sh,st,bu),gen=req_gen(f,m,id,sh,st,pool);
    kv("key",key);kv("slot",pslot(key,n));kv("generation",gen);kv("lane",pslot(key,lanes));kv("coalesce_slot",pslot(key,n));kv("buffer_slot",req_buf(f,m,id,sh,st,fr,pool));kv("result_slot",req_result(f,m,id,sh,st,gen,pool));kv("poolable",(f>=0&&f<18&&dep!=0&&side==0)?1:0);return 0;
}

static int run_pool_catalog(void){
    int f;
    kv("pool_catalog_abi",1); kv("pool_abi",3); kv("pool_format_abi",1); kv("pool_format_count",18);
    for(f=0;f<18;f++){
        printf("format=%d,size=%lld,buffers=%lld,streaming=%d,persistent=%d\n",
               f,(long long)fmt_size(f,0),(long long)buf_count(f),fmt_streaming(f),fmt_persistent(f));
    }
    return 0;
}

static int run_optimizer(void){
    int64_t id=getv("GB_OPT_ID",0), raw=getv("GB_OPT_DIRTY",255), frame=getv("GB_OPT_FRAME",0), lanes=getv("GB_OPT_LANES",8), pool=getv("GB_OPT_POOL",64), shape=getv("GB_OPT_SHAPE",0), editing=getv("GB_OPT_EDITING",0), low=getv("GB_OPT_LOW_POWER",0), budget=getv("GB_OPT_BUDGET",999), dep=getv("GB_OPT_DEP_READY",1);
    int64_t dirty=dep_mask(raw), bucket=(frame-(frame%4))/4, parallel=(lanes<=1||shape<=1)?1:(shape<lanes?shape:lanes), bg=editing?8:(low?4:2);
    int64_t fmt[9]={0,7,8,16,17,10,14,12,13};
    const char *nm[9]={"","audio","visual","game","media","ui","canonical","symbol","project"};
    int64_t bits[9]={0,1,2,4,8,16,64,128,32};
    int i;
    kv("scode_optimizer_abi",9);kv("pool_abi",3);kv("pool_format_abi",1);kv("pool_format_count",18);kv("scheduler_abi",2);kv("completion_abi",1);kv("completion_policy_count",5);kv("symbol_abi",4);
    kv("identity",id);kv("dirty_raw",raw);kv("dirty",dirty);kv("generation",req_gen(0,0,id,shape,0,pool));kv("pool_slot",req_slot(0,0,id,shape,0,bucket,pool));kv("coalesce_bucket",bucket);kv("parallel_width",parallel);kv("background_cadence",bg);kv("rust_plan_abi",1);kv("rust_workers",rust_workers(lanes,shape));kv("rust_fft_block",rust_fft_block(shape));kv("rust_stream_chunk",rust_fft_block(shape)*8);kv("rust_native_threshold",256);
    kv("audio_pool_format",7);kv("visual_pool_format",8);kv("game_pool_format",16);kv("media_pool_format",17);kv("ui_pool_format",10);kv("canonical_pool_format",14);kv("symbol_pool_format",12);kv("project_pool_format",13);
    kv("completion_policy_pure",0);kv("completion_policy_generation",1);kv("completion_policy_frame",2);kv("completion_policy_stream",3);kv("completion_policy_side_effect",4);
    for(i=1;i<=8;i++){ char k[64]; snprintf(k,sizeof(k),"%s_lane",nm[i]); kv(k,lane(i,id,bucket,lanes)); }
    for(i=1;i<=8;i++){ char k[64]; snprintf(k,sizeof(k),"%s_cost",nm[i]); kv(k,mod_cost(i,shape)); }
    { int ord[8]={1,2,3,4,5,8,6,7}; for(int oi=0;oi<8;oi++){ i=ord[oi]; char k[64]; snprintf(k,sizeof(k),"run_%s", i==7?"symbols":nm[i]); kv(k,admit(i,dirty,bits[i],mod_cost(i,shape),budget,dep)); }}
    for(i=1;i<=8;i++){ char k[64]; snprintf(k,sizeof(k),"%s_pool_slot",nm[i]); kv(k,req_slot(fmt[i],i,id,shape,0,bucket,pool)); }
    for(i=1;i<=8;i++){ char k[64]; snprintf(k,sizeof(k),"%s_generation",nm[i]); kv(k,req_gen(fmt[i],i,id,shape,0,pool)); }
    for(i=1;i<=8;i++){ char k[64]; int64_t gn=req_gen(fmt[i],i,id,shape,0,pool); snprintf(k,sizeof(k),"%s_result_slot",nm[i]); kv(k,req_result(fmt[i],i,id,shape,0,gn,pool)); }
    for(i=1;i<=8;i++){ char k[64]; snprintf(k,sizeof(k),"%s_buffer_slot",nm[i]); kv(k,req_buf(fmt[i],i,id,shape,0,frame,pool)); }
    for(i=1;i<=8;i++){ char k[64]; snprintf(k,sizeof(k),"%s_cadence",nm[i]); kv(k,qos(i,editing,low,shape)); }
    kv("reuse_window",8);kv("symbol_base",16);kv("symbol_full_cycle",16);kv("symbol_half_denominator",2);kv("symbol_subscale_bits",4);kv("symbol_variant_count",5188);
    kv("symbol_pool_key",fi(id+71LL*(5184+3)+257LL*0));
    kv("symbol_crossbar_count",4);kv("symbol_crossbar_state_count",3);kv("symbol_full_cycle_dividers",4);kv("symbol_full_cycle_main_strokes",12);kv("symbol_full_cycle_main_strokes_solid",12);kv("symbol_full_cycle_solid_mask",15);kv("symbol_full_cycle_dotted_mask",0);kv("symbol_divider_full_milli",1000);kv("symbol_divider_dotted_milli",500);
    return 0;
}

static int scode_main(int argc,char **argv){
    if(argc>=2 && (!strcmp(argv[1],"--version")||!strcmp(argv[1],"version"))){ puts("sCode stage0 Groovebox ABI-9 native bootstrap 2026.09.21-v35.22a"); return 0; }
    if(argc>=2 && (!strcmp(argv[1],"--probe")||!strcmp(argv[1],"probe"))){ puts("scode_stage0_native=1"); puts("scode_optimizer_abi=9"); puts("pool_catalog_abi=1"); return 0; }
    if(argc>=3 && !strcmp(argv[1],"run")){
        const char *p=argv[2];
        const char *b=strrchr(p,'/'); const char *w=strrchr(p,'\\'); if(w && (!b||w>b))b=w; b=b?b+1:p;
        if(!strcmp(b,"groovebox_optimizer.sC")) return run_optimizer();
        if(!strcmp(b,"pool_catalog.sC")) return run_pool_catalog();
        if(!strcmp(b,"pool_request_probe.sC")) return run_pool_request_probe();
        fprintf(stderr,"sCode stage0 bootstrap: unsupported first-stage .sC program.\n");
        return 3;
    }
    fprintf(stderr,"usage: scode0 run apps/groovebox/{groovebox_optimizer.sC|pool_catalog.sC|pool_request_probe.sC} | --probe | --version\n");
    return 2;
}

int main(int argc,char **argv){ return scode_finish(scode_main(argc,argv)); }
