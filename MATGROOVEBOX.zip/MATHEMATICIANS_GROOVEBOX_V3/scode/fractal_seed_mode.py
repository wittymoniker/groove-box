"""Groovebox V3 deterministic, bounded fractal-seed reference engine.

The seed identity is independent of exploration depth and musical mapping. This
module is deliberately side-effect-free: it creates event plans, not audio.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from hashlib import sha256
import json, math
from typing import Iterable

@dataclass(frozen=True)
class SeedSpec:
    expression: str = "x[n+1] = (x[n] * 3 + 1) mod 8"
    initial: int = 1
    radix: int = 8
    max_depth: int = 6
    def validate(self):
        if not 2 <= self.radix <= 256: raise ValueError('radix must be 2..256')
        if not 0 <= self.initial < self.radix: raise ValueError('initial must be within radix')
        if not 0 <= self.max_depth <= 16: raise ValueError('max_depth must be 0..16')

@dataclass(frozen=True)
class ExploreSpec:
    depth: int = 4
    start_step: int = 0
    step_count: int = 64
    bpm: float = 120.0
    mapping: str = 'pentatonic'
    base_note: int = 60
    canonical_controls: bool = True
    variation: str = 'none' # none, omit_even, phase_shift
    phase_shift: int = 0
    def validate(self, seed: SeedSpec):
        if not 0 <= self.depth <= seed.max_depth: raise ValueError('depth exceeds seed max_depth')
        if self.start_step < 0 or not 1 <= self.step_count <= 4096: raise ValueError('invalid bounded window')
        if not 20 <= self.bpm <= 400: raise ValueError('bpm must be 20..400')
        if self.mapping not in ('chromatic','pentatonic','diatonic'): raise ValueError('unsupported mapping')
        if self.variation not in ('none','omit_even','phase_shift'): raise ValueError('unsupported variation')
        if self.variation != 'none' and not self.canonical_controls: raise ValueError('deliberate variations require Canonical controls ON')

SCALES = {'chromatic': tuple(range(12)), 'pentatonic': (0,2,4,7,9), 'diatonic': (0,2,4,5,7,9,11)}

def seed_identity(seed: SeedSpec) -> str:
    seed.validate()
    # Exclude max_depth: depth is a computation budget, not mathematical identity.
    payload = {'expression': seed.expression.strip(), 'initial': seed.initial, 'radix': seed.radix}
    return sha256(json.dumps(payload, sort_keys=True, separators=(',',':')).encode()).hexdigest()

def sequence(seed: SeedSpec, depth: int) -> list[int]:
    seed.validate()
    if not 0 <= depth <= seed.max_depth: raise ValueError('depth out of range')
    values = [seed.initial]
    # Deterministic recurrence; depth expands a finite window, never random.
    for _ in range(depth):
        prior = values[-1]
        values.append((prior * 3 + 1) % seed.radix)
    return values

def build_plan(seed: SeedSpec, explore: ExploreSpec, authored_anchors: Iterable[dict] = ()) -> dict:
    explore.validate(seed)
    ident = seed_identity(seed)
    vals = sequence(seed, explore.depth)
    scale = SCALES[explore.mapping]
    events = []
    end = explore.start_step + explore.step_count
    for step in range(explore.start_step, end):
        level = vals[step % len(vals)]
        # Deterministic recurrence-derived subdivision; no probability/random calls.
        active = ((step + level) % max(2, min(seed.radix, 8))) == 0 or step % 4 == 0
        if not active: continue
        out_step = step
        if explore.variation == 'phase_shift': out_step += explore.phase_shift
        if explore.variation == 'omit_even' and step % 2 == 0: continue
        degree = (level + step // max(1, len(vals))) % len(scale)
        midi = max(0, min(127, explore.base_note + scale[degree]))
        events.append({'id': f'{ident[:12]}:{step}', 'step': out_step,
                       'beat': round(out_step * 0.25, 6), 'midi': midi,
                       'duration_beats': 0.25, 'velocity': 0.65,
                       'source': 'fractal', 'seed_identity': ident,
                       'lineage': {'seed_step': step, 'depth': explore.depth,
                                   'recurrence_value': level, 'mapping': explore.mapping}})
    anchors=[]
    for i, item in enumerate(authored_anchors):
        anchors.append({'id': str(item.get('id', f'anchor-{i+1}')), 'step': int(item['step']),
                        'beat': round(int(item['step'])*0.25,6), 'midi': int(item['midi']),
                        'duration_beats': float(item.get('duration_beats',0.25)),
                        'velocity': float(item.get('velocity',0.8)), 'source':'authored',
                        'seed_identity':ident, 'lineage':{'preserved_authored_event':True}})
    combined = sorted(events + anchors, key=lambda e:(e['step'], e['source'] != 'authored', e['id']))
    # Canonical fingerprint excludes UI state and includes event content and seed identity.
    fingerprint = sha256(json.dumps({'seed_identity':ident,'events':combined},sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {'schema':'groovebox.fractal-seed-plan.v1','seed_identity':ident,
            'seed':asdict(seed),'exploration':asdict(explore),'window':{'start_step':explore.start_step,'end_step_exclusive':end,'bounded':True},
            'events':combined,'generated_count':len(events),'authored_count':len(anchors),
            'truncated': explore.start_step + explore.step_count > 4096,
            'fingerprint':fingerprint}

def export_json(plan: dict) -> str: return json.dumps(plan, indent=2, sort_keys=True)
