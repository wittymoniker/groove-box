#!/usr/bin/env python3
"""Read-only Groovebox platform, audio, camera and Qt multimedia diagnostic.

Usage: python scripts/diagnose_platform.py [--json PATH]
Read-only: it never installs packages, alters device routing, or starts playback.
A detected endpoint is not proof that it can be opened for real playback.
"""
from __future__ import annotations
import argparse, importlib, json, os, platform, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def run(cmd, timeout=2.5):
    if not shutil.which(cmd[0]):
        return {"available": False, "command": cmd[0]}
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
        return {"available": True, "returncode": p.returncode,
                "output": ((p.stdout or p.stderr or "").strip())[:3500]}
    except Exception as exc:
        return {"available": True, "error": repr(exc)}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--json', dest='json_path', help='also write report JSON to this path')
    args=ap.parse_args()
    report={"generated_local_time":time.strftime('%Y-%m-%d %H:%M:%S'),
      "groovebox_root":str(ROOT), "python":sys.version, "python_executable":sys.executable,
      "os":platform.platform(), "system":platform.system(), "release":platform.release(),
      "machine":platform.machine(), "architecture":platform.architecture()[0],
      "environment":{k:os.environ.get(k) for k in ('DISPLAY','WAYLAND_DISPLAY','XDG_SESSION_TYPE','QT_QPA_PLATFORM','PYTHONPATH','VIRTUAL_ENV') if os.environ.get(k)},
      "imports":{}, "audio":{}, "video":{}, "commands":{}}
    modules=('numpy','scipy','PyQt6.QtCore','PyQt6.QtMultimedia','PyQt6.QtMultimediaWidgets','PyQt6.QtWebEngineWidgets','sounddevice','PIL')
    for mod in modules:
        try:
            m=importlib.import_module(mod)
            report['imports'][mod]={"ok":True,"file":getattr(m,'__file__',None)}
        except Exception as exc:
            report['imports'][mod]={"ok":False,"error":repr(exc)}
    try:
        import sounddevice as sd
        try:
            from audio_os_backend import audio_device_diagnostics
            snap=audio_device_diagnostics(force=True)
            report['audio']={"backend":"PortAudio/sounddevice","default_device":str(snap.get('default_device')),
              "host_apis":snap.get('host_apis',[]),"enumeration_error":snap.get('enumeration_error'),
              "devices":[{"index":i,"name":d.get('name'),"inputs":d.get('max_input_channels',0),
                "outputs":d.get('max_output_channels',0),"default_samplerate":d.get('default_samplerate')}
                for i,d in enumerate(snap.get('devices',[]))]}
        except Exception as exc:
            report['audio']={"backend":"PortAudio/sounddevice","default_device":str(sd.default.device),
              "devices":[{"index":i,"name":d.get('name'),"inputs":d.get('max_input_channels',0),
                "outputs":d.get('max_output_channels',0),"default_samplerate":d.get('default_samplerate')}
                for i,d in enumerate(sd.query_devices())],"diagnostics_error":repr(exc)}
    except Exception as exc: report['audio']={"error":repr(exc),"devices":[]}
    # Qt's device enumerators require a GUI application on several platforms.
    # Use offscreen only when no display/session is advertised; never launch media.
    try:
        if not any(os.environ.get(k) for k in ('DISPLAY','WAYLAND_DISPLAY')) and platform.system() != 'Windows' and platform.system() != 'Darwin':
            os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
        from PyQt6.QtWidgets import QApplication
        from PyQt6.QtMultimedia import QMediaDevices
        app=QApplication.instance() or QApplication(["groovebox-diagnostic"])
        report['video']={"qt_multimedia_imported":True,
          "audio_outputs":[{"description":d.description(),"id":bytes(d.id()).hex()} for d in QMediaDevices.audioOutputs()],
          "audio_inputs":[{"description":d.description(),"id":bytes(d.id()).hex()} for d in QMediaDevices.audioInputs()],
          "video_inputs":[{"description":d.description(),"id":bytes(d.id()).hex()} for d in QMediaDevices.videoInputs()],
          "note":"Enumeration only; playback/capture was not opened."}
        del app
    except Exception as exc:
        report['video']={"qt_multimedia_imported":False,"error":repr(exc),
          "note":"Qt Multimedia/device enumeration unavailable in this interpreter."}
    if platform.system() == 'Linux':
        report['commands']={"wpctl":run(['wpctl','status']),"pactl_sinks":run(['pactl','list','short','sinks']),
          "aplay_cards":run(['aplay','-l']),"v4l2_cameras":run(['v4l2-ctl','--list-devices']),
          "ffmpeg":run(['ffmpeg','-version']),"ffplay":run(['ffplay','-version'])}
    elif platform.system() == 'Windows':
        report['commands']={"ffmpeg":run(['ffmpeg','-version']),"where_python":run(['where','python']),
          "where_ffplay":run(['where','ffplay']),"powershell_audio_devices":run(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_SoundDevice | Select-Object Name,Status | Format-Table -AutoSize"])}
    elif platform.system() == 'Darwin':
        report['commands']={"ffmpeg":run(['ffmpeg','-version']),"system_profiler_audio":run(['system_profiler','SPAudioDataType']),
          "system_profiler_camera":run(['system_profiler','SPCameraDataType'])}
    report['status']="diagnostic-only; device presence does not guarantee successful playback"
    out=json.dumps(report,indent=2,ensure_ascii=False)
    print(out)
    if args.json_path:
        p=Path(args.json_path).expanduser(); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(out+'\n',encoding='utf-8')
        print(f'Wrote report: {p}',file=sys.stderr)
    return 0
if __name__=='__main__': raise SystemExit(main())
