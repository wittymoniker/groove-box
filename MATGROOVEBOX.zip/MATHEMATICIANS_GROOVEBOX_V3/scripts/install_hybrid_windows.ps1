# Groovebox Hybrid installer (Windows)
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
Write-Host "=== Groovebox Hybrid installer (Windows) ==="

if (Test-Path .\install_deps_windows.ps1) { & .\install_deps_windows.ps1 }
python -m pip install --user -U pip numpy sounddevice Pillow PyQt6 juliacall

$julia = Get-Command julia -ErrorAction SilentlyContinue
if (-not $julia) {
    Write-Host "Installing Julia via winget..."
    try { winget install --id Julialang.Juliaup -e --accept-source-agreements --accept-package-agreements } catch {}
    $env:Path = "$env:USERPROFILE\.juliaup\bin;$env:Path"
}

julia --project="$Root\julia" -e 'using Pkg; Pkg.instantiate(); using GrooveboxMeumOT; println("Julia kernel OK")'
python "$Root\scripts\ensure_rust_toolchain.py" --install
if ($LASTEXITCODE -ne 0) { throw 'Rust toolchain provisioning failed.' }
python "$Root\scripts\build_rust_accel.py"
if ($LASTEXITCODE -ne 0) { throw 'Rust accelerator build failed.' }
Write-Host "Done. Launch: bin\windows\groovebox_hybrid.bat"
