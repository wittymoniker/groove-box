#!/usr/bin/env bash
# Install Python deps + Julia + juliacall for Groovebox hybrid (Fedora/Ubuntu/Debian)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "=== Groovebox Hybrid installer (Linux) ==="

# The canonical installer owns the one required DNF/APT transaction. Keeping
# a second package list here caused duplicate transactions and package-name drift.
# Use the canonical runtime installer; do not hide its failure and do not mix
# Fedora's RPM Qt ABI with user-site PyQt wheels.
bash ./install_deps_linux.sh
if command -v dnf >/dev/null 2>&1; then
  export PYTHONNOUSERSITE=1
  unset PYTHONPATH || true
  SELECTED_PY="$(python3 scripts/ensure_runtime_dependencies.py --force-install --prefer-system-qt)"
else
  SELECTED_PY="$(python3 scripts/ensure_runtime_dependencies.py --force-install)"
fi
"$SELECTED_PY" -m pip install --disable-pip-version-check --no-input --upgrade juliacall

# Julia
export PATH="${HOME}/.juliaup/bin:${PATH:-}"
if ! command -v julia >/dev/null 2>&1; then
  echo "Installing Julia (juliaup)..."
  curl -fsSL https://install.julialang.org | sh -s -- -y
  export PATH="${HOME}/.juliaup/bin:${PATH}"
  echo 'export PATH="$HOME/.juliaup/bin:$PATH"' >> "${HOME}/.bashrc"
fi
julia --version

# Activate Julia package
julia --project="$ROOT/julia" -e 'using Pkg; Pkg.instantiate(); using GrooveboxMeumOT; println("Julia kernel OK")'

echo ""

echo "Hybrid install complete."
echo "  Launch:  ./bin/linux-x86_64/groovebox_hybrid"
echo "  Or:      GROOVEBOX_JULIA=1 python3 run_groovebox.py"
echo "  Disable Julia: GROOVEBOX_JULIA=0 python3 run_groovebox.py"
