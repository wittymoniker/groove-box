#!/usr/bin/env python3
"""Verify/install a stable Rust toolchain for Groovebox on Linux/macOS/Windows."""
from __future__ import annotations
import argparse, os, platform, shutil, subprocess, sys, tempfile, urllib.request
from pathlib import Path

CARGO_HOME=Path(os.environ.get('CARGO_HOME',Path.home()/'.cargo'))
CARGO_BIN=CARGO_HOME/'bin'

def which(name):
    p=shutil.which(name)
    if p: return p
    q=CARGO_BIN/(name+'.exe' if os.name=='nt' else name)
    return str(q) if q.exists() else None

def run(cmd, **kw):
    print('[rust]', ' '.join(map(str,cmd)), file=sys.stderr)
    return subprocess.run([str(x) for x in cmd], check=True, **kw)

def install_windows():
    winget=shutil.which('winget')
    if winget:
        run([winget,'install','--id','Rustlang.Rustup','-e','--silent','--accept-package-agreements','--accept-source-agreements'])
        return
    machine=platform.machine().lower()
    suffix='aarch64' if machine in {'arm64','aarch64'} else 'x86_64' if machine in {'amd64','x86_64'} else 'i686'
    url=f'https://win.rustup.rs/{suffix}'
    with tempfile.TemporaryDirectory() as td:
        exe=Path(td)/'rustup-init.exe'; urllib.request.urlretrieve(url,exe)
        run([exe,'-y','--profile','minimal'])

def install_unix():
    curl=shutil.which('curl')
    if not curl: raise RuntimeError('curl is required to install rustup')
    sh=shutil.which('sh') or '/bin/sh'
    p=subprocess.Popen([curl,'--proto','=https','--tlsv1.2','-sSf','https://sh.rustup.rs'],stdout=subprocess.PIPE)
    q=subprocess.run([sh,'-s','--','-y','--profile','minimal'],stdin=p.stdout,check=False)
    if p.stdout: p.stdout.close()
    rc=p.wait()
    if rc or q.returncode: raise RuntimeError(f'rustup bootstrap failed curl={rc} installer={q.returncode}')

def ensure(install=False):
    cargo=which('cargo'); rustc=which('rustc')
    if (not cargo or not rustc) and install:
        if os.name=='nt': install_windows()
        elif sys.platform.startswith(('linux','darwin')): install_unix()
        else: raise RuntimeError(f'unsupported Rust host: {sys.platform}')
        cargo=which('cargo'); rustc=which('rustc')
    if not cargo or not rustc:
        raise RuntimeError('Rust/Cargo missing. Run the platform dependency installer.')
    rustup=which('rustup')
    if rustup:
        # rustup 1.28+ no longer guarantees implicit active-toolchain install.
        # ISO_BUILD_SKIP_RUSTUP_REFRESH_20261102: "toolchain install stable" checks the network on every build.
        # Skip it when a working default toolchain already exists; GROOVEBOX_RUST_REFRESH=1 forces the refresh.
        _have = False
        if not os.environ.get('GROOVEBOX_RUST_REFRESH'):
            _p=subprocess.run([cargo,'--version'],text=True,capture_output=True)
            _q=subprocess.run([rustup,'show','active-toolchain'],text=True,capture_output=True)
            _have = _p.returncode==0 and _q.returncode==0 and bool(_q.stdout.strip())
        if not _have:
            subprocess.run([rustup,'toolchain','install','stable','--profile','minimal'],check=False)
            subprocess.run([rustup,'default','stable'],check=False)
    cp=subprocess.run([cargo,'--version'],text=True,capture_output=True)
    rp=subprocess.run([rustc,'--version'],text=True,capture_output=True)
    if cp.returncode or rp.returncode: raise RuntimeError('Rust toolchain probe failed')
    print(f"{cargo}\t{cp.stdout.strip()}\t{rp.stdout.strip()}")
    return cargo

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--install',action='store_true'); a=ap.parse_args()
    try: ensure(a.install); return 0
    except Exception as e: print(f'[rust] ERROR: {e}',file=sys.stderr); return 3
if __name__=='__main__': raise SystemExit(main())
