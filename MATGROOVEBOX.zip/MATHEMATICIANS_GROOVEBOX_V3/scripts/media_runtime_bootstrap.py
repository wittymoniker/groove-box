#!/usr/bin/env python3
"""Non-blocking Fedora-friendly audio/video initialization diagnostics.

Call schedule(app) after QApplication construction. The first probe runs only
after the event loop has started; retries are bounded to allow PipeWire and Qt
Multimedia to publish devices during desktop-session startup.
"""
from __future__ import annotations
import os, sys, time, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG = Path(os.environ.get("GROOVEBOX_MEDIA_BOOT_LOG", str(Path.home() / ".local" / "state" / "groovebox" / "media-bootstrap.log")))

def _log(message: str) -> None:
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f: f.write(line + "\n")
    except Exception: pass
    print("[MediaBootstrap] " + message, file=sys.stderr, flush=True)

def _probe(attempt: int) -> bool:
    audio_outputs = []
    video_inputs = []
    qt_error = None
    try:
        from PyQt6.QtMultimedia import QMediaDevices
        audio_outputs = [d.description() or "Unnamed output" for d in QMediaDevices.audioOutputs()]
        video_inputs = [d.description() or "Unnamed camera" for d in QMediaDevices.videoInputs()]
        _log(f"Qt Multimedia available; audio outputs={audio_outputs!r}; camera inputs={video_inputs!r}")
    except Exception as exc:
        qt_error = repr(exc)
        _log(f"Qt Multimedia unavailable: {qt_error}")
    sd_outputs = []
    try:
        from audio_os_backend import audio_device_diagnostics, invalidate_device_cache
        # A fresh query avoids carrying a startup-time empty cache across the
        # PipeWire/WirePlumber service becoming ready after login.
        invalidate_device_cache()
        # audio_device_diagnostics performs a fresh sounddevice/PortAudio query
        # (equivalent to sd.query_devices()) and records host API errors.
        snapshot = audio_device_diagnostics(force=True)
        sd_outputs = [str(d.get("name", "")) for d in snapshot.get("devices", [])
                      if int(d.get("max_output_channels", 0) or 0) > 0]
        _log(f"PortAudio outputs={sd_outputs!r}; default_device={snapshot.get('default_device')!r}; "
             f"host_apis={snapshot.get('host_apis')!r}; enumeration_error={snapshot.get('enumeration_error')!r}")
    except Exception as exc:
        _log(f"PortAudio enumeration failed: {type(exc).__name__}: {exc!r}")
    if not audio_outputs and not sd_outputs:
        _log(f"No audio outputs published on attempt {attempt}; checking desktop audio service")
        for command in (("wpctl", "status"), ("pactl", "list", "short", "sinks"), ("aplay", "-l")):
            import shutil, subprocess
            if not shutil.which(command[0]): continue
            try:
                r = subprocess.run(command, capture_output=True, text=True, timeout=2.0, check=False)
                _log(f"{command[0]} exit={r.returncode}: {(r.stdout or r.stderr).strip()[:1800]}")
            except Exception as exc: _log(f"{command[0]} probe failed: {exc!r}")
    if not audio_outputs and not sd_outputs and attempt < 4:
        return False
    if not audio_outputs and not sd_outputs:
        _log("ERROR: no usable audio output detected after bounded retries. Confirm the user session has PipeWire + WirePlumber (or PulseAudio) running, ALSA sees the card, and the launcher uses the same Python environment where sounddevice and PyQt6.QtMultimedia import successfully.")
    if qt_error:
        _log("ERROR: video/media player features may be unavailable; install the distro PyQt6 Qt Multimedia package and its GStreamer plugins")
    return True

def schedule(app) -> None:
    """Run after Qt event-loop startup, with bounded retries and no blocking UI work."""
    try:
        from PyQt6.QtCore import QTimer
        state = {"attempt": 0}
        def run_probe():
            state["attempt"] += 1
            try:
                complete = _probe(state["attempt"])
            except Exception:
                _log("Unexpected media bootstrap error:\n" + traceback.format_exc())
                complete = True
            if not complete and state["attempt"] < 4:
                QTimer.singleShot(1800, run_probe)
        QTimer.singleShot(1200, run_probe)
    except Exception as exc:
        _log(f"Could not schedule media bootstrap: {exc!r}")
