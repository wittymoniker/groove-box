#!/usr/bin/env python3
"""Required desktop runtime dependencies. QtWebEngine is optional/lazy-loaded.

QtWebEngine can hang while Chromium initializes on some Fedora/Qt setups; it
must not prevent the main audio/video application from launching. The browser
tab already handles an unavailable WebEngine backend gracefully.
"""
from __future__ import annotations

# (import target, pip distribution)
REQUIRED = (
    ("numpy", "numpy"),
    ("scipy", "scipy"),
    ("cffi", "cffi"),
    ("PyQt6.QtCore", "PyQt6"),
    ("PyQt6.QtMultimedia", "PyQt6"),
    ("PyQt6.QtMultimediaWidgets", "PyQt6"),
    ("sounddevice", "sounddevice"),
    ("PIL", "Pillow"),
)

# Keep WebEngine explicitly discoverable for the ISO/source contract and for
# optional browser provisioning, but never include it in the blocking startup
# import probe: Chromium initialization can hang on Fedora and must not block audio.
OPTIONAL = (
    ("PyQt6.QtWebEngineWidgets", "PyQt6-WebEngine"),
)
OPTIONAL_IMPORT_MODULES = tuple(mod for mod, _pkg in OPTIONAL)
OPTIONAL_PIP_PACKAGES = tuple(pkg for _mod, pkg in OPTIONAL)
# Force-install also provisions optional WebEngine so installers/builders can
# run their explicit browser smoke test. Fedora filters all Qt wheels and uses
# the matching RPM bindings instead.
PIP_PACKAGES = tuple(dict.fromkeys(pkg for _mod, pkg in (*REQUIRED, *OPTIONAL)))
IMPORT_MODULES = tuple(mod for mod, _pkg in REQUIRED)
