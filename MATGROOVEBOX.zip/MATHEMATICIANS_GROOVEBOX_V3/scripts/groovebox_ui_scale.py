import sys, json
sys.path.insert(0, sys.argv[1])
import compat_settings as c
d = c.load()
if len(sys.argv) > 2 and sys.argv[2]:
    v = float(sys.argv[2]); v = v * 100 if 0 < v <= 4 else v
    d["ui_scale"] = int(round(v)); c.save(d)
    print(f"UI scale saved: {d['ui_scale']}% (applies at the next Groovebox start)")
print(json.dumps({k: d[k] for k in ("ui_scale", "window_scale", "smooth_mode", "threads")}, indent=2))
