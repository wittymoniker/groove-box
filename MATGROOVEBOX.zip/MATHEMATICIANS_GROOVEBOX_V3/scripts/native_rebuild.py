#!/usr/bin/env python3
"""Local native recompiler shared by BUILD_ISO and BUILD_KIT.

GROOVEBOX_R23R_NATIVE_REBUILD_20261101

One place decides how Groovebox's native pieces are compiled, with a profile
for each consumer's preferred link/include method:

  --profile iso   Linux live root (sOS). Output must not depend on the build
                  host's C++ runtime: the C++ accelerator links libstdc++/libgcc
                  statically; stage-0 is a static musl binary via zig when
                  available, otherwise a static glibc binary, otherwise dynamic.
                  Writes cpp/libgroovebox_accel.so (what the initramfs stamp
                  stages) and native/libgroovebox_accel.so.
  --profile kit   Desktop executable for the current host. Linux g++/clang
                  shared object, macOS -dynamiclib with @rpath install name,
                  Windows MSVC cl /LD /MD (MinGW only with --allow-mingw, since
                  its libstdc++ DLLs are not bundled). Writes native/.

Targets: accel (C++), stage0 (sCode C11 seed), rust (delegates to
scripts/build_rust_accel.py). Default: accel stage0.

Both profiles share: include dirs (cpp/, sCode/bootstrap_source/portable/),
honoured CC / CXX / CFLAGS / CXXFLAGS / LDFLAGS overrides, an incremental
manifest (native/BUILD_MANIFEST.json: source hash + compiler + flags -> skip
when unchanged; --force rebuilds), and a post-build verification (the accel is
loaded and its exported ABI symbols resolved; stage-0 must answer --probe with
scode_optimizer_abi=9). Optional pieces never fail the caller unless --strict.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
import platform
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CPP_SRC = ROOT / "cpp" / "groovebox_accel.cpp"
STAGE0_SRC = ROOT / "sCode" / "bootstrap_source" / "portable" / "scode0_hosted.c"
INCLUDES = [ROOT / "cpp", ROOT / "sCode" / "bootstrap_source" / "portable"]
NATIVE = ROOT / "native"
MANIFEST = NATIVE / "BUILD_MANIFEST.json"
ACCEL_SYMBOLS = ("gb_meum_modulation_f32", "gb_voice_synth_f32", "gb_hardclip_f32", "gb_ot_band_tensor_f32")


def _system() -> str:
    return platform.system().lower()


def _arch() -> str:
    m = platform.machine().lower()
    return {"amd64": "x86_64", "aarch64": "arm64"}.get(m, m)


def _env_flags(name: str) -> list:
    return shlex.split(os.environ.get(name, ""), posix=os.name != "nt")


def _which(*names):
    for n in names:
        if not n:
            continue
        p = shutil.which(n)
        if p:
            return p
    return None


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _load_manifest() -> dict:
    try:
        return json.loads(MANIFEST.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_manifest(m: dict):
    NATIVE.mkdir(exist_ok=True)
    MANIFEST.write_text(json.dumps(m, indent=2, sort_keys=True), encoding="utf-8")


def _run(cmd, cwd=None) -> subprocess.CompletedProcess:
    print("[native] $ " + " ".join(shlex.quote(str(c)) for c in cmd), flush=True)
    return subprocess.run([str(c) for c in cmd], cwd=str(cwd or ROOT), capture_output=True, text=True, timeout=1800)


def _inc() -> list:
    return [f"-I{p}" for p in INCLUDES if p.is_dir()]


# ---------------------------------------------------------------- accel (C++)
def _accel_plans(profile: str, allow_mingw: bool):
    """Ordered (compiler argv, outputs) attempts for the profile."""
    s = _system()
    cxx = _which(os.environ.get("CXX"), "g++", "c++", "clang++")
    cxxflags = _env_flags("CXXFLAGS"); ldflags = _env_flags("LDFLAGS")
    base = ["-std=c++17", "-O3", "-DNDEBUG", "-fPIC", "-fvisibility=hidden", *_inc(), *cxxflags]
    plans = []
    if profile == "iso" or s == "linux":
        if not cxx:
            return plans
        outs = [NATIVE / "libgroovebox_accel.so"] + ([ROOT / "cpp" / "libgroovebox_accel.so"] if profile == "iso" else [])
        if profile == "iso":
            # Self-contained for the live root: no host libstdc++ ABI dependency.
            plans.append(([cxx, *base, "-shared", str(CPP_SRC), "-static-libstdc++", "-static-libgcc",
                           "-Wl,--as-needed", "-Wl,-z,relro,-z,now", *ldflags], outs))
        plans.append(([cxx, *base, "-shared", str(CPP_SRC), "-Wl,--as-needed", *ldflags], outs))
        return plans
    if s == "darwin":
        c = _which(os.environ.get("CXX"), "clang++", "c++")
        if c:
            out = NATIVE / "libgroovebox_accel.dylib"
            plans.append(([c, *base, "-dynamiclib", "-install_name", "@rpath/libgroovebox_accel.dylib",
                           f"-mmacosx-version-min={os.environ.get('MACOSX_DEPLOYMENT_TARGET', '11.0')}",
                           str(CPP_SRC), *ldflags], [out]))
        return plans
    if s == "windows":
        out = NATIVE / "groovebox_accel.dll"
        cl = _which("cl")
        if cl:
            incs = [f"/I{p}" for p in INCLUDES if p.is_dir()]
            # /MD: the MSVC runtime the Python/Qt wheels already ship with.
            plans.append(([cl, "/nologo", "/std:c++17", "/O2", "/DNDEBUG", "/MD", "/LD", *incs, str(CPP_SRC),
                           f"/Fe:{out}", f"/Fo:{NATIVE}\\", "/link", "/NOLOGO"], [out]))
        gxx = _which("g++", "clang++")
        if gxx and allow_mingw:
            plans.append(([gxx, *base, "-shared", str(CPP_SRC), "-static", "-static-libstdc++", "-static-libgcc",
                           *ldflags], [out]))
        return plans
    return plans


def _verify_accel(path: Path) -> tuple:
    try:
        lib = ctypes.CDLL(str(path))
        missing = [s for s in ACCEL_SYMBOLS if not hasattr(lib, s)]
        return (not missing), ("missing symbols: " + ", ".join(missing)) if missing else "ABI symbols resolved"
    except OSError as exc:
        # Cross-profile output (e.g. iso on a non-Linux host) cannot be loaded here.
        return (_system() != "linux"), f"not loadable on this host ({exc})"


def build_accel(profile: str, force: bool, allow_mingw: bool, manifest: dict) -> tuple:
    if not CPP_SRC.is_file():
        return False, "cpp/groovebox_accel.cpp missing"
    plans = _accel_plans(profile, allow_mingw)
    if not plans:
        return False, "no suitable C++ compiler for this profile"
    src_hash = _sha(CPP_SRC)
    key = f"accel:{profile}:{_system()}:{_arch()}"
    for argv, outs in plans:
        sig = hashlib.sha256(json.dumps([src_hash, argv[1:]], default=str).encode()).hexdigest()
        prev = manifest.get(key, {})
        if (not force and prev.get("sig") == sig and all(Path(o).is_file() for o in outs)
                and all(prev.get("outputs", {}).get(str(o)) == _sha(Path(o)) for o in outs)):
            return True, f"up to date ({outs[0].name})"
        NATIVE.mkdir(exist_ok=True)
        tmp = Path(str(outs[0]) + ".part")
        a = list(argv)
        if "/LD" in a:  # MSVC
            a = [x if not str(x).startswith("/Fe:") else f"/Fe:{tmp}" for x in a]
        else:
            a += ["-o", str(tmp)]
        r = _run(a)
        if r.returncode != 0 or not tmp.is_file():
            print((r.stderr or r.stdout or "")[-2000:], file=sys.stderr)
            try: tmp.unlink()
            except OSError: pass
            continue
        ok, why = _verify_accel(tmp)
        if not ok:
            print(f"[native] accel verification failed: {why}", file=sys.stderr)
            try: tmp.unlink()
            except OSError: pass
            continue
        for o in outs:
            Path(o).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(tmp, o)
            try: os.chmod(o, 0o755)
            except OSError: pass
        tmp.unlink()
        manifest[key] = {"sig": sig, "compiler": argv[0], "flags": [str(x) for x in argv[1:]],
                         "source_sha256": src_hash, "outputs": {str(o): _sha(Path(o)) for o in outs}}
        return True, f"built {', '.join(Path(o).relative_to(ROOT).as_posix() for o in outs)} ({why})"
    return False, "every compiler plan failed"


# ------------------------------------------------------------ stage-0 (C11)
def _stage0_out() -> Path:
    s = _system(); a = _arch()
    if s == "linux":
        return ROOT / "sCode" / "bootstrap" / ("linux-arm64" if a == "arm64" else "linux-x86_64") / "scode0"
    if s == "darwin":
        return ROOT / "sCode" / "bootstrap" / ("macos-arm64" if a == "arm64" else "macos-x86_64") / "scode0"
    return ROOT / "sCode" / "bootstrap" / ("windows-arm64" if a == "arm64" else "windows-x86_64") / "scode0.exe"


def _stage0_plans(profile: str):
    s = _system(); a = _arch()
    cflags = ["-O2", "-std=c11", *_inc(), *_env_flags("CFLAGS")]; ld = _env_flags("LDFLAGS")
    zig = _which(os.environ.get("ZIG"), "zig")
    cc = _which(os.environ.get("CC"), "cc", "gcc", "clang")
    plans = []
    if s == "linux":
        zt = ("aarch64" if a == "arm64" else "x86_64") + "-linux-musl"
        if zig:
            plans.append([zig, "cc", "-target", zt, *cflags, "-static", "-s", str(STAGE0_SRC)])
        if cc and profile == "iso":
            plans.append([cc, *cflags, "-static", "-s", str(STAGE0_SRC), *ld])
        if cc:
            plans.append([cc, *cflags, "-s", str(STAGE0_SRC), *ld])
    elif s == "darwin":
        if zig:
            plans.append([zig, "cc", "-target", ("aarch64" if a == "arm64" else "x86_64") + "-macos", *cflags, "-s", str(STAGE0_SRC)])
        c = _which(os.environ.get("CC"), "clang", "cc")
        if c:
            plans.append([c, *cflags, str(STAGE0_SRC), *ld])
    elif s == "windows":
        cl = _which("cl")
        if cl:
            plans.append([cl, "/nologo", "/O2", "/std:c11", "/MT", str(STAGE0_SRC)])
        if zig:
            plans.append([zig, "cc", "-target", ("aarch64" if a == "arm64" else "x86_64") + "-windows-gnu", *cflags, str(STAGE0_SRC)])
    return plans


def build_stage0(profile: str, force: bool, manifest: dict) -> tuple:
    if not STAGE0_SRC.is_file():
        return False, "sCode stage-0 source missing"
    out = _stage0_out(); src_hash = _sha(STAGE0_SRC); key = f"stage0:{profile}:{_system()}:{_arch()}"
    for argv in _stage0_plans(profile):
        sig = hashlib.sha256(json.dumps([src_hash, argv[1:]], default=str).encode()).hexdigest()
        prev = manifest.get(key, {})
        if not force and prev.get("sig") == sig and out.is_file() and prev.get("sha256") == _sha(out):
            return True, f"up to date ({out.relative_to(ROOT).as_posix()})"
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_name(out.name + ".part" + (".exe" if out.suffix == ".exe" else ""))
        a = list(argv) + ([f"/Fe:{tmp}"] if argv and Path(argv[0]).name.lower().startswith("cl") else ["-o", str(tmp)])
        r = _run(a)
        if r.returncode != 0 or not tmp.is_file():
            print((r.stderr or r.stdout or "")[-1500:], file=sys.stderr)
            continue
        try:
            os.chmod(tmp, 0o755)
            pr = subprocess.run([str(tmp), "--probe"], capture_output=True, text=True, timeout=15)
            good = "scode_optimizer_abi=9" in ((pr.stdout or "") + (pr.stderr or ""))
        except Exception as exc:
            good = False; print(f"[native] stage-0 probe failed: {exc}", file=sys.stderr)
        if not good:
            try: tmp.unlink()
            except OSError: pass
            continue
        os.replace(tmp, out)
        manifest[key] = {"sig": sig, "compiler": argv[0], "flags": [str(x) for x in argv[1:]],
                         "source_sha256": src_hash, "sha256": _sha(out)}
        static = "-static" in argv
        return True, f"built {out.relative_to(ROOT).as_posix()} ({'static' if static else 'dynamic'}, ABI 9 probe OK)"
    return False, "every stage-0 compiler plan failed"


# ------------------------------------------------------------------ rust
def build_rust(profile: str) -> tuple:
    helper = ROOT / "scripts" / "build_rust_accel.py"
    if not helper.is_file():
        return False, "scripts/build_rust_accel.py missing"
    r = subprocess.run([sys.executable, str(helper)], cwd=str(ROOT), timeout=3600)
    return r.returncode == 0, "cargo build " + ("OK" if r.returncode == 0 else f"failed ({r.returncode})")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("targets", nargs="*", help="accel, stage0, rust (default: accel stage0)")
    ap.add_argument("--profile", choices=["iso", "kit"], default="kit")
    ap.add_argument("--force", action="store_true", help="rebuild even when the manifest says up to date")
    ap.add_argument("--strict", action="store_true", help="exit non-zero if any requested target fails")
    ap.add_argument("--allow-mingw", action="store_true", help="Windows kit: permit a statically linked MinGW DLL")
    ap.add_argument("--plan", action="store_true", help="print the compiler plans and exit")
    a = ap.parse_args(argv)
    bad = [t for t in a.targets if t not in ("accel", "stage0", "rust")]
    if bad:
        ap.error("unknown target(s): " + ", ".join(bad))
    if a.plan:
        for argv_, outs in _accel_plans(a.profile, a.allow_mingw):
            print("accel :", " ".join(map(str, argv_)), "->", ", ".join(map(str, outs)))
        for p in _stage0_plans(a.profile):
            print("stage0:", " ".join(map(str, p)), "->", _stage0_out())
        return 0
    manifest = _load_manifest(); failed = []
    for t in dict.fromkeys(a.targets or ["accel", "stage0"]):
        if t == "accel":
            ok, why = build_accel(a.profile, a.force, a.allow_mingw, manifest)
        elif t == "stage0":
            ok, why = build_stage0(a.profile, a.force, manifest)
        else:
            ok, why = build_rust(a.profile)
        print(f"[native] {t} ({a.profile}): {'OK' if ok else 'SKIPPED/FAILED'} — {why}", flush=True)
        if not ok:
            failed.append(t)
    _save_manifest(manifest)
    return 1 if (failed and a.strict) else 0


if __name__ == "__main__":
    raise SystemExit(main())
