#!/usr/bin/env python3
"""Build Groovebox's Rust accelerator without writing Cargo state into the source tree.

Important: BUILD_ISO is normally run through sudo.  A crate-local `target/` then
becomes root-owned and breaks the next ordinary desktop launch.  Every build is
therefore isolated in a temporary CARGO_TARGET_DIR and the finished library is
atomically installed into native/.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CRATE = ROOT / "rust" / "groovebox_accel"
NATIVE = ROOT / "native"
NATIVE.mkdir(exist_ok=True)


def target_name() -> str:
    s = platform.system().lower()
    if s == "windows":
        return "groovebox_rust_accel.dll"
    if s == "darwin":
        return "libgroovebox_rust_accel.dylib"
    return "libgroovebox_rust_accel.so"


def _cargo() -> str:
    found = shutil.which("cargo")
    if found:
        return found
    candidate = Path.home() / ".cargo" / "bin" / ("cargo.exe" if os.name == "nt" else "cargo")
    if candidate.exists():
        return str(candidate)
    rc = subprocess.call([sys.executable, str(ROOT / "scripts" / "ensure_rust_toolchain.py"), "--install"])
    if rc:
        raise SystemExit(rc)
    found = shutil.which("cargo")
    if found:
        return found
    if candidate.exists():
        return str(candidate)
    raise SystemExit("Rust/Cargo missing after dependency provisioning")


def _restore_tree_owner(path: Path) -> None:
    """Avoid sudo builds leaving the installed runtime library root-owned."""
    if os.name != "posix" or not hasattr(os, "chown") or os.geteuid() != 0:
        return
    uid_text = os.environ.get("SUDO_UID")
    gid_text = os.environ.get("SUDO_GID")
    try:
        if uid_text is not None and gid_text is not None:
            uid, gid = int(uid_text), int(gid_text)
        else:
            st = ROOT.stat()
            uid, gid = st.st_uid, st.st_gid
        os.chown(path, uid, gid)
    except (OSError, ValueError):
        # Ownership normalization is best-effort; atomic replacement already
        # prevents an old root-owned destination file from blocking the copy.
        pass


def main() -> int:
    cargo = _cargo()
    name = target_name()

    # Never use CRATE/target. It may have been created by an older sudo build.
    # A fresh isolated target also prevents Cargo lock collisions between an ISO
    # build and a concurrently launched desktop dependency check.
    with tempfile.TemporaryDirectory(prefix="groovebox-rust-build-") as td:
        target_dir = Path(td) / "target"
        env = os.environ.copy()
        env["CARGO_TARGET_DIR"] = str(target_dir)
        # Compile and execute the accelerator's deterministic parity tests first.
        # Cargo reuses the same isolated target for the final cdylib build, so this
        # catches ABI/math regressions without reintroducing source-tree locks.
        subprocess.run(
            [cargo, "test", "--release", "--locked", "--lib"],
            cwd=CRATE,
            env=env,
            check=True,
        )
        subprocess.run(
            [cargo, "build", "--release", "--locked"],
            cwd=CRATE,
            env=env,
            check=True,
        )
        built = target_dir / "release" / name
        if not built.is_file():
            raise SystemExit(f"Rust accelerator output missing: {built}")

        out = NATIVE / name
        tmp = NATIVE / f".{name}.tmp-{os.getpid()}"
        try:
            shutil.copyfile(built, tmp)
            if os.name != "nt":
                tmp.chmod(0o755)
            # Atomic replacement works even when an older output file itself is
            # root-owned, provided the source tree directory belongs to the user.
            os.replace(tmp, out)
        finally:
            try:
                if tmp.exists():
                    tmp.unlink()
            except OSError:
                pass

    _restore_tree_owner(out)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
