#!/usr/bin/env bash
# Relaunch Groovebox after any crash. A clean exit (0) stops the loop.
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
MAX=8
n=0
while [[ "$n" -lt "$MAX" ]]; do
  n=$((n + 1))
  echo "[relaunch] start $n"
  python3 "$ROOT/run_groovebox.py" "$@"
  code=$?
  if [[ "$code" -eq 0 ]]; then
    echo "[relaunch] clean exit"
    exit 0
  fi
  echo "[relaunch] exit $code — bringing windows back"
  sleep 1
  set -- --skip-startup-launcher --restore-windows
done
echo "[relaunch] stopped after $MAX crashes"
exit 1
