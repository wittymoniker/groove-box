#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if command -v python3 >/dev/null 2>&1; then python3 "$ROOT/scripts/ensure_rust_toolchain.py" --install || true; fi
exec "$ROOT/run_hybrid.sh" "$@"
