# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules
from PyInstaller.utils.hooks import collect_all

datas = [('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/native', 'native'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/rust', 'rust'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/julia', 'julia'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/assets', 'assets'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/sCode', 'sCode'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/scode', 'scode'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/scode_models', 'scode_models'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/scode_os', 'scode_os'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/modules', 'modules'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/scripts', 'scripts'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/docs', 'docs'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/groovebox_fractal', 'groovebox_fractal'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/iso_wm', 'iso_wm'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/docs/fractal-seed-mode', 'docs/fractal-seed-mode'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/README.md', '.'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/HELP_TEXT.md', '.')]
binaries = [('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/bin/ffmpeg', 'bin'), ('/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/bin/ffprobe', 'bin')]
hiddenimports = ['PASTE_ME_NEAR_MCC', 'appliance_tuning', 'appliance_wifi', 'audio_check', 'audio_export_integrity', 'audio_os_backend', 'author_number_codec', 'author_numeric_font', 'build', 'canonical_authority', 'canonical_cross_media', 'canonical_edit_list', 'canonical_engine_bridge', 'canonical_event_algebra', 'canonical_insertability', 'canonical_triad', 'clip_timeline_studio', 'coedit', 'compat_settings', 'composition_state', 'concurrent_audio_bus', 'decentralized_mesh', 'device_probe_helper', 'dj_effects', 'drive_targets', 'engine_auditor', 'export_dialog', 'export_window', 'export_worker', 'fast_widgets', 'file_tools', 'finite_infinity', 'format_converter', 'fractal_spatial_engine', 'goava_cross_modulation', 'graph_script_context', 'groovebox', 'groovebox_direct_link', 'groovebox_media_tools', 'groovebox_paths', 'groovebox_subprocess', 'groovebox_v3_runtime', 'hardware_formats', 'hardware_hub', 'hardware_runtime', 'hardware_volume', 'hotspot_plan', 'julia_bridge', 'launch_groovebox', 'layered_signal_lab', 'library_tuning', 'live_edit_ui', 'live_stream', 'math_grep', 'mathematical_composition_lab', 'mcc_filetype', 'mcc_integrity', 'mcc_media', 'media_cutup_engine', 'media_layer_engine', 'media_output_router', 'memory_guard', 'meum_compression', 'meum_constants', 'meum_ot_math', 'mg_artifacts', 'multi_output', 'nearby_groovebox', 'notes_editor', 'operation_station_transfer', 'ot_symbol_notation', 'parametric_file_remix', 'performance', 'performance_box', 'performance_modules', 'pi_media_hub', 'platform_runtime', 'program_identity', 'radio_station', 'relativity_projection', 'removable_media_inventory', 'render_queue', 'reverse_engineer', 'scode_cli', 'scode_optimizer_bridge', 'scode_selfbuild', 'scode_update', 'sequencer_schema', 'shared_synth_context', 'signal_lab', 'spatial_synth_engines', 'standalone_import_audit', 'teach_scode', 'thread_budget', 'trig_series', 'universal_field', 'user_synth_library', 'video_clip_studio', 'videogame_engine', 'visual_determinism', 'wavespace', 'web_browser_tab', 'groovebox_v3', 'groovebox_v3.fractal_seed_engine', 'nonmodal_dialogs', 'media_visualizer', 'master_hardware_panel', 'obj_scene', 'debug_panel', 'live_player', 'key_assign', 'ot_script_math', 'audio_device_profiles', 'multidim_synth', 'multidim_ui', 'multidim_scene', 'finite_infinity', 'math_grep', 'memory_manager', 'project_tabs']
hiddenimports += collect_submodules('PyQt6')
hiddenimports += collect_submodules('numpy')
hiddenimports += collect_submodules('scipy')
hiddenimports += collect_submodules('sounddevice')
hiddenimports += collect_submodules('PIL')
tmp_ret = collect_all('PyQt6')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('scipy')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('PIL')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('sounddevice')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/run_groovebox.py'],
    pathex=['/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=['/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/BUILD_KIT/pyi_rth_groovebox_portaudio.py'],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='MathematiciansGroovebox',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['/home/eski/Documents/MATHEMATICIANS_GROOVEBOX_V3/assets/logo.png'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='MathematiciansGroovebox',
)
