# Mathematician's Groovebox / sOS — R30 source archive

Date: 2026-11-08

## Included in this source refresh

- R30 hardware-aware thread and memory budgeting (`thread_budget.py`, `memory_guard.py`), with runtime CPU-affinity/cgroup/memory detection and no fixed 32 GB reservation or process-wide CPU pinning.
- Refreshed `BUILD_ISO/app-overlay-v35.22zz` from the canonical application sources and regenerated `BUILD_ISO/runtime-payload-manifest.json` (140 runtime modules verified byte-for-byte).
- Dell Latitude 3510 target hardware profile for the ordered 32 GB (2 × 16 GB) DDR4-2666 SO-DIMM memory; profile is descriptive and does not hard-code resource limits.
- Six-second hold behavior on Quit Groovebox to request the sOS power-off path.
- Multidimensional UI synchronization separated from its animation tick; project-load guard prevents Boost Beats from arming during project restoration; render-queue dispatch no longer uses nested `QApplication.processEvents()` pumping.
- Live Player / media updates include native MCC media playback with bounded background decode-ahead, fullscreen player support, and recording/export format selection.
- Clip Studio and Performance sources include drag/drop and media workflow support; the lower launcher area is organized as a single-column layout with a prominent Live Player launcher.
- Existing project, audio, hardware, and ISO release-contract sources are retained.

## Validation performed

- `scripts/check_iso_build.py`: passed. This verified 140 runtime modules synchronized byte-for-byte, Python syntax for 505 files, shell syntax for 118 files, the Dell hardware profile/staging contract, and the EFI/Limine synthetic boot-image checks plus 10 release source/boot contract commands.
- Focused source/regression suite: 32 passed (`test_threading_stability_patch_20261108.py`, `test_bottom_pane_single_column_20261108.py`, thread-budget, sCode concurrency-pool, memory-guard, workstation-hardening, and realtime-lag contract tests).
- The Qt-dependent Live Player runtime test could not be collected because PyQt6 is not installed in this build environment.

## Important release limitation

This is the refreshed **source/build-tree archive**, not a newly generated bootable ISO. The master ISO remaster script requires the runtime initramfs image and runtime kernel tree, which are not present in the supplied source bundle (`BUILD_ISO/dist/runtime-cache/initramfs.v33c-limine-scode.img` is absent). The synthetic EFI/Limine checks pass, but a final ISO build, target-machine boot, real audio-device validation, and interactive Qt freeze/stress testing have not been performed here. Do not treat those hardware/runtime checks as passed.
