from __future__ import annotations
import memory_guard


def test_memory_guard_applies_cgroup_ceiling(monkeypatch):
    mib = 1024 * 1024
    monkeypatch.setattr(memory_guard, "_read_cgroup_memory", lambda: (512 * mib, 2 * 1024 * mib))
    avail, total = memory_guard._read_meminfo()
    assert total <= 2 * 1024 * mib
    assert avail <= 512 * mib


def test_memory_reserve_scales_but_is_bounded():
    mib = 1024 * 1024
    assert memory_guard._system_reserve(4 * 1024 * mib) == 384 * mib
    assert memory_guard._system_reserve(32 * 1024 * mib) == 1536 * mib
    assert memory_guard._system_reserve(128 * 1024 * mib) == 1536 * mib


def test_snapshot_uses_scaled_reserve(monkeypatch):
    mib = 1024 * 1024
    monkeypatch.setattr(memory_guard, "_read_meminfo", lambda: (20 * 1024 * mib, 32 * 1024 * mib))
    snap = memory_guard.snapshot(force=True)
    assert snap["reserve"] == 1536 * mib
    assert snap["usable"] == 20 * 1024 * mib - 1536 * mib
