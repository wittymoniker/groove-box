param(
  [switch]$OneFile,
  [switch]$Console,
  [switch]$NoInstall,
  [switch]$NoNative,
  [switch]$Doctor
)
$ErrorActionPreference = 'Stop'
$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Kit
Set-Location $Root
$ArgsList = @()
if ($OneFile)   { $ArgsList += '--onefile' }
if ($Console)   { $ArgsList += '--console' }
if ($NoInstall) { $ArgsList += '--no-install' }
if ($NoNative)  { $ArgsList += '--no-native' }
if ($Doctor)    { $ArgsList += '--doctor' }
$Vpy = Join-Path $Root '.groovebox-build-venv\Scripts\python.exe'
if (Test-Path $Vpy) {
  & $Vpy "$Kit\build.py" @ArgsList
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
  & py -3 "$Kit\build.py" @ArgsList
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  & python "$Kit\build.py" @ArgsList
} else {
  throw 'Python 3 was not found. Run install_dependencies_windows.ps1 first.'
}
exit $LASTEXITCODE
