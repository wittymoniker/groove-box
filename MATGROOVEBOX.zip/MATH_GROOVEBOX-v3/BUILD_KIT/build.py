#!/usr/bin/env python3
"""Cross-platform executable builder for Mathematician's Groovebox.

This file intentionally lives in BUILD_KIT/ and resolves the application root
as its parent, so the kit can stay in a subfolder.
"""
from __future__ import annotations

import argparse
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent
ROOT = KIT.parent
ENTRY = ROOT / "run_groovebox.py"
VENV = ROOT / ".groovebox-build-venv"
BUILD = ROOT / "build_executable"
DIST = ROOT / "dist"
APPNAME = "MathematiciansGroovebox"

# BUILD_KIT lives one directory below the application modules.  Running this
# file directly makes BUILD_KIT/ sys.path[0], so doctor/build-time imports of
# Groovebox helpers need the project root explicitly on the import path.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from runtime_payload import runtime_sources, runtime_module_names


def run(cmd, *, cwd=ROOT, env=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run([str(x) for x in cmd], cwd=str(cwd), env=build_environment(env), check=True)


def build_environment(env=None):
    """Keep build caches local and discard inherited Python path overrides."""
    result = dict(os.environ if env is None else env)
    for name in ("PYTHONHOME", "PYTHONPATH", "PYTHONPYCACHEPREFIX"):
        result.pop(name, None)
    result["PYTHONNOUSERSITE"] = "1"
    result["PYTHONDONTWRITEBYTECODE"] = "1"
    result["PYINSTALLER_CONFIG_DIR"] = str(BUILD / "cache" / "pyinstaller")
    result["PIP_CACHE_DIR"] = str(BUILD / "cache" / "pip")
    return result


def venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def ensure_venv() -> Path:
    py = venv_python()
    if VENV.exists() and not py.is_file():
        raise SystemExit(
            f"Build environment is incomplete or belongs to another platform: {VENV}\n"
            "Use a fresh extraction or move that environment aside before recreating it."
        )
    if not py.exists():
        print(f"Creating build environment: {VENV}")
        run([sys.executable, "-m", "venv", str(VENV)])
    try:
        subprocess.run(
            [str(py), "-E", "-s", "-c",
             "import sys; assert sys.prefix != sys.base_prefix, 'not a virtual environment'"],
            cwd=str(ROOT), env=build_environment(), check=True, timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise SystemExit(
            f"Build Python is stale, moved, or unusable: {py}\n"
            "Recreate the project build environment from its platform installer.\n"
            f"{exc}"
        ) from exc
    return py


def verify_python_runtime(py: Path, check_pyinstaller: bool = False):
    # BUILD_KIT_BROWSER_RUNTIME_GATE_20261030: run this for normal installs and
    # --no-install builds alike; a stale venv must fail before PyInstaller starts.
    code = r"""
import importlib, os, pathlib, sounddevice
from PyQt6 import QtCore
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
from PyQt6.QtMultimedia import QMediaDevices, QMediaPlayer, QAudioOutput
from PyQt6.QtMultimediaWidgets import QVideoWidget
import numpy, scipy, cffi, PIL
print('Build Python:', __import__('sys').executable, __import__('sys').version)
if os.name == 'nt':
    root = pathlib.Path(sounddevice.__file__).resolve().parent
    names = {'libportaudio64bit.dll', 'libportaudio32bit.dll', 'libportaudioarm64.dll', 'libportaudio.dll', 'portaudio.dll'}
    found = [p for p in root.rglob('*.dll') if p.name.lower() in names]
    if not found:
        raise SystemExit('sounddevice wheel is missing its Windows PortAudio DLL')
    print('Windows PortAudio payload:', found[0])
print('Qt/WebEngine/Multimedia + NumPy/SciPy/audio runtime PASS', QtCore.QT_VERSION_STR)
"""
    run([py, "-c", code])
    if check_pyinstaller:
        run([py, "-m", "PyInstaller", "--version"])


def install_python_deps(py: Path):
    req = ROOT / "requirements.txt"
    run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    if req.exists():
        run([py, "-m", "pip", "install", "-r", req])
    verify_python_runtime(py)
    run([py, "-m", "pip", "install", "pyinstaller>=6.10,<7"])
    verify_python_runtime(py, check_pyinstaller=True)


def valid_local_modules():
    return runtime_module_names(ROOT, exclude={ENTRY.stem})




def enforce_runtime_import_policy():
    """Fail standalone builds if active runtime code reintroduces banned direct deps."""
    import ast
    violations = []
    for path in runtime_sources(ROOT):
        try:
            source = path.read_bytes()
            compile(source, str(path), "exec", dont_inherit=True)
            tree = ast.parse(source, filename=str(path))
        except (SyntaxError, UnicodeError, OSError, ValueError) as exc:
            raise SystemExit(f"Runtime source is invalid or unreadable: {path}\n{exc}") from exc
        for node in ast.walk(tree):
            mod = None
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [node.module or ""]
            else:
                continue
            for name in names:
                if (name == "sounddevice" or name.startswith("sounddevice.")) and path.name != "audio_os_backend.py":
                    violations.append(f"{path.name}:{getattr(node, 'lineno', '?')} direct sounddevice import; use audio_os_backend")
    if violations:
        raise SystemExit("Standalone import policy failed:\n  " + "\n  ".join(violations))

def compile_rust():
    """Build the optional Rust accelerator; Python/C++ paths remain available."""
    helper = ROOT / 'scripts' / 'build_rust_accel.py'
    ensure = ROOT / 'scripts' / 'ensure_rust_toolchain.py'
    if not helper.is_file():
        print("WARNING: Rust accelerator builder absent; continuing without Rust acceleration.")
        return
    try:
        if ensure.is_file():
            run([sys.executable, str(ensure), '--install'])
        run([sys.executable, str(helper)])
    except (subprocess.CalledProcessError, OSError) as exc:
        print(f"WARNING: optional Rust accelerator unavailable ({exc}); executable will use supported fallback paths.")

def compile_native():
    # GROOVEBOX_R23R_NATIVE_REBUILD_20261101: the shared local recompiler owns the
    # executable's link/include method (kit profile); the inline path below stays
    # as the fallback when the script is absent.
    shared = ROOT / "scripts" / "native_rebuild.py"
    if shared.is_file():
        try:
            run([sys.executable, str(shared), "--profile", "kit", "accel", "stage0"])
            return
        except (subprocess.CalledProcessError, OSError) as exc:
            print(f"WARNING: shared native_rebuild failed ({exc}); trying the inline compiler path.")
    system = platform.system().lower()
    native = ROOT / "native"
    native.mkdir(exist_ok=True)
    src = ROOT / "cpp" / "groovebox_accel.cpp"
    if not src.exists():
        return
    try:
        if system == "linux":
            compiler = shutil.which("g++") or shutil.which("c++")
            if not compiler:
                print("WARNING: no C++ compiler found; executable will use Python fallback.")
                return
            run([compiler, "-std=c++17", "-O3", "-ffp-contract=off", "-DNDEBUG", "-fPIC", "-fvisibility=hidden",
                 "-shared", str(src), "-o", str(native / "libgroovebox_accel.so")])
        elif system == "darwin":
            compiler = shutil.which("c++") or shutil.which("clang++")
            if not compiler:
                print("WARNING: no C++ compiler found; executable will use Python fallback.")
                return
            run([compiler, "-std=c++17", "-O3", "-ffp-contract=off", "-DNDEBUG", "-fPIC", "-fvisibility=hidden",
                 "-dynamiclib", str(src), "-o", str(native / "libgroovebox_accel.dylib")])
        elif system == "windows":
            cl = shutil.which("cl")
            if cl:
                run([cl, "/nologo", "/std:c++17", "/O2", "/DNDEBUG", "/LD", str(src),
                     f"/Fe:{native / 'groovebox_accel.dll'}"])
            else:
                # Do not emit a MinGW DLL with undeclared libstdc++ runtime
                # dependencies into a Windows bundle. MSVC is the supported
                # native Windows ABI; Python fallback is safer without it.
                print("WARNING: MSVC C++ compiler not found; executable will use Python fallback.")
    except subprocess.CalledProcessError:
        print("WARNING: native accelerator build failed; continuing with Python fallback.")



def patch_macos_bundle_filetype():
    """Declare .MCC as a document type in a PyInstaller macOS .app bundle."""
    if platform.system().lower() != "darwin":
        return
    import plistlib
    app = DIST / f"{APPNAME}.app"
    plist = app / "Contents" / "Info.plist"
    if not plist.exists():
        return
    with plist.open("rb") as f:
        info = plistlib.load(f)
    info["CFBundleDocumentTypes"] = [{
        "CFBundleTypeName": "Mathematician's Groovebox Composition",
        "CFBundleTypeRole": "Editor",
        "LSHandlerRank": "Owner",
        "LSItemContentTypes": ["com.mathematiciansgroovebox.mcc"],
        "CFBundleTypeExtensions": ["MCC", "mcc"],
    }]
    info["UTExportedTypeDeclarations"] = [{
        "UTTypeIdentifier": "com.mathematiciansgroovebox.mcc",
        "UTTypeDescription": "Mathematician's Groovebox Composition",
        "UTTypeConformsTo": ["public.data", "public.json"],
        "UTTypeTagSpecification": {
            "public.filename-extension": ["MCC", "mcc"],
            "public.mime-type": "application/x-mathematicians-groovebox-mcc",
        },
    }]
    with plist.open("wb") as f:
        plistlib.dump(info, f)
    print(f"Registered .MCC document declaration in {plist}")

def add_arg(cmd, kind: str, source: Path, dest: str):
    # PyInstaller's add-data/add-binary syntax is platform dependent.
    sep = ";" if os.name == "nt" else ":"
    cmd.extend([kind, f"{source}{sep}{dest}"])


def ensure_local_ffmpeg():
    """Build input is invalid until the exact local codec pair exists."""
    sys.path.insert(0, str(ROOT))
    try:
        from groovebox_media_tools import require_local_pair
        return require_local_pair()
    except Exception:
        provision = ROOT / "scripts" / "provision_first_launch.py"
        run([sys.executable, str(provision)])
        from groovebox_media_tools import require_local_pair
        return require_local_pair()


def host_scode_relative_path() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if machine in ("amd64", "x64"):
        machine = "x86_64"
    elif machine in ("aarch64", "arm64"):
        machine = "arm64"
    if system == "windows":
        return f"sCode/bootstrap/windows-{machine}/scode0.exe"
    if system == "darwin":
        return f"sCode/bootstrap/macos-{machine}/scode0"
    if system == "linux":
        return f"sCode/bootstrap/linux-{machine}/scode0"
    raise SystemExit(f"Unsupported executable build host: {platform.platform()}")


def verify_scode_stage0():
    """Execute the exact host-native ABI-9 runtime that will ship in the bundle."""
    from platform_runtime import find_scode_stage0
    scode = find_scode_stage0(ROOT)
    optimizer = ROOT / "sCode" / "apps" / "groovebox" / "groovebox_optimizer.sC"
    if not scode or not optimizer.is_file():
        raise SystemExit("FAIL: host-native sCode stage-0 or Groovebox optimizer source is missing")
    env = build_environment()
    env.update({"GB_OPT_ID": "1", "GB_OPT_DIRTY": "255", "GB_OPT_FRAME": "0",
                "GB_OPT_LANES": "4", "GB_OPT_POOL": "64", "GB_OPT_SHAPE": "1"})
    probe = subprocess.run([str(scode), "run", str(optimizer.relative_to(ROOT / "sCode"))],
                           cwd=str(ROOT / "sCode"), env=env,
                           capture_output=True, text=True, timeout=30)
    if probe.returncode != 0 or "scode_optimizer_abi=9" not in probe.stdout:
        raise SystemExit("FAIL: host-native sCode stage-0 ABI-9 preflight failed:\n" + probe.stdout + probe.stderr)
    print("PASS: host-native sCode stage-0 ABI 9:", scode)


def build(onefile=False, console=False, clean=True, install=True, native=True):
    if not ENTRY.exists():
        raise SystemExit(f"Cannot find {ENTRY}")
    codecs = ensure_local_ffmpeg()
    py = ensure_venv()
    if install:
        install_python_deps(py)
    else:
        verify_python_runtime(py, check_pyinstaller=True)
    enforce_runtime_import_policy()
    if native:
        compile_rust()
        compile_native()
    # Required stage-0 repair precedes its strict gate. This is independent of
    # optional Rust/C++ accelerators and does not select another platform's file.
    stage0_helper = ROOT / "scripts" / "ensure_native_scode_stage0.py"
    if stage0_helper.is_file():
        run([py, str(stage0_helper)])
    verify_scode_stage0()

    # Remove only this app's previous target. PyInstaller --clean clears its
    # cache but does not guarantee old onedir files are removed from dist/.
    target = DIST / (f"{APPNAME}.exe" if onefile and os.name == "nt" else APPNAME)
    if target.is_dir():
        shutil.rmtree(target)
    elif target.exists():
        target.unlink()

    cmd = [py, "-m", "PyInstaller", str(ENTRY),
           "--name", APPNAME,
           "--noconfirm",
           "--distpath", str(DIST),
           "--workpath", str(BUILD / "work"),
           "--specpath", str(BUILD / "spec"),
           "--paths", str(ROOT)]
    portaudio_hook = KIT / "pyi_rth_groovebox_portaudio.py"
    if portaudio_hook.is_file():
        cmd.extend(["--runtime-hook", str(portaudio_hook)])
    if clean:
        cmd.append("--clean")
    cmd.append("--onefile" if onefile else "--onedir")
    cmd.append("--console" if console else "--windowed")
    # GROOVEBOX_R23R_NOUPX_20261103: never let a UPX found on the build host repack the
    # bundled binaries (a known source of corrupted runtime payloads).
    cmd.append("--noupx")

    # Local modules include dynamically loaded/optional Groovebox components.
    for mod in valid_local_modules():
        cmd.extend(["--hidden-import", mod])

    # Fractal Seed is loaded dynamically by the canonical sequence writer.
    # Explicit hidden imports preserve the package in PyInstaller builds.
    cmd.extend(["--hidden-import", "groovebox_v3", "--hidden-import", "groovebox_v3.fractal_seed_engine"])

    # These packages have platform/native hooks, but explicit collection makes
    # the build resilient to optional submodule imports inside Groovebox.
    for pkg in ("PyQt6", "numpy", "scipy", "sounddevice", "PIL"):
        cmd.extend(["--collect-submodules", pkg])
    # Collect the complete PyQt6 distribution: QtMultimedia's extension modules,
    # QtWebEngine resources, platform plugins, and media backend plugins are
    # dynamically loaded and cannot be trusted to static import analysis alone.
    cmd.extend(["--collect-all", "PyQt6"])
    # SciPy and Pillow load native extensions/plugins dynamically on some hosts;
    # collect their binary/data payloads as well as importable submodules.
    cmd.extend(["--collect-all", "scipy"])
    cmd.extend(["--collect-all", "PIL"])
    # sounddevice ships platform-specific PortAudio binaries as package data;
    # submodule-only collection silently omits these DLLs on Windows.
    cmd.extend(["--collect-all", "sounddevice"])

    # Runtime resources that are intentionally external to Python imports.
    # Keep the known-good build.py path, but include every current data tree the
    # shipping application resolves by filesystem path.
    for dirname in ("native", "rust", "julia", "assets", "sCode", "scode", "scode_models", "scode_os", "modules", "scripts", "docs", "groovebox_fractal", "iso_wm"):
        p = ROOT / dirname
        if p.exists():
            add_arg(cmd, "--add-data", p, dirname)
    explorer_docs = ROOT / "docs" / "fractal-seed-mode"
    if (explorer_docs / "musical_explorer.html").is_file():
        add_arg(cmd, "--add-data", explorer_docs, "docs/fractal-seed-mode")

    for filename in ("README.md", "HELP_TEXT.md", "PERFORMANCE_BOX.md", "CURRENT_FEATURES_AND_MATH.md", "DEPENDENCIES.md"):
        p = ROOT / filename
        if p.exists():
            add_arg(cmd, "--add-data", p, ".")

    # Use the project's actual Groovebox logo for executable/bundle metadata.
    icon = ROOT / "assets" / "logo.png"
    if icon.exists():
        cmd.extend(["--icon", str(icon)])

    # FFmpeg/ffprobe are mandatory build inputs and are bundled from local bin only.
    for codec in codecs:
        # Bundle the exact host-format binaries validated above, not a suffix
        # guess which could pick an old Linux binary for a Windows build.
        add_arg(cmd, "--add-binary", Path(codec), "bin")

    run(cmd)
    patch_macos_bundle_filetype()
    bundle = DIST / APPNAME if not onefile else DIST
    expected = [
        "README.md", "HELP_TEXT.md",
        "scripts/provision_first_launch.py",
        "docs/fractal-seed-mode/musical_explorer.html",
        "groovebox_fractal/groovebox_fractal/video_assembly.py",
        "sCode/apps/groovebox/groovebox_optimizer.sC",
        host_scode_relative_path(),
    ]
    windows_payload = [
        "Qt6Core.dll", "Qt6Gui.dll", "Qt6Widgets.dll",
        "Qt6Multimedia.dll", "Qt6MultimediaWidgets.dll", "Qt6WebEngineCore.dll",
        "QtWebEngineProcess.exe", "qwindows.dll", "ffmpegmediaplugin.dll",
        "icudtl.dat", "qtwebengine_resources.pak", "ffmpeg.exe", "ffprobe.exe",
    ]
    portaudio_names = ("libportaudio64bit.dll", "libportaudio32bit.dll", "libportaudioarm64.dll", "libportaudio.dll", "portaudio.dll")
    search_bases = [bundle, bundle / APPNAME, bundle / "_internal"]
    if platform.system().lower() == "darwin":
        app_bundle = DIST / f"{APPNAME}.app"
        search_bases.extend([
            app_bundle / "Contents" / "Frameworks",
            app_bundle / "Contents" / "Resources",
        ])
    exe = DIST / (f"{APPNAME}.exe" if onefile and os.name == "nt" else APPNAME)

    def inspect_onefile_archive(archive_path: Path):
        # build.py itself may be launched by system Python while PyInstaller is
        # installed only in the dedicated build venv. Ask that interpreter to
        # inspect the CArchive, rather than importing PyInstaller here.
        code = (
            "import sys; from PyInstaller.archive.readers import CArchiveReader; "
            "a=CArchiveReader(sys.argv[1]); print(*a.toc.keys(), sep=chr(10))"
        )
        cp = subprocess.run([str(py), "-c", code, str(archive_path)],
                            cwd=str(ROOT), env=build_environment(), timeout=120,
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if cp.returncode:
            raise SystemExit("FAIL: PyInstaller one-file archive cannot be inspected:\n" + cp.stdout)
        return {line.replace('\\', '/').lower() for line in cp.stdout.splitlines() if line.strip()}

    if onefile:
        if not exe.is_file() or exe.stat().st_size < 1024 * 1024:
            raise SystemExit(f"FAIL: one-file executable missing or implausibly small: {exe}")
        archive_names = inspect_onefile_archive(exe)
        missing = [rel for rel in expected if not any(n.endswith(rel.lower()) for n in archive_names)]
        if missing:
            raise SystemExit("FAIL: one-file archive is missing required runtime resources:\n  " + "\n  ".join(missing))
        if os.name == "nt":
            missing_windows = [name for name in windows_payload if not any(n.endswith(name.lower()) for n in archive_names)]
            if missing_windows:
                raise SystemExit("FAIL: Windows one-file archive is missing Qt/codec payload:\n  " + "\n  ".join(missing_windows))
            if not any(any(n.endswith(pa) for pa in portaudio_names) for n in archive_names):
                raise SystemExit("FAIL: Windows bundle is missing sounddevice's PortAudio DLL (expected libportaudio64bit.dll/libportaudio32bit.dll/libportaudioarm64.dll)")
        print("PASS: one-file archive contents and required runtime payload verified")
    else:
        exe = DIST / APPNAME / (f"{APPNAME}.exe" if os.name == "nt" else APPNAME)
        if not exe.is_file() or exe.stat().st_size == 0:
            raise SystemExit(f"FAIL: onedir executable missing or empty: {exe}")
        missing = [rel for rel in expected if not any((base / rel).exists() for base in search_bases)]
        if missing:
            raise SystemExit("FAIL: required bundled runtime resources missing:\n  " + "\n  ".join(missing))
        if os.name == "nt":
            files = [p for base in search_bases if base.exists() for p in base.rglob('*') if p.is_file()]
            lower_names = {p.name.lower() for p in files}
            missing_windows = [name for name in windows_payload if name.lower() not in lower_names]
            if missing_windows:
                raise SystemExit("FAIL: Windows onedir bundle is missing Qt/codec payload:\n  " + "\n  ".join(missing_windows))
            portaudio = [p for p in files if p.name.lower() in portaudio_names]
            if not portaudio:
                raise SystemExit("FAIL: Windows bundle is missing sounddevice's PortAudio DLL (expected libportaudio64bit.dll/libportaudio32bit.dll/libportaudioarm64.dll)")
            print("PASS: bundled PortAudio DLL:", portaudio[0])
        print("PASS: executable and all required bundled runtime resources verified")
    print("\nBUILD COMPLETE")
    print(f"Output: {exe if onefile else DIST / APPNAME}")
    if platform.system().lower() == "linux":
        print(f"Run:    {DIST / APPNAME / APPNAME if not onefile else DIST / APPNAME}")


def doctor():
    print("Mathematician's Groovebox build doctor")
    print("ROOT:", ROOT)
    print("Python:", sys.executable, sys.version.replace("\n", " "))
    print("OS:", platform.platform())
    print("Entry:", ENTRY, "OK" if ENTRY.exists() else "MISSING")
    if not ENTRY.is_file():
        raise SystemExit("Required application entry point is missing")
    py = venv_python()
    if not py.is_file():
        raise SystemExit(f"Build environment is missing: {py}. Run the platform dependency installer.")
    print("Selected build Python:", py)
    enforce_runtime_import_policy()
    try:
        verify_python_runtime(py, check_pyinstaller=True)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SystemExit(f"Required executable-build imports unavailable in {py}:\n{exc}") from exc
    from groovebox_media_tools import resolve_local_tool, validate_local_tool, require_local_pair
    codec_failures = []
    for tool in ("ffmpeg", "ffprobe"):
        valid = validate_local_tool(tool)
        print(f"local {tool:10s}", resolve_local_tool(tool, False) or "not found", "OK" if valid else "INVALID")
        if not valid:
            codec_failures.append(tool)
    if codec_failures:
        raise SystemExit("Required project-local codecs unavailable: " + ", ".join(codec_failures) + ". Run scripts/provision_first_launch.py.")
    require_local_pair()
    for tool in ("cargo", "rustc", "rustup", "g++", "c++", "clang++", "cl"):
        print(f"{tool:10s}", shutil.which(tool) or "not found")
    for lib in ("native/libgroovebox_rust_accel.so", "native/libgroovebox_rust_accel.dylib", "native/groovebox_rust_accel.dll", "native/libgroovebox_accel.so", "native/libgroovebox_accel.dylib", "native/groovebox_accel.dll"):
        p = ROOT / lib
        if p.exists():
            print("native:", p)
    print("sCode runtime:", ROOT / host_scode_relative_path())
    verify_scode_stage0()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--onefile", action="store_true", help="single executable; slower startup, less debuggable")
    ap.add_argument("--console", action="store_true", help="keep console visible for diagnostics")
    ap.add_argument("--no-install", action="store_true", help="do not pip-install/refresh build dependencies")
    ap.add_argument("--no-native", action="store_true", help="skip C++ accelerator compilation")
    ap.add_argument("--no-clean", action="store_true")
    ap.add_argument("--doctor", action="store_true")
    args = ap.parse_args()
    if args.doctor:
        doctor()
        return 0
    # Do not silently fall back to a previous user's/global caches. Existing
    # root-owned build folders produce an actionable error, not chmod/chown.
    import tempfile
    try:
        for directory in (BUILD, DIST, BUILD / "cache" / "pip", BUILD / "cache" / "pyinstaller"):
            directory.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryFile(dir=directory):
                pass
    except OSError as exc:
        raise SystemExit(
            f"Build/output directory is not writable: {exc}\n"
            "Extract into a user-owned folder and run BUILD_KIT without sudo."
        ) from exc
    build(args.onefile, args.console, not args.no_clean, not args.no_install, not args.no_native)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
