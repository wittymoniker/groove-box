#!/usr/bin/env python3
"""Static runtime/UI-path audit for Groovebox (R30.3+).

This is a source audit, not a substitute for launching the Qt application on
physical hardware. It checks interpreter contract wiring, Qt binding uniformity,
central UI publication, and reports legacy blocking/pool hotspots.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE = ("BUILD_ISO/", "V3_REFERENCE/", "release-tests-", "__pycache__/")
CORE_UI = ("groovebox.py", "performance.py", "multidim_ui.py", "live_player.py",
           "video_clip_studio.py", "clip_timeline_studio.py", "export_window.py",
           "screen_recorder.py", "screen_recording.py")


def active_python_files():
    for path in ROOT.rglob("*.py"):
        rel = path.relative_to(ROOT).as_posix()
        if any(rel.startswith(x) for x in EXCLUDE) or path.name.startswith("test_"):
            continue
        yield path


def _source(path):
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8", errors="replace")


def _call_audit(source):
    """Collect likely blocking-call sites without counting string/os.path.join."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return {"future_result_calls": 0, "thread_join_candidates": 0,
                "process_events_calls": 0, "local_qthread_pools": 0,
                "local_threadpool_executors": 0, "single_shot_calls": 0,
                "blocking_sites": []}
    counts = Counter()
    sites = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func
        if isinstance(fn, ast.Attribute):
            if fn.attr == "result":
                counts["future_result_calls"] += 1
                sites.append(f"Future.result? line {node.lineno}")
            elif fn.attr == "join":
                receiver = fn.value
                if isinstance(receiver, ast.Constant) and isinstance(receiver.value, str):
                    continue
                if isinstance(receiver, ast.Attribute) and receiver.attr in ("path", "posixpath", "ntpath"):
                    continue
                counts["thread_join_candidates"] += 1
                sites.append(f"join? line {node.lineno} ({ast.unparse(receiver)})")
            elif fn.attr == "processEvents":
                counts["process_events_calls"] += 1
                sites.append(f"QApplication.processEvents? line {node.lineno}")
            elif fn.attr == "singleShot":
                counts["single_shot_calls"] += 1
        elif isinstance(fn, ast.Name):
            if fn.id == "QThreadPool":
                counts["local_qthread_pools"] += 1
            elif fn.id == "ThreadPoolExecutor":
                counts["local_threadpool_executors"] += 1
    keys = ("future_result_calls", "thread_join_candidates", "process_events_calls",
            "local_qthread_pools", "local_threadpool_executors", "single_shot_calls")
    return {key: counts.get(key, 0) for key in keys} | {"blocking_sites": sites[:40]}


def audit():
    files = list(active_python_files())
    binding_counts = Counter()
    syntax_errors = []
    pyqt_lines = 0
    for path in files:
        rel = path.relative_to(ROOT).as_posix()
        source = _source(path)
        try:
            ast.parse(source, filename=rel)
        except SyntaxError as exc:
            syntax_errors.append(f"{rel}:{exc.lineno}: {exc.msg}")
        for line in source.splitlines():
            if re.search(r"\b(?:PyQt6|PyQt5|PySide6|PySide2)\b", line):
                pyqt_lines += 1
                match = re.search(r"\b(PyQt6|PyQt5|PySide6|PySide2)\b", line)
                if match:
                    binding_counts[match.group(1)] += 1

    issues = []
    checks = []
    runtime_source = _source(ROOT / "runtime_contract.py")
    checks.append(("Python minimum", "CPython >= 3.10" in _source(ROOT / "requirements.txt") and "MIN_PYTHON = (3, 10)" in runtime_source and "def interpreter_is_supported" in runtime_source))
    checks.append(("Qt binding is PyQt6-only", not any(binding_counts[k] for k in ("PyQt5", "PySide6", "PySide2"))))
    checks.append(("main launcher installs dispatcher", "_install_ui_runtime(app)" in _source(ROOT / "run_groovebox.py")))
    direct = _source(ROOT / "groovebox.py")
    checks.append(("direct launcher installs dispatcher", "install_ui_runtime(app)" in direct))
    checks.append(("direct launcher enforces CPython contract", "interpreter_error()" in direct))
    checks.append(("Live Player uses shared UI tasks", "submit_ui_task(" in _source(ROOT / "live_player.py")))
    checks.append(("Clip Timeline uses shared UI tasks", "submit_ui_task(" in _source(ROOT / "clip_timeline_studio.py")))
    checks.append(("main composition lanes use sCode shared lanes", "R30.3_SHARED_SCODE_SCHEDULER" in _source(ROOT / "groovebox.py")))
    checks.append(("Performance worker pools use shared sCode lanes", "performance-probes" in _source(ROOT / "performance.py") and "performance-file-manager" in _source(ROOT / "performance.py")))
    checks.append(("core windows avoid private QThreadPool instances", not any(re.search(r"=\s*QThreadPool\s*\(", _source(ROOT / name)) for name in ("groovebox.py", "performance.py", "video_clip_studio.py", "clip_timeline_studio.py"))))

    if syntax_errors:
        issues.extend("SYNTAX " + x for x in syntax_errors)
    for label, passed in checks:
        if not passed:
            issues.append("CONTRACT " + label)

    hotspots = {}
    for name in CORE_UI:
        path = ROOT / name
        if not path.exists():
            continue
        src = _source(path)
        hotspots[name] = _call_audit(src)

    return {
        "files_scanned": len(files),
        "qt_binding_lines": pyqt_lines,
        "qt_binding_counts": dict(binding_counts),
        "checks": checks,
        "issues": issues,
        "hotspots": hotspots,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true", help="exit nonzero when a required contract fails")
    parser.add_argument("--json", action="store_true", help="print machine-readable JSON")
    args = parser.parse_args()
    report = audit()
    if args.json:
        import json
        print(json.dumps(report, indent=2))
    else:
        print("Groovebox UI/runtime path audit")
        print(f"Python files scanned: {report['files_scanned']}")
        print(f"Qt binding source lines: {report['qt_binding_lines']} {report['qt_binding_counts']}")
        for label, passed in report["checks"]:
            print(f"{'PASS' if passed else 'FAIL'}  {label}")
        print("\nUI-path hotspot counts (candidate waits require call-context review):")
        for name, counts in report["hotspots"].items():
            summary = {k: v for k, v in counts.items() if k != "blocking_sites"}
            print(f"  {name}: " + ", ".join(f"{k}={v}" for k, v in summary.items()))
            for site in counts.get("blocking_sites", [])[:12]:
                print(f"      {site}")
        for issue in report["issues"]:
            print("ISSUE " + issue)
        print("\nR31: audio, video, stem and Bake & Compare exports run in ExportScheduler worker processes; "
              "remaining _run_off_gui waits execute only inside those workers or worker threads, never on the GUI thread.")
    return 1 if args.strict and report["issues"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
