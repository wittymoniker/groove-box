#!/usr/bin/env python3
"""Generate static cooperative variants without changing canonical math order."""
import ast
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
WANTED = {
    "_ensure_perfect_unison", "_establish_clean_baseline",
    "_apply_engine_for_composition", "_apply_engine_with_shared_context",
    "_apply_active_engines_meum_composite", "_apply_goava_deterministically",
    "_apply_phase_lock_deterministically", "_apply_randomizer_deterministically",
    "_apply_fractal_seed_deterministically", "_apply_euclidean_deterministically",
    "_apply_seeded_deterministically", "_final_unison_reconciliation",
    "_rebuild_active_canonical_playlist", "_evaluate_canonical_candidate",
    "apply_seeded_harmonic_randomization", "apply_euclidean_and_idealized_rhythms",
    "apply_phase_lock_preset", "_apply_live_engine_once", "_canonical_playlist_paint",
    "_paint_operator_pattern_to_playlist", "_goava_write_patterns",
    "_compose_active_canonical", "_canonical_macro_merge",
    "_canonical_sequence_reconcile", "_finish_canonical_sequence_projection",
    "_engine_resize_untouched_sequences", "_engine_write_sequence_panels",
}


class Cooperative(ast.NodeTransformer):
    def __init__(self, names):
        self.names = names

    def visit_FunctionDef(self, node):
        return node  # Local helpers/callbacks keep their synchronous contract.

    visit_AsyncFunctionDef = visit_FunctionDef
    visit_Lambda = visit_FunctionDef
    visit_ListComp = visit_FunctionDef
    visit_SetComp = visit_FunctionDef
    visit_DictComp = visit_FunctionDef
    visit_GeneratorExp = visit_FunctionDef

    def visit_Call(self, node):
        node = self.generic_visit(node)
        f = node.func
        if (isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name)
                and f.value.id == "self" and f.attr in self.names):
            f.attr = "_cooperative_" + f.attr
            return ast.YieldFrom(node)
        return node

    def visit_For(self, node):
        node = self.generic_visit(node)
        node.body.insert(0, ast.Expr(ast.Yield(ast.Constant(None))))
        return node

    visit_While = visit_For

    def visit_Try(self, node):
        # Generator.close() must never encounter a yield in cleanup.
        cleanup = node.finalbody
        node.finalbody = []
        node = self.generic_visit(node)
        node.finalbody = cleanup
        return node


def main():
    tree = ast.parse((ROOT / "groovebox.py").read_text(encoding="utf-8"))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef)
               and n.name == "MathematiciansGrooveboxApp")
    methods = {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}
    names = WANTED & methods.keys()
    assert {"_ensure_perfect_unison", "_canonical_sequence_reconcile",
            "apply_seeded_harmonic_randomization"} <= names
    result = []
    for name in sorted(names):
        node = methods[name]
        node.name = "_cooperative_" + name
        node.decorator_list = []
        transform = Cooperative(names)
        node.body = [transform.visit(statement) for statement in node.body]
        pos = int(bool(node.body and isinstance(node.body[0], ast.Expr)
                       and isinstance(node.body[0].value, ast.Constant)
                       and isinstance(node.body[0].value.value, str)))
        node.body.insert(pos, ast.Expr(ast.Yield(ast.Constant(None))))
        result.append(node)
    module = ast.fix_missing_locations(ast.Module(body=result, type_ignores=[]))
    text = '"""Generated static cooperative canonical kernels; regenerate with scripts/build_cooperative_kernels.py."""\n\n'
    text += ast.unparse(module) + "\n"
    compile(text, "canonical_cooperative_kernels.py", "exec")
    (ROOT / "canonical_cooperative_kernels.py").write_text(text, encoding="utf-8")
    print(f"Generated {len(result)} static cooperative kernels")


if __name__ == "__main__":
    main()
