#!/usr/bin/env python3
"""Read-only source/build preflight. Does not download, flash or install an ISO."""
import argparse
import ast
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BI = ROOT / "BUILD_ISO"


def command(args, *, timeout=90):
    result = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
    if result.returncode:
        print(result.stdout, end="")
        raise RuntimeError(f"exit {result.returncode}: {' '.join(map(str, args))}")
    return result.stdout


def check_sources():
    if not BI.is_dir():
        raise RuntimeError("BUILD_ISO is missing; extract the complete archive first")
    print(command([sys.executable, str(ROOT / "scripts" / "sync_runtime_payload.py"), "--check"]),
          end="")
    for name in ("groovebox.py", "run_groovebox.py", "requirements.txt",
                 "BUILD_ISO/runtime_setup_v35_22q.sh",
                 "BUILD_ISO/bootstrap_clean_tree_v33c.sh",
                 "BUILD_ISO/limine-v12.9.0/BOOTX64.EFI",
                 "BUILD_ISO/limine-v12.9.0/limine",
                 "BUILD_ISO/limine-v12.9.0/limine-uefi-cd.bin"):
        if not (ROOT / name).is_file() or not (ROOT / name).stat().st_size:
            raise RuntimeError(f"required build input missing or empty: {name}")
    python_files = (list(ROOT.glob("*.py")) + list((ROOT / "scripts").rglob("*.py"))
                    + list(BI.glob("*.py")))
    for path in python_files:
        ast.parse(path.read_bytes(), filename=str(path))
    shell_files = list(BI.glob("*.sh")) + list(ROOT.glob("*.sh"))
    for path in shell_files:
        command(["bash", "-n", str(path)])
    print(f"PASS: Python syntax ({len(python_files)} files), shell syntax ({len(shell_files)} files)")
    profile_verifier = BI / "verify_hardware_profile_20261108.py"
    if not profile_verifier.is_file():
        raise RuntimeError("Dell Latitude 3510 hardware-profile verifier is missing")
    print(command([sys.executable, str(profile_verifier)]), end="")

    # Discover the standalone source verifiers from the actual release entry
    # points rather than maintaining a second, drifting release-stage list.
    pattern = re.compile(
        r'^python3 "\$(HERE|BI)/((?:verify_|test_|run_efi_boot_contract_)[^"]+\.py)"'
        r'(?: "\$(ROOT|HERE|BI)")?\s*$', re.MULTILINE)
    seen = set()
    count = 0
    for runner in ("RUN_ME_ZERO_STATE.sh", "RUN_ME_v35_22.sh"):
        for _, filename, argument in pattern.findall((BI / runner).read_text()):
            args = [sys.executable, str(BI / filename)]
            if argument:
                args.append(str(ROOT if argument == "ROOT" else BI))
            key = tuple(args)
            if key in seen:
                continue
            seen.add(key)
            output = command(args, timeout=120)
            print(f"PASS: {filename}")
            if filename.startswith("run_efi_boot_contract_"):
                print(output, end="")
            count += 1
    print(f"PASS: {count} release source/boot contract commands")
    print("Source preflight complete. No release ISO has been built or hardware-tested.")


def check_host():
    import platform
    if platform.system() != "Linux" or platform.machine().lower() not in ("x86_64", "amd64"):
        raise RuntimeError("full appliance build requires an x86_64 Linux host")
    required = ("bash", "python3", "cc", "curl", "cpio", "ar", "gzip", "tar",
                "find", "sha256sum", "cargo", "rustc")
    missing = [name for name in required if not shutil.which(name)]
    if missing:
        raise RuntimeError("missing host tools: " + ", ".join(missing)
                           + "; run BUILD_ISO/ensure_host_build_deps_v35_22zt.sh")
    command([sys.executable, str(BI / "select_container_engine.py")])
    free = shutil.disk_usage(ROOT).free // (1024 * 1024)
    if free < 8192:
        raise RuntimeError(f"at least 8192 MiB scratch space required; only {free} MiB available")
    print(f"PASS: x86_64 Linux host, tools, root container access and scratch space ({free} MiB free)")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", action="store_true", help="also check host tools and container privileges")
    parser.add_argument("--host-only", action="store_true", help="only check host prerequisites")
    args = parser.parse_args()
    try:
        if not args.host_only:
            check_sources()
        if args.host or args.host_only:
            check_host()
    except (RuntimeError, OSError, SyntaxError, subprocess.TimeoutExpired) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
