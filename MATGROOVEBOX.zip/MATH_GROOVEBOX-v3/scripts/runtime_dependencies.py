#!/usr/bin/env python3
"""Required desktop runtime dependencies. QtWebEngine is optional/lazy-loaded.

QtWebEngine can hang while Chromium initializes on some Fedora/Qt setups; it
must not prevent the main audio/video application from launching. The browser
tab already handles an unavailable WebEngine backend gracefully.
"""
from __future__ import annotations

from runtime_contract import MIN_PYTHON, interpreter_is_supported, REQUIRED, OPTIONAL  # canonical active-overlay contract


# WebEngine remains optional: its Chromium startup is deliberately not a launch gate.
OPTIONAL_IMPORT_MODULES = tuple(mod for mod, _pkg in OPTIONAL)
OPTIONAL_PIP_PACKAGES = tuple(pkg for _mod, pkg in OPTIONAL)
# Force-install also provisions optional WebEngine so installers/builders can
# run their explicit browser smoke test. Fedora filters all Qt wheels and uses
# the matching RPM bindings instead.
PIP_PACKAGES = tuple(dict.fromkeys(pkg for _mod, pkg in (*REQUIRED, *OPTIONAL)))
IMPORT_MODULES = tuple(mod for mod, _pkg in REQUIRED)
