#!/usr/bin/env python3
"""Synchronize/verify active ISO modules against the BUILD_KIT inventory."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from runtime_payload import runtime_sources


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="verify only; do not copy")
    parser.add_argument("--manifest", type=Path, help="also write SHA-256 module hashes")
    args = parser.parse_args()
    active = ROOT / "BUILD_ISO" / "app-overlay-v35.22zz"
    mismatches, hashes = [], {}
    changed = 0
    for source in runtime_sources(ROOT):
        content = source.read_bytes()
        hashes[source.name] = hashlib.sha256(content).hexdigest()
        target = active / source.name
        if not target.is_file() or target.read_bytes() != content:
            if args.check:
                mismatches.append(source.name)
            else:
                shutil.copy2(source, target)
                changed += 1
    if mismatches:
        print("FAIL: active ISO differs from BUILD_KIT sources: " + ", ".join(mismatches),
              file=sys.stderr)
        return 1
    if args.manifest:
        args.manifest.parent.mkdir(parents=True, exist_ok=True)
        profile_dir = ROOT / "BUILD_ISO" / "hardware-profiles"
        profile_hashes = {
            str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(profile_dir.glob("*.json")) if path.is_file()
        } if profile_dir.is_dir() else {}
        args.manifest.write_text(json.dumps(
            {"schema": 1, "active_overlay": active.name, "sha256": hashes,
             "hardware_profiles_sha256": profile_hashes}, indent=2) + "\n",
            encoding="utf-8")
    print(f"PASS: ISO/BUILD_KIT share {len(hashes)} runtime module sources"
          + (f" ({changed} refreshed)" if not args.check else " (byte-for-byte)"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
