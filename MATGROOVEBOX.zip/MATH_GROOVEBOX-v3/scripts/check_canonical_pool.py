#!/usr/bin/env python3
"""Short GUI wiring probe for latest-seed publication; no audio or install test."""
import os
from pathlib import Path
import sys
import time
import cProfile
import pstats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("GROOVEBOX_PREDICTIVE_BUFFER", "0")


def main():
    from PyQt6.QtCore import Qt, QTimer
    from PyQt6.QtWidgets import QApplication
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app = QApplication([])
    from groovebox import MathematiciansGrooveboxApp
    window = MathematiciansGrooveboxApp()
    window.resize(1366, 768)
    window.show()
    start = time.monotonic()
    ticks = []
    profile = cProfile.Profile()
    beat = QTimer(window)
    beat.setInterval(20)
    beat.timeout.connect(lambda: ticks.append(time.monotonic()))
    beat.start()

    def trigger():
        if "--profile" in sys.argv:
            profile.enable()
        window.btn_seeded_randomize.setChecked(True)
        window.btn_local_phase_lock.setChecked(True)
        window.input_seed_val.setPlainText("0.048")
        window.input_seed_val.setPlainText("0.19758")
        window.input_seed_val.setPlainText("1.1975807343")
        window._on_live_source_changed()

    def check():
        pool = getattr(window, "_canonical_sequence_pool", None)
        if (pool is not None and pool.ready is not None and pool.future is None
                and pool.running_packet[1]["seed_text"] == "1.1975807343"):
            assert pool.failed is None, "pure canonical pool failed"
            owners = {m.get("canonical_owner") for b in window.instrument_sequence_banks.values()
                      for m in b.values() if isinstance(m, dict)}
            job = getattr(window, "_canonical_commit", None)
            if {"canonical:seeded", "canonical:phase_lock"} <= owners and not (job and job.running):
                gaps = [b - a for a, b in zip(ticks, ticks[1:])]
                print(f"PASS: latest seed and both engines committed; heartbeat ticks={len(ticks)};"
                      f" observed max UI gap={max(gaps, default=0):.3f}s", flush=True)
                if "--profile" in sys.argv:
                    profile.disable()
                    pstats.Stats(profile).sort_stats("cumtime").print_stats(28)
                sys.stdout.flush(); sys.stderr.flush()
                os._exit(0)
        if time.monotonic() - start > 20:
            print(f"FAIL: canonical pool timeout; pool={pool}; error={getattr(pool, 'failed', None)};"
                  f" active={window._get_active_engine_set()}; sources={window._active_engine_sources()}", flush=True)
            os._exit(1)
        QTimer.singleShot(50, check)

    QTimer.singleShot(150, trigger)
    QTimer.singleShot(350, check)
    app.exec()


if __name__ == "__main__":
    main()
