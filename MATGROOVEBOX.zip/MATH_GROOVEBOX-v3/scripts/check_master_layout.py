#!/usr/bin/env python3
"""Scoped, offscreen master-editor geometry inspection; no playback or disk install."""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


def main():
    from PyQt6.QtCore import Qt, QTimer
    from PyQt6.QtWidgets import QApplication
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app = QApplication([])
    from groovebox import MathematiciansGrooveboxApp
    from multidim_ui import MultidimWindow, SynthsMasterPanel
    output = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / "master-layout-results"
    output.mkdir(parents=True, exist_ok=True)
    window = MathematiciansGrooveboxApp()
    window.resize(1366, 768)
    window.show()

    def capture():
        try:
            arc = window.arc_seq_view
            master = arc._md
            stage = arc._stage_rect()
            assert abs(stage.center().y() - arc._ring_cy()) <= 1
            assert abs(stage.center().x() - arc.width() / 2) <= 1
            assert master.view.width() >= 1280 and master.view.height() >= 1120
            for a, b in ((master.top_geo_strip, master.control_rack),
                         (master.control_rack, master.view),
                         (master.view, master.bottom_dock)):
                assert not a.geometry().intersects(b.geometry()), (a.objectName(), b.objectName())
            arc.grab().save(str(output / "master-full-canvas.png"))
            master.grab().scaledToWidth(1600, Qt.TransformationMode.SmoothTransformation).save(
                str(output / "master-panel.png"))
            for action in window.workstation_toolbar.actions():
                if action.text() == "Master Synth":
                    action.trigger()
            app.processEvents()
            window.grab().save(str(output / "master-centered-viewport.png"))
            result = {"stage": stage.getRect(), "ring_center_y": arc._ring_cy(), "panes": {}}
            for name in ("top_ui_scroll", "bottom_render_scroll"):
                scroll = getattr(window, name)
                assert scroll.horizontalScrollBar().maximum() > 0
                assert scroll.verticalScrollBar().maximum() > 0
                result["panes"][name] = {
                    "content": [scroll.widget().width(), scroll.widget().height()],
                    "scroll_ranges": [scroll.horizontalScrollBar().maximum(), scroll.verticalScrollBar().maximum()],
                }
            for cls, name in ((MultidimWindow, "multidimensional"), (SynthsMasterPanel, "master-status")):
                dialog = cls(window)
                dialog.resize(1200, 760)
                dialog.show()
                app.processEvents()
                scroll = dialog.canvas_scroll
                assert scroll.horizontalScrollBar().maximum() > 0
                assert scroll.verticalScrollBar().maximum() > 0
                dialog.grab().save(str(output / f"{name}.png"))
                dialog.close()
            result["manual_geometry"] = "centered; control regions do not overlap; both axes scroll"
            (output / "results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
            print(json.dumps(result), flush=True)
        except Exception:
            import traceback
            traceback.print_exc()
            sys.stdout.flush(); sys.stderr.flush()
            os._exit(1)
        sys.stdout.flush()
        os._exit(0)

    QTimer.singleShot(1200, capture)
    app.exec()


if __name__ == "__main__":
    main()
