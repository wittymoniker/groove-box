#!/usr/bin/env python3
"""Exercise real Qt layout geometry without audio playback or project changes.

Run from the source tree with QT_QPA_PLATFORM=offscreen for CI, or DISPLAY set
to inspect on a desktop. Screenshots and JSON go outside the project by default.
This checks layout-managed sibling rectangles, not intentional scene overlays.
"""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT.parent / "ui-layout-results")
    parser.add_argument("--sizes", nargs="+", default=["1920x1080", "1366x768", "1024x768", "800x600"])
    parser.add_argument("--font-scale", type=float, default=1.0)
    parser.add_argument("--exercise", action="store_true", help="open and check added feature dialogs")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    from PyQt6.QtCore import Qt, QTimer, QEvent
    from PyQt6.QtWidgets import QApplication, QLayout
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app = QApplication([])
    if args.font_scale != 1:
        font = app.font()
        font.setPointSizeF(font.pointSizeF() * args.font_scale)
        app.setFont(font)
    from groovebox import MathematiciansGrooveboxApp
    window = MathematiciansGrooveboxApp()
    window.show()
    results = []
    sizes = list(args.sizes)

    def describe(item):
        widget = item.widget()
        if widget is not None:
            label = widget.text() if callable(getattr(widget, "text", None)) else (
                widget.title() if callable(getattr(widget, "title", None)) else "")
            return f"{type(widget).__name__}:{widget.objectName()}:{str(label)[:100]}"
        return type(item.layout()).__name__ if item.layout() else "spacer"

    def inspect_layout(layout):
        if layout is None:
            return []
        items = [layout.itemAt(i) for i in range(layout.count())]
        visible = [it for it in items if not it.isEmpty() and not it.spacerItem()]
        issues = []
        for i, a in enumerate(visible):
            for b in visible[i + 1:]:
                intersection = a.geometry().intersected(b.geometry())
                if intersection.width() > 2 and intersection.height() > 2:
                    issues.append({"kind": "overlap", "a": describe(a), "b": describe(b),
                                   "rect": intersection.getRect()})
            rect = a.geometry()
            if not layout.geometry().adjusted(-2, -2, 2, 2).contains(rect):
                issues.append({"kind": "layout-overflow", "item": describe(a),
                               "rect": rect.getRect(), "layout": layout.geometry().getRect(),
                               "hint": [a.sizeHint().width(), a.sizeHint().height()],
                               "minimum": [a.minimumSize().width(), a.minimumSize().height()],
                               "hfw": a.heightForWidth(rect.width())})
            child = a.layout()
            if child is None and a.widget() is not None:
                child = a.widget().layout()
            if child is not None:
                issues.extend(inspect_layout(child))
        return issues

    def capture():
        size = current[0]
        app.sendPostedEvents(None, QEvent.Type.LayoutRequest)
        issues = []
        panes = {}
        for name in ("top_ui_scroll", "bottom_render_scroll"):
            scroll = getattr(window, name)
            content = scroll.widget()
            content.layout().activate()
            panes[name] = {"viewport": scroll.viewport().size().width(),
                           "content": content.size().width(),
                           "height": content.height(),
                           "horizontal_max": scroll.horizontalScrollBar().maximum(),
                           "vertical_max": scroll.verticalScrollBar().maximum()}
            issues.extend(inspect_layout(content.layout()))
        window.grab().save(str(args.output / f"{size}.png"))
        results.append({"size": size, "actual": [window.width(), window.height()],
                        "panes": panes, "issues": issues})
        print(json.dumps(results[-1]), flush=True)
        QTimer.singleShot(0, advance)

    current = [None]

    def advance():
        if not sizes:
            if args.exercise:
                from PyQt6.QtWidgets import QMessageBox, QTabWidget
                messages = []
                def warning(parent, title, message, *rest, **kwargs):
                    messages.append({"kind": "dialog-error", "title": title, "message": message})
                    return QMessageBox.StandardButton.Ok
                QMessageBox.warning = staticmethod(warning)
                QMessageBox.critical = staticmethod(warning)
                window._open_live_jam_dialog()
                app.processEvents()
                dialog = getattr(window, "_live_jam_dialog", None)
                if dialog is None:
                    messages.append({"kind": "missing-dialog", "dialog": "Live Jam"})
                else:
                    assert window._live_jam_controller is not None
                    window._handle_live_jam_event({"kind": "macro", "target": "amplitude", "value": 0.75})
                    assert window._live_jam_controls["amplitude"] == 0.75
                    for tabs in dialog.findChildren(QTabWidget):
                        for index in range(tabs.count()):
                            tabs.setCurrentIndex(index)
                            app.processEvents()
                            messages.extend(inspect_layout(dialog.layout()))
                    dialog.grab().save(str(args.output / "live-jam.png"))
                    dialog.close()
                window._open_random_object_dialog()
                app.processEvents()
                dialog = getattr(window, "_random_object_dialog", None)
                if dialog is None:
                    messages.append({"kind": "missing-dialog", "dialog": "Random Object"})
                else:
                    assert not dialog.bind.isChecked()
                    for index in range(4):
                        dialog.kind.setCurrentIndex(index)
                        app.processEvents()
                        assert dialog.amount.value() == (128 if index == 3 else 2)
                        messages.extend(inspect_layout(dialog.layout()))
                    dialog.grab().save(str(args.output / "random-object.png"))
                    dialog.close()
                results.append({"size": "feature-dialogs", "issues": messages})
                print(json.dumps(results[-1]), flush=True)
            (args.output / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
            # The application has session-owned background workers; avoid sip
            # teardown races, just as the production entry point does.
            sys.stdout.flush()
            os._exit(1 if any(r["issues"] for r in results) else 0)
        current[0] = sizes.pop(0)
        width, height = map(int, current[0].split("x"))
        window.resize(width, height)
        QTimer.singleShot(1000, capture)

    QTimer.singleShot(1000, advance)
    app.exec()


if __name__ == "__main__":
    main()
