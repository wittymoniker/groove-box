# R30 — Hardware-aware ISO source refresh (2026-11-08)

- Refreshed the active `BUILD_ISO/app-overlay-v35.22zz` using the canonical root source tree.
- Rebuilt `BUILD_ISO/runtime-payload-manifest.json`; the 140 runtime source modules are byte-for-byte synchronized.
- Added the Dell Latitude 3510 target profile for the ordered NEMIX 32GB (2×16GB) DDR4-2666 SO-DIMM kit.
- Wired the profile into the final initramfs staging step at `/etc/sos/hardware-profiles/`.
- The profile is inventory metadata only. Runtime CPU, memory, affinity, and cgroup limits continue to be detected; no hard-coded 32GB reservation or CPU pinning is introduced.
- Source/boot preflight passes. A final ISO was not produced in this environment because the supplied source bundle does not include `BUILD_ISO/dist/runtime-cache/initramfs.v33c-limine-scode.img` or the runtime kernel tree required by the master remaster script.
