"""Source-level regression checks for the bottom-pane layout refresh."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _block(source: str, start: str, end: str) -> str:
    a = source.index(start)
    b = source.index(end, a)
    return source[a:b]


def test_live_player_has_a_dedicated_large_launcher():
    source = (ROOT / "groovebox.py").read_text(encoding="utf-8")
    block = _block(source, "    def _build_panel2_tools(self):", "    def _perf_backend(self):")
    assert 'QPushButton("🎬   OPEN LIVE PLAYER")' in block
    assert 'setObjectName("livePlayerLaunchButton")' in block
    assert "setMinimumHeight(54)" in block
    assert 'open_live_player(self)' in block
    assert 'self._panel2_buttons = {"🎬 Live Player": live_player_btn}' in block
    # The normal Play & Media list should not duplicate the hero launcher.
    assert '("🎬 Live Player",' not in block


def test_bottom_launch_groups_are_stacked_in_one_column():
    source = (ROOT / "groovebox.py").read_text(encoding="utf-8")
    block = _block(source, "    def _build_panel2_tools(self):", "    def _perf_backend(self):")
    assert "outer = QVBoxLayout(holder)" in block
    assert "column = QVBoxLayout(box)" in block
    assert "QGridLayout(box)" not in block
    assert "column.addWidget(btn)" in block


def test_bottom_status_transport_and_tools_are_separate_stacked_rows():
    source = (ROOT / "groovebox.py").read_text(encoding="utf-8")
    assert "scope_bar = QVBoxLayout()" in source
    assert "scope_status_row = QHBoxLayout()" in source
    assert "scope_transport_row = QHBoxLayout()" in source
    assert "scope_tools_row = QHBoxLayout()" in source
    assert "scope_bar.addLayout(scope_status_row)" in source
    assert "scope_bar.addLayout(scope_transport_row)" in source
    assert "scope_bar.addLayout(scope_tools_row)" in source
    assert "bottom_content.setMinimumWidth(2400)" not in source
