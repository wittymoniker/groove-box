"""PIN_LOCK_R31: optional PIN lock (4-8 digits, default 4; Compatibility settings).

Stored in compat-settings.json as a salted PBKDF2 hash, never the PIN itself.
This is a casual "keep hands off the session" lock, not encryption: four digits
cannot protect files on disk, and the help text says so.

While locked, a full-window overlay takes keyboard and mouse input for every
window. Audio, video, exports and timers keep running underneath: nothing here
sleeps or waits. Wrong PINs back off with a QTimer, never time.sleep().
"""
from __future__ import annotations

import hashlib
import hmac
import os
import time

from PyQt6.QtCore import Qt, QTimer, QObject, QEvent
from PyQt6.QtGui import QPainter, QColor
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QGridLayout, QLabel, QLineEdit, QPushButton, QApplication,
                             QDialog, QDialogButtonBox, QFormLayout, QMessageBox)

ITER = 120_000


def hash_pin(pin: str, salt_hex: str | None = None):
    salt = bytes.fromhex(salt_hex) if salt_hex else os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", str(pin).encode("utf-8"), salt, ITER)
    return salt.hex(), dk.hex()


MIN_DIGITS, MAX_DIGITS = 4, 8


def digits(settings: dict) -> int:
    try:
        return max(MIN_DIGITS, min(MAX_DIGITS, int(settings.get("pin_digits", 4) or 4)))
    except (TypeError, ValueError):
        return 4


def valid_pin(pin, n: int = 4) -> bool:
    return isinstance(pin, str) and len(pin) == int(n) and pin.isdigit()


def check_pin(pin: str, settings: dict) -> bool:
    salt, want = settings.get("pin_salt") or "", settings.get("pin_hash") or ""
    if not (valid_pin(pin, digits(settings)) and salt and want):
        return False
    return hmac.compare_digest(hash_pin(pin, salt)[1], want)


def pin_configured(settings: dict) -> bool:
    return bool(settings.get("pin_enabled") and settings.get("pin_hash") and settings.get("pin_salt"))


class _InputBlocker(QObject):
    """While locked, swallow input to every window except the lock overlay itself."""
    _TYPES = (QEvent.Type.KeyPress, QEvent.Type.KeyRelease, QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease,
              QEvent.Type.MouseButtonDblClick, QEvent.Type.Wheel, QEvent.Type.Shortcut, QEvent.Type.ShortcutOverride)

    def __init__(self, overlay):
        super().__init__(overlay)
        self.overlay = overlay

    def eventFilter(self, obj, ev):
        if ev.type() in self._TYPES and isinstance(obj, QWidget):
            w = obj
            while w is not None:            # walk across window boundaries (dialogs owned by the overlay)
                if w is self.overlay:
                    return False
                w = w.parentWidget()
            return True
        return False


class PinLockOverlay(QWidget):
    def __init__(self, host, settings_loader):
        super().__init__(host)
        self.host, self._load = host, settings_loader
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setObjectName("PinLockOverlay")
        self.setStyleSheet("#PinLockOverlay{background:rgba(3,8,14,235);} QLabel{color:#f6d46d;font-size:18px;}"
                           "QPushButton{min-width:64px;min-height:52px;font-size:20px;font-weight:800;color:#e8f6ff;"
                           "background:#17354a;border:1px solid #6ca6ba;border-radius:10px;}"
                           "QPushButton:pressed{background:#2a5d7c;}"
                           "QLineEdit{font-size:28px;letter-spacing:12px;min-height:48px;color:#e8f6ff;background:#05121c;"
                           "border:1px solid #8b6b2c;border-radius:8px;}")
        outer = QVBoxLayout(self); outer.addStretch(1)
        box = QWidget(); col = QVBoxLayout(box); box.setMaximumWidth(320)
        self.title = QLabel("🔒 Groovebox is locked"); self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hint = QLabel("Enter the PIN"); self.hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hint.setStyleSheet("color:#9cc7ff;font-size:13px;")
        self.edit = QLineEdit(); self.edit.setEchoMode(QLineEdit.EchoMode.Password); self.edit.setMaxLength(MAX_DIGITS)
        self.edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.edit.textChanged.connect(self._typed)
        col.addWidget(self.title); col.addWidget(self.hint); col.addWidget(self.edit)
        grid = QGridLayout()
        keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "✓"]
        for i, k in enumerate(keys):
            b = QPushButton(k); b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(lambda _c=False, k=k: self._key(k)); grid.addWidget(b, i // 3, i % 3)
        col.addLayout(grid)
        self.reset_btn = QPushButton("Forgot PIN — reset Groovebox…")
        self.reset_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.reset_btn.setStyleSheet("font-size:12px;min-height:30px;color:#ffb0b0;background:#2a0d12;border-color:#a04050;")
        self.reset_btn.clicked.connect(self._reset_clicked)
        self.reset_label = QLabel(""); self.reset_label.setWordWrap(True)
        self.reset_label.setStyleSheet("color:#ffb0b0;font-size:12px;")
        col.addWidget(self.reset_btn); col.addWidget(self.reset_label)
        self._countdown = None
        row = QVBoxLayout(); row.addWidget(box, 0, Qt.AlignmentFlag.AlignHCenter)
        outer.addLayout(row); outer.addStretch(1)
        self._fails = 0
        self._locked_until = 0.0
        self._backoff = QTimer(self); self._backoff.setInterval(500); self._backoff.timeout.connect(self._tick_backoff)
        self._blocker = _InputBlocker(self)
        self.hide()

    # -- lock / unlock -------------------------------------------------------
    def lock(self):
        if not pin_configured(self._load()):
            return False
        if self.isVisible():
            return True
        self.setGeometry(self.host.rect())
        self._n = digits(self._load())
        self.edit.setMaxLength(self._n)
        self.hint.setText("Enter the %d-digit PIN" % self._n)
        self.edit.clear(); self.show(); self.raise_()
        QApplication.instance().installEventFilter(self._blocker)
        self.edit.setFocus()
        return True

    def is_locked(self):
        return self.isVisible()

    def _unlock(self):
        if self._countdown is not None and self._countdown.active():
            self._countdown.cancel(); self._reset_status("Reset cancelled: the PIN was entered.")
            self.reset_btn.setText("Forgot PIN — reset Groovebox…")
        QApplication.instance().removeEventFilter(self._blocker)
        self._fails = 0
        self.hide()

    def resize_to_host(self):
        if self.isVisible():
            self.setGeometry(self.host.rect()); self.raise_()

    # -- forgot PIN: timed reset -------------------------------------------------
    def _reset_clicked(self):
        if self._countdown is not None and self._countdown.active():
            self._countdown.cancel(); self._reset_status("Reset cancelled.")
            self.reset_btn.setText("Forgot PIN — reset Groovebox…")
            return
        targets = reset_targets()
        if not targets:
            self._reset_status("Reset is unavailable: the Groovebox data folder could not be identified safely."); return
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        box.setWindowTitle("Reset Groovebox")
        box.setText("Erase ALL Groovebox projects, recordings, exports, samples and settings (including the PIN)?\n\n"
                    "The erase starts after 1 hour 15 minutes of the device staying on. If it sleeps, suspends, "
                    "or Groovebox is closed, the countdown starts over. Entering the PIN cancels it.\n\n"
                    "Operating-system files are not touched. This deletes:\n" + "\n".join(targets))
        box.setStandardButtons(QMessageBox.StandardButton.Cancel)
        go = box.addButton("Start 1:15:00 countdown", QMessageBox.ButtonRole.DestructiveRole)
        box.setDefaultButton(QMessageBox.StandardButton.Cancel)
        # The input blocker lets this box through: it is a child of the overlay.
        box.exec()
        if box.clickedButton() is not go:
            return
        if self._countdown is None:
            self._countdown = ResetCountdown(self)
        self._countdown.start()
        self.reset_btn.setText("Cancel reset")

    def _reset_status(self, text):
        self.reset_label.setText(text)

    def _do_reset(self):
        """Stop host activity, erase on a worker thread, then quit (UI thread never waits)."""
        import threading
        self._reset_status("Resetting… do not turn the device off.")
        self.reset_btn.setEnabled(False)
        try:
            stop = getattr(self.host, "stop_playback", None) or getattr(self.host, "stop", None)
            if callable(stop):
                stop()
        except Exception:
            pass
        try:
            sch = getattr(self.host, "_export_scheduler_obj", None)
            if sch is not None:
                sch.shutdown()
        except Exception:
            pass
        try:
            self.host._autosave_disabled = True
        except Exception:
            pass
        targets = reset_targets()

        try:
            t = getattr(self.host, "_autosave_timer", None)
            if t is not None:
                t.stop()
        except Exception:
            pass
        box = {}

        def work():
            box["errs"] = wipe(targets)
        threading.Thread(target=work, name="groovebox-reset", daemon=True).start()
        poll = QTimer(self); poll.setInterval(250)
        def _check():
            if "errs" in box:
                poll.stop(); self._reset_done(box["errs"])
        poll.timeout.connect(_check); poll.start()

    def _reset_done(self, errs):
        if errs:
            self._reset_status("Reset finished with errors:\n" + "\n".join(errs[:5]))
        else:
            self._reset_status("Groovebox was reset. Closing; start it again to set up fresh.")
        QTimer.singleShot(4000, QApplication.instance().quit)

    # -- input -----------------------------------------------------------------
    def _key(self, k):
        if k == "⌫":
            self.edit.setText(self.edit.text()[:-1])
        elif k == "✓":
            self._try()
        elif len(self.edit.text()) < getattr(self, "_n", 4):
            self.edit.setText(self.edit.text() + k)

    def _typed(self, text):
        if len(text) == getattr(self, "_n", 4):
            QTimer.singleShot(0, self._try)

    def keyPressEvent(self, ev):
        if ev.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self._try(); return
        super().keyPressEvent(ev)

    def _try(self):
        if time.monotonic() < self._locked_until:
            return
        pin = self.edit.text()
        if check_pin(pin, self._load()):
            self._unlock(); return
        self._fails += 1
        self.edit.clear()
        if self._fails >= 5:
            wait = min(300, 30 * (2 ** (self._fails - 5)))
            self._locked_until = time.monotonic() + wait
            self.edit.setEnabled(False); self._backoff.start(); self._tick_backoff()
        else:
            self.hint.setText("Wrong PIN (%d of 5 before a pause)" % self._fails)

    def _tick_backoff(self):
        left = self._locked_until - time.monotonic()
        if left <= 0:
            self._backoff.stop(); self.edit.setEnabled(True); self.edit.setFocus()
            self.hint.setText("Enter the %d-digit PIN" % getattr(self, "_n", 4))
        else:
            self.hint.setText("Too many tries. Wait %d s" % int(left + 0.99))


class IdleLockWatch(QObject):
    """Locks after N idle minutes (0 = never). Event filter only records time."""

    def __init__(self, overlay, settings_loader):
        super().__init__(overlay)
        self.overlay, self._load = overlay, settings_loader
        self._last = time.monotonic()
        self.timer = QTimer(self); self.timer.setInterval(15000); self.timer.timeout.connect(self._check)
        QApplication.instance().installEventFilter(self)
        self.timer.start()

    def eventFilter(self, obj, ev):
        if ev.type() in (QEvent.Type.KeyPress, QEvent.Type.MouseButtonPress, QEvent.Type.MouseMove, QEvent.Type.Wheel):
            self._last = time.monotonic()
        return False

    def _check(self):
        s = self._load()
        mins = int(s.get("pin_idle_minutes", 0) or 0)
        if mins > 0 and pin_configured(s) and not self.overlay.is_locked() and time.monotonic() - self._last >= mins * 60:
            self.overlay.lock()


class SetPinDialog(QDialog):
    """Set / change the PIN. Changing requires the current PIN."""

    def __init__(self, parent, settings):
        super().__init__(parent)
        self.setWindowTitle("Set 4-digit PIN")
        self.settings = settings
        form = QFormLayout(self)
        self.cur = None
        if pin_configured(settings):
            self.cur = QLineEdit(); self.cur.setEchoMode(QLineEdit.EchoMode.Password)
            form.addRow("Current PIN", self.cur)
        from PyQt6.QtWidgets import QSpinBox
        self.ndig = QSpinBox(); self.ndig.setRange(MIN_DIGITS, MAX_DIGITS); self.ndig.setValue(digits(settings))
        self.ndig.setSuffix(" digits")
        form.addRow("PIN length", self.ndig)
        self.new1 = QLineEdit(); self.new2 = QLineEdit()
        for e in (self.new1, self.new2):
            e.setEchoMode(QLineEdit.EchoMode.Password); e.setMaxLength(MAX_DIGITS);
        form.addRow("New PIN", self.new1); form.addRow("Repeat", self.new2)
        form.addRow(QLabel("A PIN keeps hands off the running session. It does not encrypt your files."))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._ok); bb.rejected.connect(self.reject); form.addRow(bb)
        self.result_fields = None

    def _ok(self):
        if self.cur is not None and not check_pin(self.cur.text(), self.settings):
            QMessageBox.warning(self, "PIN", "The current PIN is wrong."); return
        a, b = self.new1.text().strip(), self.new2.text().strip()
        n = int(self.ndig.value())
        if not valid_pin(a, n):
            QMessageBox.warning(self, "PIN", "The PIN must be exactly %d digits." % n); return
        if a != b:
            QMessageBox.warning(self, "PIN", "The two PINs do not match."); return
        salt, h = hash_pin(a)
        self.result_fields = {"pin_enabled": True, "pin_salt": salt, "pin_hash": h, "pin_digits": n}
        self.accept()


# ---------------------------------------------------------------------------
# PIN_RESET_R31: "Forgot PIN" → erase Groovebox user data after 1 h 15 min
# ---------------------------------------------------------------------------
RESET_SECONDS = 75 * 60
SUSPEND_GAP = 120.0      # a tick gap this long means the device slept / was suspended


def reset_targets():
    """Only Groovebox's own data root and its settings file. Never system paths."""
    out = []
    try:
        import groovebox_paths as gp
        root = os.path.realpath(gp.base_dir())
        home = os.path.realpath(os.path.expanduser("~"))
        if (root not in ("/", home, os.path.dirname(home)) and len(root) > 8
                and gp.APP_DIRNAME.lower() in root.lower()):
            out.append(root)
    except Exception:
        pass
    try:
        import compat_settings as cs
        p = os.path.realpath(cs.settings_path())
        if os.path.basename(p) == "compat-settings.json" and not any(p.startswith(t + os.sep) for t in out):
            out.append(p)
    except Exception:
        pass
    return out


def wipe(targets):
    import shutil
    errors = []
    for t in targets:
        try:
            if os.path.isdir(t):
                shutil.rmtree(t)
            elif os.path.exists(t):
                os.remove(t)
        except Exception as exc:
            errors.append("%s: %s" % (t, exc))
    return errors


class ResetCountdown(QObject):
    """Counts 75 minutes of continuous uptime. Sleep, suspend or quitting restarts it."""

    def __init__(self, overlay):
        super().__init__(overlay)
        self.ov = overlay
        self.remaining = float(RESET_SECONDS)
        self._last = time.monotonic()
        self._wall = time.time()
        self.timer = QTimer(self); self.timer.setInterval(1000); self.timer.timeout.connect(self._tick)

    def start(self):
        self.remaining = float(RESET_SECONDS)
        self._last, self._wall = time.monotonic(), time.time()
        self.timer.start(); self._tick()

    def cancel(self):
        self.timer.stop()
        self.remaining = float(RESET_SECONDS)

    def active(self):
        return self.timer.isActive()

    def _tick(self):
        now, wall = time.monotonic(), time.time()
        gap = max(now - self._last, wall - self._wall)     # monotonic may pause in suspend; wall clock does not
        self._last, self._wall = now, wall
        if gap > SUSPEND_GAP:
            self.remaining = float(RESET_SECONDS)
            self.ov._reset_status("The device slept or paused: the reset countdown started over.")
        else:
            self.remaining -= gap
        if self.remaining <= 0:
            self.timer.stop()
            self.ov._do_reset()
            return
        m, s = divmod(int(self.remaining + 0.99), 60)
        self.ov._reset_status("Reset in %d:%02d. Keep the device on. Entering the PIN or Cancel stops it." % (m, s))
