"""Export render worker (EXPORT_WORKER_20261102).

The main window packs the canonical project document (the same document Save writes) and starts this
program as a separate process. The worker loads the document into its own headless engine, renders the
shared mixdown buffer, and writes it as a float32 .npy plus a small JSON note. The main window keeps its
own thread, GIL and event loop, so scrolling, editing and playing stay smooth while a long render runs.

    python export_worker.py JOB.json

JOB.json: {"project": "<project .MCC path>", "sample_rate": 48000, "out_npy": "...", "out_meta": "...",
           "kind": "audio", "purpose": "Export prepare"}

Progress lines on stdout:  PROGRESS <0-100> <text>   and finally   DONE <out_npy>   (or   FAIL <message>).
"""
from __future__ import annotations

import json
import os
import sys


def _say(*parts):
    print(" ".join(str(p) for p in parts), flush=True)


_QAPP = None
_APP = None


def _make_app():
    """One headless engine per worker process (a warm worker reuses it for many jobs)."""
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ["GROOVEBOX_HEADLESS_WORKER"] = "1"
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    from PyQt6.QtWidgets import QApplication
    global _QAPP, _APP
    _QAPP = QApplication.instance() or QApplication(["export_worker"])   # module-level: must outlive this call
    _say("PROGRESS", 2, "worker starting")
    import groovebox as g
    app = _APP = g.MathematiciansGrooveboxApp()
    try:
        t = getattr(app, "_autosave_timer", None)
        if t is not None:
            t.stop()                      # a worker never autosaves anyone's project
    except Exception:
        pass
    _say("PROGRESS", 8, "engine ready")
    return app


def _reset_between_jobs(app, job):
    """WARM_WORKER_R31: undo per-job state so the next job starts clean."""
    for attr, val in (("_render_stem_filter", None), ("_render_raw_no_fx", False), ("_export_preset", None)):
        try:
            setattr(app, attr, val)
        except Exception:
            pass
    if job.get("kind") in ("stem_file", "bake_compare"):
        try:
            app._shared_mixdown_cache.clear()    # filtered / manifest renders must never be reused
        except Exception:
            pass


def run(job: dict, app=None) -> int:
    import numpy as np
    if app is None:
        app = _make_app()
    _say("PROGRESS", 10, "loading project")
    if not app.open_project_path(job["project"], show_message=False):
        _say("FAIL", "project document could not be loaded")
        return 2
    _say("PROGRESS", 15, "project loaded")
    if job.get("kind") == "video_file":
        return _write_video_file(app, job)
    if job.get("kind") == "stem_file":
        return _write_stem_file(app, job, np)
    if job.get("kind") == "bake_compare":
        os.environ["GROOVEBOX_VIDEO_EXPORT_GUI_THREAD"] = "1"
        o = dict(job.get("options") or {})
        report, identical, ratio = app._bake_compare_compute(o.get("target") or {}, str(o.get("file_label") or ""))
        with open(job["out_meta"], "w", encoding="utf-8") as f:
            json.dump({"file_path": "", "report": report, "identical": bool(identical), "rms_ratio": float(ratio)}, f)
        _say("DONE", "identical" if identical else "rms %.6f" % ratio)
        return 0
    sr = int(job.get("sample_rate") or 0)
    if sr > 0:
        app.preferred_sample_rate = sr
    try:
        app._set_work_progress = lambda label, pct, text="": _say("PROGRESS", 15 + int(max(0, min(100, pct)) * 0.8), text)
    except Exception:
        pass
    # EXPORT_SNAPSHOT_20261102: the render reads its settings from this snapshot; without it the worker rendered
    # the defaults (120 bpm, 32 rows) instead of the project's own values.
    app._snapshot_render_inputs()
    mr = job.get("max_rows")
    buf, rate = app._get_shared_mixdown_buffer(max_rows=(int(mr) if mr else None),
                                               purpose=str(job.get("purpose") or "Export prepare"),
                                               force=False)   # R31: same frozen state → reuse (keyed on full render state)
    buf = np.array(buf, dtype=np.float32, order="C", copy=True)   # private copy: the cached render stays pristine
    if job.get("kind") == "audio_file":
        return _write_audio_file(app, job, buf, rate, np)
    if job.get("final"):
        # GROOVEBOX_R23R_EXPORT_MERGE_20261103: Batch Export — this project's own DJ bake +
        # master volume + hard clip, so each file is exactly what its project would export.
        _say("PROGRESS", 96, "master bus")
        try:
            buf = app._bake_dj_write(buf, rate)
        except Exception:
            pass
        buf, _info = app._master_hardclip(buf, rate, apply_master_vol=True)
        buf = np.ascontiguousarray(np.asarray(buf, dtype=np.float32))
    np.save(job["out_npy"], buf)
    with open(job["out_meta"], "w", encoding="utf-8") as f:
        json.dump({"sample_rate": int(rate), "frames": int(buf.shape[0]), "channels": 1 if buf.ndim == 1 else int(buf.shape[1]),
                   "final": bool(job.get("final"))}, f)
    _say("DONE", job["out_npy"])
    return 0


class _SayEmitter:
    """Stand-in for a pyqtSignal: forwards progress to stdout for the parent window."""
    def __init__(self, kind, sink):
        self.kind, self.sink = kind, sink

    def emit(self, *args):
        self.sink(self.kind, args)


class _SaySignals:
    def __init__(self):
        self.result = None
        self.error = None
        self.progress = _SayEmitter("progress", self._on)
        self.finished = _SayEmitter("finished", self._on)
        self.failed = _SayEmitter("failed", self._on)

    def _on(self, kind, args):
        if kind == "progress":
            _say("PROGRESS", int(args[1]), str(args[2]))
        elif kind == "finished":
            self.result = args[1]
        else:
            self.error = str(args[1])


def _write_audio_file(app, job, buf, rate, np):
    """EXPORT_SCHEDULER_R31: the whole audio export runs here, in this process.

    One DJ bake, then the canonical post-render pipeline (_AudioExportTask: one master
    hardclip, resample, quantize, parts, stitch, verify). The parent window only queues
    the job and reads progress lines, so it never waits on a render or an encode.
    """
    import groovebox as g
    _say("PROGRESS", 90, "DJ bake")
    try:
        buf = app._bake_dj_write(buf, rate)
    except Exception:
        pass
    o = dict(job.get("options") or {})
    master = np.ascontiguousarray(np.nan_to_num(np.asarray(buf, dtype=np.float32), nan=0.0, posinf=1.0, neginf=-1.0))
    master.setflags(write=False)
    try:
        prov = app._export_provenance_payload()
        prov = prov.encode("utf-8") if isinstance(prov, str) else bytes(prov or b"")
    except Exception:
        prov = b""
    clip = float(o.get("clip_ratio_pct", 50.0))
    vol = float(o.get("master_volume", getattr(app, "master_volume", 0.72)))
    snap = g._AudioExportSnapshot(
        token=1, file_path=str(job["out_file"]), master=master,
        render_sample_rate=int(rate), output_sample_rate=int(o.get("output_sample_rate") or rate),
        bit_depth=int(o.get("bit_depth", 24)), n_parts=int(o.get("n_parts", 1)),
        audio_format=str(o.get("audio_format", "wav")),
        bitrate_kbps=(int(o["bitrate_kbps"]) if o.get("bitrate_kbps") else None),
        stitch_parts=bool(o.get("stitch_parts", True)), provenance_bytes=prov,
        clip_ratio_pct=clip, master_volume=max(0.0, min(1.0, vol)),
        cancel_event=None, preview=np.empty(0, dtype=np.float32))
    sig = _SaySignals()
    g._AudioExportTask(snap, app._write_audio_parts_and_final, sig).run()
    if sig.error:
        _say("FAIL", sig.error)
        return 3
    res = sig.result or {}
    with open(job["out_meta"], "w", encoding="utf-8") as f:
        json.dump({"file_path": str(res.get("file_path") or ""), "part_paths": list(res.get("part_paths") or []),
                   "peak": float(res.get("peak", 0.0) or 0.0), "sample_rate": int(res.get("sample_rate") or 0)}, f)
    _say("DONE", res.get("file_path") or job["out_file"])
    return 0


def _write_stem_file(app, job, np):
    """EXPORT_SCHEDULER_R31: one stem (bus / rows / instruments filter) rendered and written here."""
    from audio_os_backend import write_wav
    o = dict(job.get("options") or {})
    app._render_stem_filter = {"bus": o.get("bus"), "rows": set(o["rows"]) if o.get("rows") else None,
                               "instruments": set(o["instruments"]) if o.get("instruments") else None}
    app._render_raw_no_fx = bool(o.get("raw"))
    app._snapshot_render_inputs()
    buf, sr = app._get_shared_mixdown_buffer(purpose="stem export", force=True)
    _say("PROGRESS", 92, "master hard clip")
    pcm, _info = app._master_hardclip(np.asarray(buf, dtype=np.float32), sr)
    write_wav(str(job["out_file"]), int(sr), np.asarray(pcm, dtype=np.float32))
    with open(job["out_meta"], "w", encoding="utf-8") as f:
        json.dump({"file_path": str(job["out_file"]), "part_paths": [], "peak": float(np.max(np.abs(pcm))) if np.size(pcm) else 0.0,
                   "sample_rate": int(sr)}, f)
    _say("DONE", job["out_file"])
    return 0


def _write_video_file(app, job):
    """EXPORT_SCHEDULER_R31: run the normal video exporter headless with the frozen options."""
    os.environ["GROOVEBOX_VIDEO_EXPORT_GUI_THREAD"] = "1"      # no UI to keep live here: run frame waits inline
    from PyQt6.QtWidgets import QMessageBox
    notes = {"fail": ""}

    def _info(*a, **k):
        _say("PROGRESS", 99, str(a[2] if len(a) > 2 else "")[:160].replace("\n", " "))
        return QMessageBox.StandardButton.Ok

    def _bad(*a, **k):
        notes["fail"] = str(a[2] if len(a) > 2 else "video export failed")[:400].replace("\n", " ")
        return QMessageBox.StandardButton.Ok
    QMessageBox.information = staticmethod(_info)
    QMessageBox.warning = staticmethod(_bad)
    QMessageBox.critical = staticmethod(_bad)
    o = dict(job.get("options") or {})
    _resume = bool(dict(o.get("preset") or {}).get("resume", True))
    QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes if _resume
                                        else QMessageBox.StandardButton.No)   # resume or restart .part sets
    app._export_preset = dict(o.get("preset") or {}, path=str(job["out_file"]))
    app.export_video_dialog(include_audio=bool(o.get("include_audio", True)), container=str(o.get("container", "mp4")))
    out = str(job["out_file"])
    if notes["fail"]:
        _say("FAIL", notes["fail"]); return 4
    pre = dict(o.get("preset") or {})
    if pre.get("only_parts") is not None:
        # PARALLEL_PARTS_R31: a part-set job succeeds when each of its .partNN segments exists.
        d = os.path.dirname(os.path.abspath(out)); stem = os.path.splitext(os.path.basename(out))[0]
        cont = str(o.get("container", "mp4"))
        missing = [i for i in pre["only_parts"] if not (os.path.isfile(os.path.join(d, f"{stem}.part{int(i):02d}.{cont}"))
                   and os.path.getsize(os.path.join(d, f"{stem}.part{int(i):02d}.{cont}")) > 64)]
        if missing:
            _say("FAIL", "part(s) not written: %s" % ", ".join(str(m) for m in missing)); return 6
        with open(job["out_meta"], "w", encoding="utf-8") as f:
            json.dump({"file_path": "", "part_paths": [], "peak": 0.0, "sample_rate": 0}, f)
        _say("DONE", "parts %s" % ",".join(str(i) for i in pre["only_parts"]))
        return 0
    if not (os.path.isfile(out) and os.path.getsize(out) > 0):
        _say("FAIL", "the video file was not written"); return 5
    with open(job["out_meta"], "w", encoding="utf-8") as f:
        json.dump({"file_path": out, "part_paths": [], "peak": 0.0, "sample_rate": 0}, f)
    _say("DONE", out)
    return 0


def serve(max_jobs=8) -> int:
    """WARM_WORKER_R31: read job.json paths from stdin, one per line; after each job print
    "JOBEND <rc>". Exits after max_jobs (the parent starts a fresh worker) or on EOF."""
    try:
        app = _make_app()
    except Exception as exc:
        _say("FAIL", f"worker start: {type(exc).__name__}: {exc}")
        _say("JOBEND", 1)
        return 1
    _say("READY")
    done = 0
    for line in sys.stdin:
        path = line.strip()
        if not path:
            continue
        job = {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                job = json.load(f)
            rc = int(run(job, app) or 0)
        except Exception as exc:
            _say("FAIL", f"{type(exc).__name__}: {exc}")
            rc = 1
        try:
            _reset_between_jobs(app, job)
        except Exception:
            pass
        _say("JOBEND", rc)
        done += 1
        if done >= max_jobs:
            break
    return 0


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print(__doc__)
        return 64
    if argv[0] == "--serve":
        try:
            n = int(argv[1]) if len(argv) > 1 else 8
        except ValueError:
            n = 8
        return serve(max(1, n))
    try:
        with open(argv[0], "r", encoding="utf-8") as f:
            job = json.load(f)
        return run(job)
    except Exception as exc:  # report, never hang the caller
        _say("FAIL", f"{type(exc).__name__}: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
