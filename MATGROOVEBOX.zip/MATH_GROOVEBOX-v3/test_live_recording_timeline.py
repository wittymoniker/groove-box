"""Regression tests for the current Live Player recording and DJ-chain contracts."""
from types import SimpleNamespace
import queue
import shutil
import threading
import time

import numpy as np
import pytest

from live_player import DJChain, LiveEngine, LiveRecorder
from dj_effects import LiveDJEffects, configure_extra_dj


class FrameSink:
    def __init__(self):
        self.values = []

    def write(self, frame):
        self.values.append(int(frame[0, 0, 0]))


@pytest.fixture
def recorder(tmp_path):
    engine = SimpleNamespace(sr=48000, rec=None)
    host = SimpleNamespace(_exports_dir=lambda: str(tmp_path))
    rec = LiveRecorder(host, engine)
    rec._video_size = (16, 12)
    rec._venc = FrameSink()
    yield rec
    rec.stop_evt.set()
    shutil.rmtree(rec.tmpdir, ignore_errors=True)


def frame(value):
    return np.full((12, 16, 3), value, dtype=np.uint8)


def test_audio_samples_not_wall_time_are_the_recording_clock(recorder):
    # Large wall-clock movement must not affect AV sync; only audio samples do.
    recorder._on_audio(np.zeros(24000, np.float32))
    assert recorder.frames_due() == 12
    assert recorder.audio_samples == 24000


def test_frame_queue_owns_pixels_and_stays_bounded(recorder):
    recorder._vq = queue.Queue(maxsize=2)
    image = frame(10)
    assert recorder.push_frame(image)
    image.fill(99)
    assert recorder.push_frame(frame(50))
    assert not recorder.push_frame(frame(200))
    assert recorder.frames_dropped == 1
    writer = threading.Thread(target=recorder._video_writer, daemon=True)
    writer.start()
    deadline = time.monotonic() + 1.0
    while not recorder._vq.empty() and time.monotonic() < deadline:
        time.sleep(0.005)
    recorder._vq.put(None, timeout=1.0)
    writer.join(timeout=2.0)
    assert not writer.is_alive()
    assert recorder._venc.values == [10, 50, 50]   # R31: the dropped frame is held as a repeat in place (A/V sync)
    assert recorder.frames_written == 3   # R31: includes the held repeat


def test_dj_filter_effect_changes_recorded_audio_and_toggle_is_exact_bypass():
    source = np.linspace(-0.3, 0.3, 2048, dtype=np.float32)
    host = SimpleNamespace(master_volume=1.0)
    engine = LiveEngine(host)
    engine.q.put((0, source.copy()))

    fx = DJChain(engine.sr)
    fx.p.update(gate=100.0, gate_div=0.25, gate_enabled=True)
    engine.fx = fx
    captured = []
    engine.rec = lambda block: captured.append(block)
    output = np.zeros((2048, 1), np.float32)
    engine.callback(output, 2048, None, None)
    assert captured and np.array_equal(captured[0], output[:, 0])
    assert not np.allclose(output[:, 0], source)
    assert np.isfinite(output).all()

    bypass_engine = LiveEngine(host)
    bypass_engine.q.put((0, source.copy()))
    bypass_fx = DJChain(bypass_engine.sr)
    bypass_fx.p.update(gate=100.0, gate_enabled=False)
    bypass_engine.fx = bypass_fx
    bypass_output = np.zeros((2048, 1), np.float32)
    bypass_engine.callback(bypass_output, 2048, None, None)
    assert np.array_equal(bypass_output[:, 0], source)


def test_disabled_imported_effects_are_exact_bypass():
    host = SimpleNamespace(live_dj_beat_gate=False, live_dj_beat_gate_amount=0.8)
    fx = LiveDJEffects()
    configure_extra_dj(fx, host)
    source = np.linspace(-0.5, 0.5, 4096, dtype=np.float32)
    assert np.array_equal(fx.process(source, start_sample=0), source)


def test_live_recorder_encoder_startup_runs_off_the_calling_thread(recorder):
    ready = __import__("threading").Event()
    thread_names = []

    def fake_open_video():
        thread_names.append(__import__("threading").current_thread().name)
        recorder._venc = FrameSink()
        ready.set()
        return True

    recorder._open_video = fake_open_video
    recorder.start()
    assert ready.wait(2.0)
    assert thread_names == ["live-take-video-start"]
    recorder.stop_evt.set()
    recorder._vq.put(None, timeout=1.0)
    for thread in recorder._threads:
        thread.join(timeout=2.0)
    assert all(not thread.is_alive() for thread in recorder._threads)
