"""Audio visualizer + native .MCC video player for Groovebox player windows.

GROOVEBOX_R23R_PLAYER_VISUALIZER_MCC_20261103

AudioVisualizer   — waveform overview with playhead, live oscilloscope and a
                    log-frequency spectrum, driven by any clock callable
                    (Qt player position, mpv time-pos, host file-player cursor).
MccVideoPlayer    — plays a media .MCC video exactly as written (lossless RGB
                    frames, decoded lazily) with its embedded audio on the
                    Groovebox output device; no FFmpeg needed.
"""
from __future__ import annotations

import os
import threading
import time

import numpy as np
from qt_painting import owned_painter
from PyQt6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PyQt6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QSlider, QVBoxLayout, QWidget


class _DecodeBridge(QObject):
    done = pyqtSignal(object, int, str)


# VIS_STYLES_R31: 16 looks for the media-player visualizer (right-click to choose; remembered).
# wave/scope/low/mid/high colours · spectrum style (bars | mirror | line | dots) · bands · decay
VIS_STYLES = {
    "Teal (classic)":   ("#2f6f8a", "#7fd8ff", "#0d6e8a", "#00ffcc", "#ffd166", "bars", 64, 0.86),
    "Ice":              ("#3d6f9a", "#bfe6ff", "#14406e", "#6fc3ff", "#ffffff", "bars", 96, 0.90),
    "Ember":            ("#8a3f2f", "#ffb07f", "#6e1d0d", "#ff6a00", "#ffe066", "bars", 64, 0.84),
    "Neon violet":      ("#5d2f8a", "#e07fff", "#3a0d6e", "#c040ff", "#ff9cf0", "mirror", 64, 0.88),
    "Aurora":           ("#2f8a5a", "#9dffcf", "#0d6e4a", "#4dffa0", "#c8ff66", "mirror", 96, 0.90),
    "Gold":             ("#8a6f2f", "#ffe07f", "#6e520d", "#ffc000", "#fff4c0", "bars", 48, 0.86),
    "Mono":             ("#555555", "#dddddd", "#333333", "#999999", "#ffffff", "line", 128, 0.80),
    "Studio meter":     ("#2f6f8a", "#7fd8ff", "#1d8a3a", "#e6d000", "#ff3030", "bars", 32, 0.92),
    "Club":             ("#8a2f6f", "#ff7fd8", "#00a0ff", "#ff00a0", "#ffffff", "mirror", 48, 0.70),
    "Ocean line":       ("#1f5f7a", "#8fe0ff", "#0d4e6a", "#30c0ff", "#b0f0ff", "line", 128, 0.88),
    "Sunset line":      ("#7a3f5f", "#ffb0a0", "#6a0d3e", "#ff7050", "#ffd080", "line", 96, 0.86),
    "Matrix dots":      ("#1f6a2f", "#7fff8f", "#0d4e1a", "#30ff50", "#d0ffd0", "dots", 96, 0.85),
    "Candy dots":       ("#7a2f8a", "#ffa0e0", "#ff4fa0", "#60c0ff", "#ffe060", "dots", 64, 0.82),
    "Infrared":         ("#6a1f1f", "#ff8080", "#300000", "#ff2020", "#ffd0d0", "bars", 128, 0.93),
    "Broadcast clean":  ("#2a3a46", "#e6f5ff", "#2a5a72", "#7fd8ff", "#ffffff", "line", 64, 0.90),
    "Fast decay":       ("#2f6f8a", "#7fd8ff", "#0d6e8a", "#00ffcc", "#ffd166", "bars", 64, 0.55),
}


def _vis_style_path():
    try:
        import groovebox_paths
        return os.path.join(groovebox_paths.base_dir(), "media-visualizer-style.txt")
    except Exception:
        return os.path.join(os.path.expanduser("~"), ".groovebox-media-visualizer-style.txt")


def _load_vis_style():
    try:
        with open(_vis_style_path(), "r", encoding="utf-8") as f:
            name = f.read().strip()
        return name if name in VIS_STYLES else "Teal (classic)"
    except Exception:
        return "Teal (classic)"


class AudioVisualizer(QWidget):
    """Waveform overview + scope + spectrum for an audio buffer."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(320, 180)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self._x = None            # mono float32
        self._sr = 0
        self._overview = None     # (min, max) per column bucket
        self._clock = None
        self._title = ""
        self._msg = "No audio loaded"
        self._spec_smooth = None
        self._bridge = _DecodeBridge()
        self._bridge.done.connect(self._on_decoded)
        self._gen = 0
        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self.update)
        self._win = np.hanning(2048).astype(np.float32)
        self._style = _load_vis_style()
        self._ov_pix = None        # cached overview picture (size, style) -> QPixmap
        self._band_bins = None     # cached spectrum band index ranges per (sr, bands)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._style_menu)

    def _style_menu(self, pos):
        from PyQt6.QtWidgets import QMenu
        m = QMenu(self)
        m.addSection("Visualizer style")
        for name in VIS_STYLES:
            act = m.addAction(name); act.setCheckable(True); act.setChecked(name == self._style)
            act.triggered.connect(lambda _c=False, n=name: self.set_style(n))
        m.exec(self.mapToGlobal(pos))

    def set_style(self, name):
        if name not in VIS_STYLES:
            return
        self._style = name
        self._ov_pix = None; self._band_bins = None; self._spec_smooth = None
        try:
            with open(_vis_style_path(), "w", encoding="utf-8") as f:
                f.write(name)
        except Exception:
            pass
        self.update()

    def _bins(self, n, bands):
        """Start/end FFT bin per band, computed once per (sr, n, bands) instead of 64 masks per frame."""
        key = (self._sr, n, bands)
        if self._band_bins is None or self._band_bins[0] != key:
            freqs = np.fft.rfftfreq(n, 1.0 / self._sr)
            edges = np.geomspace(30.0, min(20000.0, self._sr / 2.0), bands + 1)
            lo = np.searchsorted(freqs, edges[:-1], side="left")
            hi = np.searchsorted(freqs, edges[1:], side="left")
            self._band_bins = (key, lo, hi)
        return self._band_bins[1], self._band_bins[2]

    # ------------------------------------------------------------ loading
    def set_clock(self, fn):
        """fn() -> seconds (float) or None when stopped."""
        self._clock = fn
        if not self._timer.isActive():
            self._timer.start()

    def set_audio(self, x, sr, title=""):
        x = np.asarray(x, dtype=np.float32)
        if x.ndim == 2:
            x = x.mean(axis=1) if x.shape[1] > 1 else x[:, 0]
        self._x = np.ascontiguousarray(x)
        self._sr = int(sr)
        self._title = title
        self._msg = ""
        self._overview = None
        self._spec_smooth = None
        self._ov_pix = None; self._band_bins = None
        self.update()

    def load_path(self, path, decoder, title=None):
        """Decode on a worker thread; decoder(path) -> (array, sr)."""
        self._gen += 1
        gen = self._gen
        self._msg = f"Analysing {os.path.basename(path)} …"
        self._x = None
        self.update()
        br = self._bridge

        def run():
            try:
                x, sr = decoder(path)
                br.done.emit((gen, x, title or os.path.basename(path)), int(sr), "")
            except Exception as e:
                br.done.emit((gen, None, ""), 0, str(e))
        threading.Thread(target=run, daemon=True, name="groovebox-visualizer-decode").start()

    def _on_decoded(self, payload, sr, err):
        gen, x, title = payload
        if gen != self._gen:
            return
        if err or x is None:
            self._msg = f"Visualizer: {err or 'no audio'}"
            self.update()
            return
        self.set_audio(x, sr, title)

    def clear(self, msg="No audio loaded"):
        self._gen += 1
        self._x = None
        self._msg = msg
        self.update()

    def showEvent(self, e):
        super().showEvent(e)
        if self._clock is not None and not self._timer.isActive():
            self._timer.start()

    def hideEvent(self, e):
        self._timer.stop()
        super().hideEvent(e)

    # ------------------------------------------------------------ painting
    def _ensure_overview(self, cols):
        if self._x is None:
            return None
        ov = self._overview
        if ov is not None and ov[0].size == cols:
            return ov
        n = self._x.size
        if n == 0 or cols <= 0:
            return None
        edges = np.linspace(0, n, cols + 1).astype(np.int64)
        mins = np.empty(cols, np.float32); maxs = np.empty(cols, np.float32)
        for i in range(cols):
            seg = self._x[edges[i]:max(edges[i] + 1, edges[i + 1])]
            mins[i] = seg.min(); maxs[i] = seg.max()
        self._overview = (mins, maxs)
        return self._overview

    def paintEvent(self, _e):
        with owned_painter(self) as p:
            if p is None:
                return
            try:
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                r = self.rect()
                p.fillRect(r, QColor("#05090e"))
                W, H = r.width(), r.height()
                if self._x is None or self._x.size == 0 or not self._sr:
                    p.setPen(QColor("#6f8a99"))
                    p.drawText(r, Qt.AlignmentFlag.AlignCenter, self._msg)
                    return
                pos = None
                try:
                    pos = self._clock() if self._clock is not None else None
                except Exception:
                    pos = None
                dur = self._x.size / float(self._sr)
                t = 0.0 if pos is None else max(0.0, min(dur, float(pos)))
                idx = int(t * self._sr)
                # --- overview (top 28 %)
                oh = int(H * 0.28)
                ov = self._ensure_overview(max(1, W))
                st = VIS_STYLES.get(self._style, VIS_STYLES["Teal (classic)"])
                if ov is not None:
                    mid = oh / 2.0
                    key = (W, oh, self._style, id(self._x))
                    if self._ov_pix is None or self._ov_pix[0] != key:
                        # Draw the overview once per size/style/audio, not every frame (W lines @ 30 fps).
                        pm = QPixmap(max(1, W), max(1, oh)); pm.fill(QColor(0, 0, 0, 0))
                        with owned_painter(pm) as q:
                            if q is not None:
                                try:
                                    q.setPen(QPen(QColor(st[0]), 1))
                                    mins, maxs = ov
                                    for xpx in range(0, W):
                                        q.drawLine(QPointF(xpx, mid - maxs[xpx] * mid * 0.95), QPointF(xpx, mid - mins[xpx] * mid * 0.95))
                                finally:
                                    q.end()
                        self._ov_pix = (key, pm)
                    p.drawPixmap(0, 0, self._ov_pix[1])
                    px = W * (t / dur if dur > 0 else 0)
                    p.fillRect(QRectF(0, 0, px, oh), QColor(0, 255, 200, 28))
                    p.setPen(QPen(QColor("#00ffcc"), 2)); p.drawLine(QPointF(px, 0), QPointF(px, oh))
                # --- oscilloscope (middle 30 %)
                sy, sh = oh + 4, int(H * 0.30)
                n = 2048
                seg = self._x[idx:idx + n]
                if seg.size < n:
                    seg = np.pad(seg, (0, n - seg.size))
                p.setPen(QPen(QColor("#1b2a35"), 1)); p.drawLine(0, sy + sh // 2, W, sy + sh // 2)
                step = max(1, n // max(1, W))
                pts = seg[::step][:W]
                path = QPainterPath()
                for i, v in enumerate(pts):
                    yy = sy + sh / 2.0 - float(v) * sh * 0.48
                    (path.moveTo if i == 0 else path.lineTo)(QPointF(i * W / max(1, len(pts) - 1), yy))
                p.setPen(QPen(QColor(st[1]), 1.4)); p.drawPath(path)
                # --- spectrum (bottom)
                by = sy + sh + 6
                bh = H - by - 18
                if bh > 10:
                    spec = np.abs(np.fft.rfft(seg * self._win))
                    bands = int(st[6])
                    lo, hi = self._bins(n, bands)
                    vals = np.zeros(bands, np.float32)
                    for b in range(bands):
                        if hi[b] > lo[b]:
                            vals[b] = spec[lo[b]:hi[b]].max()
                    _lin = vals / (n / 4.0)
                    with np.errstate(divide="ignore"):
                        db = 20.0 * np.log10(_lin)          # exact; silence = -inf dB
                    db = np.where(np.isfinite(db), db, -120.0)   # drawn at the bottom of the scale
                    lvl = np.clip((db + 72.0) / 72.0, 0.0, 1.0)
                    if self._spec_smooth is None or self._spec_smooth.size != bands:
                        self._spec_smooth = lvl
                    else:
                        self._spec_smooth = np.maximum(lvl, self._spec_smooth * float(st[7]))
                    bw = W / float(bands)
                    g = QLinearGradient(0, by + bh, 0, by)
                    g.setColorAt(0.0, QColor(st[2])); g.setColorAt(0.6, QColor(st[3])); g.setColorAt(1.0, QColor(st[4]))
                    mode = st[5]
                    if mode == "line":
                        path = QPainterPath()
                        for b in range(bands):
                            yy = by + bh - float(self._spec_smooth[b]) * bh
                            (path.moveTo if b == 0 else path.lineTo)(QPointF(b * bw + bw / 2, yy))
                        p.setPen(QPen(g, 2.0)); p.drawPath(path)
                    elif mode == "dots":
                        p.setPen(Qt.PenStyle.NoPen); p.setBrush(g)
                        r = max(1.5, bw * 0.35)
                        for b in range(bands):
                            yy = by + bh - float(self._spec_smooth[b]) * bh
                            p.drawEllipse(QPointF(b * bw + bw / 2, yy), r, r)
                    elif mode == "mirror":
                        mid_y = by + bh / 2.0
                        for b in range(bands):
                            hgt = float(self._spec_smooth[b]) * bh / 2.0
                            p.fillRect(QRectF(b * bw + 1, mid_y - hgt, max(1.0, bw - 2), 2 * hgt), g)
                    else:
                        for b in range(bands):
                            hgt = float(self._spec_smooth[b]) * bh
                            p.fillRect(QRectF(b * bw + 1, by + bh - hgt, max(1.0, bw - 2), hgt), g)
                # --- caption
                p.setPen(QColor("#9fb8c6"))
                mm = lambda s: f"{int(s // 60)}:{int(s % 60):02d}"
                p.drawText(QRectF(6, H - 16, W - 12, 14), Qt.AlignmentFlag.AlignLeft,
                           f"{self._title}  ·  {mm(t)} / {mm(dur)}  ·  {self._sr / 1000:g} kHz  ·  {self._style} (right-click)")
            finally:
                p.end()


class _FrameView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.img = None
        self.setMinimumSize(320, 180)

    def set_frame(self, rgb):
        frame = np.asarray(rgb)
        if frame.ndim != 3 or frame.shape[2] < 3:
            raise ValueError("Video preview expects an H x W x 3 RGB image")
        h, w = frame.shape[:2]
        if h < 1 or w < 1:
            return
        frame = np.ascontiguousarray(frame[:, :, :3], dtype=np.uint8)
        # Own the pixels independently of decoder buffers and the next frame.
        self.img = QImage(frame.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy()
        self.update()

    def paintEvent(self, _e):
        with owned_painter(self) as p:
            if p is None:
                return
            p.fillRect(self.rect(), QColor("#000"))
            if self.img is not None:
                s = self.img.size().scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio)
                x = (self.width() - s.width()) // 2; y = (self.height() - s.height()) // 2
                p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
                p.drawImage(QRectF(x, y, s.width(), s.height()), self.img)
            p.end()


class MccVideoPlayer(QDialog):
    """Native MCC player with bounded decode-ahead; the UI timer never decodes."""
    def __init__(self, path, parent=None, host=None, volume_pct=100, play_audio=None, stop_audio=None):
        super().__init__(parent)
        import mcc_media as mm
        import queue
        self._mm=mm; self.path=str(path); self.host=host
        self._play_audio=play_audio; self._stop_audio=stop_audio
        self.hdr=mm.read_header(self.path); self.fps=max(1.0,float(self.hdr.get('fps',24.0) or 24.0))
        self.setWindowFlag(Qt.WindowType.Window, True)
        self.setWindowTitle(f"Groovebox MCC player · {os.path.basename(self.path)}")
        self.setMinimumSize(480,300); self.resize(960,640)
        self.setStyleSheet("QDialog{background:#071321;color:#e4f4ff;} QLabel{color:#c5dfec;} QPushButton{background:#12344b;color:#e8fbff;border:1px solid #3d8298;border-radius:8px;padding:7px 11px;} QPushButton:hover{background:#1c5067;} QSlider::groove:horizontal{height:5px;background:#234257;} QSlider::handle:horizontal{background:#5fd0c4;width:13px;margin:-5px 0;border-radius:6px;}")
        lay=QVBoxLayout(self)
        from parametric_math_background import ParametricMathBackground
        self._math_bg=ParametricMathBackground(self); self._math_bg.lower()
        self.view=_FrameView(self); lay.addWidget(self.view,1)
        row=QHBoxLayout(); self.btn=QPushButton('⏸ Pause'); row.addWidget(self.btn)
        self.btn_restart=QPushButton('⏮ Restart'); row.addWidget(self.btn_restart)
        self.btn_fullscreen=QPushButton('⛶ Fullscreen'); row.addWidget(self.btn_fullscreen)
        self.pos=QSlider(Qt.Orientation.Horizontal); self.pos.setEnabled(False); row.addWidget(self.pos,1)
        self.time=QLabel('0:00'); row.addWidget(self.time)
        self.info=QLabel(''); self.info.setWordWrap(True); lay.addWidget(self.info)
        self._vol_lbl=QLabel('Vol'); row.addWidget(self._vol_lbl)
        self._vol_sl=QSlider(Qt.Orientation.Horizontal); self._vol_sl.setRange(0,100); self._vol_sl.setMaximumWidth(90); row.addWidget(self._vol_sl)
        lay.addLayout(row)
        self.btn.clicked.connect(self._toggle); self.btn_restart.clicked.connect(self.restart); self.btn_fullscreen.clicked.connect(self._toggle_fullscreen)
        self._vol=int(volume_pct); self._vol_sl.setValue(self._vol); self._vol_sl.valueChanged.connect(self._on_vol)
        self._timer=QTimer(self); self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.setInterval(max(8,int(1000.0/self.fps))); self._timer.timeout.connect(self._tick)
        self._queue=queue.Queue(maxsize=4); self._decode_stop=None; self._decode_thread=None
        self._decode_done=True; self._decode_error=''; self._decode_generation=0; self._shown=-1
        self._audio=None; self._audio_bridge=_DecodeBridge(self); self._audio_bridge.done.connect(self._on_audio_decoded)
        self._audio_generation=0; self._audio_loading=False; self._has_audio=bool(self.hdr.get('audio_rate'))
        self._paused=False; self._t0=0.0; self._pause_at=None; self._frames=None
        self.info.setText(f"{self.hdr.get('width')}×{self.hdr.get('height')} @ {self.fps:g} fps · lossless MCC · " + ("embedded audio on Groovebox output" if self._has_audio else "no audio track"))
        self.restart()

    def resizeEvent(self,event):
        try: self._math_bg.setGeometry(self.rect()); self._math_bg.lower()
        except Exception: pass
        super().resizeEvent(event)

    def _on_vol(self,v): self._vol=int(v)

    def _load_audio(self):
        if not self._has_audio or self._play_audio is None or self._audio_loading: return
        self._audio_loading=True; self._audio_generation+=1; gen=self._audio_generation
        def decode():
            try:
                cached=self._audio
                if cached is None: cached=self._mm.decode_audio(self.path)[:2]
                x,sr=cached
                self._audio_bridge.done.emit((gen,cached),int(sr),'')
            except Exception as exc:
                self._audio_bridge.done.emit((gen,None),0,str(exc))
        threading.Thread(target=decode,daemon=True,name='groovebox-mcc-audio-decode').start()

    def _on_audio_decoded(self,payload,sr,err):
        gen,cached=payload
        if gen!=self._audio_generation: return
        self._audio_loading=False
        if err or cached is None:
            self.info.setText(self.info.text().split(' ‖ ')[0]+f' ‖ audio failed: {err}'); return
        self._audio=cached
        try:
            x,rate=self._audio; note=self._play_audio(self.host,x,rate,self.path,self._vol)
            self.info.setText(self.info.text().split(' ‖ ')[0]+' ‖ '+str(note))
        except Exception as exc:
            self.info.setText(self.info.text().split(' ‖ ')[0]+f' ‖ audio failed: {exc}')

    def _start_video_decode(self):
        import queue
        if self._decode_stop is not None: self._decode_stop.set()
        self._decode_generation+=1; gen=self._decode_generation
        stop=threading.Event(); self._decode_stop=stop; self._queue=queue.Queue(maxsize=4)
        self._decode_done=False; self._decode_error=''; self._shown=-1
        def produce():
            try:
                for frame in self._mm.iter_video_frames(self.path):
                    if stop.is_set(): break
                    while not stop.is_set():
                        try: self._queue.put((gen,frame),timeout=.08); break
                        except queue.Full: continue
            except Exception as exc:
                self._decode_error=str(exc)
            finally:
                self._decode_done=True
        self._decode_thread=threading.Thread(target=produce,daemon=True,name='groovebox-mcc-video-decode')
        self._decode_thread.start()

    def restart(self):
        self._start_video_decode(); self._paused=False; self._t0=time.monotonic(); self._pause_at=None
        self.btn.setText('⏸ Pause'); self._load_audio(); self._timer.start()

    def _elapsed(self):
        return (self._pause_at if self._pause_at is not None else time.monotonic())-self._t0

    def _tick(self):
        frame=None; count=0; gen=self._decode_generation
        # The consumer is deliberately non-blocking. At most four ready frames
        # are popped per tick; only the newest is painted to reduce UI pressure.
        while count<4:
            try: frame_gen,candidate=self._queue.get_nowait()
            except Exception: break
            count+=1
            if frame_gen==gen: frame=candidate; self._shown+=1
        if frame is not None:
            try: self.view.set_frame(frame)
            except Exception as exc: self._decode_error=str(exc)
        if self._decode_done and self._queue.empty():
            self._timer.stop(); self._paused=True; self._frames=None; self.btn.setText('▶ Play again')
            if self._decode_error: self.info.setText(f'MCC decode error: {self._decode_error}')
        s=self._elapsed(); self.time.setText(f'{int(s//60)}:{int(s%60):02d}')

    def _toggle_fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()
        self.btn_fullscreen.setText('▣ Windowed' if self.isFullScreen() else '⛶ Fullscreen')

    def _toggle(self):
        if self._decode_done and self._queue.empty(): self.restart(); return
        from_file_player=None
        try:
            import performance as _pf; from_file_player=_pf._GB_FILE_PLAYER
        except Exception: pass
        if self._paused:
            if self._pause_at is not None: self._t0+=time.monotonic()-self._pause_at
            self._pause_at=None; self._paused=False
            if from_file_player is not None: from_file_player.paused=False
            self._timer.start(); self.btn.setText('⏸ Pause')
        else:
            self._pause_at=time.monotonic(); self._paused=True
            if from_file_player is not None: from_file_player.paused=True
            self._timer.stop(); self.btn.setText('▶ Play')

    def closeEvent(self,e):
        self._timer.stop()
        if self._decode_stop is not None: self._decode_stop.set()
        self._audio_generation+=1
        if self._stop_audio is not None and self._has_audio:
            try: self._stop_audio()
            except Exception: pass
        super().closeEvent(e)

