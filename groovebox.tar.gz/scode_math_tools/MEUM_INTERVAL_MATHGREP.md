# Meum interval / powered-reflection tools

This master adds a bounded translation-search model based on the project theory that
`M-1` coordinates intervals and that powers of `M-1` can be useful reflected
perspectives of known points.

The compiler-facing rule is conservative:

`known point -> M-1 powered perspective -> interval/min/max/direction comparison -> semantic class -> reverse grep target syntax -> certificate`

A numeric fit alone is never promoted to an exact identity. A collapse requires the
relevant observer/dependency contract and regression or reference agreement.

`problem_tensor_3d.scode` represents translation work on three axes:
source behavior, unresolved work, and desired target-language form.

`why.scode` is the provenance surface: accepted reductions retain their route and
certificate so `why()` can explain syntax, meaning, optimization, or unresolved state.
