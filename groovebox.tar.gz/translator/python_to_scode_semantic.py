#!/usr/bin/env python3
"""Whole-file Python -> sCode semantic inventory emitter.

This is intentionally conservative: it emits every function/class/state edge as
sCode records but never pretends unsupported Python behavior has been translated.
Those records become explicit `requires_native_binding` obligations.
"""
from __future__ import annotations
import ast,argparse,json,hashlib
from pathlib import Path

M=1.1975807343385265
NORM=2-M
def names(n):
    out=set()
    for x in ast.walk(n):
        if isinstance(x,ast.Name):out.add(x.id)
        elif isinstance(x,ast.Attribute):out.add(x.attr)
    return sorted(out)
def classify(src):
    q=src.lower(); tags=[]
    for t,keys in {
      "audio":["audio","voice","sample","render","wav","sound"],
      "visual":["paint","visual","frame","scene","qcolor","qpainter"],
      "game":["game","world","npc","terrain"],
      "canonical":["canonical","seed","identity","fingerprint"],
      "state":["state","playlist","project","memory","instrument"],
      "math":["meum","sin(","cos(","isn","ics","phase","tensor","operator"],
      "ui":["qwidget","qspinbox","qpushbutton","qlabel","layout"]
    }.items():
        if any(k in q for k in keys):tags.append(t)
    return tags

def emit(src_path,out_path,map_path):
    p=Path(src_path); text=p.read_text(encoding="utf-8",errors="replace"); tree=ast.parse(text)
    lines=["program GrooveboxSemanticInventory {",
           f'  source "{p.name}"',
           f'  source_sha256 "{hashlib.sha256(text.encode()).hexdigest()}"',
           f'  meum "{M:.16g}"',
           f'  normalize_key_logic "{NORM:.16g}"']
    mapping=[]
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
            nodes=[n]
        else:nodes=[]
        for n in nodes:
            seg=ast.get_source_segment(text,n) or ""
            tags=classify(seg)
            ident=f"{n.__class__.__name__}:{n.name}:{n.lineno}"
            lines += [f'  semantic "{ident}" {{',
                      f'    kind "{n.__class__.__name__}"',
                      f'    name "{n.name}"',
                      f'    line "{n.lineno}"',
                      f'    tags "{",".join(tags)}"',
                      f'    names "{",".join(names(n)[:96])}"',
                      '    status "requires_native_binding"',
                      '  }']
            mapping.append({"id":ident,"name":n.name,"line":n.lineno,"tags":tags,"status":"requires_native_binding"})
    # nested methods/functions too
    seen={m["id"] for m in mapping}
    for n in ast.walk(tree):
        if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)): continue
        ident=f"{n.__class__.__name__}:{n.name}:{n.lineno}"
        if ident in seen: continue
        seg=ast.get_source_segment(text,n) or ""; tags=classify(seg)
        lines += [f'  semantic "{ident}" {{',f'    kind "{n.__class__.__name__}"',f'    name "{n.name}"',
                  f'    line "{n.lineno}"',f'    tags "{",".join(tags)}"',f'    names "{",".join(names(n)[:96])}"',
                  '    status "requires_native_binding"','  }']
        mapping.append({"id":ident,"name":n.name,"line":n.lineno,"tags":tags,"status":"requires_native_binding"})
    lines.append("}")
    Path(out_path).write_text("\n".join(lines)+"\n")
    Path(map_path).write_text(json.dumps({"source":str(p),"count":len(mapping),"records":mapping},indent=2))
    print(f"emitted {len(mapping)} semantic records")
def main():
    ap=argparse.ArgumentParser();ap.add_argument("source");ap.add_argument("out");ap.add_argument("--map",default="groovebox_semantic_map.json")
    n=ap.parse_args();emit(n.source,n.out,n.map)
if __name__=="__main__":main()
