#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/native"
g++ -std=c++17 -O3 -flto -fPIC -fvisibility=hidden -shared "$ROOT/cpp/groovebox_accel.cpp" -o "$ROOT/native/libgroovebox_accel.so"
echo "Built native/libgroovebox_accel.so"
