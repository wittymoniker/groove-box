#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/native"
clang++ -std=c++17 -O3 -flto -fPIC -fvisibility=hidden -dynamiclib "$ROOT/cpp/groovebox_accel.cpp" -o "$ROOT/native/libgroovebox_accel.dylib"
