$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
New-Item -ItemType Directory -Force "$Root/native" | Out-Null
if (Get-Command cl.exe -ErrorAction SilentlyContinue) { cl /std:c++17 /O2 /LD "$Root/cpp/groovebox_accel.cpp" /Fe:"$Root/native/groovebox_accel.dll" } elseif (Get-Command g++.exe -ErrorAction SilentlyContinue) { g++ -std=c++17 -O3 -shared "$Root/cpp/groovebox_accel.cpp" -o "$Root/native/groovebox_accel.dll" } else { throw 'Install MSVC or MinGW-w64' }
