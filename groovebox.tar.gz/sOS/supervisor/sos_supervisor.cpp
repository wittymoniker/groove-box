// Minimal cross-platform sOS userspace supervisor.
// Executes an sBIN with the host-native sCode runtime; keeps platform details thin.
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>
namespace fs=std::filesystem;
static std::string q(const fs::path&p){return "\""+p.string()+"\"";}
int main(int argc,char**argv){
    if(argc<3){std::cerr<<"usage: sos-supervisor RUNTIME PROGRAM.sbin [args...]\n";return 2;}
    fs::path rt=argv[1], app=argv[2];
    if(!fs::exists(rt)){std::cerr<<"runtime missing\n";return 3;}
    if(!fs::exists(app)){std::cerr<<"sbin missing\n";return 4;}
    std::string cmd=q(rt)+" "+q(app);
    for(int i=3;i<argc;i++)cmd+=" \""+std::string(argv[i])+"\"";
    std::cout<<"sOS: "<<app.filename().string()<<" -> "<<rt.filename().string()<<"\n";
    return std::system(cmd.c_str());
}
