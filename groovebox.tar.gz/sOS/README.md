# sOS 0.3 Appliance Source

This is the current practical sOS direction packaged as a buildable Linux appliance layer:

- Linux kernel/drivers remain the hardware foundation for now.
- sCode is the application/runtime layer.
- Groovebox is intended to be the full-screen shell/application.
- sAssistant is reserved as a local service layer.
- systemd owns boot sequencing and recovery.
- The package is source/build infrastructure, **not a prebuilt install-ready ISO**.

## Fastest path: install the shell onto an existing Debian/Ubuntu machine

```bash
sudo ./scripts/install_existing_linux.sh
```

Then place your current Groovebox payload at:

```text
/opt/sos/apps/groovebox/
```

Preferred launch order:

1. `/opt/sos/apps/groovebox/groovebox.sbin`
2. `/opt/sos/apps/groovebox/groovebox.sC`
3. `/opt/sos/apps/groovebox/run_groovebox.py`
4. `/opt/sos/apps/groovebox/groovebox.py`

The launcher deliberately keeps this fallback order so the same OS can carry the Python reference while the pure-sCode build replaces it.

## Build a Debian root filesystem

Requires `debootstrap` and root privileges:

```bash
sudo ./scripts/build_rootfs.sh
```

Output:

```text
build/rootfs/
```

## Build an ISO scaffold

After `build_rootfs.sh`:

```bash
sudo ./scripts/build_iso.sh
```

This requires `xorriso`, `grub-pc-bin`, and `grub-efi-amd64-bin`. The script creates an ISO only when the host has the required Linux kernel/initramfs and GRUB tooling. It refuses to pretend success otherwise.

## Recovery

Boot target is intentionally reversible. `sos-groovebox.service` can be disabled and the normal graphical/login target restored:

```bash
sudo systemctl disable --now sos-groovebox.service
sudo systemctl set-default graphical.target
```

## Core semantic rule

sOS does not invent a second application-state system. Groovebox/sCode canonical state remains authoritative:

```text
seed + canonical state
        ↓
shared sCode runtime
        ↓
audio / visual / game / system projections
```
