# sOS 0.3 architecture

```text
Firmware / UEFI
      ↓
Linux kernel + existing hardware drivers
      ↓
systemd
      ↓
sOS policy/services
      ↓
sCode runtime / sBIN
      ↓
Groovebox full-screen shell
      ↓
audio | visual | game | media
```

The current design avoids rewriting stable kernel/driver work merely to rename it.
The native boundary can move downward later as sCode becomes self-hosting.

## Failure model

Automatic Groovebox restart is bounded by systemd's start-limit. A marker at
`/var/lib/sos/SAFE_MODE` prevents the launcher from entering a crash loop.

## Migration model

The same launcher accepts the mature Python reference during migration and
prefers native sCode as soon as `groovebox.sbin` or `groovebox.sC` exists.

That means the OS work and Groovebox migration can proceed in parallel.
