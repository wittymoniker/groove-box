#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

fail=0
for f in \
  "$BASE/bin/sos-run" \
  "$BASE/bin/sos-shell" \
  "$BASE/scripts/install_existing_linux.sh" \
  "$BASE/scripts/build_rootfs.sh" \
  "$BASE/scripts/build_iso.sh"; do
  if bash -n "$f"; then
    echo "PASS bash -n: ${f#$BASE/}"
  else
    fail=1
  fi
done

grep -q '^ExecStart=/usr/local/bin/sos-run groovebox$' \
  "$BASE/systemd/sos-groovebox.service" && \
  echo "PASS systemd launch target" || fail=1

grep -q '^SOS_GROOVEBOX=/opt/sos/apps/groovebox$' \
  "$BASE/etc/sos/sos.conf" && \
  echo "PASS config path" || fail=1

exit "$fail"
