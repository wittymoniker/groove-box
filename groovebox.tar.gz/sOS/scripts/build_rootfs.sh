#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run as root." >&2
  exit 1
fi

for x in debootstrap chroot; do
  command -v "$x" >/dev/null || { echo "Missing: $x" >&2; exit 2; }
done

BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$BASE/build/rootfs"
SUITE="${SOS_DEBIAN_SUITE:-bookworm}"
MIRROR="${SOS_DEBIAN_MIRROR:-http://deb.debian.org/debian}"

rm -rf "$ROOT"
mkdir -p "$ROOT"

debootstrap --arch=amd64 "$SUITE" "$ROOT" "$MIRROR"

cp /etc/resolv.conf "$ROOT/etc/resolv.conf" || true

cat >"$ROOT/etc/apt/sources.list" <<EOF
deb $MIRROR $SUITE main contrib non-free-firmware
deb $MIRROR ${SUITE}-updates main contrib non-free-firmware
deb http://security.debian.org/debian-security ${SUITE}-security main contrib non-free-firmware
EOF

chroot "$ROOT" /bin/bash -eux <<'CHROOT'
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y \
  linux-image-amd64 systemd-sysv dbus sudo ca-certificates \
  alsa-utils pipewire pipewire-audio wireplumber \
  xserver-xorg xinit openbox mesa-utils \
  python3 python3-pip python3-numpy \
  git ffmpeg
apt-get clean

echo sOS >/etc/hostname

if ! id sos >/dev/null 2>&1; then
  useradd -m -u 1000 -s /bin/bash sos
fi
echo 'sos ALL=(ALL) NOPASSWD: /bin/systemctl, /usr/bin/journalctl' >/etc/sudoers.d/sos-maintenance
chmod 0440 /etc/sudoers.d/sos-maintenance
CHROOT

install -d "$ROOT/etc/sos" "$ROOT/opt/sos/apps/groovebox" "$ROOT/opt/sos/scode"
install -m 0644 "$BASE/etc/sos/sos.conf" "$ROOT/etc/sos/sos.conf"
install -m 0755 "$BASE/bin/sos-run" "$ROOT/usr/local/bin/sos-run"
install -m 0755 "$BASE/bin/sos-shell" "$ROOT/usr/local/bin/sos-shell"
install -m 0644 "$BASE/systemd/sos-groovebox.service" "$ROOT/etc/systemd/system/sos-groovebox.service"
install -m 0644 "$BASE/systemd/sos-recovery.service" "$ROOT/etc/systemd/system/sos-recovery.service"

ln -sf /etc/systemd/system/sos-groovebox.service \
  "$ROOT/etc/systemd/system/graphical.target.wants/sos-groovebox.service"
ln -sf /etc/systemd/system/sos-recovery.service \
  "$ROOT/etc/systemd/system/multi-user.target.wants/sos-recovery.service"

mkdir -p "$ROOT/var/lib/sos" "$ROOT/var/log/sos"
chown -R 1000:1000 "$ROOT/opt/sos/apps/groovebox" "$ROOT/var/lib/sos" "$ROOT/var/log/sos"

echo "Rootfs built at: $ROOT"
