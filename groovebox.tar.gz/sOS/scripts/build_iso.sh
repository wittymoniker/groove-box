#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run as root." >&2
  exit 1
fi

for x in xorriso grub-mkrescue; do
  command -v "$x" >/dev/null || {
    echo "Missing required ISO tool: $x" >&2
    echo "Install xorriso + grub-pc-bin + grub-efi-amd64-bin." >&2
    exit 2
  }
done

BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$BASE/build/rootfs"
ISO="$BASE/build/iso"
OUT="$BASE/build/sOS-0.3-amd64.iso"

[[ -d "$ROOT" ]] || { echo "Build rootfs first." >&2; exit 3; }

KERNEL="$(find "$ROOT/boot" -maxdepth 1 -type f -name 'vmlinuz-*' | sort | tail -1)"
INITRD="$(find "$ROOT/boot" -maxdepth 1 -type f -name 'initrd.img-*' | sort | tail -1)"
[[ -f "$KERNEL" && -f "$INITRD" ]] || {
  echo "No kernel/initramfs found in rootfs." >&2
  exit 4
}

rm -rf "$ISO"
mkdir -p "$ISO/boot/grub" "$ISO/live"

cp "$KERNEL" "$ISO/live/vmlinuz"
cp "$INITRD" "$ISO/live/initrd"

# A full live root mount requires a proper initramfs/live-boot integration.
# We intentionally stop short of emitting a misleading "install-ready" ISO
# unless live-boot is present in the rootfs.
if [[ ! -e "$ROOT/usr/share/initramfs-tools/hooks/live" && ! -d "$ROOT/usr/lib/live" ]]; then
  echo "Rootfs lacks live-boot integration." >&2
  echo "Install live-boot into the rootfs before building an actually bootable live ISO." >&2
  exit 5
fi

mksquashfs "$ROOT" "$ISO/live/filesystem.squashfs" -e boot

cat >"$ISO/boot/grub/grub.cfg" <<'EOF'
set timeout=3
set default=0
menuentry "sOS 0.3" {
    linux /live/vmlinuz boot=live quiet
    initrd /live/initrd
}
menuentry "sOS 0.3 safe mode" {
    linux /live/vmlinuz boot=live systemd.unit=multi-user.target
    initrd /live/initrd
}
EOF

grub-mkrescue -o "$OUT" "$ISO"
echo "ISO created: $OUT"
