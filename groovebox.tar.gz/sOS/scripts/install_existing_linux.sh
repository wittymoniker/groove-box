#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run with sudo/root." >&2
  exit 1
fi

BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

install -d /etc/sos /opt/sos/apps/groovebox /opt/sos/scode /var/lib/sos /var/log/sos
install -m 0644 "$BASE/etc/sos/sos.conf" /etc/sos/sos.conf
install -m 0755 "$BASE/bin/sos-run" /usr/local/bin/sos-run
install -m 0755 "$BASE/bin/sos-shell" /usr/local/bin/sos-shell
install -m 0644 "$BASE/systemd/sos-groovebox.service" /etc/systemd/system/sos-groovebox.service
install -m 0644 "$BASE/systemd/sos-recovery.service" /etc/systemd/system/sos-recovery.service

if ! id sos >/dev/null 2>&1; then
  useradd -m -u 1000 -s /bin/bash sos || useradd -m -s /bin/bash sos
fi

chown -R sos:sos /opt/sos/apps/groovebox /var/lib/sos /var/log/sos /home/sos

systemctl daemon-reload
systemctl enable sos-recovery.service
systemctl enable sos-groovebox.service

cat <<'EOF'
sOS appliance layer installed.

Copy your current Groovebox tree into:
  /opt/sos/apps/groovebox/

Then:
  sudo chown -R sos:sos /opt/sos/apps/groovebox
  sudo systemctl restart sos-groovebox.service

Logs:
  journalctl -u sos-groovebox.service -f

Safe mode:
  sudo touch /var/lib/sos/SAFE_MODE
EOF
