#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ ! -f "$ROOT/native/libgroovebox_accel.so" && ! -f "$ROOT/native/libgroovebox_accel.dylib" ]]; then "$ROOT/scripts/build_linux.sh" 2>/dev/null || "$ROOT/scripts/build_macos.sh"; fi
exec python3 "$ROOT/groovebox.py" "$@"
