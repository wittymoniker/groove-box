# Groovebox — Full C++ Hot-Path Hybrid

This build keeps the canonical Python/NumPy/PyQt architecture and moves the most expensive deterministic oscillator math into a C++17 shared library.

## Native kernels

- Meum AM/FM/PM vector generation
- Canonical voice harmonic + inharmonic partial synthesis
- Master hard-clip / gain rail
- Realtime callback hard-clip / gain rail

The voice kernel receives already-resolved canonical state from Python: phase, entropy, harmonic counts, waveform selection, seed identity, and modulation parameters. This preserves Python as the source of composition/state truth while eliminating the inner harmonic/inharmonic Python loops.

The native library is built with `-O3` + LTO where supported, without `-ffast-math`, so the implementation does not intentionally relax IEEE-style floating-point behavior.

## Build

Linux:
```bash
./scripts/build_linux.sh
```

macOS:
```bash
./scripts/build_macos.sh
```

Windows PowerShell:
```powershell
./scripts/build_windows.ps1
```

## Run

```bash
./run_hybrid.sh
```

or:
```bash
python3 groovebox.py
```

If the native library cannot be loaded, the Python source automatically falls back to its NumPy implementation.

## Validation

The native voice kernel was compared against the corresponding NumPy reference for deterministic test data: max absolute error `0.0`, RMSE `0.0` for the tested canonical harmonic/inharmonic path.

A previous hard-clip benchmark also showed the native loop becoming faster on large buffers; for tiny realtime blocks, FFI/allocation overhead can make NumPy faster. The next optimization target is therefore buffer reuse and reducing Python↔native boundary crossings rather than blindly replacing every NumPy call.

## Architecture

Python/NumPy/PyQt remains responsible for UI, sequencing, composition state, seed evaluation, deterministic bookkeeping, phase carry, envelopes/gates, imported carrier handling, effect engines, and timeline routing. C++ is used where a tight contiguous numeric loop benefits most.

The package expects the project's existing companion modules (`visual_determinism`, `fractal_spatial_engine`, `dj_effects`, `composition_state`, etc.) to remain available in the normal project environment.
