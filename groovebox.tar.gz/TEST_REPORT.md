# Groovebox Python + Julia + C++ Trio — Validation Report

Date: 2026-09-03

## Executed tests

- Python syntax compilation: PASS (`groovebox.py`, `videogame_engine.py`, `benchmark_native.py`, `tests.py`)
- C++ shared library build: PASS (Linux, C++17, `-O3`, LTO)
- Exported C ABI symbols: PASS (`gb_meum_modulation_f32`, `gb_voice_synth_f32`, `gb_hardclip_f32`)
- Native voice regression tests: PASS
  - canonical harmonic/inharmonic path: exact float32 array equality
  - waveform codes 0–4: exact float32 array equality
  - GOAVA path: exact float32 array equality
- Native hardclip regression: PASS, exact float32 array equality
- Performance smoke benchmark: PASS

## Benchmark snapshot

The benchmark is machine-dependent. On the validation host, the large hardclip test completed faster in C++ than the NumPy expression. The voice kernel was numerically exact but scalar C++ transcendental evaluation was not faster than NumPy for the benchmark size. This is intentional: the next optimization opportunity is vectorized math / buffer reuse, not sacrificing canonical output for `-ffast-math`.

## Julia validation

Julia was not installed in the execution environment, so the Julia runtime could not be executed here. The Julia source was inspected and is wired to the same C ABI using `ccall`. A Julia executable on the target machine should run the included smoke/benchmark script before enabling Julia in the application.

## Determinism policy

No nondeterministic parallel accumulation was introduced. Voice output is accumulated in the existing Python-controlled order, and the C++ voice kernel computes each sample independently. `-ffast-math` was deliberately not enabled.
