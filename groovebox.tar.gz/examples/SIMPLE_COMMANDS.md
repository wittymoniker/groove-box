# sCode theorem-aware coding quick start

Search the local programming knowledgebase:

```bash
./scodec know "dynamic programming recurrence"
./scodec know "GPU logic masks"
./scodec know "secure cryptography"
```

Ask the current exact Finite-Infinity solver for a certified affine jump:

```bash
./scodec devise affine --x 3 --a 2 --b 1 --steps 100
```

Generate an exact modular recurrence candidate:

```bash
./scodec devise modular --x 4 --step 7 --steps 1000000 --modulus 16
```

Generate a finite-state transition jump:

```bash
./scodec devise transition --start A --steps 1000 --table 'A:B,B:C,C:B'
```

Generate a Meum/logic-math optimization candidate. This is deliberately marked
as requiring equivalence verification or benchmarking; it is not automatically
called exact:

```bash
./scodec devise meum --operation canonical_mix
```

Compile the high-level example into deterministic sIR:

```bash
./scodec check examples/DeviseCode.scode
./scodec compile examples/DeviseCode.scode
```
