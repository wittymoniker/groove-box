"""sCode programmer knowledgebase: searchable, local, editable, source-tagged."""
from __future__ import annotations
import json
from pathlib import Path

_DEFAULT = Path(__file__).resolve().parent.parent / "knowledge" / "programmer_knowledgebase.json"

def load_knowledge(path=None):
    p=Path(path) if path else _DEFAULT
    return json.loads(p.read_text(encoding="utf-8"))

def search_knowledge(query: str, *, limit=8, path=None):
    q=query.strip().lower()
    if not q: return []
    toks=[t for t in q.replace('/',' ').replace('-',' ').split() if t]
    rows=[]
    for item in load_knowledge(path).get("entries",[]):
        hay=" ".join(str(item.get(k,"")) for k in ("id","title","category","summary","keywords","scode_strategy")).lower()
        score=sum(4 if t in str(item.get("title","")).lower() else 1 for t in toks if t in hay)
        if score: rows.append((score,item))
    rows.sort(key=lambda x:(-x[0],x[1].get("title","")))
    return [r[1] for r in rows[:int(limit)]]
