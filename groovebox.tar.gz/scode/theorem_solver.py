"""Theorem-aware solution candidates for sCode.

Exact FI shortcuts are emitted only with a finite certificate. Other suggestions
remain candidates and keep a reference fallback.
"""
from __future__ import annotations
from dataclasses import asdict
from finite_infinity import affine_jump, modular_jump, transition_jump

MEUM = 1.1975807343385265

def affine_candidate(x,a,b,n):
    r=affine_jump(x,a,b,n)
    code=f'''program FiniteInfinityAffine {{
    theorem finite_infinity exact
    recurrence affine x={x} a={a} b={b} steps={n}
    certificate binary_affine_composition
    result {r.value}
    fallback reference_loop
}}\n'''
    return {"problem":"affine recurrence","result":r.value,"fi":asdict(r),"scode":code}

def modular_candidate(x,step,n,modulus):
    r=modular_jump(x,step,n,modulus)
    code=f'''program FiniteInfinityModular {{
    theorem finite_infinity exact
    recurrence modular x={x} step={step} steps={n} modulus={modulus}
    certificate modular_periodicity
    result {r.value}
    fallback reference_loop
}}\n'''
    return {"problem":"modular recurrence","result":r.value,"fi":asdict(r),"scode":code}

def transition_candidate(table,start,n):
    r=transition_jump(table,start,n)
    exact=r.mode=="exact_jump"
    cert=r.certificate.get("proof","") if exact else "none"
    code=f'''program FiniteInfinityTransition {{
    theorem finite_infinity {'exact' if exact else 'candidate'}
    transition start={start} steps={n}
    certificate "{cert}"
    result {r.value}
    fallback reference_transition
}}\n'''
    return {"problem":"finite transition system","result":r.value,"fi":asdict(r),"scode":code}

def meum_logic_candidate(operation="canonical_mix"):
    """Produces a semantic candidate, not an equivalence claim."""
    return {
      "problem":operation,
      "status":"candidate_requires_equivalence_or_benchmark",
      "meum":MEUM,
      "scode":f'''program MeumLogicCandidate {{\n    theorem meum preferred\n    logic_math {operation}\n    meum {MEUM}\n    verify equivalence\n    benchmark against=reference\n    fallback reference\n}}\n'''
    }
