"""sCode runtime bridge. sCode is authoritative configuration; mature host modules remain backends."""
from __future__ import annotations
from pathlib import Path
import os, sys
from .parser import parse_program, Node
from .numerals import NumeralProfile

class CapabilityError(PermissionError): pass

class SCodeRuntime:
    def __init__(self, program_path):
        self.program_path=Path(program_path).resolve()
        self.program=parse_program(self.program_path.read_text(encoding='utf-8'))
        self.profile=NumeralProfile()
        self.capabilities=set()
        self.settings={}
        self._collect(self.program.nodes)
    def _collect(self,nodes):
        for n in nodes:
            if n.kind=='numerals' and n.name:
                p=(self.program_path.parent/n.name).resolve(); self.profile=NumeralProfile.load(p)
            elif n.kind=='permit': self.capabilities.add(n.name)
            elif n.kind=='setting' and n.name: self.settings[n.name]=(n.args[0] if n.args else n.attrs.get('value',''))
            self._collect(n.children)
    def require(self,cap):
        if cap not in self.capabilities: raise CapabilityError(f'sCode capability not granted: {cap}')
    def launch_master_studio(self, argv=None):
        self.require('studio.launch')
        from groovebox import MathematiciansGrooveboxApp, QApplication
        from mcc_filetype import project_argument, register_filetype
        argv=list(sys.argv if argv is None else argv)
        app=QApplication.instance() or QApplication(argv)
        app.setApplicationName('MatGroovebox Master Studio [sCode]')
        studio=MathematiciansGrooveboxApp()
        # Expose language state to the studio without altering canonical engines.
        studio.scode_runtime=self
        studio.scode_numeral_profile=self.profile
        # Reverse-decoded translation tensor: lets the mature Python reference
        # expose progressively more sCode structure without pretending unsupported
        # native structs are already ported.
        try:
            import json, subprocess
            tensor_path=(self.program_path.parent/'generated'/'groovebox_translation_tensor.json')
            if tensor_path.exists():
                studio.scode_translation_tensor=json.loads(tensor_path.read_text(encoding='utf-8'))
            def _reverse_target(query='', resolution=8):
                tool=self.program_path.parent/'tools'/'reverse_decode_groovebox.py'
                cmd=[sys.executable,str(tool),'--resolution',str(int(resolution))]
                if query: cmd += ['--target',str(query)]
                subprocess.run(cmd,cwd=str(self.program_path.parent),check=True)
                t=(self.program_path.parent/'generated'/'groovebox_translation_tensor.json')
                data=json.loads(t.read_text(encoding='utf-8'))
                studio.scode_translation_tensor=data
                return data
            studio.scode_reverse_target=_reverse_target
        except Exception as exc:
            studio.scode_reverse_decode_error=str(exc)
        studio.show()
        register_filetype(os.path.join(os.path.dirname(__file__),'..','groovebox.py'))
        path=project_argument(argv[1:])
        if path:
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(0,lambda p=path: studio.open_project_path(p))
        return app,studio

def run_program(path, argv=None):
    rt=SCodeRuntime(path)
    app,_=rt.launch_master_studio(argv)
    return app.exec()
