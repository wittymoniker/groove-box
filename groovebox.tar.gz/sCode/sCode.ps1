$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (Get-Command py -ErrorAction SilentlyContinue) {
  & py "$Root\sCode.py" @args
} else {
  & python "$Root\sCode.py" @args
}
exit $LASTEXITCODE
