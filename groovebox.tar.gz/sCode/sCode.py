#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, stat, subprocess, sys, tempfile, platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def _runtime_path():
    b = ROOT / "bin"
    machine = platform.machine().lower()
    if os.name == "nt":
        candidates = [b / "scode-native.exe", b / "scode-native-windows-x86_64.exe"]
    elif sys.platform == "darwin":
        tag = "arm64" if machine in {"arm64", "aarch64"} else "x86_64"
        candidates = [b / "scode-native", b / f"scode-native-macos-{tag}"]
    else:
        candidates = [b / "scode-native", b / "scode-native-linux-x86_64"]
    for p in candidates:
        if p.exists():
            return p
    return candidates[0]

RUNTIME = _runtime_path()
TRANSLATOR = ROOT / 'translator' / 'source_to_sbin.py'
TAG = b'SCODEAPP1'
SOURCE_EXTS = {'.sc', '.scode'}
RUNNABLE_EXTS = SOURCE_EXTS | {'.sbin'}


def _search_roots():
    roots = []
    for p in (
        Path.cwd(),
        ROOT,
        Path.home() / 'Desktop',
        Path.home() / 'Documents',
        Path.home() / 'Downloads',
        Path.home(),
    ):
        try:
            p = p.expanduser().resolve()
        except Exception:
            continue
        if p.exists() and p not in roots:
            roots.append(p)
    return roots


def _browse_matches(name: str):
    """Browse/search the user's files for FILE.sC. Exact basename wins."""
    p = Path(name).expanduser()
    names = [p.name]
    if p.suffix.lower() not in SOURCE_EXTS:
        names += [p.name + '.sC', p.name + '.scode']
    wanted = {n.lower() for n in names}
    hits, seen = [], set()

    for root in _search_roots():
        # Fast obvious locations first.
        for n in names:
            for c in (root / n, root / 'examples' / n, root / 'scode' / 'libs' / n):
                try:
                    c = c.resolve()
                except Exception:
                    continue
                if c.is_file() and c not in seen:
                    seen.add(c)
                    hits.append(c)

        # Then browse recursively. Avoid cache/package trees that can be enormous.
        for dpath, dirs, files in os.walk(root, topdown=True, onerror=lambda _e: None):
            dirs[:] = [
                d for d in dirs
                if d not in {'.git', '.cache', 'node_modules', '__pycache__', '.local', '.cargo', '.rustup'}
            ]
            for f in files:
                if f.lower() in wanted:
                    c = (Path(dpath) / f).resolve()
                    if c not in seen:
                        seen.add(c)
                        hits.append(c)
            if len(hits) >= 64:
                break
        if hits:
            break
    return hits


def locate(name: str, browse: bool = False) -> Path:
    p = Path(name).expanduser()
    if p.exists():
        return p.resolve()

    needle = p.name.lower()
    hits = []
    if browse:
        hits = _browse_matches(name)
    else:
        for x in Path.cwd().rglob('*'):
            if x.is_file() and x.name.lower() == needle:
                hits.append(x)
        if not hits and p.suffix.lower() not in SOURCE_EXTS:
            for ext in ('.sC', '.scode'):
                for x in Path.cwd().rglob(p.name + ext):
                    hits.append(x)

    if not hits:
        where = 'your browsed files' if browse else str(Path.cwd())
        raise SystemExit(f'sCode: could not find {name!r} in {where}')

    hits = sorted(
        dict.fromkeys(x.resolve() for x in hits),
        key=lambda x: (len(x.parts), str(x).lower()),
    )
    if len(hits) > 1:
        print('sCode find: matches:', file=sys.stderr)
        for i, h in enumerate(hits[:16], 1):
            print(f'  {i}. {h}', file=sys.stderr)
        print(f'sCode find: using {hits[0]}', file=sys.stderr)
    return hits[0]


def build_sbin(src: Path, dst: Path, keep_ir: Path | None = None):
    cmd = [sys.executable, str(TRANSLATOR), str(src), str(dst)]
    if keep_ir:
        cmd.append(str(keep_ir))
    subprocess.run(cmd, check=True)


def append_exe(runtime: Path, sbin: Path, out: Path):
    data = sbin.read_bytes()
    out.write_bytes(runtime.read_bytes() + data + len(data).to_bytes(8, 'little') + TAG)
    out.chmod(out.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def parse_run_tokens(tokens):
    """Grammar: sCode run [find] FILE.sC [run as it].

    find      -> browse/search files for FILE.sC.
    run as it -> FILE.sC is the sole entry identity; every connected source is
                 compiled into and executed as part of FILE.sC.

    A .sbin is already compiled, so `sCode run FILE.sbin` executes it directly
    through the native runtime instead of attempting to parse it as UTF-8 source.
    """
    low = [t.lower() for t in tokens]
    browse = 'find' in low
    run_as_it = any(low[i:i+3] == ['run', 'as', 'it'] for i in range(max(0, len(low)-2)))
    junk = {'find', 'run', 'as', 'it', 'please', 'then'}
    cand = [t for t in tokens if t.lower() not in junk]
    if not cand:
        raise SystemExit('sCode run: give me FILE.sC or FILE.sbin (example: sCode run find FILE.sC run as it)')
    src_token = next((t for t in cand if t.lower().endswith(('.sc', '.scode', '.sbin'))), cand[0])
    p = Path(src_token).expanduser()
    if p.exists():
        return p.resolve(), browse, run_as_it
    if p.suffix.lower() == '.sbin':
        # For compiled payloads, find means browse for the exact .sbin basename.
        if browse:
            wanted=p.name.lower(); hits=[]
            for root in _search_roots():
                for dpath, dirs, files in os.walk(root, topdown=True, onerror=lambda _e: None):
                    dirs[:] = [d for d in dirs if d not in {'.git','.cache','node_modules','__pycache__','.local','.cargo','.rustup'}]
                    for f in files:
                        if f.lower()==wanted:
                            hits.append((Path(dpath)/f).resolve())
                    if hits: break
                if hits: break
            if hits: return sorted(set(hits), key=lambda x:(len(x.parts),str(x).lower()))[0], browse, run_as_it
        raise SystemExit(f'sCode: could not find {src_token!r}')
    return locate(src_token, browse=browse), browse, run_as_it


def cmd_run(tokens):
    src, _browse, run_as_it = parse_run_tokens(tokens)
    if src.suffix.lower() == '.sbin':
        mode = 'run as it' if run_as_it else 'compiled payload'
        print(f'sCode: {src} is it ({mode}) -> native runtime', file=sys.stderr)
        raise SystemExit(subprocess.run([str(RUNTIME), str(src)], cwd=str(src.parent)).returncode)

    with tempfile.TemporaryDirectory(prefix='scode-run-') as td:
        sb = Path(td) / (src.stem + '.sbin')
        ir = Path(td) / (src.stem + '.sir')
        build_sbin(src, sb, ir)
        doc = json.loads(ir.read_text(encoding='utf-8'))
        connected = doc.get('connected_sources', [])
        unresolved = doc.get('unresolved_connections', [])
        mode = 'run as it' if run_as_it else 'entry'
        print(
            f'sCode: {src} is it ({mode}); connected codes={len(connected)} -> native runtime',
            file=sys.stderr,
        )
        for c in connected:
            print(f'  connected: {c}', file=sys.stderr)
        for owner, name in unresolved:
            print(f'  unresolved connection (kept symbolic): {name} from {owner}', file=sys.stderr)
        raise SystemExit(subprocess.run([str(RUNTIME), str(sb)], cwd=str(src.parent)).returncode)


def cmd_compile(args):
    src = locate(args.source, browse=getattr(args, 'find', False))
    out = Path(args.output or src.stem).expanduser().resolve()
    with tempfile.TemporaryDirectory(prefix='scode-build-') as td:
        sb = Path(td) / (src.stem + '.sbin')
        build_sbin(src, sb, Path(args.ir).resolve() if args.ir else None)
        append_exe(RUNTIME, sb, out)
    print(out)


def cmd_find(name):
    print(locate(name, browse=True))


def cmd_analyze(source, output=None, jump='1000000'):
    src = locate(source)
    out = Path(output or (src.stem + '_infinity_lplot.svg')).expanduser().resolve()
    with tempfile.TemporaryDirectory(prefix='scode-analyze-') as td:
        sb = Path(td) / (src.stem + '.sbin')
        build_sbin(src, sb)
        rc = subprocess.run([str(RUNTIME), str(sb), '--lplot', str(out), '--jump', str(jump)]).returncode
    if rc:
        raise SystemExit(rc)
    print(out)


def cmd_shortcut(source):
    src = locate(source)
    exe = src.with_suffix('')
    ns = argparse.Namespace(source=str(src), output=str(exe), ir=None, find=False)
    cmd_compile(ns)
    desk = src.with_name(src.stem + '.desktop')
    desk.write_text(
        '[Desktop Entry]\nType=Application\nName=' + src.stem + '\nExec=' + str(exe) +
        '\nTerminal=false\nCategories=AudioVideo;\n'
    )
    desk.chmod(0o755)
    print(f'executable: {exe}\nshortcut: {desk}')


def shlex_quote(s):
    import shlex
    return shlex.quote(s)


def cmd_install_user():
    bindir = Path.home() / '.local/bin'
    bindir.mkdir(parents=True, exist_ok=True)
    wrapper = bindir / 'sCode'
    wrapper.write_text('#!/bin/sh\nexec python3 ' + shlex_quote(str(ROOT / 'sCode.py')) + ' "$@"\n')
    wrapper.chmod(0o755)

    appdir = Path.home() / '.local/share/applications'
    appdir.mkdir(parents=True, exist_ok=True)
    hold = bindir / 'sCode-open'
    runner = ROOT / 'bin' / 'scode-source-runner'
    hold.write_text('#!/bin/sh\nexec ' + shlex_quote(str(runner)) + ' "$1" ' + shlex_quote(str(wrapper)) + '\n')
    hold.chmod(0o755)

    desktop = appdir / 'scode-source.desktop'
    desktop.write_text(
        f'[Desktop Entry]\nType=Application\nName=sCode Source Runner\nExec={hold} %f\n'
        'Terminal=false\nMimeType=text/x-scode;application/x-scode-binary;\nCategories=Development;AudioVideo;\n'
    )

    mime = Path.home() / '.local/share/mime/packages'
    mime.mkdir(parents=True, exist_ok=True)
    xml = mime / 'scode.xml'
    xml.write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">'
        '<mime-type type="text/x-scode"><comment>sCode source</comment>'
        '<glob pattern="*.sC"/><glob pattern="*.scode"/></mime-type>'
        '<mime-type type="application/x-scode-binary"><comment>sCode compiled payload</comment>'
        '<glob pattern="*.sbin"/></mime-type></mime-info>'
    )

    for cmd in (
        ['update-mime-database', str(mime.parent)],
        ['update-desktop-database', str(appdir)],
        ['xdg-mime', 'default', 'scode-source.desktop', 'text/x-scode'],
        ['xdg-mime', 'default', 'scode-source.desktop', 'application/x-scode-binary'],
    ):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f'installed {wrapper}\nDouble-click associations registered for .sC/.scode and .sbin where the desktop supports XDG MIME.')


def main():
    if len(sys.argv) < 2:
        print(
            'sCode run [find] FILE.sC [run as it]\n'
            'sCode run [find] FILE.sbin [run as it]\n'
            '  find      = browse/search files for FILE.sC\n'
            '  run as it = FILE.sC is the entry; connected code runs as part of FILE.sC\n'
            'sCode find FILE.sC\n'
            'sCode analyze FILE.sC [--lplot OUT.svg] [--jump N]\n'
            'sCode compile FILE.sC [-o APP]\n'
            'sCode shortcut FILE.sC\n'
            'sCode install-user'
        )
        return

    op = sys.argv[1].lower()
    if op == 'run':
        return cmd_run(sys.argv[2:])
    if op == 'find':
        return cmd_find(sys.argv[2])
    if op in {'analyze', 'lplot'}:
        ap = argparse.ArgumentParser(prog='sCode analyze')
        ap.add_argument('source')
        ap.add_argument('--lplot', '-o', dest='output')
        ap.add_argument('--jump', default='1000000')
        a = ap.parse_args(sys.argv[2:])
        return cmd_analyze(a.source, a.output, a.jump)
    if op == 'compile':
        ap = argparse.ArgumentParser(prog='sCode compile')
        ap.add_argument('source')
        ap.add_argument('-o', '--output')
        ap.add_argument('--ir')
        ap.add_argument('--find', action='store_true')
        return cmd_compile(ap.parse_args(sys.argv[2:]))
    if op in {'shortcut', 'unlock'}:
        return cmd_shortcut(sys.argv[2])
    if op in {'install-user', 'install'}:
        return cmd_install_user()
    return cmd_run(sys.argv[1:])


if __name__ == '__main__':
    main()
