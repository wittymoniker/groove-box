#!/usr/bin/env python3
"""sNativeData v1 — lossless typed byte container for sCode/sOS.

The payload is never interpreted by the container.  Type semantics live in the
manifest, so any file/binary can round-trip exactly while sOS can dispatch it
by definition id / MIME / extension.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import argparse, hashlib, json, mimetypes, struct, time

MAGIC=b"SNDATA01"
VERSION=1
HEADER=struct.Struct("<8sIQQ")  # magic, version, manifest_len, payload_len

@dataclass
class NativeDefinition:
    definition_id:str
    original_name:str
    suffix:str
    mime:str
    byte_length:int
    sha256:str
    created_unix:int
    metadata:dict

def sha256_bytes(b:bytes)->str:
    return hashlib.sha256(b).hexdigest()

def infer_definition(path:Path, definition_id:str|None=None, metadata:dict|None=None)->NativeDefinition:
    payload=path.read_bytes()
    mime=mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return NativeDefinition(
        definition_id=definition_id or f"file:{path.suffix.lower() or 'binary'}",
        original_name=path.name,
        suffix=path.suffix,
        mime=mime,
        byte_length=len(payload),
        sha256=sha256_bytes(payload),
        created_unix=int(time.time()),
        metadata=dict(metadata or {}),
    )

def pack(src, dst, definition_id=None, metadata=None):
    src=Path(src); dst=Path(dst)
    payload=src.read_bytes()
    d=infer_definition(src, definition_id, metadata)
    manifest=json.dumps(asdict(d),sort_keys=True,separators=(",",":")).encode("utf-8")
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(HEADER.pack(MAGIC,VERSION,len(manifest),len(payload))+manifest+payload)
    return d

def read_container(path):
    raw=Path(path).read_bytes()
    if len(raw)<HEADER.size: raise ValueError("truncated sNativeData")
    magic,version,mlen,plen=HEADER.unpack_from(raw,0)
    if magic!=MAGIC: raise ValueError("not sNativeData")
    if version!=VERSION: raise ValueError(f"unsupported sNativeData version {version}")
    start=HEADER.size; end=start+mlen
    manifest=json.loads(raw[start:end].decode("utf-8"))
    payload=raw[end:end+plen]
    if len(payload)!=plen: raise ValueError("truncated payload")
    if sha256_bytes(payload)!=manifest["sha256"]: raise ValueError("payload sha256 mismatch")
    return manifest,payload

def unpack(src,dst=None):
    manifest,payload=read_container(src)
    dst=Path(dst or manifest["original_name"])
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(payload)
    return manifest,dst

def main(argv=None):
    ap=argparse.ArgumentParser(prog="snative")
    sp=ap.add_subparsers(dest="cmd",required=True)
    p=sp.add_parser("pack"); p.add_argument("src"); p.add_argument("dst"); p.add_argument("--definition")
    p=sp.add_parser("unpack"); p.add_argument("src"); p.add_argument("dst",nargs="?")
    p=sp.add_parser("info"); p.add_argument("src")
    ns=ap.parse_args(argv)
    if ns.cmd=="pack":
        d=pack(ns.src,ns.dst,ns.definition); print(json.dumps(asdict(d),indent=2))
    elif ns.cmd=="unpack":
        m,d=unpack(ns.src,ns.dst); print(d)
    else:
        m,_=read_container(ns.src); print(json.dumps(m,indent=2))
if __name__=="__main__": main()
