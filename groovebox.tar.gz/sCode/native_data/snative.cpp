// sNativeData v1 portable C++17 pack/unpack/info utility.
// Payload bytes are opaque. Manifest is stored as compact JSON text.
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs=std::filesystem;
static const char MAGIC[8]={'S','N','D','A','T','A','0','1'};
static uint64_t fnv1a64(const std::vector<unsigned char>& b){
    uint64_t h=1469598103934665603ULL;
    for(auto x:b){h^=x;h*=1099511628211ULL;} return h;
}
static std::vector<unsigned char> readall(const fs::path&p){
    std::ifstream f(p,std::ios::binary); if(!f)throw std::runtime_error("open failed: "+p.string());
    return {std::istreambuf_iterator<char>(f),{}};
}
static void w64(std::ofstream&f,uint64_t x){for(int i=0;i<8;i++)f.put((char)((x>>(i*8))&255));}
static uint64_t r64(std::ifstream&f){uint64_t x=0;for(int i=0;i<8;i++){int c=f.get();if(c<0)throw std::runtime_error("truncated");x|=(uint64_t)(unsigned char)c<<(i*8);}return x;}
static std::string esc(const std::string&s){std::string o;for(char c:s){if(c=='\\'||c=='"')o+='\\';o+=c;}return o;}
int main(int ac,char**av){try{
    if(ac<3)throw std::runtime_error("usage: snative pack SRC DST [definition] | unpack SRC DST | info SRC");
    std::string cmd=av[1]; fs::path a=av[2];
    if(cmd=="pack"){
        if(ac<4)throw std::runtime_error("pack needs DST");
        fs::path dst=av[3]; auto b=readall(a); std::string def=ac>4?av[4]:"file:"+a.extension().string();
        std::ostringstream js; js<<"{\"definition_id\":\""<<esc(def)<<"\",\"original_name\":\""<<esc(a.filename().string())
          <<"\",\"suffix\":\""<<esc(a.extension().string())<<"\",\"byte_length\":"<<b.size()
          <<",\"fnv1a64\":\""<<std::hex<<fnv1a64(b)<<"\"}";
        std::string m=js.str(); std::ofstream f(dst,std::ios::binary); if(!f)throw std::runtime_error("create failed");
        f.write(MAGIC,8); uint32_t v=1; f.write((char*)&v,4); w64(f,m.size());w64(f,b.size());f.write(m.data(),m.size());f.write((char*)b.data(),b.size());
        std::cout<<dst<<"\n";
    }else if(cmd=="unpack"||cmd=="info"){
        std::ifstream f(a,std::ios::binary);char mg[8];f.read(mg,8);if(std::string(mg,8)!=std::string(MAGIC,8))throw std::runtime_error("bad magic");
        uint32_t v=0;f.read((char*)&v,4);auto ml=r64(f),pl=r64(f);std::string m(ml,'\0');f.read(m.data(),ml);
        if(cmd=="info"){std::cout<<m<<"\n";return 0;}
        if(ac<4)throw std::runtime_error("unpack needs DST");std::vector<char>b(pl);f.read(b.data(),pl);if((uint64_t)f.gcount()!=pl)throw std::runtime_error("truncated payload");
        std::ofstream o(av[3],std::ios::binary);o.write(b.data(),b.size());std::cout<<av[3]<<"\n";
    }else throw std::runtime_error("unknown command");
    return 0;
}catch(const std::exception&e){std::cerr<<"snative: "<<e.what()<<"\n";return 2;}}
