@echo off
setlocal
set ROOT=%~dp0
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py "%ROOT%sCode.py" %*
) else (
  python "%ROOT%sCode.py" %*
)
