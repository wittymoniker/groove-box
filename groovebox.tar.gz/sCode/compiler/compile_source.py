#!/usr/bin/env python3
"""Compile current sCode source through the project's existing parser/compiler,
while always preserving .sir and .sbin as first-class artifacts."""
from pathlib import Path
import argparse, json, sys
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("source"); ap.add_argument("--out-dir",default="build")
    ap.add_argument("--project-root",default=".")
    ns=ap.parse_args()
    root=Path(ns.project_root).resolve()
    # Prefer SCODE_NATIVE_PREVIEW compiler because it handles connected sources.
    sys.path.insert(0,str(root/"SCODE_NATIVE_PREVIEW"))
    from scode.compiler import compile_file, write_ir
    from translator.sir_to_sbin import main as sir_to_sbin
    src=Path(ns.source).resolve(); out=Path(ns.out_dir).resolve(); out.mkdir(parents=True,exist_ok=True)
    sir=out/(src.stem+".sir"); sbin=out/(src.stem+".sbin")
    ir=compile_file(src); write_ir(ir,sir); sir_to_sbin(str(sir),str(sbin))
    print(sir); print(sbin)
if __name__=="__main__": main()
