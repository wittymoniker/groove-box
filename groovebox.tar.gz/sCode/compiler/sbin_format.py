"""Stable sBIN v1 codec.

sBIN is deliberately platform-neutral. Native runtimes for Linux/Windows/macOS
consume the same payload.
"""
from __future__ import annotations
import json,struct,zlib,hashlib
MAGIC=b"SCODEBIN"
HDR=struct.Struct("<8sIIQ32s")
VERSION=1
FLAG_ZLIB=1
def encode(ir:dict, compress=True)->bytes:
    raw=json.dumps(ir,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
    digest=hashlib.sha256(raw).digest()
    flags=FLAG_ZLIB if compress else 0
    body=zlib.compress(raw,9) if compress else raw
    return HDR.pack(MAGIC,VERSION,flags,len(raw),digest)+body
def decode(blob:bytes)->dict:
    magic,ver,flags,rawlen,digest=HDR.unpack_from(blob,0)
    if magic!=MAGIC or ver!=VERSION: raise ValueError("unsupported sBIN")
    body=blob[HDR.size:]; raw=zlib.decompress(body) if flags&FLAG_ZLIB else body
    if len(raw)!=rawlen: raise ValueError("sBIN length mismatch")
    if hashlib.sha256(raw).digest()!=digest: raise ValueError("sBIN sha256 mismatch")
    return json.loads(raw)
