Groovebox / sOS v33c — true clean-tree Limine + sCode bootstrap

This fixes the v33b failure:
  FAIL: no usable full Groovebox runtime initramfs was found.

v33b could rebuild a missing runtime-cache only when some full runtime foundation
still existed. v33c also handles a clean Groovebox tree that has neither the old
ISO nor runtime-cache/runtime-base.

Install over the Groovebox project root:
  cd ~/Desktop/groovebox
  unzip -o ~/Downloads/Groovebox-BUILD_ISO-R26-V33C-CLEAN-TREE-BOOTSTRAP-20260918.zip -d .
  sudo ./BUILD_ISO/RUN_ME_v33c.sh

RUN_ME_v33a.sh and RUN_ME_v33b.sh in this package forward to v33c.

Clean-tree recovery order:
  1. Use/repair a current full runtime if one exists.
  2. Search for the historical baseline archive locally.
  3. If absent, download BUILD_ISO-UEFI-HYBRID-FIX-20260917(1).zip from
     https://github.com/wittymoniker/groove-box
  4. Fill only missing baseline files; current v33c files are not overwritten.
  5. Restore a Python-capable runtime-base/initramfs.img.
  6. Run the current BUILD_ISO/build_iso.sh to regenerate the full runtime.
  7. Verify/normalize runtime-cache, apply v32x hardware recovery, then build
     the Limine + native-sCode ISO.

Expected output:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-LIMINE-SCODE-v33c.iso
