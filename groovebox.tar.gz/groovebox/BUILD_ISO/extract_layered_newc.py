#!/usr/bin/env python3
"""Low-memory extractor for gzip-compressed concatenated newc layers.

Later archive entries overwrite earlier entries, matching the effective
initramfs view.  File bodies are streamed to disk instead of retaining the
entire decompressed archive in RAM.
"""
from pathlib import Path
import gzip, os, stat, sys, shutil

MAGICS=(b'070701',b'070702')
CHUNK=1024*1024

def norm_name(name):
    while name.startswith('./'): name=name[2:]
    return name.lstrip('/')

def safe_rel(name: str):
    name=norm_name(name)
    parts=[p for p in name.split('/') if p not in ('','.')]
    if any(p=='..' for p in parts): raise RuntimeError(f'unsafe cpio path: {name!r}')
    return Path(*parts) if parts else Path('.')

def read_exact(f,n):
    out=bytearray()
    while len(out)<n:
        b=f.read(n-len(out))
        if not b: raise EOFError('unexpected EOF in newc stream')
        out+=b
    return bytes(out)

def discard(f,n):
    while n:
        b=f.read(min(CHUNK,n))
        if not b: raise EOFError('unexpected EOF while skipping newc payload')
        n-=len(b)

def find_magic(f):
    win=bytearray()
    while True:
        b=f.read(1)
        if not b: return None
        win+=b
        if len(win)>6: del win[0]
        if len(win)==6 and bytes(win) in MAGICS: return bytes(win)

def ensure_parent(path): path.parent.mkdir(parents=True,exist_ok=True)

def remove_existing(path):
    try: st=path.lstat()
    except FileNotFoundError: return
    if stat.S_ISDIR(st.st_mode) and not path.is_symlink(): shutil.rmtree(path)
    else: path.unlink()

def set_meta(out,typ,perm,uid,gid,mtime):
    if typ != stat.S_IFLNK:
        try: os.chmod(out,perm,follow_symlinks=False)
        except (PermissionError,NotImplementedError): pass
    try: os.chown(out,uid,gid,follow_symlinks=False)
    except (PermissionError,NotImplementedError): pass
    if typ != stat.S_IFLNK:
        try: os.utime(out,(mtime,mtime),follow_symlinks=False)
        except (PermissionError,NotImplementedError,OSError): pass

def main():
    if len(sys.argv)!=3:
        print('usage: extract_layered_newc.py INITRAMFS_GZ DEST',file=sys.stderr); return 2
    src=Path(sys.argv[1]); root=Path(sys.argv[2]); root.mkdir(parents=True,exist_ok=True)
    entries=trailers=0
    with gzip.open(src,'rb') as f:
        magic=find_magic(f)
        while magic is not None:
            h=magic+read_exact(f,104)
            try:
                mode=int(h[14:22],16); uid=int(h[22:30],16); gid=int(h[30:38],16)
                mtime=int(h[46:54],16); size=int(h[54:62],16)
                rdevmaj=int(h[78:86],16); rdevmin=int(h[86:94],16); namesz=int(h[94:102],16)
            except ValueError as e: raise RuntimeError('malformed newc numeric header') from e
            raw=read_exact(f,namesz); name=raw[:-1].decode('utf-8','surrogateescape')
            discard(f,(-(110+namesz))&3)
            key=norm_name(name)
            if key=='TRAILER!!!':
                discard(f,size); discard(f,(-size)&3); trailers+=1; magic=find_magic(f); continue
            rel=safe_rel(name); out=root/rel; typ=stat.S_IFMT(mode); perm=stat.S_IMODE(mode)
            if str(rel)=='.':
                discard(f,size)
            elif typ==stat.S_IFDIR:
                discard(f,size)
                if out.exists() and not out.is_dir(): remove_existing(out)
                out.mkdir(parents=True,exist_ok=True); set_meta(out,typ,perm,uid,gid,mtime)
            elif typ==stat.S_IFLNK:
                body=read_exact(f,size); ensure_parent(out); remove_existing(out)
                out.symlink_to(body.decode('utf-8','surrogateescape')); set_meta(out,typ,perm,uid,gid,mtime)
            elif typ==stat.S_IFREG:
                ensure_parent(out)
                if out.exists() and out.is_dir() and not out.is_symlink(): shutil.rmtree(out)
                elif out.exists() or out.is_symlink():
                    try: out.unlink()
                    except IsADirectoryError: shutil.rmtree(out)
                remain=size
                with open(out,'wb') as w:
                    while remain:
                        b=f.read(min(CHUNK,remain))
                        if not b: raise EOFError(f'truncated cpio body: {name}')
                        w.write(b); remain-=len(b)
                set_meta(out,typ,perm,uid,gid,mtime)
            elif typ in (stat.S_IFCHR,stat.S_IFBLK):
                discard(f,size); ensure_parent(out); remove_existing(out)
                os.mknod(out,mode,os.makedev(rdevmaj,rdevmin)); set_meta(out,typ,perm,uid,gid,mtime)
            elif typ==stat.S_IFIFO:
                discard(f,size); ensure_parent(out); remove_existing(out); os.mkfifo(out,perm); set_meta(out,typ,perm,uid,gid,mtime)
            elif typ==stat.S_IFSOCK:
                discard(f,size)
            else:
                discard(f,size); raise RuntimeError(f'unsupported cpio mode {mode:o} for {rel}')
            discard(f,(-size)&3); entries+=1
            magic=read_exact(f,6)
            if magic not in MAGICS: raise RuntimeError(f'malformed newc header after {key!r}')
    if entries==0 or trailers==0: raise RuntimeError('no usable newc archive entries/trailers found')
    print(f'PASS: layered initramfs extracted: {entries} entries across {trailers} cpio layer(s) (streaming)')
    return 0
if __name__=='__main__': raise SystemExit(main())
