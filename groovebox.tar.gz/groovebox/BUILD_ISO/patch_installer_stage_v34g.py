#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path

MARK = 'GROOVEBOX_V34G_INSTALLER_STAGE_NOHANG_20260919'

REPLACEMENT = r'''# GROOVEBOX_V34G_INSTALLER_STAGE_NOHANG_20260919
# Avoid re-entering the Debian formatter staging helper when the staged rootfs
# already has executable mkfs.ext4 and mkfs.vfat.  v32t's helper already makes
# that determination internally, but on the user's Dell build the parent build
# stopped immediately after the helper printed its no-download message.  This
# shell-side fast path removes that redundant process and the following cache
# hash when no mutation is possible.
guest_has_tool_v34g() {
  local n="$1" p
  for p in "usr/sbin/$n" "usr/bin/$n" "sbin/$n" "bin/$n"; do
    [[ -x "$ROOTFS/$p" ]] && return 0
  done
  return 1
}

echo '[v34g] checking staged Copy-to-Disk formatters'
if guest_has_tool_v34g mkfs.ext4 && guest_has_tool_v34g mkfs.vfat; then
  echo '[v34g] mkfs.ext4 + mkfs.vfat already executable in staged ROOTFS; skipping redundant v32t tool helper'
else
  echo '[v34g] staging mkfs.ext4 + mkfs.vfat without touching the live loader cache'
  LDCACHE_BEFORE=missing
  if [[ -f "$ROOTFS/etc/ld.so.cache" ]]; then
    LDCACHE_BEFORE="$(sha256sum "$ROOTFS/etc/ld.so.cache" | awk '{print $1}')"
  fi
  if command -v timeout >/dev/null 2>&1; then
    timeout 600s python3 -u "$HERE/prepare_debian_copy_tools_v32t.py" "$ROOTFS" "$BI" amd64
  else
    python3 -u "$HERE/prepare_debian_copy_tools_v32t.py" "$ROOTFS" "$BI" amd64
  fi
  LDCACHE_AFTER=missing
  if [[ -f "$ROOTFS/etc/ld.so.cache" ]]; then
    LDCACHE_AFTER="$(sha256sum "$ROOTFS/etc/ld.so.cache" | awk '{print $1}')"
  fi
  [[ "$LDCACHE_BEFORE" == "$LDCACHE_AFTER" ]] || { echo 'FAIL: v34g installer staging changed the live ld.so.cache' >&2; exit 4; }
fi
echo '[v34g] formatter stage complete; continuing to installed-root initramfs'
'''

OLD_RE = re.compile(
    r"echo '\[v32x\] staging mkfs\.ext4 \+ mkfs\.vfat without touching the live loader cache'\n"
    r"LDCACHE_BEFORE=missing\n"
    r"if \[\[ -f \"\$ROOTFS/etc/ld\.so\.cache\" \]\]; then LDCACHE_BEFORE=\"\$\(sha256sum \"\$ROOTFS/etc/ld\.so\.cache\" \| awk '\{print \$1\}'\)\"; fi\n"
    r"python3 \"\$HERE/prepare_debian_copy_tools_v32t\.py\" \"\$ROOTFS\" \"\$BI\" amd64\n"
    r"LDCACHE_AFTER=missing\n"
    r"if \[\[ -f \"\$ROOTFS/etc/ld\.so\.cache\" \]\]; then LDCACHE_AFTER=\"\$\(sha256sum \"\$ROOTFS/etc/ld\.so\.cache\" \| awk '\{print \$1\}'\)\"; fi\n"
    r"\[\[ \"\$LDCACHE_BEFORE\" == \"\$LDCACHE_AFTER\" \]\] \|\| \{ echo 'FAIL: v32t installer staging changed the live ld\.so\.cache' >&2; exit 4; \}\n"
)

def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
    if root.name != 'BUILD_ISO' and (root / 'BUILD_ISO').is_dir():
        root = root / 'BUILD_ISO'
    target = root / 'build_from_v31c_layered_cache_v32x.sh'
    if not target.is_file():
        print(f'FAIL: active v32x builder not found: {target}', file=sys.stderr)
        return 3
    text = target.read_text()
    if MARK in text:
        print('[v34g] installer-stage patch already present')
        return 0
    new, n = OLD_RE.subn(REPLACEMENT, text, count=1)
    if n != 1:
        # tolerate prior patches that kept the same entry/exit markers
        start = text.find("echo '[v32x] staging mkfs.ext4 + mkfs.vfat without touching the live loader cache'")
        end = text.find("echo '[v32x] building installed-root boot initramfs from exact storage modules'")
        if start < 0 or end < 0 or end <= start:
            print('FAIL: could not identify the v32t formatter-staging block in current v32x builder', file=sys.stderr)
            return 4
        new = text[:start] + REPLACEMENT + '\n' + text[end:]
    target.write_text(new)
    target.chmod(target.stat().st_mode | 0o111)
    print('[v34g] patched v32x formatter stage with shell-side no-op fast path + 10-minute timeout')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
