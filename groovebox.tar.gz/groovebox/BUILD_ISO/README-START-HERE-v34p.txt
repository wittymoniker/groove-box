Groovebox / sOS v34p — final runtime diagnostic injection

Fixes the booted recovery menu reporting that groovebox-runtime-check is not present.
The problem was ordering: v34o staged the checker into the v32x rootfs, but the later
Limine/sCode initramfs patch replaced /init and did not itself inject or wire the
diagnostic. v34p installs the checker again in the FINAL initramfs patch and changes
PID-1 recovery `runtime` to execute /usr/bin/groovebox-runtime-check directly.

Build:
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

Expected preflight:
  PASS: v34p runtime checker is injected both before and after final initramfs layering
  PASS: PID1 recovery runtime command executes /usr/bin/groovebox-runtime-check

After boot, at sOS> type:
  runtime

and expect:
  === Groovebox runtime check v34p ===
