Groovebox / sOS BUILD_ISO v35.21 — input + storage + seatd (Dell fix)

Extends v35.18f. Addresses the remaining physical failures on Dell laptops
(e.g. Latitude 3510):

  1. wlroots/Labwc: "no input devices" / "backend client disconnected"
     → real udev + libinput-tools + seatd started before compositor
     → sos-input-ready no longer overwritten by older v35.18e helper
  2. Copy-to-Disk: "No whole disk devices detected"
     → live rootfs storage modules + aggressive PCI/NVMe/AHCI rescan
     → installer always runs sos-storage-ready first

UI (v35.21 app layer):
  - DJ / Parametric Remix tab uses existing Performance dark-teal/gold theme
  - Web Browser tab styled to match; Network panel available even without WebEngine

Build:
  cd <extracted-groovebox-root>
  chmod +x BUILD_ISO/RUN_ME_ZERO_STATE.sh BUILD_ISO/v35_18f/*
  python3 BUILD_ISO/APPLY_v35_21_INPUT_STORAGE_SEATD_FIX.py   # idempotent
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

Expected ISO name pattern:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-YYYYMMDD-GAME-READY-UDEV-INPUT-STORAGE-v35.18f.iso
  (or v35.21-tagged if you rename after build)

After first boot on the Dell:
  - Check /var/log/sos/input-ready-v35.18f.log  → INPUT_READY|PASS
  - Check /var/log/sos/storage-ready-v35.18f.log → STORAGE_READY|PASS
  - Copy-to-Disk should list /dev/nvme0n1 or /dev/sda
  - Groovebox GUI should accept keyboard + touchpad
