Groovebox/sOS v32r — DIRECT-CTTY-DISK
2026-09-18

Reason for this update
----------------------
v32q made Copy to Disk self-contained, but the live recovery/install entry path
still inherited BusyBox cttyhack / interactive-shell job-control behavior. On
some physical boots that can still print:

  can't access tty; job control turned off

v32r removes that path completely for Copy to Disk.

What changed
------------
- Copy to Disk no longer starts through cttyhack or an interactive shell.
- A bundled Python TTY helper creates a new session, explicitly claims /dev/tty1
  with TIOCSCTTY, makes the installer process group foreground with tcsetpgrp,
  duplicates tty1 onto stdin/stdout/stderr, then execs the installer backend.
- Recovery shell uses the same helper if a shell is needed.
- If the helper cannot claim tty1 it reports a specific error instead of
  dropping into the misleading BusyBox job-control warning.
- v32q self-contained GPT/filesystem/UEFI installation remains intact.
- v32p/v32q cursor + trackpad improvements remain intact.

Build
-----
  ./RUN_ME_v32r.sh

Expected ISO
------------
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-DIRECT-CTTY-DISK-v32r.iso

Copy to Disk is destructive only after the exact ERASE /dev/... confirmation.
