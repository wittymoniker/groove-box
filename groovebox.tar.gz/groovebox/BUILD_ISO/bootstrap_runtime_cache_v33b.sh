#!/usr/bin/env bash
# GROOVEBOX_V35_1_LOW_MEMORY_CACHE_SCAN_20260919
set -euo pipefail
[[ $# -ge 1 ]] || { echo 'usage: bootstrap_runtime_cache_v33b.sh GROOVEBOX_ROOT' >&2; exit 2; }
ROOT="$(cd "$1" && pwd)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BI="$ROOT/BUILD_ISO"
CACHE="$BI/dist/runtime-cache/initramfs.full.img"
VERIFY="$HERE/verify_v31c.py"
PATCHER="$HERE/patch_bridge_v31c.py"

[[ -d "$BI" ]] || { echo "FAIL: BUILD_ISO directory missing under $ROOT" >&2; exit 3; }
mkdir -p "$BI/dist/runtime-cache"

cache_ok() {
    [[ -s "$1" ]] || return 1
    gzip -t "$1" >/dev/null 2>&1 || return 1
    python3 "$VERIFY" "$1" >/dev/null 2>&1 || return 1
}

runtime_ok() {
    local f="$1"
    [[ -s "$f" ]] || return 1
    gzip -t "$f" >/dev/null 2>&1 || return 1
    python3 - "$f" "$HERE" <<'PY' >/dev/null 2>&1
from pathlib import Path
import sys
sys.path.insert(0, sys.argv[2])
from newc_stream import scan_newc
need=[
 'opt/groovebox/scode_optimizer_bridge.py',
 'usr/bin/groovebox-appliance',
 'opt/pyvenv/bin/python3',
 'opt/groovebox/sCode/bootstrap/linux-x86_64/scode0',
]
meta,_,_=scan_newc(Path(sys.argv[1]))
missing=[x for x in need if x not in meta or meta[x][1] <= 0]
if missing: raise SystemExit('missing: '+', '.join(missing))
PY
}

if cache_ok "$CACHE"; then
    echo "PASS: v33b runtime cache already present and clean v31c: $CACHE"
    exit 0
fi

# Prefer the long-lived runtime foundation. Then accept a usable staged cache or
# the initrd currently referenced by iso-root. Never overwrite the source file.
candidates=()
add_candidate() { [[ -n "${1:-}" ]] && candidates+=("$1"); }
add_candidate "$BI/runtime-base/initramfs.img"
add_candidate "$BI/runtime-base/initramfs.full.img"
add_candidate "$BI/initramfs.img"
add_candidate "$BI/dist/runtime-cache/initramfs.img"

for f in "$BI"/dist/runtime-cache/initramfs.v31c*.img \
         "$BI"/dist/runtime-cache/initramfs.v31*.img \
         "$BI"/dist/runtime-cache/initramfs.full*.img; do
    [[ -e "$f" ]] && add_candidate "$f"
done

for tree in "$BI/iso-root" "$ROOT/iso-root"; do
    cfg="$tree/boot/grub/grub.cfg"
    if [[ -f "$cfg" ]]; then
        rel="$(awk '/^[[:space:]]*initrd([[:space:]]|$)/ {for(i=2;i<=NF;i++) if($i !~ /^--/){print $i; exit}}' "$cfg")"
        [[ -n "$rel" ]] && add_candidate "$tree/${rel#/}"
    fi
done

SRC=''
seen='|'
for f in "${candidates[@]}"; do
    [[ -n "$f" ]] || continue
    case "$seen" in *"|$f|"*) continue ;; esac
    seen+="$f|"
    if runtime_ok "$f"; then SRC="$f"; break; fi
done

if [[ -z "$SRC" ]]; then
    echo 'FAIL: no usable full Groovebox runtime initramfs was found.' >&2
    echo 'Checked the persistent runtime foundation, runtime-cache, and iso-root initrd.' >&2
    echo "Expected first-choice source: $BI/runtime-base/initramfs.img" >&2
    exit 4
fi

echo "[v33b] seeding runtime cache from: $SRC"
cp -f "$SRC" "$CACHE"
gzip -t "$CACHE"

# If the source predates clean v31c, repair only the active sCode bridge via a
# tiny later cpio overlay. This preserves the rest of the runtime byte-for-byte.
if ! python3 "$VERIFY" "$CACHE" >/dev/null 2>&1; then
    echo '[v33b] runtime source predates clean v31c; repairing sCode bridge overlay'
    WORK="$BI/dist/.v33b-cache-bootstrap"
    rm -rf "$WORK"; mkdir -p "$WORK/original" "$WORK/overlay/opt/groovebox"
    trap 'rm -rf "$WORK" 2>/dev/null || true' EXIT
    python3 - "$CACHE" "$WORK/original/scode_optimizer_bridge.py" "$HERE" <<'PY'
from pathlib import Path
import sys
sys.path.insert(0, sys.argv[3])
from newc_stream import scan_newc
name='opt/groovebox/scode_optimizer_bridge.py'
_,bodies,_=scan_newc(Path(sys.argv[1]), capture=(name,))
body=bodies.get(name)
if body is None: raise SystemExit('FAIL: active sCode bridge not found')
Path(sys.argv[2]).write_bytes(body)
PY
    cp "$WORK/original/scode_optimizer_bridge.py" "$WORK/overlay/opt/groovebox/scode_optimizer_bridge.py"
    python3 "$PATCHER" "$WORK/overlay/opt/groovebox/scode_optimizer_bridge.py"
    python3 -m py_compile "$WORK/overlay/opt/groovebox/scode_optimizer_bridge.py"
    ( cd "$WORK/overlay" && find . -print0 | LC_ALL=C sort -z | cpio --null -o --quiet -H newc --owner=0:0 ) > "$WORK/v31c-overlay.cpio"
    {
      gzip -dc "$CACHE"
      cat "$WORK/v31c-overlay.cpio"
    } | gzip -9n > "$WORK/initramfs.full.v31c.img"
    gzip -t "$WORK/initramfs.full.v31c.img"
    python3 "$VERIFY" "$WORK/initramfs.full.v31c.img"
    mv -f "$WORK/initramfs.full.v31c.img" "$CACHE"
fi

python3 "$VERIFY" "$CACHE"
sha256sum "$CACHE" > "$CACHE.sha256"
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    u="$SUDO_USER"; g="$(id -gn "$u" 2>/dev/null || printf '%s' "$u")"
    chown "$u:$g" "$CACHE" "$CACHE.sha256" 2>/dev/null || true
fi
echo "PASS: v33b runtime cache ready: $CACHE"
