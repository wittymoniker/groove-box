#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
exec "$HERE/RUN_ME_v34m.sh" "${1:-$(dirname "$HERE")}" 
