Groovebox BUILD_ISO v34g — formatter-stage no-hang patch — 2026-09-19

Fixes the build stop observed immediately after:
  [v32t-tools] mkfs.ext4 + mkfs.vfat already present; no download needed

The v32x parent builder now checks those two tools itself. If both are already
executable in the staged ROOTFS it does not launch the redundant Python staging
helper and does not hash ld.so.cache around a no-op. If staging is really needed,
the helper runs unbuffered with a 10-minute timeout. A continuation marker is
printed before the installed-root initramfs stage.

This overlay preserves v34e runtime/kernel/FFmpeg/Limine work and re-applies the
v34f Dell touchpad-priority patch when present.

Apply over ~/Desktop/groovebox, then:
  cd ~/Desktop/groovebox
  chmod +x RUN_ME_v34g.sh
  sudo ./RUN_ME_v34g.sh
