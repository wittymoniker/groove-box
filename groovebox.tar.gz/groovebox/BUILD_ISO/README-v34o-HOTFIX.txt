Overlay this ZIP into an existing v34n Groovebox project root, then run:
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

v34o fixes the full-GUI launcher using system Python instead of /opt/pyvenv,
preserves the QPA backend/input variables selected by the passing probe, and
installs the recovery `runtime` diagnostic command.
