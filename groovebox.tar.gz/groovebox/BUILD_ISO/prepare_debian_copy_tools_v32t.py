#!/usr/bin/env python3
# GROOVEBOX_R19_DEBIAN_COPY_TOOLS_NO_LDCACHE_V32T_20260918
"""Stage only mkfs.ext4 + mkfs.vfat and their ELF dependency closure.

The Fedora host downloads Debian 13 .deb files, but nothing is installed into
Fedora. Packages are unpacked into a private cache, then only the formatter
binaries, mke2fs.conf, and libraries they actually need are copied into the
staged sOS initramfs root. This avoids dragging a desktop installer stack into
sOS and avoids replacing unrelated live-runtime files.
"""
from __future__ import annotations
import hashlib, lzma, os, pathlib, re, shutil, subprocess, sys, urllib.request

if len(sys.argv) != 4:
    raise SystemExit('usage: prepare_debian_copy_tools_v32q.py ROOTFS BUILD_ISO_DIR ARCH')
root=pathlib.Path(sys.argv[1]).resolve(); bi=pathlib.Path(sys.argv[2]).resolve(); arch=sys.argv[3]
if arch!='amd64': raise SystemExit(f'FAIL: v32t supports amd64 installer tools, got {arch}')
cache=bi/'dist/installer-toolchain-cache/debian-trixie-amd64'
debdir=cache/'debs'; stage=cache/'stage'
debdir.mkdir(parents=True,exist_ok=True)

def find_in(r: pathlib.Path, name: str):
    for d in ('usr/sbin','usr/bin','sbin','bin'):
        p=r/d/name
        if p.exists() or p.is_symlink(): return p
    hits=list(r.rglob(name))
    return hits[0] if hits else None

def live_has(name:str):
    p=find_in(root,name)
    return bool(p and os.access(p,os.X_OK))
if live_has('mkfs.ext4') and live_has('mkfs.vfat'):
    print('[v32t-tools] mkfs.ext4 + mkfs.vfat already present; no download needed')
    raise SystemExit(0)

indexes=[
 'https://security.debian.org/debian-security/dists/trixie-security/main/binary-amd64/Packages.xz',
 'https://deb.debian.org/debian/dists/trixie-updates/main/binary-amd64/Packages.xz',
 'https://deb.debian.org/debian/dists/trixie/main/binary-amd64/Packages.xz',
]

def parse_index(text):
    for stanza in text.split('\n\n'):
        f={}; key=None
        for line in stanza.splitlines():
            if line[:1].isspace() and key: f[key]+=' '+line.strip()
            elif ':' in line:
                key,val=line.split(':',1); f[key]=val.strip()
        if f.get('Package'): yield f
records={}; bases={}
print('[v32t-tools] loading Debian 13 package indexes')
for url in indexes:
    try:
        with urllib.request.urlopen(url,timeout=45) as r: raw=r.read()
        text=lzma.decompress(raw).decode('utf-8','replace')
    except Exception as e:
        print(f'[v32t-tools] index unavailable: {url}: {e}',file=sys.stderr); continue
    base=url.split('/dists/',1)[0]+'/'
    for rec in parse_index(text):
        pkg=rec.get('Package','')
        if pkg and pkg not in records and rec.get('Architecture') in ('amd64','all'):
            records[pkg]=rec; bases[pkg]=base
if not records: raise SystemExit('FAIL: v32t could not read Debian 13 package indexes')

def deps(value):
    out=[]
    for group in (value or '').split(','):
        pick=None
        for alt in group.split('|'):
            alt=re.sub(r'\([^)]*\)','',alt); alt=re.sub(r'\[[^]]*\]','',alt); alt=re.sub(r'<[^>]*>','',alt).strip()
            name=alt.split(':',1)[0].strip() if alt else ''
            if name in records: pick=name; break
        if pick: out.append(pick)
    return out
queue=['e2fsprogs','dosfstools']; selected=[]; seen=set()
while queue:
    pkg=queue.pop(0)
    if pkg in seen: continue
    rec=records.get(pkg)
    if not rec: raise SystemExit(f'FAIL: Debian package unavailable: {pkg}')
    seen.add(pkg); selected.append(pkg)
    queue += deps(rec.get('Pre-Depends','')) + deps(rec.get('Depends',''))
print('[v32t-tools] formatter dependency packages: '+', '.join(selected))

def download(pkg):
    rec=records[pkg]; fn=rec.get('Filename')
    if not fn: raise SystemExit(f'FAIL: no Filename for Debian package {pkg}')
    out=debdir/pathlib.Path(fn).name; want=rec.get('SHA256','').lower()
    if out.is_file() and (not want or hashlib.sha256(out.read_bytes()).hexdigest()==want): return out
    url=bases[pkg]+fn; tmp=out.with_suffix(out.suffix+'.part'); tmp.unlink(missing_ok=True)
    print(f'[v32t-tools] download {pkg}')
    with urllib.request.urlopen(url,timeout=90) as r, tmp.open('wb') as f:
        while True:
            b=r.read(1024*1024)
            if not b: break
            f.write(b)
    if want and hashlib.sha256(tmp.read_bytes()).hexdigest()!=want:
        tmp.unlink(missing_ok=True); raise SystemExit(f'FAIL: SHA256 mismatch for {pkg}')
    tmp.replace(out); return out

if not shutil.which('ar') or not shutil.which('tar') or not shutil.which('readelf'):
    raise SystemExit('FAIL: host ar/tar/readelf required for v32q formatter staging')
if stage.exists(): shutil.rmtree(stage)
stage.mkdir(parents=True)
for pkg in selected:
    deb=download(pkg); work=cache/'extract'/pkg
    if work.exists(): shutil.rmtree(work)
    work.mkdir(parents=True)
    subprocess.run(['ar','x',str(deb)],cwd=work,check=True,stdout=subprocess.DEVNULL)
    ds=sorted(work.glob('data.tar.*'))
    if not ds: raise SystemExit(f'FAIL: {deb.name} has no data.tar.*')
    subprocess.run(['tar','-xf',str(ds[0]),'-C',str(stage)],check=True)

def guest_real(base: pathlib.Path, src: pathlib.Path):
    cur=src; seen=set()
    for _ in range(20):
        key=str(cur)
        if key in seen: break
        seen.add(key)
        if not cur.is_symlink(): return cur
        target=os.readlink(cur)
        cur=(base/target.lstrip('/')) if target.startswith('/') else (cur.parent/target)
    return cur

def search_lib(name):
    dirs=[stage/'lib64',stage/'lib/x86_64-linux-gnu',stage/'usr/lib/x86_64-linux-gnu',stage/'lib',stage/'usr/lib']
    for d in dirs:
        p=d/name
        if p.exists() or p.is_symlink(): return p
    for d in dirs:
        if d.is_dir():
            hits=list(d.glob(name+'*'))
            if hits: return hits[0]
    return None

def copy_flat(src: pathlib.Path):
    rel=src.relative_to(stage); dst=root/rel; dst.parent.mkdir(parents=True,exist_ok=True)
    # Preserve any existing live-runtime ABI file. Missing dependencies are copied
    # from the coherent Debian package stage.
    if dst.exists(): return dst
    if dst.is_symlink(): dst.unlink()
    real=guest_real(stage,src)
    if not real.is_file(): raise SystemExit(f'FAIL: staged dependency target missing: {src} -> {real}')
    shutil.copy2(real,dst)
    return dst

def elf_info(src):
    real=guest_real(stage,src)
    txt=subprocess.check_output(['readelf','-d',str(real)],text=True,stderr=subprocess.DEVNULL)
    needed=re.findall(r'\(NEEDED\).*?\[(.*?)\]',txt)
    ph=subprocess.check_output(['readelf','-l',str(real)],text=True,stderr=subprocess.DEVNULL)
    m=re.search(r'Requesting program interpreter:\s*([^\]]+)',ph)
    return needed,(m.group(1).strip() if m else None)

def copy_elf_closure(src,seen):
    real=guest_real(stage,src); key=str(real)
    if key in seen: return
    seen.add(key); copy_flat(src)
    needed,interp=elf_info(src)
    if interp:
        ip=stage/interp.lstrip('/')
        if ip.exists() or ip.is_symlink(): copy_flat(ip)
    for n in needed:
        p=search_lib(n)
        if not p: raise SystemExit(f'FAIL: dependency {n} for {src.name} not found in Debian package stage')
        copy_elf_closure(p,seen)

mke2=find_in(stage,'mke2fs'); vfat=find_in(stage,'mkfs.vfat')
if not mke2 or not vfat: raise SystemExit('FAIL: Debian formatter packages did not contain mke2fs/mkfs.vfat')
seen=set(); copy_elf_closure(mke2,seen); copy_elf_closure(vfat,seen)
# Put the executables at stable paths regardless of Debian usrmerge layout.
(root/'usr/sbin').mkdir(parents=True,exist_ok=True)
shutil.copy2(guest_real(stage,mke2),root/'usr/sbin/mke2fs')
(root/'usr/sbin/mkfs.ext4').unlink(missing_ok=True); os.symlink('mke2fs',root/'usr/sbin/mkfs.ext4')
shutil.copy2(guest_real(stage,vfat),root/'usr/sbin/mkfs.vfat')
# mke2fs uses this for ext4 defaults/features.
conf=stage/'etc/mke2fs.conf'
if conf.is_file():
    (root/'etc').mkdir(parents=True,exist_ok=True)
    if not (root/'etc/mke2fs.conf').exists(): shutil.copy2(conf,root/'etc/mke2fs.conf')
# v32t intentionally preserves the live /etc/ld.so.cache byte-for-byte.
# The formatter dependencies are placed in standard guest library directories,
# so regenerating the loader cache is unnecessary and could disturb the already
# working Qt/Python runtime.
if not live_has('mkfs.ext4') or not live_has('mkfs.vfat'):
    raise SystemExit('FAIL: v32q formatter staging finished but commands are not executable')
print('PASS: v32t staged mkfs.ext4/mkfs.vfat + required libraries without regenerating ld.so.cache')
