Groovebox / sOS BUILD_ISO R16 — v32q SELF-CONTAINED-DISK
2026-09-18

Why v32q exists
---------------
v32p correctly fixed the controlling-TTY path, but then validated a full desktop
Linux installation toolchain inside the deliberately small live initramfs.  The
live runtime does not contain bash, lsblk, parted, rsync, dracut, grub-install,
etc., so the build stopped before producing an ISO.

v32q removes that unnecessary requirement.  Copy to Disk is now designed for
this minimal sOS live runtime instead of pretending the initramfs is a complete
Debian installation environment.

Copy-to-Disk design
-------------------
- keeps the v32p /dev/tty1 TTY attachment and friendly disk picker
- uses bundled /opt/pyvenv/bin/python3 to enumerate/validate whole disks
- writes a standards-compliant GPT directly (no parted/sfdisk dependency)
- automatically downloads/extracts only Debian 13 e2fsprogs + dosfstools and
  their dependency closure into the staged live root (no Fedora installation)
- formats a 512 MiB EFI system partition and the remaining disk as ext4
- copies the configured live root using a Python copier that preserves modes,
  ownership, symlinks, hardlinks and xattrs where possible (no rsync dependency)
- builds a tiny exact-kernel installed-boot initramfs with NVMe/SATA/SCSI/USB/
  virtio/ext4 storage drivers
- builds an unsigned removable UEFI GRUB loader at EFI/BOOT/BOOTX64.EFI
- retains the exact ERASE /dev/... confirmation and refuses mounted targets
- additionally refuses the current GROOVEBOX_SOS boot medium when detectable

This development installer is UEFI-only. Secure Boot must remain disabled.

Trackpad/display
----------------
v32q keeps the working v32o/v32p trackpad, cursor synchronization and reduced
software-cursor overhead paths unchanged.

Build
-----
From anywhere inside or below ~/Desktop/groovebox after extracting this folder:

  ./RUN_ME_v32q.sh

Expected ISO:

  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-SELFCONTAINED-DISK-v32q.iso

First v32q build may download the exact Debian kernel package (if not already
cached) and the small filesystem-formatting dependency set. Later builds reuse
the BUILD_ISO/dist caches.

Copy to Disk
------------
Boot the ISO and use the GUI Copy to Disk action, or from recovery:

  sos-copy-to-disk

WARNING: Copy to Disk is intentionally destructive after the exact ERASE target
confirmation. Verify the selected whole disk carefully before confirming.
