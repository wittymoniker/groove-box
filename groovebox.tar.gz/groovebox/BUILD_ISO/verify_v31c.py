#!/usr/bin/env python3
from pathlib import Path
import sys
from newc_stream import scan_newc

MARK = "GROOVEBOX_R5_SCODE_POOL_FALLBACK_V31C_20260918"
BRIDGE = "opt/groovebox/scode_optimizer_bridge.py"

def main():
    if len(sys.argv) != 2:
        print("usage: verify_v31c.py INITRAMFS", file=sys.stderr); return 2
    meta, bodies, _ = scan_newc(Path(sys.argv[1]), capture=(BRIDGE,))
    bridge = bodies.get(BRIDGE)
    if not bridge:
        raise SystemExit("FAIL: bridge missing")
    txt = bridge.decode("utf-8", "replace")
    checks = [
        MARK,
        "def _builtin_pool_catalog():",
        'if "usage:" in msg or "groovebox_optimizer.sc" in msg:',
        "return self._builtin_pool_catalog()",
    ]
    bad = [x for x in checks if x not in txt]
    if bad:
        raise SystemExit("FAIL: v31c bridge checks missing: " + ", ".join(bad))
    if r'\"\"\"Exact host mirror' in txt:
        raise SystemExit("FAIL: malformed escaped v31 docstring still active")
    print("PASS: active initramfs bridge is clean v31c (streaming verifier)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
