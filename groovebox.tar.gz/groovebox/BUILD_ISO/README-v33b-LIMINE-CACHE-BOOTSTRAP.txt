Groovebox / sOS R25 v33b — Limine + sCode cache bootstrap fix

R24/v33a incorrectly required BUILD_ISO/dist/runtime-cache/initramfs.full.img
before the wrapper was allowed to locate and prepare the project. v33b fixes this.

Run from the Groovebox project root:

  cd ~/Desktop/groovebox
  ./RUN_ME_v33b.sh

The wrapper now locates the root by the BUILD_ISO directory, then:
1. uses an already-clean runtime-cache/initramfs.full.img when present;
2. otherwise prefers BUILD_ISO/runtime-base/initramfs.img;
3. otherwise checks staged runtime-cache or the initrd referenced by iso-root;
4. verifies the candidate is a full Groovebox runtime;
5. repairs the active sCode bridge to clean v31c when required;
6. runs the current v32x exact-module/input/display refresh;
7. converts the refreshed runtime to Limine + native sCode boot.

Expected ISO:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-LIMINE-SCODE-v33b.iso

RUN_ME_v33a.sh remains as a compatibility alias and forwards to v33b.
