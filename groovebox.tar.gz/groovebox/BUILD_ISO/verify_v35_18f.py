#!/usr/bin/env python3
from pathlib import Path
import py_compile,sys,tempfile,subprocess,os
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent).resolve()
fail=[]
def text(p):
    try:return (root/p).read_text(errors='replace')
    except Exception:return ''
def need(p,x):
    s=text(p)
    if x not in s: fail.append(f'{p}: missing {x}')
need('bootstrap_clean_tree_v33c.sh','GROOVEBOX_V35_18F_UDEV_RUNTIME_20260921')
for pkg in (' udev ',' libinput-tools ',' seatd'):
    if pkg not in ' '+text('bootstrap_clean_tree_v33c.sh')+' ': fail.append('runtime package missing:'+pkg.strip())
need('build_from_v31c_layered_cache_v32x.sh','GROOVEBOX_V35_18F_INPUT_STORAGE_FIX_20260921')
need('build_from_v31c_layered_cache_v32x.sh','bundle_live_storage_modules_v35_18f.py')
need('build_from_v31c_layered_cache_v32x.sh','patch_final_rootfs_v35_18f.py')

si=text('v35_18f/sos-input-ready-v35_18f')
if not any(x in si for x in ('GROOVEBOX_V35_18F_UDEV_INPUT_READY_20260921','GROOVEBOX_V35_21_UDEV_SEATD_INPUT_READY_20260921')):
    fail.append('v35_18f/sos-input-ready-v35_18f: missing accepted current input-ready marker')

ss=text('v35_18f/sos-storage-ready-v35_18f')
if not any(x in ss for x in ('GROOVEBOX_V35_18F_LIVE_STORAGE_READY_20260921','GROOVEBOX_V35_21_LIVE_STORAGE_READY_20260921')):
    fail.append('v35_18f/sos-storage-ready-v35_18f: missing accepted current storage-ready marker')
need('bundle_live_storage_modules_v35_18f.py',"'vmd'")
need('bundle_live_storage_modules_v35_18f.py',"'nvme'")
need('bundle_live_storage_modules_v35_18f.py',"'mmc_block'")
for p in ('APPLY_v35_18f_INPUT_STORAGE_FIX.py','verify_v35_18f.py','patch_final_rootfs_v35_18f.py','bundle_live_storage_modules_v35_18f.py','gpt_disk_v32q.py'):
    try: py_compile.compile(str(root/p),doraise=True)
    except Exception as e: fail.append(f'{p}: compile {e}')
# Synthetic final-rootfs ordering test.
with tempfile.TemporaryDirectory() as td:
    r=Path(td); (r/'usr/bin').mkdir(parents=True); (r/'usr/lib/sos').mkdir(parents=True); (r/'opt/sos').mkdir(parents=True)
    (r/'init').write_text("#!/bin/sh\nmdev -s || true\nif [ -x /usr/bin/sos-supervisor ]; then\n /usr/bin/sos-supervisor &\nfi\n/usr/bin/groovebox-appliance\n")
    (r/'usr/bin/sos-install-appliance').write_text("#!/bin/sh\nREAL=/usr/lib/sos/sos-install-appliance.real-v32q\nexec \"$REAL\" \"$@\"\n")
    os.chmod(r/'init',0o755); os.chmod(r/'usr/bin/sos-install-appliance',0o755)
    q=subprocess.run([sys.executable,str(root/'patch_final_rootfs_v35_18f.py'),str(r)],capture_output=True,text=True)
    if q.returncode: fail.append('synthetic final-rootfs patch failed:'+q.stderr)
    else:
        s=(r/'init').read_text(); a=s.find('/usr/bin/sos-input-ready'); b=s.find('/usr/bin/sos-supervisor')
        if a<0 or b<0 or a>b: fail.append('input readiness is not before supervisor in synthetic init')
        if 'sos-storage-ready' not in (r/'usr/bin/sos-install-appliance').read_text(): fail.append('installer wrapper lacks storage readiness')
if fail:
    print('FAIL: v35.18f verification')
    for x in fail: print(' -',x)
    raise SystemExit(1)
print('PASS: v35.18f real-udev input + live-storage source validation')
