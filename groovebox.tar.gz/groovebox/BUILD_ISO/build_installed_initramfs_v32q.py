#!/usr/bin/env python3
# GROOVEBOX_R16_INSTALLED_INITRAMFS_V32Q_20260918
from __future__ import annotations
import gzip, lzma, os, pathlib, re, shlex, shutil, subprocess, sys, tempfile

if len(sys.argv) != 5:
    raise SystemExit('usage: build_installed_initramfs_v32q.py ROOTFS KVER MODULE_TREE OUT')
root=pathlib.Path(sys.argv[1]).resolve(); kver=sys.argv[2]
mtree=pathlib.Path(sys.argv[3]).resolve(); out=pathlib.Path(sys.argv[4]).resolve()
if not mtree.is_dir(): raise SystemExit(f'FAIL: module tree missing: {mtree}')

readelf=shutil.which('readelf')
depmod=shutil.which('depmod')
cpio=shutil.which('cpio')
if not (readelf and depmod and cpio): raise SystemExit('FAIL: host readelf/depmod/cpio required')

busy_candidates=[root/'bin/busybox',root/'usr/bin/busybox',root/'bin/busybox.static',root/'usr/bin/busybox.static']
busy=next((p for p in busy_candidates if p.is_file()),None)
if not busy:
    raise SystemExit('FAIL: v32q installed boot initramfs requires BusyBox in the live rootfs')

# Locate a library inside the staged guest root by basename.
def root_find_lib(name:str):
    dirs=[root/'lib64',root/'lib/x86_64-linux-gnu',root/'usr/lib/x86_64-linux-gnu',root/'lib',root/'usr/lib']
    for d in dirs:
        p=d/name
        if p.is_symlink() or p.exists(): return p
    for d in dirs:
        if d.is_dir():
            hits=list(d.glob(name+'*'))
            if hits: return hits[0]
    return None

def guest_real(src:pathlib.Path):
    cur=src
    seen=set()
    for _ in range(16):
        key=str(cur)
        if key in seen: break
        seen.add(key)
        if not cur.is_symlink(): return cur
        target=os.readlink(cur)
        if target.startswith('/'):
            cur=root/target.lstrip('/')
        else:
            cur=(cur.parent/target)
    return cur

def copy_path(src:pathlib.Path, dstroot:pathlib.Path):
    rel=src.relative_to(root)
    dst=dstroot/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    # Flatten guest symlinks to bytes at the path the loader requests. Resolve
    # absolute links inside the staged guest root, never against the Fedora host.
    real=guest_real(src)
    if not real.is_file(): raise SystemExit(f'FAIL: guest file target missing: {src} -> {real}')
    shutil.copy2(real,dst)
    return dst

def elf_deps(src:pathlib.Path):
    try:
        real=guest_real(src)
        txt=subprocess.check_output([readelf,'-d',str(real)],text=True,stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        return [],None
    needed=re.findall(r'\(NEEDED\).*?\[(.*?)\]',txt)
    try:
        ph=subprocess.check_output([readelf,'-l',str(real)],text=True,stderr=subprocess.DEVNULL)
        m=re.search(r'Requesting program interpreter:\s*([^\]]+)',ph)
        interp=m.group(1).strip() if m else None
    except subprocess.CalledProcessError:
        interp=None
    return needed,interp

def add_elf_with_deps(src:pathlib.Path, dstroot:pathlib.Path, seen:set[str]):
    key=str(guest_real(src))
    if key in seen: return
    seen.add(key)
    copy_path(src,dstroot)
    needed,interp=elf_deps(src)
    if interp:
        ip=root/interp.lstrip('/')
        if ip.is_symlink() or ip.exists():
            copy_path(ip,dstroot)
    for n in needed:
        p=root_find_lib(n)
        if not p: raise SystemExit(f'FAIL: mini-initramfs dependency missing for {src}: {n}')
        add_elf_with_deps(p,dstroot,seen)

# Build an index directly from module files. Debian generates modules.dep during
# package installation, so a raw linux-image .deb may not contain it yet. modinfo
# can read dependency metadata straight from each .ko(.xz/.zst) file.
def norm_module_name(p):
    n=pathlib.Path(p).name
    n=re.sub(r'\.ko(?:\.(?:xz|gz|zst))?$','',n)
    return n.replace('-','_')
module_index={}
module_rels=[]
for p in mtree.rglob('*'):
    if p.is_file() and re.search(r'\.ko(?:\.(?:xz|gz|zst))?$',p.name):
        rel=str(p.relative_to(mtree)); module_rels.append(rel)
        module_index.setdefault(norm_module_name(p.name),rel)
if not module_rels:
    raise SystemExit(f'FAIL: no kernel modules found in {mtree}')

# Pull whole common PC storage families, then close dependency names with modinfo.
prefixes=(
    'kernel/drivers/nvme/', 'kernel/drivers/ata/', 'kernel/drivers/scsi/',
    'kernel/drivers/usb/storage/', 'kernel/drivers/usb/host/',
    'kernel/drivers/mmc/', 'kernel/drivers/virtio/', 'kernel/drivers/block/',
    'kernel/fs/ext4/'
)
selected={rel for rel in module_rels if rel.startswith(prefixes)}
for seed in ('ext4','nvme','nvme_core','ahci','libahci','sd_mod','scsi_mod','uas','usb_storage','xhci_pci','xhci_hcd','virtio_blk','virtio_scsi','virtio_pci'):
    if seed in module_index: selected.add(module_index[seed])
queue=list(selected)
while queue:
    rel=queue.pop()
    src=mtree/rel
    proc=subprocess.run(['modinfo','-F','depends',str(src)],text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    if proc.returncode!=0: continue
    for raw in proc.stdout.replace('\n',',').split(','):
        name=raw.strip().replace('-','_')
        if not name: continue
        dep_rel=module_index.get(name)
        if dep_rel and dep_rel not in selected:
            selected.add(dep_rel); queue.append(dep_rel)


def read_module(src:pathlib.Path)->bytes:
    b=src.read_bytes()
    if src.suffix=='.xz': return lzma.decompress(b)
    if src.suffix=='.gz': return gzip.decompress(b)
    if src.suffix=='.zst':
        zstd=shutil.which('zstd')
        if not zstd: raise SystemExit('FAIL: host zstd required to unpack Debian .ko.zst modules')
        return subprocess.check_output([zstd,'-dc',str(src)])
    return b

with tempfile.TemporaryDirectory(prefix='sos-installed-initrd-') as td:
    t=pathlib.Path(td)
    for d in ('bin','sbin','proc','sys','dev','newroot',f'lib/modules/{kver}'):
        (t/d).mkdir(parents=True,exist_ok=True)
    # BusyBox and dynamic closure.
    add_elf_with_deps(busy,t,set())
    bb_rel=busy.relative_to(root)
    bb_abs='/' + str(bb_rel)
    # Ensure /bin/busybox exists even if guest stores it in /usr/bin.
    if not (t/'bin/busybox').exists():
        shutil.copy2(t/bb_rel,t/'bin/busybox'); bb_abs='/bin/busybox'
    for app in ('sh','mount','umount','switch_root','mkdir','sleep','mdev','modprobe','cat','echo','ls'):
        p=t/'bin'/app
        if p.exists() or p.is_symlink(): p.unlink()
        os.symlink('busybox',p)
    # Copy selected storage modules, always decompressed to plain .ko so BusyBox
    # modprobe does not depend on xz/zstd support.
    copied=0
    for rel in sorted(selected):
        src=mtree/rel
        if not src.exists(): continue
        clean=re.sub(r'\.ko\.(xz|gz|zst)$','.ko',rel)
        dst=t/'lib/modules'/kver/clean
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(read_module(src)); copied+=1
    # Generate clean dependency metadata for the decompressed mini tree.
    subprocess.run([depmod,'-b',str(t),kver],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    init=f'''#!/bin/sh
# GROOVEBOX_R16_INSTALLED_BOOT_V32Q_20260918
PATH=/bin:/sbin
export PATH
mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sys /sys 2>/dev/null || true
mount -t devtmpfs dev /dev 2>/dev/null || true
mdev -s 2>/dev/null || true
for m in nvme nvme_core ahci libahci sd_mod scsi_mod uas usb_storage xhci_pci xhci_hcd virtio_pci virtio_blk virtio_scsi ext4; do
  modprobe "$m" 2>/dev/null || true
done
mdev -s 2>/dev/null || true
sleep 1
mkdir -p /newroot
# Find the copied sOS root by its install marker rather than relying on a
# possibly-renumbered /dev/sdX or /dev/nvmeX name.
for dev in /dev/nvme*n*p* /dev/mmcblk*p* /dev/sd*[0-9] /dev/vd*[0-9] /dev/xvd*[0-9]; do
  [ -b "$dev" ] || continue
  mount -t ext4 -o rw "$dev" /newroot 2>/dev/null || continue
  if [ -f /newroot/etc/sos/installed-appliance ]; then
    echo "sOS installed root: $dev"
    exec switch_root /newroot /init
  fi
  umount /newroot 2>/dev/null || true
done
echo 'sOS installed root was not found. Entering recovery shell.'
echo 'Block devices:'
ls /dev 2>/dev/null || true
exec sh
'''
    (t/'init').write_text(init); os.chmod(t/'init',0o755)
    out.parent.mkdir(parents=True,exist_ok=True)
    # Reproducible newc + gzip.
    cmd=f"cd {shlex.quote(str(t))} && find . -print0 | cpio --null -o -H newc --quiet | gzip -9n > {shlex.quote(str(out))}"
    subprocess.run(['/bin/sh','-c',cmd],check=True)
    if out.stat().st_size < 100000:
        raise SystemExit('FAIL: installed initramfs unexpectedly small')
    print(f'PASS: v32q installed initramfs built: {out} ({out.stat().st_size} bytes, {copied} storage modules)')

