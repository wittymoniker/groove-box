#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
if root.name!='BUILD_ISO' and (root/'BUILD_ISO').is_dir():
    root=root/'BUILD_ISO'
need={
 'build_from_v31c_layered_cache_v32x.sh':[
     'GROOVEBOX_V35_2_LIVE_INIT_SEED_20260919',
     'install -m 0755 "$HERE/init-v33a" "$ROOTFS/init"',
 ],
 'patch_input_priority_v34f.py':[
     'V35_MARKER = "GROOVEBOX_V35_RELATIVE_POINTER_20260919"',
     'v35 relative pointer policy retained',
 ],
 'verify_input_priority_v34f.py':[
     "V35_MARKER='GROOVEBOX_V35_RELATIVE_POINTER_20260919'",
     'superseding v35 REL_X+REL_Y pointer policy',
 ],
 'RUN_ME_GAME_READY_v35.sh':['GROOVEBOX_V35_2_INIT_POINTER_PRESERVE_20260919'],
}
for rel,toks in need.items():
    p=root/rel
    if not p.is_file():
        raise SystemExit('FAIL: missing '+rel)
    s=p.read_text(errors='strict')
    for tok in toks:
        if tok not in s:
            raise SystemExit(f'FAIL: {rel} missing {tok}')
for rel in ('RUN_ME_GAME_READY_v35.sh','build_from_v31c_layered_cache_v32x.sh'):
    if subprocess.run(['/bin/bash','-n',str(root/rel)]).returncode:
        raise SystemExit('FAIL: syntax '+rel)
if subprocess.run(['/bin/sh','-n',str(root/'init-v33a')]).returncode:
    raise SystemExit('FAIL: syntax init-v33a')
for rel in ('patch_input_priority_v34f.py','verify_input_priority_v34f.py'):
    if subprocess.run([sys.executable,'-m','py_compile',str(root/rel)]).returncode:
        raise SystemExit('FAIL: compile '+rel)
print('PASS: v35.2 /init restoration + v35 relative-pointer preservation source guards')
