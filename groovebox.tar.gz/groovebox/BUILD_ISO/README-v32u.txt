Groovebox BUILD_ISO R20 / v32u — INSTALLED-INITRAMFS MARKER FIX — 2026-09-18

Run:
  ./RUN_ME_v32u.sh

Expected ISO:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-INSTALLED-INITRAMFS-MARKER-FIX-v32u.iso

Fix over v32t:
- v32t's installed-initramfs builder carried the R19 no-job-control marker only in
  the Python source file, while verify_installer_payload_v32t.py correctly looked
  for that marker inside the generated gzip/newc initramfs.
- v32u embeds GROOVEBOX_R19_INSTALLED_INITRAMFS_NOJOB_V32T_20260918 directly in
  the generated /init, so the payload verifier and generated payload agree.
- No runtime logic is reverted: v32o GUI/input restoration, direct console I/O,
  self-contained Copy-to-Disk, exact Debian kernel/module staging, and no
  interactive BusyBox recovery shell remain in place.
