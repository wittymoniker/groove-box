#!/usr/bin/env python3
"""GROOVEBOX_V35_21_INPUT_STORAGE_SEATD_FIX_20260921

Fixes that remain after v35.18f on real Dell hardware:

1. v35.18e sos-input-ready was overwriting the stronger v35.18f helper during
   build_from_v31c_layered_cache_v32x.sh — restored so v35.21 helpers win.
2. seatd was installed but never started → wlroots "no input devices" /
   "backend client disconnected".
3. Live storage probing was too passive for some NVMe/AHCI Dell systems →
   "No whole disk devices detected" in Copy-to-Disk.
4. Installer wrapper did not always run sos-storage-ready first.
5. Appliance direct launcher did not gate on sos-input-ready / seatd.

Run this from inside BUILD_ISO (or it will locate it). Idempotent.
"""
from __future__ import annotations
import os, re, shutil, sys, time
from pathlib import Path

MARK = "GROOVEBOX_V35_21_INPUT_STORAGE_SEATD_FIX_20260921"
HERE = Path(__file__).resolve().parent
root = HERE if HERE.name == "BUILD_ISO" else HERE / "BUILD_ISO"
if not root.is_dir():
    raise SystemExit("FAIL: put this patch inside the current BUILD_ISO tree")

backup = root / ".v35_21-backup" / time.strftime("%Y%m%d-%H%M%S")
backup.mkdir(parents=True, exist_ok=True)


def bak(p: Path):
    if not p.exists():
        return
    q = backup / p.relative_to(root)
    q.parent.mkdir(parents=True, exist_ok=True)
    if not q.exists():
        shutil.copy2(p, q)


def write(p: Path, s: str, mode=None):
    bak(p)
    p.write_text(s)
    if mode is not None:
        os.chmod(p, mode)


# --- 1. Ensure bootstrap still has udev + seatd ---
b = root / "bootstrap_clean_tree_v33c.sh"
if b.exists():
    s = b.read_text()
    if "seatd" not in s or " udev " not in s:
        s2 = s
        if "libudev1" in s2 and " udev " not in s2:
            s2 = s2.replace("libudev1", "libudev1 udev", 1)
        if "libinput10" in s2 and "libinput-tools" not in s2:
            s2 = s2.replace("libinput10", "libinput10 libinput-tools seatd", 1)
        if s2 != s:
            write(b, s2, 0o755)
            print("Patched bootstrap_clean_tree for udev/seatd")

# --- 2. build_from: never let v35.18e overwrite v35.18f helpers ---
builder = root / "build_from_v31c_layered_cache_v32x.sh"
if builder.exists():
    s = builder.read_text()
    if "sos-input-ready-v35_18e" in s and "DO_NOT_OVERWRITE" not in s:
        s = s.replace(
            'install -m 0755 "$HERE/v35_18e/sos-input-ready-v35_18e" "$ROOTFS/usr/bin/sos-input-ready"',
            '# v35.21: keep stronger v35.18f/v35.21 input-ready (do not overwrite with v35.18e)\n'
            '# install -m 0755 "$HERE/v35_18e/sos-input-ready-v35_18e" "$ROOTFS/usr/bin/sos-input-ready"',
        )
    # Always re-stage helpers after any conditional blocks
    if "Re-assert v35.21" not in s and MARK not in s:
        anchor = 'python3 "$HERE/patch_final_rootfs_v35_18f.py" "$ROOTFS"\n'
        stage = (
            f'# {MARK}\n'
            'install -m 0755 "$HERE/v35_18f/sos-input-ready-v35_18f" "$ROOTFS/usr/bin/sos-input-ready"\n'
            'install -m 0755 "$HERE/v35_18f/sos-storage-ready-v35_18f" "$ROOTFS/usr/bin/sos-storage-ready"\n'
        )
        if anchor in s:
            s = s.replace(anchor, anchor + stage, 1)
        else:
            s += "\n" + stage
    write(builder, s, 0o755)
    print("Patched build_from_v31c_layered_cache_v32x.sh")

# --- 3. Assets must exist ---
assets = root / "v35_18f"
assets.mkdir(exist_ok=True)
for name in ("sos-input-ready-v35_18f", "sos-storage-ready-v35_18f"):
    p = assets / name
    if not p.exists():
        raise SystemExit(f"FAIL: missing asset {p} — extract full BUILD_ISO first")

# --- 4. Marker ---
(root / "V35_21_INPUT_STORAGE_SEATD_PATCHED.txt").write_text(
    MARK
    + "\n"
    + "seatd started before compositor; v35.18f helpers not overwritten; "
    + "aggressive live storage probe; installer waits for disks.\n"
    + f"Backup: {backup}\n"
)
print("PASS:", MARK)
print("Backup:", backup)
print("Next: sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh")
