Groovebox BUILD_ISO v34o — GUI runtime / QPA preservation repair — 2026-09-19

Fixes the bare-metal symptom where the Qt display/input probe passes, the Dell
keyboard/touchpad are selected correctly, but the full Groovebox GUI exits and
recovery reports that it could not stay running.

Root causes corrected:
1. The probe used /opt/pyvenv/bin/python3 (where PyQt6/audio packages are), but
   groovebox-appliance.real launched run_groovebox.py with /usr/bin/python3.
2. After a successful eglfs/linuxfb probe, groovebox-appliance.real could replace
   the selected QT_QPA_PLATFORM with linuxfb, so the real GUI was not using the
   same backend/input environment that had just passed.
3. The recovery menu advertised `runtime`, but groovebox-runtime-check was never
   installed into the live rootfs.

v34o makes the real GUI venv-Python-first, preserves the successful QPA backend
and explicit event0/event2 keyboard/touchpad environment, and installs a runtime
diagnostic command that also tails the last GUI log.

Run: sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh
