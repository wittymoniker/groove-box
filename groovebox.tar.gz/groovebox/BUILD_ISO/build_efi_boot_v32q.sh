#!/usr/bin/env bash
# GROOVEBOX_R16_EFI_BOOT_V32Q_20260918
set -euo pipefail
ROOTFS=${1:?ROOTFS required}
KVER=${2:?kernel release required}
OUTDIR="$ROOTFS/opt/sos/install-v32q"
mkdir -p "$OUTDIR"
CFG="$OUTDIR/grub-installed.cfg"
cat > "$CFG" <<EOF
set timeout=4
set default=0
search --no-floppy --label sOS_ROOT --set=root
menuentry 'sOS / Mathematician\x27s Groovebox' {
  search --no-floppy --label sOS_ROOT --set=root
  linux /boot/vmlinuz-$KVER sos.installed=1 sos.mode=live rw
  initrd /boot/initramfs-sos-$KVER.img
}
menuentry 'sOS Safe / Recovery' {
  search --no-floppy --label sOS_ROOT --set=root
  linux /boot/vmlinuz-$KVER sos.installed=1 sos.mode=live sos.safe=1 rw
  initrd /boot/initramfs-sos-$KVER.img
}
EOF

STAND=''
for x in grub2-mkstandalone grub-mkstandalone; do command -v "$x" >/dev/null 2>&1 && { STAND=$(command -v "$x"); break; }; done
if [[ -n "$STAND" ]]; then
  "$STAND" -O x86_64-efi -o "$OUTDIR/BOOTX64.EFI" "boot/grub/grub.cfg=$CFG"
else
  IMG=''
  for x in grub2-mkimage grub-mkimage; do command -v "$x" >/dev/null 2>&1 && { IMG=$(command -v "$x"); break; }; done
  [[ -n "$IMG" ]] || { echo 'FAIL: grub2-mkstandalone/grub2-mkimage missing on Fedora host' >&2; exit 31; }
  "$IMG" -O x86_64-efi -o "$OUTDIR/BOOTX64.EFI" -p /EFI/sOS -c "$CFG" \
    part_gpt fat ext2 normal linux search search_label configfile echo reboot
fi
[[ -s "$OUTDIR/BOOTX64.EFI" ]] || { echo 'FAIL: BOOTX64.EFI not produced' >&2; exit 32; }
echo "PASS: v32q removable UEFI loader built: $OUTDIR/BOOTX64.EFI"
