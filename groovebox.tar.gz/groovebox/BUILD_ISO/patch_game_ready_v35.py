#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path

MARK='GROOVEBOX_V35_GAME_READY_INPUT_INSTALL_20260919'
PTR_MARK='GROOVEBOX_V35_RELATIVE_POINTER_20260919'
CUR_MARK='GROOVEBOX_V35_MODAL_CURSOR_SYNC_20260919'
INSTALL_MARK='GROOVEBOX_V35_INSTALL_DISPATCH_20260919'

POINTER_BLOCK=r'''# GROOVEBOX_V35_RELATIVE_POINTER_20260919
# Game-ready pointer policy: Qt evdev-mouse is only bound to a device that
# actually publishes BOTH REL_X and REL_Y.  Dell I2C touchpads often expose a
# companion "... Mouse" REL node plus a "... Touchpad" ABS node.  Binding the
# ABS node with Qt's `abs` option maps finger position across the whole screen;
# that is touchscreen semantics, not trackpad semantics.
event_has_rel_xy() {
  ev="$(basename "$1")"
  bits="$(cat "/sys/class/input/$ev/device/capabilities/rel" 2>/dev/null | awk '{print $NF}')"
  [ -n "$bits" ] || return 1
  case "$bits" in *[!0-9A-Fa-f]*) return 1;; esac
  val=$((0x$bits))
  [ $((val & 3)) -eq 3 ]
}
list_pointer_events() {
  awk '
    /^N: Name=/ {name=tolower($0); ev=""; mouse=0}
    /^H: Handlers=/ {
      mouse=($0 ~ /(^| )mouse[0-9]+( |$)/)
      for (i=1;i<=NF;i++) if ($i ~ /^event[0-9]+$/) ev=$i
      if (ev != "" && (mouse || name ~ /touchpad|trackpoint|pointing stick|mouse|synaptics|elan|alps/)) print "/dev/input/" ev
    }' /proc/bus/input/devices 2>/dev/null | awk '!seen[$0]++'
}
find_pointer_event() {
  # First pass: capability is authoritative. This picks Dell's relative
  # companion Mouse node instead of the absolute Touchpad node when both exist.
  for ev in $(list_pointer_events); do
    if event_has_rel_xy "$ev"; then printf '%s\n' "$ev"; return 0; fi
  done
  # No REL pointer: do not coerce an ABS touchpad into mouse `abs` mode. The
  # launcher already tries Qt/libinput before explicit evdev and will continue
  # through its other input backends.
  return 1
}
find_pointer_name() {
  ev="$(basename "${PTR_EVENT:-}")"
  [ -n "$ev" ] || return 0
  awk -v want="$ev" '
    /^N: Name=/ {name=$0}
    /^H: Handlers=/ {
      for (i=1;i<=NF;i++) if ($i == want) {print name; exit}
    }' /proc/bus/input/devices 2>/dev/null
}
'''

CURSOR_CODE=r'''"""Groovebox/sOS v35 modal-safe bare-metal cursor synchronization.

Used only when GROOVEBOX_SOFTWARE_CURSOR=1.  Keeps one lightweight child cursor
per active top-level and switches cleanly to modal dialogs instead of leaving the
visible cursor attached to the blocked parent window.
"""
# GROOVEBOX_V35_MODAL_CURSOR_SYNC_20260919
from __future__ import annotations
import os

if os.environ.get("GROOVEBOX_SOFTWARE_CURSOR") == "1":
    try:
        from PyQt6.QtCore import QEvent, Qt
        from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen
        from PyQt6.QtWidgets import QApplication, QWidget
        _orig_notify = QApplication.notify
        _mouse_types = {
            QEvent.Type.MouseMove,
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseButtonRelease,
            QEvent.Type.MouseButtonDblClick,
        }

        class _GrooveboxCursorV35(QWidget):
            def __init__(self, parent: QWidget):
                super().__init__(parent)
                self.resize(28, 36)
                self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
                self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
                self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
                self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                self._last_xy = None
                self.show(); self.raise_()
            def set_event_position(self, x: int, y: int) -> None:
                xy=(max(-2,int(x)-2), max(-2,int(y)-2))
                if xy == self._last_xy: return
                self._last_xy=xy; self.move(*xy)
                if not self.isVisible(): self.show()
                self.raise_()
            def paintEvent(self, event):
                p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
                path=QPainterPath(); path.moveTo(2,2); path.lineTo(2,27); path.lineTo(8,21)
                path.lineTo(13,33); path.lineTo(18,31); path.lineTo(13,19); path.lineTo(22,19); path.closeSubpath()
                p.setPen(QPen(QColor(0,0,0),4)); p.setBrush(QColor(255,255,255)); p.drawPath(path)
                p.setPen(QPen(QColor(255,255,255),1)); p.drawPath(path)

        def _target_and_pos(receiver, event):
            if not isinstance(receiver, QWidget): return None, None
            modal=QApplication.activeModalWidget()
            top=modal if isinstance(modal,QWidget) and modal.isVisible() else receiver.window()
            if top is None or not top.isVisible(): return None, None
            try:
                gp=event.globalPosition().toPoint()
                return top, top.mapFromGlobal(gp)
            except Exception:
                pass
            try:
                lp=event.position().toPoint(); src=receiver.window()
                gp=src.mapToGlobal(receiver.mapTo(src,lp))
                return top, top.mapFromGlobal(gp)
            except Exception:
                return None, None

        def _hide_other_overlays(active):
            try:
                for w in QApplication.topLevelWidgets():
                    if w is active: continue
                    c=getattr(w,"_groovebox_cursor_overlay_v35",None)
                    if c is not None and c.isVisible(): c.hide()
            except Exception:
                pass

        def _notify(self, receiver, event):
            result=_orig_notify(self, receiver, event)
            try:
                if event.type() in _mouse_types:
                    top,pos=_target_and_pos(receiver,event)
                    if top is not None and pos is not None:
                        _hide_other_overlays(top)
                        cur=getattr(top,"_groovebox_cursor_overlay_v35",None)
                        if cur is None:
                            cur=_GrooveboxCursorV35(top)
                            setattr(top,"_groovebox_cursor_overlay_v35",cur)
                        cur.set_event_position(pos.x(),pos.y())
            except Exception:
                pass
            return result
        QApplication.notify=_notify
    except Exception:
        pass
'''

def patch_launcher(p: Path) -> bool:
    s=p.read_text(errors='strict')
    if 'QT_QPA_EVDEV_MOUSE_PARAMETERS' not in s or 'find_pointer_event' not in s:
        return False
    # Replace v34f (or older) discovery section through find_pointer_name(), keeping
    # keyboard code immediately before and KBD_EVENT assignment immediately after.
    start=s.find('# GROOVEBOX_V34F_TOUCHPAD_PRIORITY_20260919')
    if start < 0:
        start=s.find('find_pointer_event() {')
    end=s.find('\nKBD_EVENT=', start)
    if start < 0 or end < 0:
        raise RuntimeError(f'cannot locate pointer discovery block in {p}')
    s=s[:start]+POINTER_BLOCK+s[end+1:]
    # New finder only returns a REL_X+REL_Y node. Replace old capability/ABS mode block.
    m=re.search(r'pointer_has_rel_xy\(\) \{.*?echo "\[v32o\] pointer coordinate mode: \$PTR_COORD_MODE"\n', s, re.S)
    repl=("PTR_COORD_MODE=relative\n"
          "if [ -n \"$PTR_EVENT\" ]; then\n"
          "  echo '[v35] pointer coordinate mode: relative (REL_X+REL_Y required)'\n"
          "else\n"
          "  echo '[v35] no relative evdev pointer selected; libinput/other backend will handle the touchpad'\n"
          "fi\n")
    if m: s=s[:m.start()]+repl+s[m.end():]
    # Explicit evdev must never re-add :abs for an ABS-only touchpad.
    s=re.sub(r'\s*# v32o: use the kernel-reported coordinate capability.*?\n\s*if \[ "\$PTR_COORD_MODE" = relative \]; then\n\s*export QT_QPA_EVDEV_MOUSE_PARAMETERS="\$PTR_EVENT:nocompress:grab=0"\n\s*else\n\s*export QT_QPA_EVDEV_MOUSE_PARAMETERS="\$PTR_EVENT:abs:nocompress:grab=0"\n\s*fi',
             '\n        # v35: PTR_EVENT is already REL_X+REL_Y validated.\n        export QT_QPA_EVDEV_MOUSE_PARAMETERS="$PTR_EVENT:nocompress:grab=0"', s, count=1, flags=re.S)
    s=s.replace("echo '[v34f] pointer priority: touchpad/synaptics/elan/alps > trackpoint/pointing-stick > generic mouse'\n", "echo '[v35] pointer policy: REL_X+REL_Y capability first; ABS-only touchpads are not coerced into mouse mode'\n")
    p.write_text(s); p.chmod(p.stat().st_mode|0o111); return True

def patch_limine_conf(p: Path) -> bool:
    s=p.read_text(errors='strict')
    if 'sos.mode=live' not in s or 'protocol: linux' not in s: return False
    if 'sos.mode=install' in s and 'Install Groovebox / sOS to Disk' in s: return False
    # Find the live stanza and reuse its kernel/module paths.
    stanzas=re.split(r'(?=^/)', s, flags=re.M)
    live=None
    for st in stanzas:
        if 'sos.mode=live' in st and 'protocol: linux' in st:
            live=st; break
    if not live: raise RuntimeError(f'no live Limine stanza in {p}')
    pm=re.search(r'^\s*path:\s*(\S+)', live, re.M); mm=re.search(r'^\s*module_path:\s*(\S+)', live, re.M)
    if not pm or not mm: raise RuntimeError(f'cannot infer Limine paths in {p}')
    install=("\n/Install Groovebox / sOS to Disk\n"
             "    protocol: linux\n"
             f"    path: {pm.group(1)}\n"
             "    cmdline: rdinit=/init sos.mode=install\n"
             f"    module_path: {mm.group(1)}\n")
    idx=s.find(live)+len(live)
    s=s[:idx].rstrip()+"\n"+install+"\n"+s[idx:].lstrip('\n')
    p.write_text(s); return True

def patch_init(p: Path) -> bool:
    s=p.read_text(errors='strict')
    changed=False
    if INSTALL_MARK not in s:
        lines=s.splitlines()
        lines.insert(2, '# '+INSTALL_MARK)
        s='\n'.join(lines)+'\n'; changed=True
    if 'sos.mode=*) SOS_MODE=${x#sos.mode=}' not in s:
        raise RuntimeError(f'{p} does not parse sos.mode')
    if re.search(r'^\s*install\)\s*$', s, re.M) is None:
        anchor=re.search(r'^\s*scode\)\s*$', s, re.M)
        if not anchor: raise RuntimeError(f'cannot insert install mode in {p}')
        block=("    install)\n"
               "        echo '[v35] install mode selected: entering Copy-to-Disk; GUI fallback is forbidden'\n"
               "        if [ -x /usr/bin/sos-install-appliance ]; then exec /usr/bin/sos-install-appliance; fi\n"
               "        recovery_menu installer-missing 87\n"
               "        ;;\n")
        s=s[:anchor.start()]+block+s[anchor.start():]; changed=True
    else:
        # Add a diagnostic line but never change the existing backend semantics.
        needle='    install)\n'
        if '[v35] install mode selected' not in s:
            s=s.replace(needle, needle+"        echo '[v35] install mode selected: entering Copy-to-Disk; GUI fallback is forbidden'\n",1); changed=True
    p.write_text(s); p.chmod(p.stat().st_mode|0o111); return changed

def patch_initramfs_patcher(p: Path) -> bool:
    s=p.read_text(errors='strict')
    if 'GROOVEBOX_V35_INSTALL_BUILD_GUARD_20260919' in s: return False
    anchor='/bin/sh -n "$R/init"\n'
    if anchor not in s: return False
    guard=(anchor+
      "# GROOVEBOX_V35_INSTALL_BUILD_GUARD_20260919\n"
      "grep -Fq 'GROOVEBOX_V35_INSTALL_DISPATCH_20260919' \"$R/init\" || { echo 'FAIL: v35 install dispatch missing from final /init' >&2; exit 4; }\n"
      "grep -Fq 'sos.mode=install' \"$HERE/limine-live.conf\" || { echo 'FAIL: v35 Limine Install-to-Disk entry missing' >&2; exit 4; }\n")
    s=s.replace(anchor,guard,1); p.write_text(s); p.chmod(p.stat().st_mode|0o111); return True

def main() -> int:
    root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
    if root.name!='BUILD_ISO' and (root/'BUILD_ISO').is_dir(): root=root/'BUILD_ISO'
    if not root.is_dir(): print('FAIL: BUILD_ISO not found',file=sys.stderr); return 3
    changed=[]
    launchers=[]
    for p in sorted(root.glob('groovebox-appliance-direct-*')):
        if p.is_file() and p.stat().st_size < 1024*1024:
            try:
                if patch_launcher(p): changed.append(str(p.name))
                if PTR_MARK in p.read_text(errors='ignore'): launchers.append(p)
            except UnicodeDecodeError: pass
    if not launchers:
        print('FAIL: no active evdev launcher could be patched',file=sys.stderr); return 4
    cursor=root/'qt_cursor_sync_sitecustomize_v32p.py'
    cursor.write_text(CURSOR_CODE); changed.append(cursor.name)
    limine_candidates=[p for p in root.rglob('*') if p.is_file() and p.name.lower() in ('limine-live.conf','limine.conf')]
    limine_ok=[]
    for p in limine_candidates:
        try:
            patch_limine_conf(p)
            if 'sos.mode=install' in p.read_text(errors='ignore'): limine_ok.append(p)
        except UnicodeDecodeError: pass
    if not limine_ok:
        print('FAIL: no Limine live config was found to receive sos.mode=install',file=sys.stderr); return 5
    init=root/'init-v33a'
    if not init.is_file(): print('FAIL: init-v33a missing',file=sys.stderr); return 6
    patch_init(init)
    pp=root/'patch_initramfs_v33a.sh'
    if pp.is_file(): patch_initramfs_patcher(pp)
    # Confirm the actual destructive backend source exists and contains its disk-write stages.
    backend=root/'sos-install-appliance-real-v32q'
    if not backend.is_file(): print('FAIL: disk installer backend source missing',file=sys.stderr); return 7
    bt=backend.read_text(errors='ignore')
    for tok in ('gpt_disk_v32q.py','mkfs.vfat','mkfs.ext4','copy_root_v32q.py'):
        if tok not in bt: print('FAIL: installer backend lacks '+tok,file=sys.stderr); return 7
    print('PASS: v35 game-ready patch applied')
    print('  relative trackpad/mouse semantics: enabled')
    print('  modal cursor synchronization: enabled')
    print('  Limine Install-to-Disk dispatch: enabled')
    return 0
if __name__=='__main__': raise SystemExit(main())
