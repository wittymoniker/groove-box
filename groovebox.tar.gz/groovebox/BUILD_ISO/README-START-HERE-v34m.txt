Groovebox BUILD_ISO v34m — sCode ABI preflight stability fix

This retains v34l module-tree stdout handling and all v34k runtime fixes.
It fixes a nondeterministic preflight false failure caused by piping verbose
sCode stage-0 output into grep -q while bash pipefail was enabled.

Run from the Groovebox project root:
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

Expected preflight:
  PASS: desktop sCode optimizer ABI 9
  PASS: desktop sCode pool catalog ABI 1
