#!/bin/sh
# GROOVEBOX_V35_22F_RUNTIME_SETUP_FILE_20260921
set -eu
printf '%s\n' '[v35.22f] runtime setup file active'
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends \
  bash coreutils findutils grep sed gawk util-linux kmod procps ca-certificates busybox-static passwd \
  python3 python3-venv python3-pip \
  ffmpeg e2fsprogs dosfstools \
  libportaudio2 portaudio19-dev libasound2t64 libpulse0 pulseaudio-utils alsa-utils pipewire pipewire-pulse wireplumber \
  labwc wlr-randr xwayland \
  libgl1 libegl1 libopengl0 libdrm2 libgbm1 libudev1 udev libinput10 libinput-tools seatd \
  libx11-6 libxext6 libxrender1 libsm6 libice6 \
  libxcb1 libxcb-cursor0 libxcb-xinerama0 libxkbcommon0 libxkbcommon-x11-0 \
  libfontconfig1 libfreetype6 libdbus-1-3 libglib2.0-0t64 \
  libnspr4 libnss3 libexpat1 libglx0 libharfbuzz0b libharfbuzz-subset0 libicu76 \
  libjpeg62-turbo liblcms2-2 libminizip1t64 libopenjp2-7 libopus0 libpng16-16t64 \
  libsnappy1v5 libtiff6 libwebp7 libwebpdemux2 libwebpmux3 zlib1g \
  libx11-xcb1 libxcomposite1 libxdamage1 libxfixes3 libxkbfile1 libxrandr2 libxtst6 \
  libxcb-dri3-0 libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-randr0 \
  libxcb-render-util0 libxcb-shape0 libxcb-xfixes0 libxcb-xkb1 \
  libatk1.0-0t64 libatk-bridge2.0-0t64 libatspi2.0-0t64 libcairo2 libcups2t64 \
  libgtk-3-0t64 libpango-1.0-0 libpangocairo-1.0-0 libxi6 libxss1 \
  fonts-dejavu-core fonts-liberation

python3 -m venv /opt/pyvenv
/opt/pyvenv/bin/python3 -m pip install --no-cache-dir --upgrade pip wheel setuptools
if ! /opt/pyvenv/bin/python3 -m pip install --no-cache-dir \
  numpy==2.5.3 scipy==1.18.1 Pillow==12.3.0 PyQt6==6.11.0 PyQt6-WebEngine==6.11.0 sounddevice==0.5.6 cffi==2.1.1; then
  echo '[v34k] pinned Python wheel set unavailable; using compatible current wheels' >&2
  /opt/pyvenv/bin/python3 -m pip install --no-cache-dir numpy scipy Pillow PyQt6 PyQt6-WebEngine sounddevice cffi
fi
ldconfig

# GROOVEBOX_V35_22F_WEBENGINE_PYTHON_LDD_AUDIT_20260921
# Avoid shell find/awk quoting entirely. Python enumerates WebEngine binaries and
# reports every unresolved native dependency in one pass.
/opt/pyvenv/bin/python3 - <<'PY'
from pathlib import Path
import subprocess, sys
roots = [Path('/opt/pyvenv/lib')]
files = []
for root in roots:
    if not root.exists():
        continue
    for p in root.rglob('*'):
        if not p.is_file():
            continue
        n = p.name
        if n == 'QtWebEngineProcess' or (n.startswith('libQt6WebEngine') and '.so' in n):
            files.append(p)
missing = set()
for p in sorted(set(files)):
    cp = subprocess.run(['ldd', str(p)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in cp.stdout.splitlines():
        if '=> not found' in line:
            missing.add(line.split('=>', 1)[0].strip())
if missing:
    print('[v35.22f] Qt WebEngine native dependency audit failed:', file=sys.stderr)
    for name in sorted(missing):
        print('  missing:', name, file=sys.stderr)
    raise SystemExit(44)
print('[v35.22f] Qt WebEngine native dependency audit PASS')
PY

/opt/pyvenv/bin/python3 - <<'PY'
import ctypes, ctypes.util
pa = ctypes.util.find_library('portaudio') or 'libportaudio.so.2'
ctypes.CDLL(pa)
import numpy, scipy, PIL, cffi, sounddevice
from PyQt6 import QtCore, QtGui, QtWidgets, QtWebEngineWidgets
print('PYTHON-RUNTIME-PASS', numpy.__version__, scipy.__version__, 'portaudio=', pa)
PY

apt-get clean
rm -rf /var/lib/apt/lists/* /root/.cache /tmp/*
