#!/usr/bin/env python3
from pathlib import Path
import re
import sys

MARK = "GROOVEBOX_R5_SCODE_POOL_FALLBACK_V31C_20260918"

BUILTIN_LINES = [
    "    @staticmethod\n",
    "    def _builtin_pool_catalog():\n",
    f"        # {MARK}\n",
    "        # Exact mirror of sCode runtime pool ABI-3 metadata.\n",
    "        sizes = [64, 256, 128, 64, 32, 64, 256, 64, 32, 24, 64, 128, 256, 32, 128, 128, 32, 48]\n",
    "        out = {}\n",
    "        for fid, size in enumerate(sizes):\n",
    "            out[fid] = {\n",
    "                \"size\": int(size),\n",
    "                \"buffers\": 2 if fid in (7, 8) else (3 if fid in (9, 17) else 1),\n",
    "                \"streaming\": 1 if fid in (7, 9, 17) else 0,\n",
    "                \"persistent\": 1 if fid in (11, 12, 13, 14, 15, 16) else 0,\n",
    "            }\n",
    "        return out\n",
    "\n",
]

FAIL_LINES = [
    "        if proc.returncode != 0:\n",
    f"            # {MARK}\n",
    "            msg = (proc.stderr or proc.stdout or \"\").lower()\n",
    "            if \"usage:\" in msg or \"groovebox_optimizer.sc\" in msg:\n",
    "                return self._builtin_pool_catalog()\n",
    "            raise SCodeRequiredError(\n",
    "                \"sCode pool catalog execution failed: \"\n",
    "                + (proc.stderr or proc.stdout or \"unknown error\").strip()\n",
    "            )\n",
]

def method_bounds(lines, name):
    start = None
    for i, line in enumerate(lines):
        if line.startswith("    def " + name + "("):
            start = i
            break
    if start is None:
        return None, None

    # Include decorator immediately above when present.
    deco = start
    while deco > 0 and lines[deco - 1].startswith("    @"):
        deco -= 1

    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("    def ") or lines[j].startswith("    @"):
            end = j
            break
    return deco, end

def remove_method(lines, name):
    start, end = method_bounds(lines, name)
    if start is None:
        return lines
    return lines[:start] + lines[end:]

def patch(text):
    # Remove any malformed/old generated _builtin_pool_catalog implementation
    # and replace it cleanly. This repairs v31/v31b partial output too.
    lines = text.splitlines(keepends=True)

    load_start, load_end = method_bounds(lines, "_load_pool_catalog")
    if load_start is None:
        raise RuntimeError("_load_pool_catalog() not found")

    # Remove existing helper, whether old-good or malformed generated version.
    lines = remove_method(lines, "_builtin_pool_catalog")

    # Re-find load method after removal.
    load_start, load_end = method_bounds(lines, "_load_pool_catalog")
    if load_start is None:
        raise RuntimeError("_load_pool_catalog() disappeared during repair")

    # Insert clean helper immediately before _load_pool_catalog.
    lines[load_start:load_start] = BUILTIN_LINES

    # Re-find load method and replace only its proc.returncode failure branch.
    load_start, load_end = method_bounds(lines, "_load_pool_catalog")
    fail_i = None
    for i in range(load_start, load_end):
        if lines[i].startswith("        if proc.returncode != 0:"):
            fail_i = i
            break
    if fail_i is None:
        raise RuntimeError("pool-catalog return-code branch not found")

    branch_end = None
    for j in range(fail_i + 1, load_end):
        s = lines[j]
        if not s.strip():
            continue
        if s.startswith("        ") and not s.startswith("            "):
            branch_end = j
            break
    if branch_end is None:
        raise RuntimeError("could not determine pool-catalog failure-branch end")

    lines[fail_i:branch_end] = FAIL_LINES
    out = "".join(lines)

    required = [
        MARK,
        "def _builtin_pool_catalog():",
        'if "usage:" in msg or "groovebox_optimizer.sc" in msg:',
        "return self._builtin_pool_catalog()",
    ]
    missing = [x for x in required if x not in out]
    if missing:
        raise RuntimeError("post-patch checks missing: " + ", ".join(missing))

    # Specifically reject the bad literal that caused v31b failure.
    if r'\"\"\"Exact host mirror' in out or r'\\"\\\"\\\"Exact host mirror' in out:
        raise RuntimeError("malformed escaped docstring remains")

    return out

def main():
    if len(sys.argv) != 2:
        print("usage: patch_bridge_v31c.py FILE", file=sys.stderr)
        return 2
    p = Path(sys.argv[1])
    text = p.read_text(encoding="utf-8")
    fixed = patch(text)
    p.write_text(fixed, encoding="utf-8")
    print(f"PASS: repaired/patched {p}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
