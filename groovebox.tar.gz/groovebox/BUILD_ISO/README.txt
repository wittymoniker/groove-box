Groovebox BUILD_ISO R23 / v32x RECOVERY-VERIFIER-FIX
Run ./RUN_ME_v32x.sh from this extracted package.
This is cumulative over v32w and fixes the stale inherited v32t recovery-menu verifier.
