#!/usr/bin/env python3
# GROOVEBOX_R19_VERIFY_CONSOLE_IO_V32T_20260918
from pathlib import Path
import gzip, sys

def parse_newc(blob):
    out={}; pos=0
    while pos+110<=len(blob):
        hdr=blob[pos:pos+110]
        if hdr[:6] not in (b'070701',b'070702'):
            nxt=blob.find(b'070701',pos+1)
            if nxt<0: break
            pos=nxt; continue
        namesz=int(hdr[94:102],16); size=int(hdr[54:62],16); pos+=110
        name=blob[pos:pos+namesz-1].decode('utf-8','replace'); pos+=namesz; pos=(pos+3)&~3
        data=blob[pos:pos+size]; pos+=size; pos=(pos+3)&~3
        if name=='TRAILER!!!': break
        out[name.lstrip('./')]=data
    return out
with gzip.open(sys.argv[1],'rb') as f: files=parse_newc(f.read())
need={
 'usr/bin/groovebox-appliance':b'GROOVEBOX_R19_CONSOLE_IO_GUI_RESTORE_V32T_20260918',
 'usr/bin/sos-install-appliance':b'GROOVEBOX_R19_CONSOLE_IO_DISK_V32T_20260918',
 'usr/bin/sos-recovery-shell':b'GROOVEBOX_R19_NOJOB_RECOVERY_MENU_V32T_20260918',
 'usr/lib/sos/sos-install-appliance.real-v32q':b'GROOVEBOX_R16_DISK_BACKEND_V32Q_20260918',
}
for name,mark in need.items():
    data=files.get(name)
    if not data: raise SystemExit(f'FAIL: v32t file missing: {name}')
    if mark not in data: raise SystemExit(f'FAIL: v32t marker missing: {name}')
for name in ('usr/bin/groovebox-appliance','usr/bin/sos-install-appliance','usr/bin/sos-recovery-shell'):
    data=files[name]
    for bad in (b'cttyhack', b'/bin/sh -i', b' sh -i'):
        if bad in data: raise SystemExit(f'FAIL: job-control shell path remains in {name}: {bad!r}')
install=files['usr/bin/sos-install-appliance']
if b'<"$CONSOLE" >"$CONSOLE" 2>&1' not in install:
    raise SystemExit('FAIL: v32t Copy-to-Disk is not wired directly to console stdio')
rec=files['usr/bin/sos-recovery-shell']
if b'sOS recovery menu v32t' not in rec or b'while :' not in rec:
    raise SystemExit('FAIL: v32t recovery menu missing')
app=files['usr/bin/groovebox-appliance']
# Preserve exact known-good v32o cursor/input behavior, including nocompress.
for x in (b'GROOVEBOX_R14_CURSOR_SYNC_V32O_20260918',b'nocompress:grab=0',b'GROOVEBOX_SOFTWARE_CURSOR=1'):
    if x not in app: raise SystemExit(f'FAIL: v32t known-good v32o GUI path missing {x!r}')
print('PASS: v32t restores known-good v32o GUI path and removes interactive-shell/cttyhack job-control paths')
