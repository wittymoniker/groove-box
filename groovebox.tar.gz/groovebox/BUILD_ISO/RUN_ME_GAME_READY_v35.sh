#!/usr/bin/env bash
# GROOVEBOX_V35_2_INIT_POINTER_PRESERVE_20260919
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-}"
if [[ -z "$ROOT" ]]; then
  d="$HERE"
  while [[ "$d" != / ]]; do
    if [[ -d "$d/BUILD_ISO" ]]; then ROOT="$d"; break; fi
    d="$(dirname "$d")"
  done
fi
[[ -n "$ROOT" && -d "$ROOT/BUILD_ISO" ]] || { echo 'FAIL: run from a Groovebox tree containing BUILD_ISO' >&2; exit 3; }
BI="$ROOT/BUILD_ISO"
if [[ $EUID -ne 0 ]]; then exec sudo "$HERE/RUN_ME_GAME_READY_v35.sh" "$ROOT"; fi

echo '[v35.2] Game-Ready build: low-memory streaming + live /init restoration + v35 pointer preservation enabled'
echo '[v35] validating bundled ISO seed'
python3 "$BI/verify_iso_seed_v35.py" "$BI"

echo '[v35] applying game-ready input + installer guards'
python3 "$BI/patch_game_ready_v35.py" "$BI"
python3 "$BI/verify_game_ready_v35.py" "$BI"
python3 "$BI/verify_game_ready_v35_2.py" "$BI"

# Chain to the newest complete runner already in the user's tree. This overlay
# does not pretend to be a clean-slate runtime base.
runner=''
for n in RUN_ME_v34q.sh RUN_ME_v34p.sh RUN_ME_v34o.sh RUN_ME_v34n.sh RUN_ME_v34m.sh RUN_ME_v34l.sh RUN_ME_v34k.sh RUN_ME_v34j.sh RUN_ME_v34i.sh RUN_ME_v34g.sh RUN_ME_v34f.sh RUN_ME_v34e.sh RUN_ME_v33c.sh RUN_ME_v33a.sh; do
  if [[ -f "$BI/$n" ]]; then runner="$BI/$n"; break; fi
done
if [[ -z "$runner" && -f "$BI/RUN_ME_ZERO_STATE.sh" ]]; then runner="$BI/RUN_ME_ZERO_STATE.sh"; fi
[[ -n "$runner" ]] || { echo 'FAIL: no current BUILD_ISO runner found under this complete Groovebox tree' >&2; exit 4; }
# Avoid a tiny overlay runner whose dependency is absent.
if [[ "$(basename "$runner")" == RUN_ME_v34q.sh ]] && [[ ! -f "$BI/RUN_ME_v34p.sh" && ! -f "$BI/RUN_ME_v34o.sh" ]]; then
  echo 'FAIL: v34q is an overlay but its complete v34p/v34o base is absent.' >&2; exit 4
fi

echo "[v35] chaining to $(basename "$runner")"
bash "$runner" "$ROOT"

echo '[v35] post-build source verification'
python3 "$BI/verify_game_ready_v35.py" "$BI"
latest="$(find "$BI/dist" -maxdepth 1 -type f -name '*.iso' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2- || true)"
if [[ -n "$latest" ]]; then
  echo "PASS: game-ready ISO produced: $latest"
  sha256sum "$latest" | tee "$latest.sha256.v35"
else
  echo 'WARN: builder returned without an ISO in BUILD_ISO/dist; inspect the preceding builder output.' >&2
fi
