#!/usr/bin/env python3
# GROOVEBOX_R22_LIVE_BOOT_PATCHER_V32W_20260918
from __future__ import annotations
import os, pathlib, shutil, sys

if len(sys.argv) != 2:
    raise SystemExit('usage: patch_live_boot_v32w.py ROOTFS')
root = pathlib.Path(sys.argv[1]).resolve()
if not root.is_dir():
    raise SystemExit(f'FAIL: rootfs missing: {root}')

legacy = root / 'opt/sos/legacy-v32w'
legacy.mkdir(parents=True, exist_ok=True)
init = root / 'init'
if not init.exists():
    raise SystemExit('FAIL: live rootfs /init missing')
old = init.read_bytes()
(legacy / 'init-before-v32w').write_bytes(old)
os.chmod(legacy / 'init-before-v32w', 0o755)

# Disable every service descriptor that automatically starts the old sOS console.
# sos-supervisor scans /etc/sos/services, so merely fixing a later recovery script
# is not enough: the old console can own tty1 before Groovebox ever starts.
svcdir = root / 'etc/sos/services'
disabled = legacy / 'services-disabled'
disabled.mkdir(parents=True, exist_ok=True)
count = 0
if svcdir.is_dir():
    for p in sorted(svcdir.iterdir()):
        if not p.is_file():
            continue
        b = p.read_bytes()
        if b'sos-console' in b or b'/bin/sh -i' in b or b'cttyhack' in b:
            shutil.copy2(p, disabled / p.name)
            p.unlink()
            count += 1

new_init = r'''#!/bin/sh
# GROOVEBOX_R22_LIVE_INIT_GUI_V32W_20260918
# PID 1 stays non-interactive. Never exec a login/interactive shell here.
set +e
export PATH=/opt/sos/bin:/opt/groovebox/bin:/opt/pyvenv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mkdir -p /dev/pts /run /tmp /run/user/0 /opt/sos/addons /etc/sos/services /var/log/sos
mount -t devpts devpts /dev/pts 2>/dev/null || true
chmod 1777 /tmp 2>/dev/null || true
chmod 700 /run/user/0 2>/dev/null || true
if command -v mdev >/dev/null 2>&1; then mdev -s 2>/dev/null || true; fi

# Bind simple stdio to the kernel console without asking a shell for job control.
if [ -c /dev/console ]; then exec </dev/console >/dev/console 2>&1; fi

echo 'sOS v32w live init: direct Groovebox GUI boot'
SOS_MODE=live
for x in $(cat /proc/cmdline 2>/dev/null); do
  case "$x" in
    sos.safe=1) touch /run/sos-safe-mode ;;
    sos.mode=*) SOS_MODE=${x#sos.mode=} ;;
  esac
done

if [ "$SOS_MODE" = install ] && [ -x /usr/bin/sos-profile-wizard ]; then
  /usr/bin/sos-profile-wizard || true
fi
if [ -x /usr/bin/sos-ready-check ]; then
  mkdir -p /var/lib/sos/structure 2>/dev/null || true
  /usr/bin/sos-ready-check >/var/lib/sos/structure/boot.report 2>&1 || true
fi
if [ -x /usr/bin/sos-supervisor ]; then
  /usr/bin/sos-supervisor &
fi

# The legacy sos-console was previously both launched here and auto-started by
# core-console.service. v32w removes both automatic paths.
if [ "$SOS_MODE" = recovery ]; then
  echo 'sOS v32w: explicit recovery mode requested'
else
  echo 'sOS v32w: launching /usr/bin/groovebox-appliance'
  if [ -x /usr/bin/groovebox-appliance ]; then
    /usr/bin/groovebox-appliance
    rc=$?
    echo "sOS v32w: Groovebox launcher returned rc=$rc"
  else
    echo 'FAIL: /usr/bin/groovebox-appliance is missing'
  fi
fi

# No /bin/sh fallback. Recovery is a tiny command reader with direct console I/O.
if [ -x /usr/bin/sos-recovery-shell ]; then
  exec /usr/bin/sos-recovery-shell
fi
echo 'FAIL: recovery menu missing; PID 1 will remain alive without a shell.'
while :; do sleep 3600; done
'''
init.write_text(new_init)
os.chmod(init, 0o755)

# Old components may call /usr/bin/sos-recovery by its legacy name. Make that
# name enter the same non-shell recovery menu rather than an interactive ash.
for rel in ('usr/bin/sos-recovery', 'usr/bin/recovery'):
    p = root / rel
    if p.exists() or p.is_symlink():
        try:
            if p.is_file() and not p.is_symlink():
                shutil.copy2(p, legacy / (p.name + '-before-v32w'))
            p.unlink()
        except FileNotFoundError:
            pass
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text('#!/bin/sh\n# GROOVEBOX_R22_RECOVERY_ALIAS_V32W_20260918\nexec /usr/bin/sos-recovery-shell "$@"\n')
    os.chmod(p, 0o755)

# Keep the old console binary for forensics but make the active command a
# short non-interactive stub. This closes any hidden caller outside the service
# directory without starting another terminal owner.
console = root/'usr/bin/sos-console'
if console.exists() and not console.is_symlink():
    saved = legacy/'sos-console-before-v32w'
    if not saved.exists(): shutil.copy2(console, saved)
    console.write_text('#!/bin/sh\n# GROOVEBOX_R22_LEGACY_CONSOLE_DISABLED_V32W_20260918\necho "sOS legacy console autostart disabled by v32w"\nexit 0\n')
    os.chmod(console, 0o755)

(root/'opt/sos/live-boot-v32w.txt').write_text(
    'GROOVEBOX_R22_LIVE_INIT_GUI_V32W_20260918\n'
    f'legacy_console_services_disabled={count}\n'
    'automatic_sos_console=disabled\ninteractive_shell_fallback=disabled\n'
)
print(f'PASS: v32w live boot patched; disabled {count} legacy console service(s)')
