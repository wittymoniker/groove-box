Groovebox BUILD_ISO v34p hotfix — 2026-09-19

Fix: the booted recovery menu could report that groovebox-runtime-check was not present.
v34p injects /usr/bin/groovebox-runtime-check in the FINAL Limine/sCode initramfs patch,
and wires PID-1 recovery `runtime` directly to it.

Apply from the Groovebox project root:
  unzip -o Groovebox-BUILD_ISO-HOTFIX-v34p-20260919.zip
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

Rebuild and reburn the ISO; this change is inside the boot initramfs.
