Groovebox/sOS BUILD_ISO R19 / v32t — CONSOLE-I/O + GUI RESTORE — 2026-09-18

The v32s recovery path still invoked `/bin/sh -i`, so BusyBox could still print
"can't access tty; job control turned off". Also, dropping straight into the
recovery console means the GUI launcher exhausted its backend/input attempts.

v32t fixes both sides:
- restores the exact v32o GUI/input/cursor launcher that worked on the Dell
  (including REL/ABS detection and nocompress event handling)
- retains the v32q self-contained UEFI Copy-to-Disk payload
- Copy to Disk no longer needs job control or a controlling-TTY helper; its
  stdin/stdout/stderr are wired directly to the active Linux console
- removes cttyhack, TIOCSCTTY, and `/bin/sh -i` from the live install/recovery path
- recovery is a simple command menu, not an interactive BusyBox shell
- installed-root failure recovery also avoids `exec sh`

Run only:
  ./RUN_ME_v32t.sh

Expected ISO:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-CONSOLE-IO-GUI-RESTORE-v32t.iso

Runtime-regression guard:
- installer formatter staging no longer runs ldconfig inside the live root
- the builder hashes /etc/ld.so.cache before and after staging and fails if it changes
- this preserves the Qt/Python runtime from the last known-working v32o build
