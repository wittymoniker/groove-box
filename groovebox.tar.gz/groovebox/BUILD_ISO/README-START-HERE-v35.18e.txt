Mathematician's Groovebox / sOS BUILD_ISO FULL v35.18e

Run from the Groovebox project root:
  chmod +x BUILD_ISO/RUN_ME_ZERO_STATE.sh
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

Included cumulative repairs:
- true zero-state Debian 13/Python runtime bootstrap
- PortAudio/sounddevice staging bridge
- usrmerge-safe exact-kernel input-module staging
- Dell touchpad priority
- bounded installer formatter stage
- BusyBox installed-root initramfs staging
- GUI/QPA runtime preservation and recovery diagnostics
- v35.18e wlroots/libinput readiness gate
- NVMe/MMC/virtio/SCSI whole-disk discovery with live-media and partition rejection
- resumable/retried exact Debian kernel-package download

The physical final ISO is produced on the Fedora build host and still requires hardware boot testing.
