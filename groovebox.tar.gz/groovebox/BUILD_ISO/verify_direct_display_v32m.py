#!/usr/bin/env python3
from __future__ import annotations
import gzip,sys
from pathlib import Path

def parse_newc(blob:bytes):
    pos=0; files={}
    while pos+110<=len(blob):
        if blob[pos:pos+6]!=b'070701': break
        h=blob[pos:pos+110]; pos+=110
        fs=[int(h[i:i+8],16) for i in range(6,110,8)]
        mode=fs[1]; fsize=fs[6]; namesize=fs[11]
        name=blob[pos:pos+namesize-1].decode('utf-8','replace'); pos+=namesize; pos=(pos+3)&~3
        data=blob[pos:pos+fsize]; pos+=fsize; pos=(pos+3)&~3
        if name=='TRAILER!!!': break
        files[name.lstrip('./')]=(mode,data)
    return files

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: verify_direct_display_v32m.py initramfs.img')
    f=parse_newc(gzip.decompress(Path(sys.argv[1]).read_bytes()))
    req=['usr/bin/groovebox-appliance','usr/bin/groovebox-appliance.real','usr/bin/sos-recovery-shell','usr/bin/groovebox-display-check','usr/bin/groovebox-input-check','usr/bin/groovebox-kernel-input-prep','usr/lib/x86_64-linux-gnu/libdrm.so.2','etc/fonts/fonts.conf','opt/sos/lib/fonts-v32l.txt','opt/sos/lib/qt-input-host-bundle-v32l.tsv']
    miss=[x for x in req if x not in f or not f[x][1]]
    if miss: raise SystemExit('FAIL: v32m missing: '+', '.join(miss))
    app=f['usr/bin/groovebox-appliance'][1].decode('utf-8','replace')
    must=['GROOVEBOX_R12_KERNEL_INPUT_V32M_20260918','unset QT_QPA_EGLFS_HIDECURSOR QT_QPA_FB_HIDECURSOR','evdev-auto','evdev-explicit','QT_QPA_EVDEV_MOUSE_PARAMETERS','QT_QPA_EVDEV_KEYBOARD_PARAMETERS','find_pointer_event','find_keyboard_event','no Qt pointer on','try_pair eglfs-kms eglfs']
    bad=[x for x in must if x not in app]
    if bad: raise SystemExit('FAIL: v32m launcher checks missing: '+', '.join(bad))
    # v32m intentionally pins only dynamically detected real event nodes, excluding
    # button-only keyboard handlers, after auto/libinput modes fail.
    forbidden=['QT_QPA_EGLFS_HIDECURSOR=1','QT_QPA_FB_HIDECURSOR=1','evdev-generic']
    hit=[x for x in forbidden if x in app]
    if hit: raise SystemExit('FAIL: v32m stale/bad input settings remain: '+', '.join(hit))
    generic=[k for k in f if '/plugins/generic/' in k and k.endswith('.so')]
    if not any('evdevkeyboard' in k.lower() for k in generic): raise SystemExit('FAIL: v32m missing Qt evdev keyboard plugin')
    if not any('evdevmouse' in k.lower() for k in generic): raise SystemExit('FAIL: v32m missing Qt evdev mouse plugin')
    fonts=[k for k in f if k.startswith('usr/share/fonts/truetype/groovebox/') and k.lower().endswith(('.ttf','.otf','.ttc')) and f[k][1]]
    if not fonts: raise SystemExit('FAIL: v32m has no bundled fallback font')
    print(f'PASS: v32m cursor + keyboard + mouse/touch + fonts/display checks ({len(fonts)} fonts, {len(generic)} generic Qt plugins)')
if __name__=='__main__': main()
