#!/usr/bin/env python3
"""Bundle missing Qt bare-metal graphics dependencies into the initramfs.

The PyQt6 wheel contains the linuxfb/eglfs plugins, but those plugins intentionally
use system libraries such as libdrm.  The sOS runtime foundation may not contain
those libraries.  This helper computes the ELF NEEDED closure of the relevant Qt
plugins/libraries and copies only missing non-core libraries from the Fedora build
host into the guest's Debian-compatible multiarch library directory.
"""
from __future__ import annotations
import os, re, shutil, subprocess, sys
from pathlib import Path

CORE = {
    'libc.so.6','libm.so.6','libdl.so.2','libpthread.so.0','librt.so.1',
    'ld-linux-x86-64.so.2','libgcc_s.so.1','libstdc++.so.6','libresolv.so.2',
    'libutil.so.1','libnsl.so.1','libcrypt.so.1'
}

NEEDED_RE = re.compile(r'\(NEEDED\).*Shared library: \[(.+?)\]')


def needed(path: Path) -> list[str]:
    try:
        p = subprocess.run(['readelf','-d',str(path)], text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           check=False)
    except FileNotFoundError:
        raise SystemExit('FAIL: readelf is required on the Fedora build host')
    if p.returncode != 0:
        return []
    return NEEDED_RE.findall(p.stdout)


def build_guest_index(root: Path) -> dict[str, Path]:
    idx: dict[str, Path] = {}
    for p in root.rglob('*'):
        if p.is_file() or p.is_symlink():
            n = p.name
            if '.so' in n or n.startswith('ld-linux'):
                idx.setdefault(n, p)
    return idx


def host_ldconfig() -> dict[str, list[Path]]:
    out: dict[str, list[Path]] = {}
    try:
        txt = subprocess.check_output(['ldconfig','-p'], text=True, stderr=subprocess.DEVNULL)
    except Exception:
        txt = ''
    for line in txt.splitlines():
        if '=>' not in line:
            continue
        left, right = line.split('=>',1)
        soname = left.strip().split()[0] if left.strip() else ''
        p = Path(right.strip())
        if soname and p.exists():
            out.setdefault(soname, []).append(p)
    return out


def resolve_host(soname: str, cache: dict[str,list[Path]]) -> Path | None:
    cands = cache.get(soname, [])
    if cands:
        def score(p: Path):
            s = str(p)
            return (('/lib64/' in s or '/usr/lib64/' in s), 'x86_64' in s, -len(s))
        return sorted(cands, key=score, reverse=True)[0]
    for d in ('/usr/lib64','/lib64','/usr/lib/x86_64-linux-gnu','/lib/x86_64-linux-gnu'):
        p = Path(d)/soname
        if p.exists():
            return p
    return None


def main() -> int:
    if len(sys.argv) != 2:
        print('usage: bundle_qt_graphics_libs_v32l.py ROOTFS', file=sys.stderr)
        return 2
    root = Path(sys.argv[1]).resolve()
    if not root.is_dir():
        raise SystemExit(f'FAIL: ROOTFS not found: {root}')

    guest = build_guest_index(root)
    roots: list[Path] = []
    patterns = [
        'opt/pyvenv/**/plugins/platforms/libqlinuxfb.so',
        'opt/pyvenv/**/plugins/platforms/libqeglfs.so',
        'opt/pyvenv/**/plugins/egldeviceintegrations/*.so',
        'opt/pyvenv/**/libQt6Gui.so.6',
        'opt/pyvenv/**/libQt6OpenGL.so.6',
        'opt/pyvenv/**/libQt6EglFSDeviceIntegration.so.6',
    ]
    for pat in patterns:
        roots.extend(root.glob(pat))
    # de-duplicate real paths while retaining readable order
    uniq=[]; seen=set()
    for p in roots:
        try: k=str(p.resolve())
        except Exception: k=str(p)
        if k not in seen and p.exists():
            seen.add(k); uniq.append(p)
    roots=uniq
    if not roots:
        raise SystemExit('FAIL: no Qt linuxfb/eglfs libraries found in guest runtime')

    cache = host_ldconfig()
    destdir = root/'usr/lib/x86_64-linux-gnu'
    destdir.mkdir(parents=True, exist_ok=True)
    manifest=[]
    queue=list(roots)
    scanned=set()
    copied={}
    missing=[]

    while queue:
        obj=queue.pop(0)
        key=str(obj)
        if key in scanned:
            continue
        scanned.add(key)
        for soname in needed(obj):
            if soname in CORE:
                # Core ABI must come from the guest foundation, never Fedora.
                if soname not in guest:
                    # The dynamic loader may not be indexed by basename if laid out oddly;
                    # do not copy host glibc just to satisfy static inspection.
                    pass
                continue
            gp = guest.get(soname)
            if gp and gp.exists():
                queue.append(gp)
                continue
            if soname in copied:
                queue.append(copied[soname]); continue
            hp = resolve_host(soname, cache)
            if hp is None:
                missing.append((soname, str(obj)))
                continue
            dst = destdir/soname
            # Dereference host symlinks and install the actual ELF bytes under SONAME.
            src = hp.resolve()
            shutil.copy2(src, dst)
            os.chmod(dst, 0o755)
            guest[soname]=dst
            copied[soname]=dst
            queue.append(dst)
            manifest.append(f'{soname}\t{src}\t{dst.relative_to(root)}')

    # libdrm is the exact failure observed on the Dell.  Require it explicitly.
    drm = guest.get('libdrm.so.2')
    if not drm or not drm.exists():
        raise SystemExit('FAIL: libdrm.so.2 is still unavailable after dependency bundling')
    if missing:
        lines='\n'.join(f'  {s} needed by {o}' for s,o in missing)
        raise SystemExit('FAIL: unresolved non-core graphics libraries:\n'+lines)

    mf=root/'opt/sos/lib/qt-graphics-host-bundle-v32l.tsv'
    mf.parent.mkdir(parents=True, exist_ok=True)
    mf.write_text('soname\thost_source\tguest_path\n'+'\n'.join(manifest)+'\n', encoding='utf-8')
    print(f'PASS: v32l Qt graphics dependency closure complete; copied {len(manifest)} missing libraries')
    print(f'PASS: libdrm.so.2 bundled at {drm.relative_to(root)}')
    for line in manifest:
        print('  '+line)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
