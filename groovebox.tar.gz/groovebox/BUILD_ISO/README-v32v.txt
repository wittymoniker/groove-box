Groovebox BUILD_ISO R21 / v32v — INITRAMFS VERIFIER SCOPE FIX — 2026-09-18

Run:
  ./RUN_ME_v32v.sh

Expected ISO:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-INITRAMFS-VERIFIER-SCOPE-FIX-v32v.iso

Fix over v32u:
- v32u correctly generated a no-job-control /init, but its verifier searched the
  entire installed initramfs byte stream for words such as "cttyhack" and "sh -i".
- The initramfs necessarily contains BusyBox, and BusyBox itself can contain those
  strings as built-in command/help text even when /init never executes them.
- v32v parses the gzip/newc archive and applies the forbidden-shell check only to
  the generated /init script.
- It still verifies the exact no-job-control marker, switch_root path, and direct
  /dev/console recovery loop.
- Runtime behavior is unchanged from v32u: known-good v32o GUI/input/cursor path,
  direct console I/O, self-contained Copy-to-Disk, exact Debian kernel/modules.
