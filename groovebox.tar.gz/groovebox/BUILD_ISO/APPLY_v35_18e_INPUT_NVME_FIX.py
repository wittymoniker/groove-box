#!/usr/bin/env python3
from __future__ import annotations
import os,re,shutil,sys,time
from pathlib import Path
MARK='GROOVEBOX_V35_18E_INPUT_NVME_PATCH_20260921'

def die(s): raise SystemExit('FAIL: '+s)
def root_from_here():
    here=Path(__file__).resolve().parent
    if here.name=='BUILD_ISO': return here
    if (here/'BUILD_ISO').is_dir(): return here/'BUILD_ISO'
    die('place this patch under the current Groovebox BUILD_ISO tree')

def backup(p:Path,bdir:Path):
    if not p.exists(): return
    rel=p.relative_to(root); q=bdir/rel; q.parent.mkdir(parents=True,exist_ok=True)
    if not q.exists(): shutil.copy2(p,q)

def write_copy(src:Path,dst:Path,bdir:Path):
    backup(dst,bdir); shutil.copy2(src,dst); os.chmod(dst,0o755)

def inject_once(p:Path,needle:str,addition:str,bdir:Path)->bool:
    s=p.read_text(errors='replace')
    if MARK in s: return False
    if needle not in s: return False
    backup(p,bdir); s=s.replace(needle,addition+needle,1); p.write_text(s); return True

def patch_builder(p:Path,bdir:Path)->bool:
    try: s=p.read_text(errors='replace')
    except Exception: return False
    if 'ROOTFS' not in s or MARK in s: return False
    # Current v35 builders still descend from the v32x ROOTFS staging path, but
    # the appliance source filename changed several times. Match the stable
    # destination rather than one historical source name.
    m=re.search(r'(?m)^.*(?:install|cp).*\$ROOTFS/usr/bin/groovebox-appliance["\']?.*$',s)
    if not m:
        m=re.search(r'(?m)^.*(?:install|cp).*\$ROOTFS/usr/bin/groovebox-kernel-input-prep["\']?.*$',s)
    if not m: return False
    anchor=m.group(0)
    ins=(f'# {MARK}\n'
         'install -m 0755 "$HERE/v35_18e/sos-input-ready-v35_18e" "$ROOTFS/usr/bin/sos-input-ready"\n')
    backup(p,bdir); s=s[:m.start()]+ins+s[m.start():]; p.write_text(s); return True

def patch_init(p:Path,bdir:Path)->bool:
    try: s=p.read_text(errors='replace')
    except Exception: return False
    if MARK in s or 'groovebox-appliance' not in s: return False
    # Prefer the live/safe launch banner; otherwise inject immediately before the first launcher execution.
    patterns=[
      r'(?m)^(\s*)echo ["\']sOS[^\n]*launching Groovebox appliance["\']\s*$',
      r'(?m)^(\s*)(?:exec\s+)?/usr/bin/groovebox-appliance\b.*$',
    ]
    for pat in patterns:
        m=re.search(pat,s)
        if not m: continue
        indent=m.group(1)
        block=(f'{indent}# {MARK}\n'
               f'{indent}if [ -x /usr/bin/sos-input-ready ]; then\n'
               f'{indent}    if ! /usr/bin/sos-input-ready; then\n'
               f'{indent}        rc=42\n'
               f'{indent}        echo "FAIL: input stack is not ready; refusing to start Labwc/wlroots without devices." >&2\n'
               f'{indent}        if command -v recovery_menu >/dev/null 2>&1; then recovery_menu input-not-ready "$rc"; fi\n'
               f'{indent}        exit 42\n'
               f'{indent}    fi\n'
               f'{indent}fi\n')
        backup(p,bdir); s=s[:m.start()]+block+s[m.start():]; p.write_text(s); return True
    return False

def patch_installer(p:Path,bdir:Path)->bool:
    try: s=p.read_text(errors='replace')
    except Exception: return False
    if MARK in s: return False
    # Only patch the canonical destructive backend.
    if '--target whole-disk device is required' not in s or 'gpt_disk' not in s: return False
    old='[ -n "$TARGET" ] || { echo \'--target whole-disk device is required\' >&2; exit 2; }\nTARGET=$($PY "$GPT" validate "$TARGET") || exit $?'
    if old not in s: return False
    new=f'''# {MARK}\nif [ -z "$TARGET" ]; then\n  echo 'Available whole-disk install targets:'\n  LIST=$($PY "$GPT" list 2>/dev/null || true)\n  printf '%s\\n' "$LIST"\n  AVAIL=$(printf '%s\\n' "$LIST" | awk -F '\\t' '$4=="available" {{print $1}}')\n  COUNT=$(printf '%s\\n' "$AVAIL" | sed '/^$/d' | wc -l | tr -d ' ')\n  [ "$COUNT" -gt 0 ] || {{ echo 'Copy to Disk: no installable whole-disk targets detected.' >&2; exit 2; }}\n  printf 'Enter whole-disk target (for example /dev/nvme0n1): '\n  IFS= read -r TARGET\nfi\nTARGET=$($PY "$GPT" validate "$TARGET") || exit $?'''
    backup(p,bdir); p.write_text(s.replace(old,new,1)); return True

root=root_from_here(); assets=root/'v35_18e'
if not (assets/'sos-input-ready-v35_18e').exists(): die('v35_18e assets are missing')
stamp=time.strftime('%Y%m%d-%H%M%S'); bdir=root/'.v35_18e-backup'/stamp
bdir.mkdir(parents=True,exist_ok=True)
changed=[]

# Keep the runtime filename stable so existing builders/installers pick up the new enumerator.
gpt_old=root/'gpt_disk_v32q.py'
if gpt_old.exists():
    write_copy(assets/'gpt_disk_v35_18e.py',gpt_old,bdir); changed.append(str(gpt_old.relative_to(root)))
else:
    write_copy(assets/'gpt_disk_v35_18e.py',root/'gpt_disk_v35_18e.py',bdir); changed.append('gpt_disk_v35_18e.py')

# Install strict input gate into every current rootfs-building script that has a known staging anchor.
for p in root.rglob('*.sh'):
    if '.v35_18e-backup' in p.parts: continue
    if patch_builder(p,bdir): changed.append(str(p.relative_to(root)))

# Patch all current init variants because the active one differs across v35 branches.
for p in root.glob('init*'):
    if p.is_file() and patch_init(p,bdir): changed.append(str(p.relative_to(root)))

# Make no-argument Copy-to-Disk enumerate NVMe/MMC/SATA whole disks instead of failing before selection.
for name in ('sos-install-appliance-real-v32q','sos-install-appliance-real-v32t','sos-install-appliance'):
    p=root/name
    if p.exists() and patch_installer(p,bdir): changed.append(str(p.relative_to(root)))

# Also tag any Labwc launcher with an explicit gate if it starts Labwc directly outside /init.
for p in root.rglob('*'):
    if not p.is_file() or p.stat().st_size>512000 or '.v35_18e-backup' in p.parts: continue
    if p.suffix not in ('','.sh','.bash'): continue
    try: s=p.read_text(errors='replace')
    except Exception: continue
    if MARK in s or 'labwc' not in s: continue
    m=re.search(r'(?m)^(\s*)(?:exec\s+)?(?:env\s+[^\n]*\s+)?labwc\b.*$',s)
    if not m: continue
    ind=m.group(1); block=(f'{ind}# {MARK}\n{ind}if [ -x /usr/bin/sos-input-ready ]; then /usr/bin/sos-input-ready || exit 42; fi\n')
    backup(p,bdir); p.write_text(s[:m.start()]+block+s[m.start():]); changed.append(str(p.relative_to(root)))

# Marker and operator note.
(root/'V35_18E_INPUT_NVME_PATCHED.txt').write_text(
    MARK+'\nStrict libinput readiness + NVMe whole-disk target detection.\nBackup: '+str(bdir)+'\n')

if not any('build' in x.lower() and x.endswith('.sh') for x in changed):
    print('WARN: no recognized rootfs builder staging anchor was found; current tree may use a newer builder layout.')
    print('      The disk helper was patched, but sos-input-ready may need an explicit staging line in that newer builder.')
print('PASS:',MARK)
print('Backup:',bdir)
for x in changed: print('PATCHED:',x)
print('Next: run the SAME BUILD_ISO/RUN_ME_ZERO_STATE.sh command you were already using.')
