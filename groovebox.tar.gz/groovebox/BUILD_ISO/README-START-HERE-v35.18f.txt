Groovebox / sOS BUILD_ISO v35.18f — real udev input + live storage repair

This release fixes two physical-boot failures observed on the Dell:
1. wlroots/Labwc: "no input devices" / libinput backend failed.
2. Copy-to-Disk: no whole-disk devices detected.

Root causes corrected:
- Debian runtime now includes udev, udevadm/libinput tools, and seatd rather than libudev/libinput libraries alone.
- sos-input-ready is staged unconditionally and executes before sos-supervisor/Labwc.
- exact-kernel live rootfs now includes VMD/NVMe/AHCI/SCSI/USB/MMC storage modules, not only the future installed initramfs.
- sos-storage-ready loads those modules, triggers udev/mdev, rescans SCSI, and waits for /dev/nvme*, /dev/mmcblk*, /dev/sd*.
- Copy-to-Disk enumerates after storage bring-up; recovery `copy` with no DEVICE invokes the enumerator.

Build:
  cd ~/Downloads/groovebox
  chmod +x BUILD_ISO/RUN_ME_ZERO_STATE.sh
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

Expected final ISO:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-YYYYMMDD-GAME-READY-UDEV-INPUT-STORAGE-v35.18f.iso
