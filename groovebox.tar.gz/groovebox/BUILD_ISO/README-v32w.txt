Groovebox / sOS BUILD_ISO R22 — v32w LIVE-INIT + CONSOLE-SERVICE FIX
Date: 2026-09-18

Why v32w exists
---------------
The repeated message:
  can't access tty; job control turned off
was not only in the later recovery wrapper. The inherited live sOS boot still
had two older console paths below the Groovebox launcher:

1. /init could launch the legacy /usr/bin/sos-console and then fall through to
   an interactive /bin/sh.
2. /etc/sos/services/core-console.service caused sos-supervisor to auto-start
   sos-console on tty1, which could take ownership of the same screen Groovebox
   needed.

v32w fixes the live PID-1 boot path itself.

Changes
-------
- replaces the live /init with a non-interactive PID-1 script
- default live mode launches /usr/bin/groovebox-appliance directly
- recovery mode launches the non-shell recovery command menu
- disables every service descriptor that auto-starts sos-console/cttyhack/sh -i
- saves the previous /init and console artifacts under /opt/sos/legacy-v32w/
- neutralizes the active legacy sos-console command so hidden callers cannot
  seize tty1
- keeps v32v exact-kernel input, v32o cursor/input behavior, self-contained
  Copy-to-Disk, installed initramfs, and removable UEFI loader
- final ISO validation parses the actual embedded live initramfs and verifies
  the live /init and service directory, not just helper scripts

Run
---
  ./RUN_ME_v32w.sh

Expected ISO
------------
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-LIVE-INIT-CONSOLE-FIX-v32w.iso

Expected early boot banner
--------------------------
  sOS v32w live init: direct Groovebox GUI boot
  sOS v32w: launching /usr/bin/groovebox-appliance

If the GUI still cannot launch, v32w enters:
  sOS recovery menu v32w — direct console I/O, no shell job control
instead of starting an interactive BusyBox shell.
