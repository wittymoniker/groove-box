#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
from newc_stream import scan_newc

def main():
    if len(sys.argv) != 2: raise SystemExit('usage: verify_cursor_sync_v32t.py initramfs.img')
    req=['usr/bin/groovebox-appliance','usr/bin/groovebox-appliance.real','usr/bin/sos-recovery-shell','usr/bin/groovebox-display-check','usr/bin/groovebox-input-check','usr/bin/groovebox-kernel-input-prep','usr/lib/x86_64-linux-gnu/libdrm.so.2','etc/fonts/fonts.conf','opt/sos/lib/fonts-v32l.txt','opt/sos/lib/qt-input-host-bundle-v32l.tsv','opt/sos/qt-cursor-fix/sitecustomize.py']
    meta,bodies,_=scan_newc(Path(sys.argv[1]),capture=('usr/bin/groovebox-appliance',))
    miss=[x for x in req if x not in meta or meta[x][1] <= 0]
    if miss: raise SystemExit('FAIL: v32t missing: '+', '.join(miss))
    app=bodies['usr/bin/groovebox-appliance'].decode('utf-8','replace')
    must=['GROOVEBOX_R19_CONSOLE_IO_GUI_RESTORE_V32T_20260918','GROOVEBOX_R14_CURSOR_SYNC_V32O_20260918','GROOVEBOX_SOFTWARE_CURSOR=1','QT_QPA_EGLFS_HIDECURSOR=1','QT_QPA_FB_HIDECURSOR=1','/opt/sos/qt-cursor-fix','PTR_COORD_MODE','pointer_has_rel_xy','evdev-auto','evdev-explicit','QT_QPA_EVDEV_MOUSE_PARAMETERS','QT_QPA_EVDEV_KEYBOARD_PARAMETERS','try_pair eglfs-kms eglfs']
    bad=[x for x in must if x not in app]
    if bad: raise SystemExit('FAIL: v32t launcher checks missing: '+', '.join(bad))
    hit=[x for x in ('evdev-generic',) if x in app]
    if hit: raise SystemExit('FAIL: v32t stale/bad input settings remain: '+', '.join(hit))
    generic=[k for k,(m,s) in meta.items() if '/plugins/generic/' in k and k.endswith('.so') and s>0]
    if not any('evdevkeyboard' in k.lower() for k in generic): raise SystemExit('FAIL: v32t missing Qt evdev keyboard plugin')
    if not any('evdevmouse' in k.lower() for k in generic): raise SystemExit('FAIL: v32t missing Qt evdev mouse plugin')
    fonts=[k for k,(m,s) in meta.items() if k.startswith('usr/share/fonts/truetype/groovebox/') and k.lower().endswith(('.ttf','.otf','.ttc')) and s>0]
    if not fonts: raise SystemExit('FAIL: v32t has no bundled fallback font')
    print(f'PASS: v32t cursor + keyboard + mouse/touch + fonts/display checks ({len(fonts)} fonts, {len(generic)} generic Qt plugins; streaming)')
if __name__=='__main__': main()
