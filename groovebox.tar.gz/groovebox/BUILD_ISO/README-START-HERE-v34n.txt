Groovebox BUILD_ISO v34n — installed-initramfs BusyBox repair — 2026-09-19

Fixes the failure:
  FAIL: v32q installed boot initramfs requires BusyBox in the live rootfs

Why it happened:
The fresh Debian 13 zero-state runtime had Python/Qt/audio and installer tools,
but BusyBox was not installed.  v32t's tiny installed-root initramfs deliberately
uses BusyBox, so its builder stopped even though the main live runtime was valid.

v34n fixes both paths:
1. New zero-state runtimes install Debian busybox-static from the start.
2. Existing v34k/v34m runtime caches are repaired in-place during v32x by
   downloading and staging only Debian busybox-static into the temporary live
   rootfs before the installed-root initramfs is built.

The Fedora host is not modified.
Run: sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh
