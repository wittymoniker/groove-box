#!/opt/pyvenv/bin/python3
# GROOVEBOX_R16_COPY_ROOT_V32Q_20260918
from __future__ import annotations
import os, pathlib, shutil, stat, sys

if len(sys.argv) != 2:
    raise SystemExit('usage: copy_root_v32q.py DESTINATION_ROOT')
dst_root = pathlib.Path(sys.argv[1]).resolve()
dst_root.mkdir(parents=True, exist_ok=True)

SKIP_TOP = {'dev','proc','sys','run','tmp','mnt','media','lost+found'}
root_dev = os.lstat('/').st_dev
hardlinks = {}
count = 0
bytes_done = 0

def copy_xattrs(src, dst, follow=False):
    try:
        for name in os.listxattr(src, follow_symlinks=follow):
            try:
                val=os.getxattr(src,name,follow_symlinks=follow)
                os.setxattr(dst,name,val,follow_symlinks=follow)
            except OSError:
                pass
    except OSError:
        pass

def copy_dir_meta(src, dst):
    try:
        st=os.stat(src, follow_symlinks=False)
        os.chmod(dst, stat.S_IMODE(st.st_mode), follow_symlinks=False)
        try: os.chown(dst, st.st_uid, st.st_gid, follow_symlinks=False)
        except PermissionError: pass
        try: os.utime(dst, ns=(st.st_atime_ns,st.st_mtime_ns), follow_symlinks=False)
        except OSError: pass
        copy_xattrs(src,dst,False)
    except OSError:
        pass

def clone(src: pathlib.Path, dst: pathlib.Path, top=False):
    global count, bytes_done
    try:
        st=os.lstat(src)
    except OSError as e:
        print(f'[copy] skip unreadable {src}: {e}', file=sys.stderr); return
    # Do not descend into unrelated mounted filesystems from the live system.
    if not top and stat.S_ISDIR(st.st_mode) and st.st_dev != root_dev:
        return
    mode=st.st_mode
    if stat.S_ISDIR(mode):
        dst.mkdir(parents=True, exist_ok=True)
        try:
            entries=list(os.scandir(src))
        except OSError as e:
            print(f'[copy] skip dir {src}: {e}', file=sys.stderr); return
        for ent in entries:
            if top and ent.name in SKIP_TOP:
                continue
            clone(pathlib.Path(ent.path), dst/ent.name, False)
        copy_dir_meta(src,dst)
        return
    if stat.S_ISLNK(mode):
        try:
            target=os.readlink(src)
            try:
                if dst.exists() or dst.is_symlink(): dst.unlink()
            except OSError: pass
            os.symlink(target,dst)
            try: os.lchown(dst,st.st_uid,st.st_gid)
            except OSError: pass
            copy_xattrs(src,dst,False)
        except OSError as e:
            print(f'[copy] symlink failed {src}: {e}', file=sys.stderr)
        count += 1
    elif stat.S_ISREG(mode):
        key=(st.st_dev,st.st_ino)
        first=hardlinks.get(key)
        try:
            dst.parent.mkdir(parents=True,exist_ok=True)
            if st.st_nlink>1 and first and pathlib.Path(first).exists():
                try:
                    if dst.exists(): dst.unlink()
                except OSError: pass
                os.link(first,dst)
            else:
                shutil.copy2(src,dst,follow_symlinks=False)
                try: os.chown(dst,st.st_uid,st.st_gid,follow_symlinks=False)
                except OSError: pass
                copy_xattrs(src,dst,False)
                if st.st_nlink>1: hardlinks[key]=str(dst)
            count += 1; bytes_done += st.st_size
        except OSError as e:
            print(f'[copy] file failed {src}: {e}', file=sys.stderr)
    elif stat.S_ISFIFO(mode):
        try: os.mkfifo(dst, stat.S_IMODE(mode)); os.chown(dst,st.st_uid,st.st_gid)
        except OSError: pass
    elif stat.S_ISCHR(mode) or stat.S_ISBLK(mode):
        # Nearly all device nodes are under /dev (skipped), but preserve any
        # intentional static special nodes elsewhere.
        try: os.mknod(dst,mode,st.st_rdev); os.chown(dst,st.st_uid,st.st_gid)
        except OSError: pass
    # sockets are runtime state; never copy them.
    if count and count % 500 == 0:
        print(f'[copy] {count} entries, {bytes_done/1024/1024:.1f} MiB file data')

clone(pathlib.Path('/'), dst_root, True)
for name, mode in [('dev',0o755),('proc',0o555),('sys',0o555),('run',0o755),('tmp',0o1777),('mnt',0o755),('media',0o755),('var/tmp',0o1777)]:
    p=dst_root/name; p.mkdir(parents=True,exist_ok=True)
    try: os.chmod(p,mode)
    except OSError: pass
print(f'PASS: copied live sOS root: {count} entries, {bytes_done/1024/1024:.1f} MiB file data')
