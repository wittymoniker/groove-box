"""Groovebox/sOS v32p bare-metal cursor sync with lower event overhead.

Activated only when GROOVEBOX_SOFTWARE_CURSOR=1.  The linuxfb/EGLFS native
cursor can remain painted at (0,0) while Qt delivers mouse events elsewhere.
v32p keeps the v32o event-synced software pointer, but does not show/raise or
repaint it redundantly for every raw trackpad event.
"""
from __future__ import annotations
import os

if os.environ.get("GROOVEBOX_SOFTWARE_CURSOR") == "1":
    try:
        from PyQt6.QtCore import QEvent, Qt
        from PyQt6.QtGui import QColor, QCursor, QPainter, QPainterPath, QPen
        from PyQt6.QtWidgets import QApplication, QWidget

        _orig_notify = QApplication.notify
        # Wheel events do not change pointer position, so avoid touching the
        # overlay for them. This trims a surprisingly hot path on touchpads.
        _mouse_types = {
            QEvent.Type.MouseMove,
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseButtonRelease,
            QEvent.Type.MouseButtonDblClick,
        }

        class _GrooveboxCursor(QWidget):
            def __init__(self, parent: QWidget):
                super().__init__(parent)
                self.resize(28, 36)
                self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
                self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
                self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
                self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                self._last_xy = None
                self.show()
                self.raise_()

            def set_event_position(self, x: int, y: int) -> None:
                xy = (max(-2, int(x) - 2), max(-2, int(y) - 2))
                if xy == self._last_xy:
                    return
                self._last_xy = xy
                self.move(*xy)

            def paintEvent(self, event):  # noqa: N802 - Qt API spelling
                p = QPainter(self)
                p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
                path = QPainterPath()
                path.moveTo(2, 2)
                path.lineTo(2, 27)
                path.lineTo(8, 21)
                path.lineTo(13, 33)
                path.lineTo(18, 31)
                path.lineTo(13, 19)
                path.lineTo(22, 19)
                path.closeSubpath()
                p.setPen(QPen(QColor(0, 0, 0), 4))
                p.setBrush(QColor(255, 255, 255))
                p.drawPath(path)
                p.setPen(QPen(QColor(255, 255, 255), 1))
                p.drawPath(path)

        def _event_pos_in_window(receiver, event):
            if not isinstance(receiver, QWidget):
                return None, None
            top = receiver.window()
            if top is None or not top.isVisible():
                return None, None
            try:
                if hasattr(event, "position"):
                    lp = event.position().toPoint()
                    return top, receiver.mapTo(top, lp)
            except Exception:
                pass
            try:
                if hasattr(event, "globalPosition"):
                    gp = event.globalPosition().toPoint()
                    return top, top.mapFromGlobal(gp)
            except Exception:
                pass
            return None, None

        def _notify(self, receiver, event):
            try:
                if event.type() in _mouse_types:
                    top, pos = _event_pos_in_window(receiver, event)
                    if top is not None and pos is not None:
                        cur = getattr(top, "_groovebox_cursor_overlay_v32p", None)
                        if cur is None:
                            cur = _GrooveboxCursor(top)
                            setattr(top, "_groovebox_cursor_overlay_v32p", cur)
                        cur.set_event_position(pos.x(), pos.y())
            except Exception:
                pass
            return _orig_notify(self, receiver, event)

        QApplication.notify = _notify
    except Exception:
        pass
