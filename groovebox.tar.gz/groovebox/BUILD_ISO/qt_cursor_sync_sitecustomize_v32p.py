"""Groovebox/sOS v35 modal-safe bare-metal cursor synchronization.

Used only when GROOVEBOX_SOFTWARE_CURSOR=1.  Keeps one lightweight child cursor
per active top-level and switches cleanly to modal dialogs instead of leaving the
visible cursor attached to the blocked parent window.
"""
# GROOVEBOX_V35_MODAL_CURSOR_SYNC_20260919
from __future__ import annotations
import os

if os.environ.get("GROOVEBOX_SOFTWARE_CURSOR") == "1":
    try:
        from PyQt6.QtCore import QEvent, Qt
        from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen
        from PyQt6.QtWidgets import QApplication, QWidget
        _orig_notify = QApplication.notify
        _mouse_types = {
            QEvent.Type.MouseMove,
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseButtonRelease,
            QEvent.Type.MouseButtonDblClick,
        }

        class _GrooveboxCursorV35(QWidget):
            def __init__(self, parent: QWidget):
                super().__init__(parent)
                self.resize(28, 36)
                self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
                self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
                self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
                self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                self._last_xy = None
                self.show(); self.raise_()
            def set_event_position(self, x: int, y: int) -> None:
                xy=(max(-2,int(x)-2), max(-2,int(y)-2))
                if xy == self._last_xy: return
                self._last_xy=xy; self.move(*xy)
                if not self.isVisible(): self.show()
                self.raise_()
            def paintEvent(self, event):
                p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
                path=QPainterPath(); path.moveTo(2,2); path.lineTo(2,27); path.lineTo(8,21)
                path.lineTo(13,33); path.lineTo(18,31); path.lineTo(13,19); path.lineTo(22,19); path.closeSubpath()
                p.setPen(QPen(QColor(0,0,0),4)); p.setBrush(QColor(255,255,255)); p.drawPath(path)
                p.setPen(QPen(QColor(255,255,255),1)); p.drawPath(path)

        def _target_and_pos(receiver, event):
            if not isinstance(receiver, QWidget): return None, None
            modal=QApplication.activeModalWidget()
            top=modal if isinstance(modal,QWidget) and modal.isVisible() else receiver.window()
            if top is None or not top.isVisible(): return None, None
            try:
                gp=event.globalPosition().toPoint()
                return top, top.mapFromGlobal(gp)
            except Exception:
                pass
            try:
                lp=event.position().toPoint(); src=receiver.window()
                gp=src.mapToGlobal(receiver.mapTo(src,lp))
                return top, top.mapFromGlobal(gp)
            except Exception:
                return None, None

        def _hide_other_overlays(active):
            try:
                for w in QApplication.topLevelWidgets():
                    if w is active: continue
                    c=getattr(w,"_groovebox_cursor_overlay_v35",None)
                    if c is not None and c.isVisible(): c.hide()
            except Exception:
                pass

        def _notify(self, receiver, event):
            result=_orig_notify(self, receiver, event)
            try:
                if event.type() in _mouse_types:
                    top,pos=_target_and_pos(receiver,event)
                    if top is not None and pos is not None:
                        _hide_other_overlays(top)
                        cur=getattr(top,"_groovebox_cursor_overlay_v35",None)
                        if cur is None:
                            cur=_GrooveboxCursorV35(top)
                            setattr(top,"_groovebox_cursor_overlay_v35",cur)
                        cur.set_event_position(pos.x(),pos.y())
            except Exception:
                pass
            return result
        QApplication.notify=_notify
    except Exception:
        pass
