#!/usr/bin/env python3
"""Static/contract validation for Groovebox/sOS v35.22 deterministic shell."""
from __future__ import annotations
import py_compile, re, subprocess, sys, tempfile
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent).resolve()
proj = root.parent

def need(path: str, needles=()):
    p = root / path
    if not p.is_file(): raise SystemExit(f"FAIL: missing {p}")
    s = p.read_text(errors="replace")
    for n in needles:
        if n not in s: raise SystemExit(f"FAIL: {path} missing contract: {n}")
    return s

def pneed(path: str, needles=()):
    p = proj / path
    if not p.is_file(): raise SystemExit(f"FAIL: missing {p}")
    s = p.read_text(errors="replace")
    for n in needles:
        if n not in s: raise SystemExit(f"FAIL: {path} missing contract: {n}")
    return s

def shcheck(path: Path, shell: str):
    r=subprocess.run([shell,"-n",str(path)],capture_output=True,text=True)
    if r.returncode: raise SystemExit(f"FAIL: {shell} syntax {path}:\n{r.stderr}")

# Application deterministic media/player contracts.
perf=pneed("performance.py",[
    '"--keep-open=no"',
    'return ",".join(self.AUDIO_FX[f] for f in self.AUDIO_FX if f in self.active_audio_fx)',
    'return ",".join(self.VIDEO_FX[f] for f in self.VIDEO_FX if f in self.active_video_fx)',
    'Equal-power', 'Canonical metadata', 'Still-image duration', 'Advanced/System Files', 'Undo Trash',
])
if '--keep-open=yes' in perf: raise SystemExit('FAIL: stale mpv keep-open=yes can stall auto-advance')

router=pneed("media_output_router.py",[
    '--fs-screen-name=', 'drm-sysfs', 'alsa/', 'def do_HEAD', 'duration_s', 'media_kind', '1024*1024',
])
if '.read()' in re.sub(r'#.*','',router[router.find('def _serve_file'):router.find('def do_GET')]):
    raise SystemExit('FAIL: LAN media file serving still has an unbounded whole-file read')

browser=pneed("web_browser_tab.py",[
    'QWebEngineProfile', 'ForcePersistentCookies', 'setDownloadPath', 'permissionRequested',
    'fullScreenRequested', 'newWindowRequested', 'PluginsEnabled', 'settings.setAttribute(plugins,False)',
    "Groovebox · sOS" if "Groovebox · sOS" in (proj/'web_browser_tab.py').read_text(errors='replace') else "Mathematician's Groovebox · sOS",
])

# Cross-platform browser/full-runtime provisioning. v35.22b desktop launchers
# verify one shared manifest on every start rather than trusting first-run markers.
pneed("scripts/runtime_dependencies.py",['PyQt6.QtWebEngineWidgets', 'PyQt6-WebEngine', 'Pillow', 'scipy', 'cffi'])
pneed("scripts/ensure_runtime_dependencies.py",['.venv', '--force-install', 'system_site_packages=True'])
pneed("scripts/ensure_export_runtime.py",['ensure_runtime_dependencies.py'])
pneed("run_hybrid.sh",['ensure_runtime_dependencies.py'])
pneed("install_deps_linux.sh",['ensure_runtime_dependencies.py'])
pneed("install_deps_macos.sh",['ensure_runtime_dependencies.py'])
pneed("install_deps_windows.ps1",['ensure_runtime_dependencies.py'])
pneed("LAUNCH_GROOVEBOX_WINDOWS.bat",['ensure_runtime_dependencies.py'])
pneed("LAUNCH_GROOVEBOX_MACOS.command",['ensure_runtime_dependencies.py'])
pneed("launch_groovebox.py",['ensure_runtime_dependencies.py', 'os.execv'])

# Runtime: real udev, compositor, WebEngine, audio graph, non-root shell.
boot=need("bootstrap_clean_tree_v33c.sh",[
    'GROOVEBOX_V35_22G_ACTIVE_BOOTSTRAP_20260921', 'GROOVEBOX_V35_22G_EXTERNAL_RUNTIME_SETUP_20260921', 'runtime_setup_v35_22g.sh',
    '/usr/sbin/useradd --system', 'usermod -a -G audio,video,input,render groovebox',
])
setup=need("runtime_setup_v35_22g.sh",[
    'GROOVEBOX_V35_22G_RUNTIME_SETUP_FILE_20260921',
    'GROOVEBOX_V35_22G_WEBENGINE_PYTHON_LDD_AUDIT_20260921',
    'udev libinput10 libinput-tools seatd', 'labwc wlr-randr xwayland', 'pulseaudio-utils',
    'PyQt6-WebEngine==6.11.0', 'libnspr4 libnss3', 'libxcomposite1 libxdamage1',
])
shcheck(root/'runtime_setup_v35_22g.sh', '/bin/sh')
if "exec \"$CID\" /bin/sh -lc '" in boot or 'GROOVEBOX_RUNTIME_SETUP' in boot:
    raise SystemExit('FAIL: stale embedded container provisioning wrapper remains')

launcher=need("source/rootfs/usr/bin/groovebox-appliance",[
    'GROOVEBOX_V35_22_UNPRIVILEGED_APPLIANCE_20260921', 'runuser -u groovebox', 'pipewire-pulse',
])

# Live readiness and exact-kernel HDMI/storage/input modules.
storage=need("v35_18f/sos-storage-ready-v35_18f",['drivers_probe'])
if 'driver/unbind' in storage or '/unbind' in storage: raise SystemExit('FAIL: storage readiness still unbinds an active controller')
need("v35_18f/sos-input-ready-v35_18f",['INPUT_READY|PASS'])
need("v35_22/sos-hdmi-ready-v35_22",['i915','snd_hda_codec_hdmi','HDMI_READY|CONNECTED','HDMI_READY|NO-CABLE'])
need("bundle_hdmi_modules_v35_22.py",['i915','snd_hda_codec_hdmi','kernel-hdmi-modules-v35.22.txt'])
builder=need("build_from_v31c_layered_cache_v32x.sh",[
    'sos-hdmi-ready-v35_22', 'bundle_hdmi_modules_v35_22.py', 'sos-input-ready-v35_18f', 'bundle_live_storage_modules_v35_18f.py',
])
direct=need("groovebox-appliance-direct-v32t",[
    'GROOVEBOX_V35_22_WAYLAND_SHELL_HDMI_20260921','sos-hdmi-ready','seatd -u root -g video','labwc',
    'snd_hda_codec_hdmi','WAYLAND_DISPLAY',
])
finalp=need("patch_final_rootfs_v35_18f.py",['sos-hdmi-ready','seatd -u root -g video'])

# One authoritative release runner. No silent old-overlay application.
zero=need("RUN_ME_ZERO_STATE.sh",['RUN_ME_v35_22.sh'])
run=need("RUN_ME_v35_22.sh",['GAME-READY-v35.22.iso','verify_v35_22.py','verify_v35_18f.py','RUN_ME_v34p.sh'])
if '|| true' in run: raise SystemExit('FAIL: v35.22 release runner silently ignores a failure')
if 'APPLY_v35_21' in run: raise SystemExit('FAIL: v35.22 release runner still applies v35.21 as an optional overlay')
if 'RUN_ME_v35_18e.sh' in run or 'RUN_ME_v35_18f.sh' in run: raise SystemExit('FAIL: v35.22 runner still delegates to historical release wrappers')

# Syntax/compile relevant patched surfaces.
for rel in [
    'bundle_hdmi_modules_v35_22.py','patch_final_rootfs_v35_18f.py','verify_v35_22.py',
]: py_compile.compile(str(root/rel),doraise=True)
for rel in ['performance.py','media_output_router.py','web_browser_tab.py','groovebox_paths.py','launch_groovebox.py','scripts/runtime_dependencies.py','scripts/ensure_runtime_dependencies.py','scripts/ensure_export_runtime.py']:
    py_compile.compile(str(proj/rel),doraise=True)
for rel in ['source/rootfs/usr/bin/groovebox-appliance','groovebox-appliance-direct-v32t','v35_18f/sos-input-ready-v35_18f','v35_18f/sos-storage-ready-v35_18f','v35_22/sos-hdmi-ready-v35_22']:
    shcheck(root/rel,'/bin/sh')
for rel in ['bootstrap_clean_tree_v33c.sh','build_from_v31c_layered_cache_v32x.sh','RUN_ME_v35_22.sh','RUN_ME_ZERO_STATE.sh']:
    shcheck(root/rel,'/bin/bash')

# Strong ordering test: patch a synthetic live /init and prove input/storage/HDMI
# readiness all precede the supervisor/compositor path.
with tempfile.TemporaryDirectory() as td:
    r=Path(td); (r/'usr/bin').mkdir(parents=True); (r/'usr/lib/sos').mkdir(parents=True); (r/'opt/sos').mkdir(parents=True)
    (r/'init').write_text("#!/bin/sh\nmdev -s || true\nif [ -x /usr/bin/sos-supervisor ]; then\n /usr/bin/sos-supervisor &\nfi\n/usr/bin/groovebox-appliance\n")
    subprocess.run([sys.executable,str(root/'patch_final_rootfs_v35_18f.py'),str(r)],check=True,capture_output=True,text=True)
    s=(r/'init').read_text(); sup=s.find('/usr/bin/sos-supervisor')
    for n in ('/usr/bin/sos-input-ready','/usr/bin/sos-storage-ready','/usr/bin/sos-hdmi-ready'):
        pos=s.find(n)
        if pos < 0 or pos > sup: raise SystemExit(f'FAIL: {n} is not ordered before supervisor')

print('PASS: v35.22 deterministic appliance/player/browser/files/HDMI contracts')
