BUILD_ISO builder revision v35.22f: Debian runtime provisioning uses standalone runtime_setup_v35_22f.sh copied into Podman/Docker; fixes nested-shell parser failure. Appliance ISO version remains v35.22.

Groovebox / sOS BUILD_ISO v35.22 — DETERMINISTIC SOS SHELL + HDMI

RUN
  cd <groovebox-root>
  chmod +x BUILD_ISO/RUN_ME_ZERO_STATE.sh
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh

FINAL ISO
  BUILD_ISO/dist/Groovebox-sOS-x86_64-YYYYMMDD-GAME-READY-v35.22.iso

V35.22 GATES
  - deterministic Player FX/filter ordering and queue EOF behavior
  - real udev + libinput + seatd before compositor
  - live NVMe/VMD/AHCI/MMC/USB storage readiness without unbinding active controllers
  - Intel i915 DRM/KMS and HDA-HDMI exact-kernel module staging
  - Latitude 3510 internal eDP + HDMI/DP connector discovery and hot-plug readiness
  - PipeWire/Pulse + ALSA HDMI audio targets
  - Labwc lightweight multi-output shell, with direct Qt fallback
  - PyQt6-WebEngine present and browser runs unprivileged

CHECK AFTER BOOT
  grep 'INPUT_READY' /var/log/sos/input-ready-v35.18f.log
  grep 'STORAGE_READY' /var/log/sos/storage-ready-v35.18f.log
  grep 'HDMI_READY' /var/log/sos/hdmi-ready-v35.22.log
  cat /sys/class/drm/card*-*/status 2>/dev/null
  aplay -l
  pactl list short sinks 2>/dev/null

V35.22C BUILD-SCRIPT CORRECTION
  - RUN_ME_v35_22.sh no longer invokes RUN_ME_v35_18e.sh / RUN_ME_v35_18f.sh
  - stale historical source-layout assertions cannot block the current v35.22 build
  - current v35.18f input/storage foundation checks are still retained in compatible form
  - final ISO remains GAME-READY-v35.22.iso because runtime behavior is unchanged

V35.22D WEBENGINE NATIVE RUNTIME
  - Debian NSPR/NSS and Chromium/Qt WebEngine native libraries installed before Python import validation
  - ldd audit reports all unresolved QtWebEngine native libraries together

V35.22E CONTAINER SCRIPT FIX
  - Debian runtime provisioning is passed to podman/docker exec through a quoted heredoc on stdin
  - no nested single-quoted /bin/sh -lc payload remains
  - verify_v35_22.py extracts and syntax-checks the exact inner /bin/sh script
  - fixes: Syntax error: end of file unexpected (expecting "}")
