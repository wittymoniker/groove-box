#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$HERE}"

pick_root() {
  local d
  for d in "$ROOT" "$HERE" "$PWD" "$HOME/Desktop/groovebox"; do
    [[ -n "$d" ]] || continue
    if [[ -d "$d/BUILD_ISO" ]]; then (cd "$d" && pwd); return 0; fi
  done
  return 1
}
ROOT="$(pick_root || true)"
[[ -n "$ROOT" ]] || { echo 'FAIL: could not locate Groovebox root with BUILD_ISO' >&2; exit 3; }
BI="$ROOT/BUILD_ISO"
echo "[v34f] Groovebox root: $ROOT"
python3 "$BI/patch_input_priority_v34f.py" "$BI"
python3 "$BI/verify_input_priority_v34f.py" "$BI"

# Run the user's current zero-state/current builder without replacing its v34e
# runtime, FFmpeg, kernel-module, Limine or Copy-to-Disk work.
if [[ -f "$BI/RUN_ME_v34e.sh" ]]; then
  echo '[v34f] chaining to current v34e zero-state builder'
  exec bash "$BI/RUN_ME_v34e.sh" "$ROOT"
fi
if [[ -f "$ROOT/RUN_ME_ZERO_STATE.sh" ]]; then
  echo '[v34f] chaining to current zero-state runner'
  exec bash "$ROOT/RUN_ME_ZERO_STATE.sh" "$ROOT"
fi
if [[ -f "$BI/RUN_ME_v33c.sh" ]]; then
  echo '[v34f] v34e runner not present; chaining to retained v33c builder'
  exec bash "$BI/RUN_ME_v33c.sh" "$ROOT"
fi

echo 'PASS: v34f input fix applied, but no recognized build runner was found.'
echo 'Run your current Groovebox BUILD_ISO runner normally; the v32x builder hook will re-apply the fix before staging.'
