Groovebox / sOS BUILD_ISO R24 — v33a LIMINE + native sCode
2026-09-18

Run:
  ./RUN_ME_v33a.sh

The builder first generates the current v32x runtime so current Debian 6.12.96
kernel modules, Dell evdev/touchpad fixes, Qt input/display plugins and fonts are
retained. It then replaces the inherited live boot shell/supervisor path with a
minimal non-interactive init that probes native sCode stage-0 ABI 9 before
launching Groovebox, and wraps the exact kernel/initramfs in Limine v12.9.0.

Default boot chain:
  Firmware -> Limine -> Linux -> /init -> native sCode stage-0 -> Groovebox

Boot menu:
  Mathematician's Groovebox + sCode
  sCode Diagnostics
  sOS Safe Mode
  sOS Recovery Diagnostics

Copy-to-Disk is also converted to Limine UEFI: the installer writes Limine's
BOOTX64.EFI plus kernel/initramfs/config to the EFI System Partition. It retains
the exact ERASE /dev/... destructive confirmation and preflight checks.

Secure Boot must remain disabled unless the unsigned Limine EFI executable is
separately signed/enrolled.
