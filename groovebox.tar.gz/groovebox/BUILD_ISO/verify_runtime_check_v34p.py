#!/usr/bin/env python3
from pathlib import Path
import sys
B=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
checks={
 'groovebox-runtime-check-v34p':'GROOVEBOX_V34P_RUNTIME_DIAGNOSTIC_20260919',
 'init-v33a':'GROOVEBOX_V34P_RUNTIME_MENU_FIX_20260919',
 'patch_initramfs_v33a.sh':'GROOVEBOX_V34P_FINAL_INITRAMFS_RUNTIME_CHECK_20260919',
 'build_from_v31c_layered_cache_v32x.sh':'GROOVEBOX_V34P_RUNTIME_CHECK_STAGING_20260919',
 'sos-recovery-shell-v32w':'GROOVEBOX_V34P_RUNTIME_MENU_ABSPATH_20260919',
}
for rel, marker in checks.items():
 p=B/rel
 if not p.is_file(): raise SystemExit(f'FAIL: missing {rel}')
 s=p.read_text(errors='replace')
 if marker not in s: raise SystemExit(f'FAIL: {rel} missing {marker}')
init=(B/'init-v33a').read_text(errors='replace')
if '/usr/bin/groovebox-runtime-check' not in init: raise SystemExit('FAIL: PID1 recovery runtime command is not wired to checker')
patch=(B/'patch_initramfs_v33a.sh').read_text(errors='replace')
if 'groovebox-runtime-check-v34p' not in patch: raise SystemExit('FAIL: final initramfs patch does not inject checker')
print('PASS: v34p runtime checker is injected both before and after final initramfs layering')
print('PASS: PID1 recovery runtime command executes /usr/bin/groovebox-runtime-check')
