Groovebox / sOS R23 v32x RECOVERY-VERIFIER-FIX — 2026-09-18

Run:
  ./RUN_ME_v32x.sh

Expected ISO:
  BUILD_ISO/dist/Groovebox-sOS-x86_64-20260918-RECOVERY-VERIFIER-FIX-v32x.iso

Fix in v32x:
- v32w correctly replaced the v32t recovery menu with the v32w non-interactive menu.
- The inherited v32t verifier still required the literal text "sOS recovery menu v32t".
- v32x uses a v32w-aware console/disk verifier that requires the R22/v32w recovery marker and "sOS recovery menu v32w" instead.
- Direct console Copy-to-Disk checks, v32o GUI/cursor checks, live-init checks, input modules, installed initramfs and UEFI loader remain intact.
