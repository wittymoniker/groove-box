Groovebox BUILD_ISO v34m hotfix
Fixes nondeterministic false "desktop sCode optimizer ABI 9 check failed".
Cause: grep -q + pipefail could SIGPIPE the correct verbose scode0 process.
Extract over the Groovebox project root and run:
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh
