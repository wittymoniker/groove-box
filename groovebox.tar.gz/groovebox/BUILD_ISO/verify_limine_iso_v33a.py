#!/usr/bin/env python3
from pathlib import Path
import struct,hashlib,sys
SECTOR=2048; CHUNK=1024*1024
if len(sys.argv)!=3: raise SystemExit('usage: verify_limine_iso_v33a.py ISO OFFICIAL_UEFI_IMAGE')
p=Path(sys.argv[1]); official=Path(sys.argv[2])
with p.open('rb') as f:
    f.seek(16*SECTOR); pvd=f.read(SECTOR); assert pvd[1:6]==b'CD001','PVD missing'
    f.seek(17*SECTOR); br=f.read(SECTOR); assert br[1:6]==b'CD001','El Torito boot record missing'
    cat_lba=struct.unpack('<I',br[71:75])[0]; f.seek(cat_lba*SECTOR); cat=f.read(SECTOR)
    assert cat[0]==1 and cat[30:32]==b'\x55\xaa','boot catalog validation entry bad'
    assert sum(struct.unpack('<16H',cat[:32]))&0xffff==0,'boot catalog checksum bad'; assert cat[32]==0x88,'BIOS default entry not bootable'; assert cat[64] in (0x90,0x91) and cat[65]==0xEF,'UEFI section missing'
    uefi_lba=struct.unpack('<I',cat[104:108])[0]; uefi_count=struct.unpack('<H',cat[102:104])[0]
    f.seek(446); ent=f.read(16); f.seek(510); assert f.read(2)==b'\x55\xaa','MBR signature missing'
    start=struct.unpack('<I',ent[8:12])[0]; count=struct.unpack('<I',ent[12:16])[0]
    assert ent[4]==0xEF and start==uefi_lba*4 and count==official.stat().st_size//512,'MBR EFI partition does not map UEFI image'
    f.seek(uefi_lba*SECTOR)
    with official.open('rb') as o:
        while True:
            ob=o.read(CHUNK)
            if not ob: break
            assert f.read(len(ob))==ob,'embedded UEFI FAT image differs from official Limine payload'
# Stream both token search and SHA-256; never load the ISO into RAM.
tokens=[b'LIMINE.CONF;1',b'LIMINE-BIOS.SYS;1',b'VMLINUZ;1',b'INITRAMF.IMG;1',b'BOOTX64.EFI;1']; found=[False]*len(tokens); h=hashlib.sha256(); tail=b''
with p.open('rb') as f:
    while True:
        b=f.read(CHUNK)
        if not b: break
        h.update(b); search=tail+b
        for i,t in enumerate(tokens):
            if not found[i] and t in search: found[i]=True
        tail=search[-64:]
for ok,t in zip(found,tokens): assert ok,f'missing ISO record {t!r}'
print('PASS: ISO9660 PVD'); print('PASS: El Torito BIOS + UEFI catalog'); print('PASS: official Limine UEFI FAT image byte-exact'); print('PASS: MBR EFI partition maps embedded FAT image'); print('PASS: required Limine/kernel/initramfs records present'); print('SHA256',h.hexdigest()); print('PASS: low-memory streaming ISO verification')
