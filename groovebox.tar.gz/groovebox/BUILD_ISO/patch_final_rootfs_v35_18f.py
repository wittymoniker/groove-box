#!/usr/bin/env python3
# GROOVEBOX_V35_18F_FINAL_ROOTFS_ORDERING_20260921
from __future__ import annotations
import os,re,sys
from pathlib import Path
MARK='GROOVEBOX_V35_18F_FINAL_ROOTFS_ORDERING_20260921'
if len(sys.argv)!=2: raise SystemExit('usage: patch_final_rootfs_v35_18f.py ROOTFS')
root=Path(sys.argv[1]).resolve()
if not root.is_dir(): raise SystemExit(f'FAIL: rootfs missing: {root}')

def patch_text(p:Path, fn):
    if not p.is_file(): return False
    s=p.read_text(errors='replace'); n=fn(s)
    if n==s: return False
    p.write_text(n); os.chmod(p,p.stat().st_mode|0o111); return True

def init_patch(s:str)->str:
    if MARK in s: return s
    block=f'''\n# {MARK}\n# MUST run before sos-supervisor/Labwc/wlroots. mdev nodes alone do not provide udev seat metadata.\nif [ -x /usr/bin/sos-input-ready ]; then\n  /usr/bin/sos-input-ready || {{\n    rc=$?\n    echo "sOS v35.18f: input readiness failed rc=$rc; compositor will not be started without real input devices."\n    if [ -x /usr/bin/sos-recovery-shell ]; then exec /usr/bin/sos-recovery-shell; fi\n    while :; do sleep 3600; done\n  }}\nfi\nif [ -x /usr/bin/sos-storage-ready ]; then /usr/bin/sos-storage-ready || true; fi\nif [ -x /usr/bin/sos-hdmi-ready ]; then /usr/bin/sos-hdmi-ready || true; fi\nexport LIBSEAT_BACKEND=seatd\nexport XDG_RUNTIME_DIR=${{XDG_RUNTIME_DIR:-/run/user/0}}\nmkdir -p /run/user/0 /run/seatd; chmod 700 /run/user/0 2>/dev/null || true\nif command -v seatd >/dev/null 2>&1 && ! pidof seatd >/dev/null 2>&1; then seatd -u root -g video >/tmp/seatd-init.log 2>&1 & sleep 0.2; fi\n'''
    # Place after mounts/mdev but strictly before any supervisor/compositor startup.
    anchors=[
        "if [ -c /dev/console ]; then exec </dev/console >/dev/console 2>&1; fi\n",
        "echo 'sOS v32w live init: direct Groovebox GUI boot'\n",
        "if [ -x /usr/bin/sos-supervisor ]; then\n",
    ]
    for a in anchors:
        if a in s:
            pos=s.index(a)+ (len(a) if 'console' in a or 'live init' in a else 0)
            return s[:pos]+block+s[pos:]
    # Last resort: directly before first supervisor or launcher reference.
    m=re.search(r'(?m)^.*(?:sos-supervisor|groovebox-appliance|labwc).*$' ,s)
    return s[:m.start()]+block+s[m.start():] if m else block+s

def installer_patch(s:str)->str:
    if MARK in s: return s
    anchor='REAL=/usr/lib/sos/sos-install-appliance.real-v32q\n'
    block=f'''# {MARK}\nif [ -x /usr/bin/sos-storage-ready ]; then /usr/bin/sos-storage-ready || true; fi\nif [ -x /usr/bin/sos-hdmi-ready ]; then /usr/bin/sos-hdmi-ready || true; fi\nexport LIBSEAT_BACKEND=seatd\nexport XDG_RUNTIME_DIR=${{XDG_RUNTIME_DIR:-/run/user/0}}\nmkdir -p /run/user/0 /run/seatd; chmod 700 /run/user/0 2>/dev/null || true\nif command -v seatd >/dev/null 2>&1 && ! pidof seatd >/dev/null 2>&1; then seatd -u root -g video >/tmp/seatd-init.log 2>&1 & sleep 0.2; fi\n'''
    if anchor in s: return s.replace(anchor,anchor+block,1)
    # real backend variant
    m=re.search(r'(?m)^\[ "\$\(id -u\)" -eq 0 \].*$',s)
    if m: return s[:m.start()]+block+s[m.start():]
    return s

def labwc_patch(s:str)->str:
    if MARK in s or 'labwc' not in s: return s
    block=f'''# {MARK}\nif [ -x /usr/bin/sos-input-ready ]; then /usr/bin/sos-input-ready || exit 42; fi\n'''
    m=re.search(r'(?m)^\s*(?:exec\s+)?(?:env\s+[^\n]*\s+)?(?:/usr/bin/)?labwc\b.*$',s)
    return s[:m.start()]+block+s[m.start():] if m else s

changed=[]
init=root/'init'
if patch_text(init,init_patch): changed.append('/init')
for base in ('usr/bin','usr/lib/sos'):
    d=root/base
    if not d.exists(): continue
    for p in d.glob('*'):
        if p.is_symlink() or not p.is_file(): continue
        if ('sos-install-appliance' in p.name or p.name in ('sos-copy-to-disk','copy-to-disk')) and patch_text(p,installer_patch):
            changed.append('/'+str(p.relative_to(root)))
# Patch any explicit compositor launcher/service that can bypass the GUI wrapper.
for base in ('usr/bin','usr/lib/sos','opt/sos','etc/sos/services','root/.config'):
    d=root/base
    if not d.exists(): continue
    for p in d.rglob('*'):
        try:
            if not p.is_file() or p.stat().st_size>512000: continue
            s=p.read_text(errors='replace')
        except Exception: continue
        if 'labwc' in s and patch_text(p,labwc_patch): changed.append('/'+str(p.relative_to(root)))
(root/'opt/sos/v35.18f-final-rootfs.txt').parent.mkdir(parents=True,exist_ok=True)
(root/'opt/sos/v35.18f-final-rootfs.txt').write_text(MARK+'\n'+'\n'.join(changed)+'\n')
print('PASS: v35.18f final rootfs ordering patched')
for x in changed: print('PATCHED:',x)
