Groovebox BUILD_ISO v35.22h — root pin + executable normalization

Fixes a post-runtime-cache Permission denied caused by ZIP-extracted historical shell helpers losing executable bits.
Pins all nested stages to the physical project root and refuses builds under ~/.local/share/Trash.
Current runners invoke historical shell helpers through bash where practical.
