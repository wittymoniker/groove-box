#!/usr/bin/env bash
# GROOVEBOX_V35_18F_REAL_UDEV_LIVE_STORAGE_20260921
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$HERE/APPLY_v35_21_INPUT_STORAGE_SEATD_FIX.py" "$HERE" 2>/dev/null || python3 "$HERE/APPLY_v35_21_INPUT_STORAGE_SEATD_FIX.py" || true
ROOT="${1:-$(dirname "$HERE")}"; BI="$ROOT/BUILD_ISO"
[[ -d "$BI" ]] || { echo 'FAIL: project root must contain BUILD_ISO' >&2; exit 3; }
echo "[v35.18f] Groovebox root: $ROOT"
python3 "$BI/verify_v35_18f.py" "$BI"
echo 'PASS: v35.18f preflight: real udev input + live internal-storage path'
bash "$BI/RUN_ME_v35_18e.sh" "$ROOT"
SRC="$(find "$BI/dist" -maxdepth 1 -type f -name 'Groovebox-sOS-x86_64-*-GAME-READY-INPUT-NVME-v35.18e.iso' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2-)"
[[ -n "$SRC" && -s "$SRC" ]] || { echo 'FAIL: v35.18e base ISO missing after build' >&2; exit 5; }
STAMP="$(date +%Y%m%d)"; DST="$BI/dist/Groovebox-sOS-x86_64-${STAMP}-GAME-READY-UDEV-INPUT-STORAGE-v35.18f.iso"
cp -f "$SRC" "$DST"; sha256sum "$DST" > "$DST.sha256"
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"; chown "$SUDO_USER:$g" "$DST" "$DST.sha256" 2>/dev/null || true; fi
echo; echo 'PASS: v35.18f standalone ISO built'; echo "ISO: $DST"; echo "SHA-256: $(cut -d' ' -f1 "$DST.sha256")"
