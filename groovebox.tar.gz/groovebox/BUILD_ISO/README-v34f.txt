Groovebox / sOS v34f — Dell touchpad event-priority hotfix
2026-09-19

What this fixes
- The photographed Dell exposes:
    event0 = AT keyboard
    event1 = DELL ... Mouse
    event2 = DELL ... Touchpad
    event3 = PS/2 Generic Mouse
- The retained v32t selector previously accepted the first mouse-like block, so Qt
  could bind QT_QPA_EVDEV_MOUSE_PARAMETERS to event1 even though event2 is the
  actual touchpad.
- v34f selects pointer nodes in this order:
    Touchpad/Synaptics/ELAN/ALPS -> TrackPoint/Pointing Stick -> named Mouse -> mouse-handler fallback.
- Keyboard selection is unchanged.
- Relative-vs-absolute coordinate detection is unchanged and still comes from the
  selected event node's kernel capability bits.
- Existing v34e zero-state runtime, FFmpeg, Debian 13/Python 3.13, exact kernel
  module staging, Limine, Copy-to-Disk and no-job-control recovery work are not replaced.

Use
1. Extract this archive over the current Groovebox project root so BUILD_ISO merges.
2. Run:
     chmod +x RUN_ME_v34f.sh
     ./RUN_ME_v34f.sh

Expected on the photographed Dell
- boot diagnostics should report the pointer as /dev/input/event2
- explicit Qt mouse params should contain:
     /dev/input/event2:nocompress:grab=0
  if the selected touchpad reports REL_X/REL_Y, as in the photo.

If the GUI still exits, the existing launcher will continue through its backend/input
fallbacks and leave the exact failure tail in /var/log/sos/groovebox-*.log before the
non-interactive sOS recovery menu appears.
