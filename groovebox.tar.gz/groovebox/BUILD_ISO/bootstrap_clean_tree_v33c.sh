#!/usr/bin/env bash
# GROOVEBOX_V35_22H_ROOT_PIN_EXEC_NORMALIZATION_20260921
# GROOVEBOX_V34N_BUSYBOX_ZERO_STATE_FIX_20260919
# GROOVEBOX_V34K_SOUNDDEVICE_FINDLIB_FIX_20260919
# Compatibility filename retained because RUN_ME_v33c.sh calls this helper.
# v34j retains the v34i zero-state path and hardens staged PortAudio discovery/loading.
set -euo pipefail
[[ $# -ge 1 ]] || { echo 'usage: bootstrap_clean_tree_v33c.sh GROOVEBOX_ROOT' >&2; exit 2; }
ROOT="$(cd "$1" && pwd)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BI="$ROOT/BUILD_ISO"
CACHE="$BI/dist/runtime-cache/initramfs.full.img"
WORK="$BI/dist/.v34k-zero-state-bootstrap"
mkdir -p "$BI/dist/runtime-cache" "$BI/runtime-base"

say(){ printf '%s\n' "$*"; }
fail(){ say "FAIL: $*" >&2; exit 1; }

# Reuse a known-good current cache/foundation if one is already present.
if bash "$HERE/bootstrap_runtime_cache_v33b.sh" "$ROOT" >"$BI/dist/.v34j-existing-cache.log" 2>&1; then
    cat "$BI/dist/.v34j-existing-cache.log"
    say '[v34k] existing full runtime cache accepted; zero-state bootstrap not needed.'
    exit 0
fi

say '[v34k] No complete runtime cache/foundation is present.'
say '[v34k] Building a fresh Debian 13 / Python 3.13 Groovebox runtime.'
say '[v34k] Historical BUILD_ISO baseline archives are intentionally not used.'

for x in tar gzip cpio python3 find; do
    command -v "$x" >/dev/null 2>&1 || fail "required host tool missing: $x"
done

ENGINE=''
if command -v podman >/dev/null 2>&1; then ENGINE=podman
elif command -v docker >/dev/null 2>&1; then ENGINE=docker
else
    fail 'first zero-state build needs podman or docker. Fedora: sudo dnf install -y podman'
fi
IMAGE="${GROOVEBOX_RUNTIME_IMAGE:-debian:13-slim}"

rm -rf "$WORK"
mkdir -p "$WORK/rootfs"
CID=''
cleanup(){
    set +e
    if [[ -n "$CID" ]]; then "$ENGINE" rm -f "$CID" >/dev/null 2>&1 || true; fi
    rm -rf "$WORK/rootfs.tar" "$WORK/rootfs" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

say "[v34k] container engine: $ENGINE"
say "[v34k] runtime image: $IMAGE"
"$ENGINE" pull "$IMAGE" >/dev/null
CID="$($ENGINE create "$IMAGE" /bin/sh -c 'while :; do sleep 3600; done')"
[[ -n "$CID" ]] || fail 'could not create Debian runtime container.'
"$ENGINE" start "$CID" >/dev/null

# GROOVEBOX_V35_18F_UDEV_RUNTIME_20260921
say '[v34k] installing Debian runtime libraries and appliance tools'
# GROOVEBOX_V35_22G_ACTIVE_BOOTSTRAP_20260921
# GROOVEBOX_V35_22G_EXTERNAL_RUNTIME_SETUP_20260921
# Compatibility manifest for retained historical source checks. The actual install
# is owned by runtime_setup_v35_22g.sh: busybox-static portaudio19-dev udev libinput10 libinput-tools seatd labwc wlr-randr xwayland pulseaudio-utils PyQt6-WebEngine==6.11.0 libnspr4 libnss3 libxcomposite1 libxdamage1
# Use a real file copied into the container.  This avoids all nested shell
# quoting/heredoc parsing between bash, podman/docker, and Debian /bin/sh.
RUNTIME_SETUP="$BI/runtime_setup_v35_22g.sh"
[[ -s "$RUNTIME_SETUP" ]] || fail "missing runtime setup: $RUNTIME_SETUP"
/bin/sh -n "$RUNTIME_SETUP" || fail 'runtime setup shell syntax check failed.'
say '[v35.22g] copying standalone runtime setup into Debian container'
"$ENGINE" cp "$RUNTIME_SETUP" "${CID}:/tmp/groovebox-runtime-setup.sh"
"$ENGINE" exec "$CID" /bin/sh /tmp/groovebox-runtime-setup.sh

say '[v34k] exporting fresh Debian runtime rootfs'
"$ENGINE" export -o "$WORK/rootfs.tar" "$CID"
[[ -s "$WORK/rootfs.tar" ]] || fail 'Debian runtime container did not produce its runtime tar.'
"$ENGINE" rm -f "$CID" >/dev/null 2>&1 || true
CID=''
tar -xf "$WORK/rootfs.tar" -C "$WORK/rootfs"
R="$WORK/rootfs"

say '[v34k] overlaying sOS foundation and current Groovebox/sCode source'
[[ -d "$BI/source/rootfs" ]] || fail 'BUILD_ISO/source/rootfs is missing.'
cp -a "$BI/source/rootfs/." "$R/"
mkdir -p "$R/opt/groovebox"
# The project root is authoritative so a newer Groovebox/sCode tree beside BUILD_ISO
# is what gets embedded. Keep build/output/user-cache trees out of the appliance.
(
  cd "$ROOT"
  tar \
    --exclude='./BUILD_ISO' \
    --exclude='./APPLIANCE_ISO' \
    --exclude='./.git' \
    --exclude='./.venv' \
    --exclude='./venv' \
    --exclude='./__pycache__' \
    --exclude='./dist' \
    --exclude='./build' \
    -cf - .
) | ( cd "$R/opt/groovebox" && tar --warning=no-timestamp -xf - )
find "$R/opt/groovebox" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true

[[ -f "$R/opt/groovebox/scode_optimizer_bridge.py" ]] || fail 'current Groovebox sCode bridge missing.'
[[ -x "$R/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0" ]] || chmod 0755 "$R/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0" 2>/dev/null || true
[[ -x "$R/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0" ]] || fail 'native Linux sCode stage-0 missing from project.'
[[ -f "$R/usr/bin/groovebox-appliance" ]] || fail 'sOS Groovebox appliance launcher missing from source/rootfs.'
chmod 0755 "$R/usr/bin/groovebox-appliance" "$R/init" 2>/dev/null || true

say '[v35.22] creating unprivileged Groovebox appliance user'
for grp in audio video input render; do chroot "$R" /usr/sbin/groupadd -f "$grp" 2>/dev/null || true; done
if ! grep -q '^groovebox:' "$R/etc/passwd" 2>/dev/null; then
  chroot "$R" /usr/sbin/useradd --system --create-home --home-dir /home/groovebox --shell /bin/sh --user-group groovebox
fi
chroot "$R" /usr/sbin/usermod -a -G audio,video,input,render groovebox 2>/dev/null || true
GB_UID="$(chroot "$R" /usr/bin/id -u groovebox)"
GB_GID="$(chroot "$R" /usr/bin/id -g groovebox)"
mkdir -p "$R/var/lib/groovebox" "$R/run/user/$GB_UID" "$R/home/groovebox"
chown -R "$GB_UID:$GB_GID" "$R/var/lib/groovebox" "$R/run/user/$GB_UID" "$R/home/groovebox"
chmod 700 "$R/run/user/$GB_UID"

say '[v34k] repairing/verifying staged PortAudio loader path'
# sounddevice uses ctypes to locate/dlopen PortAudio. Refresh the staged loader
# cache after the container export + sOS overlay, and guarantee both the ABI
# soname and unversioned linker name are present in the multiarch library dir.
PA_REAL="$(find "$R/usr/lib" "$R/lib" -xdev -type f -name 'libportaudio.so.2.*' -print -quit 2>/dev/null || true)"
if [[ -z "$PA_REAL" ]]; then
    PA_REAL="$(find "$R/usr/lib" "$R/lib" -xdev -type f -name 'libportaudio.so.2' -print -quit 2>/dev/null || true)"
fi
[[ -n "$PA_REAL" && -s "$PA_REAL" ]] || fail 'staged Debian rootfs is missing libportaudio.so.2 bytes.'
PA_DIR="$(dirname "$PA_REAL")"
if [[ "$(basename "$PA_REAL")" != 'libportaudio.so.2' ]]; then
    ln -sfn "$(basename "$PA_REAL")" "$PA_DIR/libportaudio.so.2"
fi
ln -sfn 'libportaudio.so.2' "$PA_DIR/libportaudio.so"
if [[ -x "$R/sbin/ldconfig" ]]; then
    chroot "$R" /sbin/ldconfig
elif [[ -x "$R/usr/sbin/ldconfig" ]]; then
    chroot "$R" /usr/sbin/ldconfig
else
    fail 'staged Debian rootfs is missing ldconfig.'
fi

say '[v34k] installing sounddevice PortAudio find_library compatibility bridge'
# Python's ctypes.util.find_library() can return None in a minimal staged rootfs
# even when the dynamic loader can successfully dlopen libportaudio.so.2.
# sounddevice treats that None as fatal before attempting dlopen. Install a
# venv-local startup shim which preserves normal discovery and only falls back
# to the known ABI soname for the single Linux 'portaudio' lookup.
SITEPKG="$R/opt/pyvenv/lib/python3.13/site-packages"
[[ -d "$SITEPKG" ]] || fail 'staged Python site-packages directory missing.'
cat > "$SITEPKG/groovebox_portaudio_findlib.py" <<'PYVENV'
import ctypes.util as _ctypes_util
import sys as _sys
_original_find_library = _ctypes_util.find_library

def _groovebox_find_library(name):
    result = _original_find_library(name)
    if result is None and name == 'portaudio' and _sys.platform.startswith('linux'):
        return 'libportaudio.so.2'
    return result

_ctypes_util.find_library = _groovebox_find_library
PYVENV
printf '%s\n' 'import groovebox_portaudio_findlib' > "$SITEPKG/groovebox-portaudio-findlib.pth"

# Verify PortAudio independently before importing sounddevice so a future
# failure reports the native-loader layer precisely instead of a generic Python error.
chroot "$R" /usr/bin/env \
  PATH=/opt/pyvenv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu:/opt/pyvenv/lib \
  /opt/pyvenv/bin/python3 - <<'PY'
import ctypes, ctypes.util
name = ctypes.util.find_library('portaudio') or 'libportaudio.so.2'
ctypes.CDLL(name)
print('PORTAUDIO-DLOPEN-PASS', name)
PY

say '[v34k] applying clean sCode pool compatibility bridge'
python3 "$HERE/patch_bridge_v31c.py" "$R/opt/groovebox/scode_optimizer_bridge.py"
python3 -m py_compile "$R/opt/groovebox/scode_optimizer_bridge.py"

# Validate the stage-0 using the actual command used by Groovebox. Do not require
# a separate --probe spelling; older/newer ABI-9 launchers differ there.
SCODE0="$R/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0"
SCODE_HOME="$R/opt/groovebox/sCode"
SCODE_OUT="$(cd "$SCODE_HOME" && "$SCODE0" run apps/groovebox/groovebox_optimizer.sC 2>&1 || true)"
printf '%s\n' "$SCODE_OUT" | grep -q '^scode_optimizer_abi=9$' || {
    printf '%s\n' "$SCODE_OUT" >&2
    fail 'native sCode stage-0 did not execute groovebox_optimizer.sC with ABI 9.'
}

say '[v34k] validating Python/PyQt/audio imports in staged rootfs'
chroot "$R" /usr/bin/env \
  PATH=/opt/pyvenv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu:/opt/pyvenv/lib \
  /opt/pyvenv/bin/python3 - <<'PY'
import ctypes, ctypes.util
pa = ctypes.util.find_library('portaudio')
if not pa:
    raise SystemExit('PORTAUDIO-FINDLIB-FAIL')
ctypes.CDLL(pa)
import numpy, scipy, PIL, cffi, sounddevice
from PyQt6 import QtCore, QtGui, QtWidgets, QtWebEngineWidgets
print('PORTAUDIO-FINDLIB-PASS', pa)
print('STAGED-RUNTIME-PASS', 'portaudio=', pa, 'sounddevice=', getattr(sounddevice, '__version__', '?'))
PY

say '[v34k] packing persistent full runtime cache'
rm -f "$CACHE" "$CACHE.sha256"
( cd "$R" && find . -xdev -print0 | LC_ALL=C sort -z | cpio --null -o --quiet -H newc --owner=0:0 ) | gzip -9n > "$CACHE"
gzip -t "$CACHE"
python3 "$HERE/verify_v31c.py" "$CACHE"
sha256sum "$CACHE" > "$CACHE.sha256"

# Keep a durable first-choice foundation too, so later rebuilds never re-enter
# the container bootstrap unless the user deletes both runtime-base and cache.
cp -f "$CACHE" "$BI/runtime-base/initramfs.img"
sha256sum "$BI/runtime-base/initramfs.img" > "$BI/runtime-base/initramfs.img.sha256"

if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"
    chown "$SUDO_USER:$g" "$CACHE" "$CACHE.sha256" \
      "$BI/runtime-base/initramfs.img" "$BI/runtime-base/initramfs.img.sha256" 2>/dev/null || true
fi
say "PASS: v34j zero-state runtime cache ready: $CACHE"
