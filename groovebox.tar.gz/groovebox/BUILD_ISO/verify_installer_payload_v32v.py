#!/usr/bin/env python3
# GROOVEBOX_R21_INITRAMFS_VERIFIER_SCOPE_V32V_20260918
from pathlib import Path
import gzip, os, sys

if len(sys.argv) < 3:
    raise SystemExit('usage: verify_installer_payload_v32v.py ROOTFS KVER')
root = Path(sys.argv[1]); kver = sys.argv[2]
paths = [root/'usr/sbin', root/'usr/bin', root/'sbin', root/'bin']

def cmd(name):
    for d in paths:
        p = d/name
        if p.exists() and os.access(p, os.X_OK):
            return p
    return None

missing = [x for x in ('mount','umount','mkfs.ext4','mkfs.vfat') if not cmd(x)]
if not (root/'opt/pyvenv/bin/python3').is_file():
    missing.append('/opt/pyvenv/bin/python3')
if missing:
    raise SystemExit('FAIL: v32v Copy-to-Disk minimal runtime missing: ' + ', '.join(missing))

need = {
    'usr/bin/sos-install-appliance': b'GROOVEBOX_R19_CONSOLE_IO_DISK_V32T_20260918',
    'usr/lib/sos/sos-install-appliance.real-v32q': b'GROOVEBOX_R16_DISK_BACKEND_V32Q_20260918',
    'usr/lib/sos/gpt_disk_v32q.py': b'GROOVEBOX_R16_GPT_DISK_V32Q_20260918',
    'usr/lib/sos/copy_root_v32q.py': b'GROOVEBOX_R16_COPY_ROOT_V32Q_20260918',
}
for rel, mark in need.items():
    p = root/rel
    if not p.is_file():
        raise SystemExit(f'FAIL: v32v installer component missing: {p}')
    if mark not in p.read_bytes():
        raise SystemExit(f'FAIL: current installer marker missing: {p}')

pay = root/'opt/sos/install-v32q'
efi = pay/'BOOTX64.EFI'; cfg = pay/'grub-installed.cfg'; kr = pay/'kernel-release'
initrd = pay/f'initramfs-sos-{kver}.img'; kernel = root/'boot'/f'vmlinuz-{kver}'
if not efi.is_file() or efi.stat().st_size < 64*1024 or efi.read_bytes()[:2] != b'MZ':
    raise SystemExit('FAIL: v32v BOOTX64.EFI invalid')
if not cfg.is_file() or b'sOS_ROOT' not in cfg.read_bytes():
    raise SystemExit('FAIL: v32v installed GRUB config missing')
if not kr.is_file() or kr.read_text().strip() != kver:
    raise SystemExit('FAIL: v32v kernel-release mismatch')
if not kernel.is_file() or kernel.stat().st_size < 1024*1024:
    raise SystemExit('FAIL: v32v exact kernel payload missing')
if not initrd.is_file() or initrd.stat().st_size < 64*1024:
    raise SystemExit('FAIL: v32v installed initramfs missing/small')

# Parse the gzip/newc archive and inspect ONLY the generated /init script.
# The previous verifier searched the entire initramfs byte stream. That includes
# the BusyBox binary, whose built-in command/help strings legitimately contain
# words such as "cttyhack" and shell examples. Those strings are not executable
# recovery paths and caused the v32u false failure.
def parse_newc(blob: bytes):
    files = {}
    pos = 0
    n = len(blob)
    while pos + 110 <= n:
        hdr = blob[pos:pos+110]
        if hdr[:6] not in (b'070701', b'070702'):
            raise SystemExit(f'FAIL: v32v malformed installed initramfs newc header at offset {pos}')
        try:
            size = int(hdr[54:62], 16)
            namesz = int(hdr[94:102], 16)
        except ValueError:
            raise SystemExit('FAIL: v32v malformed installed initramfs newc numeric header')
        pos += 110
        if namesz < 1 or pos + namesz > n:
            raise SystemExit('FAIL: v32v malformed installed initramfs filename')
        raw_name = blob[pos:pos+namesz-1]
        pos += namesz
        pos = (pos + 3) & ~3
        if pos + size > n:
            raise SystemExit('FAIL: v32v malformed installed initramfs file payload')
        data = blob[pos:pos+size]
        pos += size
        pos = (pos + 3) & ~3
        name = raw_name.decode('utf-8', 'replace')
        if name == 'TRAILER!!!':
            break
        files[name] = data
    return files

with gzip.open(initrd, 'rb') as f:
    files = parse_newc(f.read())
init_blob = files.get('./init') or files.get('init')
if not init_blob:
    raise SystemExit('FAIL: v32v installed initramfs /init missing')
if b'GROOVEBOX_R19_INSTALLED_INITRAMFS_NOJOB_V32T_20260918' not in init_blob:
    raise SystemExit('FAIL: v32v installed-initramfs marker missing from /init')
if b'GROOVEBOX_R20_INSTALLED_INITRAMFS_MARKER_FIX_V32U_20260918' not in init_blob:
    raise SystemExit('FAIL: v32v v32u initramfs marker missing from /init')
for bad in (b'exec sh', b'/bin/sh -i', b' sh -i', b'cttyhack'):
    if bad in init_blob:
        raise SystemExit(f'FAIL: v32v installed /init contains raw interactive-shell recovery path: {bad!r}')
if b'exec switch_root /newroot /init' not in init_blob:
    raise SystemExit('FAIL: v32v installed /init does not switch to the installed root')
if b'exec </dev/console >/dev/console 2>&1' not in init_blob:
    raise SystemExit('FAIL: v32v installed recovery loop is not bound directly to /dev/console')
print('PASS: v32v self-contained disk payload verified; /init has no interactive-shell recovery path')
