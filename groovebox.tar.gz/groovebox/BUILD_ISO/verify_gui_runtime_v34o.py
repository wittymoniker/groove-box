#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
req={
 'build_from_v31c_layered_cache_v32x.sh':'GROOVEBOX_V34O_GUI_RUNTIME_HOOK_20260919',
 'patch_gui_runtime_v34o.py':'GROOVEBOX_V34O_GUI_RUNTIME_LAUNCH_FIX_20260919',
 'groovebox-runtime-check-v34o':'GROOVEBOX_V34O_RUNTIME_DIAGNOSTIC_20260919',
 'source/rootfs/usr/bin/groovebox-appliance':'GROOVEBOX_V34O_GUI_RUNTIME_LAUNCH_FIX_20260919',
}
for rel,mark in req.items():
    p=root/rel
    if not p.exists() or mark not in p.read_text(errors='ignore'):
        raise SystemExit(f'FAIL: v34o missing {rel} / {mark}')
s=(root/'source/rootfs/usr/bin/groovebox-appliance').read_text()
if '/opt/pyvenv/bin/python3' not in s: raise SystemExit('FAIL: source launcher not venv-first')
if 'if [ -z "${QT_QPA_PLATFORM:-}" ]' not in s: raise SystemExit('FAIL: source launcher does not preserve QPA')
print('PASS: v34o GUI runtime/QPA/recovery diagnostic patch present')
