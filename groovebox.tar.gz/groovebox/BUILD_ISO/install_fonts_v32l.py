#!/usr/bin/env python3
"""Install a small host-local open-font fallback set into the sOS initramfs.

No font binaries are distributed by this patch.  When the user runs the builder
on Fedora, this helper copies already-installed system fonts (preferring
DejaVu/Noto/Liberation) into the guest image, then writes a minimal fontconfig
configuration.  It also reuses any TTF/OTF fonts already shipped with Groovebox.
"""
from __future__ import annotations
import os, shutil, subprocess, sys
from pathlib import Path

QUERIES = [
    'DejaVu Sans', 'DejaVu Sans:style=Bold', 'DejaVu Sans Mono',
    'Noto Sans', 'Noto Sans Mono',
    'Liberation Sans', 'Liberation Mono',
    'sans-serif', 'monospace',
]

def fc_match(q: str) -> Path | None:
    try:
        out = subprocess.check_output(['fc-match','-f','%{file}\n',q], text=True,
                                      stderr=subprocess.DEVNULL).strip().splitlines()
    except Exception:
        return None
    if not out:
        return None
    p = Path(out[0])
    return p if p.is_file() else None

def fallback_scan() -> list[Path]:
    bases=[Path('/usr/share/fonts'),Path('/usr/local/share/fonts')]
    names=('DejaVuSans.ttf','DejaVuSans-Bold.ttf','DejaVuSansMono.ttf',
           'NotoSans-Regular.ttf','NotoSansMono-Regular.ttf',
           'LiberationSans-Regular.ttf','LiberationMono-Regular.ttf')
    found=[]
    for base in bases:
        if not base.is_dir():
            continue
        for n in names:
            for p in base.rglob(n):
                if p.is_file(): found.append(p)
    return found

def main() -> int:
    if len(sys.argv) != 2:
        print('usage: install_fonts_v32l.py ROOTFS', file=sys.stderr); return 2
    root=Path(sys.argv[1]).resolve()
    if not root.is_dir(): raise SystemExit(f'FAIL: ROOTFS not found: {root}')
    dest=root/'usr/share/fonts/truetype/groovebox'
    dest.mkdir(parents=True, exist_ok=True)

    sources=[]
    # First keep/re-expose fonts already in the application/runtime.
    for base in (root/'opt/groovebox', root/'opt/pyvenv', root/'usr/share/fonts'):
        if base.is_dir():
            for ext in ('*.ttf','*.otf','*.ttc'):
                sources.extend(base.rglob(ext))
    # Add host fonts. These are copied at build time; they are not in this patch.
    for q in QUERIES:
        p=fc_match(q)
        if p: sources.append(p)
    if not any(Path(p).is_file() and not str(p).startswith(str(root)) for p in sources):
        sources.extend(fallback_scan())

    unique=[]; seen=set()
    for p in sources:
        p=Path(p)
        if not p.is_file(): continue
        try: key=str(p.resolve())
        except Exception: key=str(p)
        if key in seen: continue
        seen.add(key); unique.append(p)

    copied=[]
    for i,p in enumerate(unique):
        # Avoid recursively re-copying our own destination.
        try:
            if dest in p.resolve().parents: continue
        except Exception:
            pass
        name=p.name
        out=dest/name
        # de-duplicate same basenames from different locations
        if out.exists():
            if out.stat().st_size == p.stat().st_size: continue
            out=dest/f'{p.stem}-{i}{p.suffix}'
        try:
            shutil.copy2(p, out)
            os.chmod(out,0o644)
            copied.append(out)
        except Exception:
            continue
        if len(copied) >= 16:
            break

    fonts=[p for p in dest.iterdir() if p.is_file() and p.suffix.lower() in ('.ttf','.otf','.ttc')]
    if not fonts:
        raise SystemExit('FAIL: no usable TTF/OTF/TTC font could be installed. Fedora host needs an installed DejaVu, Noto, or Liberation font package.')

    etc=root/'etc/fonts'; etc.mkdir(parents=True, exist_ok=True)
    (root/'var/cache/fontconfig').mkdir(parents=True, exist_ok=True)
    conf='''<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">\n<fontconfig>\n  <dir>/usr/share/fonts/truetype/groovebox</dir>\n  <cachedir>/var/cache/fontconfig</cachedir>\n</fontconfig>\n'''
    (etc/'fonts.conf').write_text(conf, encoding='utf-8')
    manifest=root/'opt/sos/lib/fonts-v32l.txt'; manifest.parent.mkdir(parents=True, exist_ok=True)
    manifest.write_text('\n'.join('/'+str(p.relative_to(root)) for p in fonts)+'\n',encoding='utf-8')
    print(f'PASS: v32l font fallback installed: {len(fonts)} font file(s)')
    for p in fonts[:16]: print('  /'+str(p.relative_to(root)))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
