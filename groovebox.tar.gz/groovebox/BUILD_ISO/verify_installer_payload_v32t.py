#!/usr/bin/env python3
from pathlib import Path
import gzip, os, sys
if len(sys.argv)<3: raise SystemExit('usage: verify_installer_payload_v32t.py ROOTFS KVER')
root=Path(sys.argv[1]); kver=sys.argv[2]
paths=[root/'usr/sbin',root/'usr/bin',root/'sbin',root/'bin']
def cmd(name):
    for d in paths:
        p=d/name
        if p.exists() and os.access(p,os.X_OK): return p
    return None
missing=[x for x in ('mount','umount','mkfs.ext4','mkfs.vfat') if not cmd(x)]
if not (root/'opt/pyvenv/bin/python3').is_file(): missing.append('/opt/pyvenv/bin/python3')
if missing: raise SystemExit('FAIL: v32t Copy-to-Disk minimal runtime missing: '+', '.join(missing))
need={
 'usr/bin/sos-install-appliance':b'GROOVEBOX_R19_CONSOLE_IO_DISK_V32T_20260918',
 'usr/lib/sos/sos-install-appliance.real-v32q':b'GROOVEBOX_R16_DISK_BACKEND_V32Q_20260918',
 'usr/lib/sos/gpt_disk_v32q.py':b'GROOVEBOX_R16_GPT_DISK_V32Q_20260918',
 'usr/lib/sos/copy_root_v32q.py':b'GROOVEBOX_R16_COPY_ROOT_V32Q_20260918',
}
for rel,mark in need.items():
    p=root/rel
    if not p.is_file(): raise SystemExit(f'FAIL: v32t installer component missing: {p}')
    if mark not in p.read_bytes(): raise SystemExit(f'FAIL: current installer marker missing: {p}')
pay=root/'opt/sos/install-v32q'; efi=pay/'BOOTX64.EFI'; cfg=pay/'grub-installed.cfg'; kr=pay/'kernel-release'; initrd=pay/f'initramfs-sos-{kver}.img'; kernel=root/'boot'/f'vmlinuz-{kver}'
if not efi.is_file() or efi.stat().st_size<64*1024 or efi.read_bytes()[:2]!=b'MZ': raise SystemExit('FAIL: v32t BOOTX64.EFI invalid')
if not cfg.is_file() or b'sOS_ROOT' not in cfg.read_bytes(): raise SystemExit('FAIL: v32t installed GRUB config missing')
if not kr.is_file() or kr.read_text().strip()!=kver: raise SystemExit('FAIL: v32t kernel-release mismatch')
if not kernel.is_file() or kernel.stat().st_size<1024*1024: raise SystemExit('FAIL: v32t exact kernel payload missing')
if not initrd.is_file() or initrd.stat().st_size<64*1024: raise SystemExit('FAIL: v32t installed initramfs missing/small')
with gzip.open(initrd,'rb') as f: blob=f.read()
if b'GROOVEBOX_R19_INSTALLED_INITRAMFS_NOJOB_V32T_20260918' not in blob: raise SystemExit('FAIL: v32t installed-initramfs marker missing')
if b'exec sh' in blob or b'sh -i' in blob or b'cttyhack' in blob: raise SystemExit('FAIL: v32t installed initramfs still contains raw interactive shell recovery')
print('PASS: v32t self-contained disk payload + no-job-control installed recovery present')
