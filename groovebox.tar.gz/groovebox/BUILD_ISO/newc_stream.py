#!/usr/bin/env python3
"""Low-memory gzip/newc scanner for Groovebox BUILD_ISO.

The older verifiers expanded an entire multi-GB initramfs into a Python bytes
object and often kept every member body in a dictionary.  This module walks the
archive sequentially and only retains explicitly requested small files.
"""
from __future__ import annotations
import gzip
from pathlib import Path
from typing import Iterable

MAGICS = (b"070701", b"070702")
CHUNK = 1024 * 1024


def norm_name(name: str) -> str:
    while name.startswith("./"):
        name = name[2:]
    return name.lstrip("/")


def _read_exact(fh, n: int) -> bytes:
    out = bytearray()
    while len(out) < n:
        b = fh.read(n - len(out))
        if not b:
            raise EOFError(f"unexpected EOF while reading {n} bytes")
        out += b
    return bytes(out)


def _discard(fh, n: int) -> None:
    while n:
        b = fh.read(min(CHUNK, n))
        if not b:
            raise EOFError("unexpected EOF while skipping cpio payload")
        n -= len(b)


def _find_magic(fh):
    """Find the next newc magic after zero/block padding without buffering archive."""
    win = bytearray()
    while True:
        b = fh.read(1)
        if not b:
            return None
        win += b
        if len(win) > 6:
            del win[0]
        if len(win) == 6 and bytes(win) in MAGICS:
            return bytes(win)


def scan_newc(path, capture: Iterable[str] = (), capture_prefixes: Iterable[str] = ()):
    """Return (meta, bodies, trailers) using O(number-of-paths + captured-data) RAM.

    meta[name] = (mode, size) for the last occurrence of each path.
    bodies contains bytes only for exact capture names or capture_prefixes.
    """
    capture = {norm_name(x) for x in capture}
    prefixes = tuple(norm_name(x) for x in capture_prefixes)
    meta = {}
    bodies = {}
    trailers = 0

    with gzip.open(Path(path), "rb") as fh:
        magic = _find_magic(fh)
        while magic is not None:
            hdr = magic + _read_exact(fh, 104)
            try:
                mode = int(hdr[14:22], 16)
                size = int(hdr[54:62], 16)
                namesz = int(hdr[94:102], 16)
            except ValueError as e:
                raise RuntimeError("malformed newc numeric header") from e
            if namesz < 1:
                raise RuntimeError("malformed newc filename length")
            raw = _read_exact(fh, namesz)
            name = raw[:-1].decode("utf-8", "replace")
            _discard(fh, (-(110 + namesz)) & 3)
            key = norm_name(name)
            keep = key in capture or any(key.startswith(p) for p in prefixes)
            if keep:
                body = _read_exact(fh, size)
            else:
                _discard(fh, size)
                body = None
            _discard(fh, (-size) & 3)

            if key == "TRAILER!!!":
                trailers += 1
                magic = _find_magic(fh)
                continue

            meta[key] = (mode, size)
            if keep:
                bodies[key] = body

            magic = _read_exact(fh, 6)
            if magic not in MAGICS:
                raise RuntimeError(f"malformed newc header after {key!r}")

    if not meta or trailers == 0:
        raise RuntimeError("no usable newc archive entries/trailer found")
    return meta, bodies, trailers
