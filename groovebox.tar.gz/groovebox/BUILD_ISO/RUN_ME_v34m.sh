#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(dirname "$HERE")}" 
if [[ ! -d "$ROOT/BUILD_ISO" ]]; then
  for d in "$PWD" "$HOME/Downloads/groovebox/groovebox" "$HOME/Desktop/groovebox"; do
    if [[ -d "$d/BUILD_ISO" ]]; then ROOT="$(cd "$d" && pwd)"; break; fi
  done
fi
[[ -d "$ROOT/BUILD_ISO" ]] || { echo 'FAIL: run this from a Groovebox project root containing BUILD_ISO.' >&2; exit 3; }
BI="$ROOT/BUILD_ISO"

echo "[v34m] Groovebox root: $ROOT"
echo '[v34m] validating zero-state/bootstrap, input, installer, and sCode compatibility fixes'

grep -Fq 'GROOVEBOX_V34K_SOUNDDEVICE_FINDLIB_FIX_20260919' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34k PortAudio staging fix missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34I_SCODE_BOOT_COMPAT_20260919' "$BI/init-v33a" || { echo 'FAIL: retained v34i boot sCode compatibility missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34I_PATCH_INITRAMFS_SCODE_COMPAT_20260919' "$BI/patch_initramfs_v33a.sh" || { echo 'FAIL: retained v34i initramfs sCode compatibility missing' >&2; exit 4; }
python3 "$BI/patch_input_priority_v34f.py" "$BI"
python3 "$BI/verify_input_priority_v34f.py" "$BI"
python3 "$BI/patch_installer_stage_v34g.py" "$BI"
python3 "$BI/verify_installer_stage_v34g.py" "$BI"
python3 -m py_compile "$BI/bundle_kernel_input_modules_v32n.py" "$BI/verify_kernel_input_v32m.py"
grep -Fq 'PORTAUDIO-DLOPEN-PASS' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34k PortAudio dlopen validation missing' >&2; exit 4; }
grep -Fq 'groovebox_portaudio_findlib.py' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34k sounddevice find_library bridge missing' >&2; exit 4; }
grep -Fq 'PORTAUDIO-FINDLIB-PASS' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34k find_library validation missing' >&2; exit 4; }
grep -Fq 'portaudio19-dev' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34k PortAudio linker package missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34K_PORTAUDIO_RUNTIME_PATH_20260919' "$BI/groovebox-appliance-direct-v32t" || { echo 'FAIL: v34k runtime PortAudio path missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34E_USRMERGE_SAFE_MODULE_STAGING_20260919' "$BI/bundle_kernel_input_modules_v32n.py" || { echo 'FAIL: v34e usrmerge-safe module staging missing' >&2; exit 4; }
grep -Fq 'usr/lib/modules/' "$BI/verify_kernel_input_v32m.py" || { echo 'FAIL: v34e usr/lib/modules verifier path missing' >&2; exit 4; }

# GROOVEBOX_V34M_SCODE_PIPEFAIL_SIGPIPE_FIX_20260919
# Do not pipe the verbose stage-0 output through `grep -q` under `set -o pipefail`.
# grep -q may close the pipe as soon as the first ABI line matches, causing scode0
# to receive SIGPIPE (141).  That made a correct ABI-9 binary fail nondeterministically.
SCODE0="$ROOT/sCode/bootstrap/linux-x86_64/scode0"
if [[ -x "$SCODE0" ]]; then
  if ! SCODE_OPT_OUT="$(cd "$ROOT/sCode" && "$SCODE0" run apps/groovebox/groovebox_optimizer.sC 2>&1)"; then
    printf '%s\n' "$SCODE_OPT_OUT" >&2
    echo 'FAIL: desktop sCode optimizer execution failed' >&2
    exit 4
  fi
  if ! grep -Fqx 'scode_optimizer_abi=9' <<<"$SCODE_OPT_OUT"; then
    printf '%s\n' "$SCODE_OPT_OUT" >&2
    echo 'FAIL: desktop sCode optimizer ABI 9 check failed' >&2
    exit 4
  fi

  if ! SCODE_POOL_OUT="$(cd "$ROOT/sCode" && "$SCODE0" run apps/groovebox/pool_catalog.sC 2>&1)"; then
    printf '%s\n' "$SCODE_POOL_OUT" >&2
    echo 'FAIL: desktop sCode pool catalog execution failed' >&2
    exit 4
  fi
  if ! grep -Fqx 'pool_catalog_abi=1' <<<"$SCODE_POOL_OUT"; then
    printf '%s\n' "$SCODE_POOL_OUT" >&2
    echo 'FAIL: desktop sCode pool catalog check failed' >&2
    exit 4
  fi
  echo 'PASS: desktop sCode optimizer ABI 9'
  echo 'PASS: desktop sCode pool catalog ABI 1'
fi

echo '[v34m] starting clean zero-state builder; no historical baseline ZIP is required'
bash "$BI/RUN_ME_v33c.sh" "$ROOT"

SRC="$BI/dist/Groovebox-sOS-x86_64-20260918-LIMINE-SCODE-v33c.iso"
if [[ -s "$SRC" ]]; then
  DST="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34m.iso"
  cp -f "$SRC" "$DST"
  sha256sum "$DST" > "$DST.sha256"
  if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"
    chown "$SUDO_USER:$g" "$DST" "$DST.sha256" 2>/dev/null || true
  fi
  echo
  echo 'PASS: v34m zero-state ISO built'
  echo "ISO: $DST"
  echo "SHA-256: $(cut -d' ' -f1 "$DST.sha256")"
fi
