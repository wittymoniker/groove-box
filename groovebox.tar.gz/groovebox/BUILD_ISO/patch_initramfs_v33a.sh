#!/usr/bin/env bash
# GROOVEBOX_V34I_PATCH_INITRAMFS_SCODE_COMPAT_20260919
# GROOVEBOX_V34P_FINAL_INITRAMFS_RUNTIME_CHECK_20260919
set -euo pipefail
[[ $# -eq 3 ]] || { echo 'usage: patch_initramfs_v33a.sh IN_INITRD OUT_INITRD THIS_DIR' >&2; exit 2; }
IN="$1"; OUT="$2"; HERE="$3"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
mkdir -p "$WORK/root"
gzip -t "$IN"
( cd "$WORK/root" && gzip -dc "$IN" | cpio -idmu --quiet )
R="$WORK/root"
[[ -x "$R/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0" ]] || { echo 'FAIL: native sCode stage-0 missing from runtime' >&2; exit 3; }
install -m 0755 "$HERE/init-v33a" "$R/init"
install -m 0755 "$HERE/sos-scode-stage0-v33a" "$R/usr/bin/sos-scode-stage0"
# v34p: inject the runtime diagnostic after all earlier cache layering, so the
# final Limine boot initramfs cannot lose it to a stale cached rootfs.
install -m 0755 "$HERE/groovebox-runtime-check-v34p" "$R/usr/bin/groovebox-runtime-check"
# Kill inherited automatic interactive console ownership paths.
cat > "$R/usr/bin/sos-console" <<'SH'
#!/bin/sh
echo 'sOS v33a: interactive sos-console disabled; use Limine Recovery Diagnostics.' >&2
exit 64
SH
chmod 0755 "$R/usr/bin/sos-console"
cat > "$R/usr/bin/sos-supervisor" <<'SH'
#!/bin/sh
exit 0
SH
chmod 0755 "$R/usr/bin/sos-supervisor"
# Make installed Copy-to-Disk use Limine too.
install -m 0755 "$HERE/sos-install-appliance-limine-v33a" "$R/usr/lib/sos/sos-install-appliance.real-v32q"
install -m 0644 "$HERE/limine-v12.9.0/BOOTX64.EFI" "$R/opt/sos/install-v32q/BOOTX64.EFI"
KVER="$(cat "$R/opt/sos/install-v32q/kernel-release" 2>/dev/null || true)"
[[ -n "$KVER" ]] || { echo 'FAIL: installed kernel release marker missing in runtime' >&2; exit 4; }
cat > "$R/opt/sos/install-v32q/limine-installed.conf" <<CONF
timeout: 3
default_entry: 1

/Mathematician's Groovebox + sCode
    protocol: linux
    path: boot():/EFI/sOS/vmlinuz
    cmdline: rdinit=/init sos.mode=live scode.boot=1
    module_path: boot():/EFI/sOS/initramfs.img

/sOS Recovery Diagnostics
    protocol: linux
    path: boot():/EFI/sOS/vmlinuz
    cmdline: rdinit=/init sos.mode=recovery
    module_path: boot():/EFI/sOS/initramfs.img
CONF
mkdir -p "$R/opt/sos"
cat > "$R/opt/sos/LIMINE-SCODE-BOOT-v33a.txt" <<'TXT'
sOS v33a: Firmware -> Limine v12.9.0 -> Linux -> native sCode stage-0 ABI 9 -> Groovebox.
No automatic interactive shell/getty/cttyhack/job-control fallback is used by /init.
TXT
# Shell syntax + native sCode ABI tests against staged root.
/bin/sh -n "$R/init"
# GROOVEBOX_V35_INSTALL_BUILD_GUARD_20260919
grep -Fq 'GROOVEBOX_V35_INSTALL_DISPATCH_20260919' "$R/init" || { echo 'FAIL: v35 install dispatch missing from final /init' >&2; exit 4; }
grep -Fq 'sos.mode=install' "$HERE/limine-live.conf" || { echo 'FAIL: v35 Limine Install-to-Disk entry missing' >&2; exit 4; }
/bin/sh -n "$R/usr/bin/sos-scode-stage0"
/bin/sh -n "$R/usr/bin/groovebox-runtime-check"
grep -Fq 'GROOVEBOX_V34P_RUNTIME_DIAGNOSTIC_20260919' "$R/usr/bin/groovebox-runtime-check" || { echo 'FAIL: v34p runtime checker missing from final initramfs root' >&2; exit 4; }
grep -Fq '/usr/bin/groovebox-runtime-check' "$R/init" || { echo 'FAIL: v34p runtime recovery command not wired in final /init' >&2; exit 4; }
/bin/sh -n "$R/usr/lib/sos/sos-install-appliance.real-v32q"
SCODE0="$R/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0"
SCODE_HOME="$R/opt/groovebox/sCode"
SCODE_OUT="$(cd "$SCODE_HOME" && "$SCODE0" run apps/groovebox/groovebox_optimizer.sC 2>&1 || true)"
printf '%s\n' "$SCODE_OUT" | grep -q '^scode_optimizer_abi=9$' || {
  printf '%s\n' "$SCODE_OUT" >&2
  echo 'FAIL: native sCode stage-0 did not execute Groovebox optimizer ABI 9' >&2
  exit 4
}
! grep -E '/bin/(a)?sh[[:space:]]+-i|exec[[:space:]]+/bin/(a)?sh' "$R/init"
( cd "$R" && find . -xdev -print0 | cpio --null -o -H newc --quiet | gzip -9n ) > "$OUT"
gzip -t "$OUT"
echo "PASS: v33a Limine+sCode initramfs: $OUT ($(stat -c %s "$OUT") bytes)"
