#!/usr/bin/env bash
# GROOVEBOX_V34P_FINAL_RUNTIME_CHECK_INJECTION_20260919
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(dirname "$HERE")}"
[[ -d "$ROOT/BUILD_ISO" ]] || { echo 'FAIL: project root must contain BUILD_ISO' >&2; exit 3; }
BI="$ROOT/BUILD_ISO"
echo "[v34p] Groovebox root: $ROOT"
python3 "$BI/verify_runtime_check_v34p.py" "$BI"
/bin/sh -n "$BI/init-v33a"
/bin/sh -n "$BI/patch_initramfs_v33a.sh"
/bin/sh -n "$BI/groovebox-runtime-check-v34p"
echo 'PASS: v34p preflight confirms final-initramfs runtime diagnostic injection'
bash "$BI/RUN_ME_v34o.sh" "$ROOT"
SRC="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34o.iso"
[[ -s "$SRC" ]] || { echo "FAIL: v34o base ISO missing after build: $SRC" >&2; exit 5; }
DST="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34p.iso"
cp -f "$SRC" "$DST"
sha256sum "$DST" > "$DST.sha256"
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"; chown "$SUDO_USER:$g" "$DST" "$DST.sha256" 2>/dev/null || true; fi
echo
echo 'PASS: v34p zero-state ISO built'
echo "ISO: $DST"
echo "SHA-256: $(cut -d' ' -f1 "$DST.sha256")"
