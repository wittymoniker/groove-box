#!/usr/bin/env bash
# GROOVEBOX_V35_22H_ROOT_PIN_EXEC_NORMALIZATION_20260921
# GROOVEBOX_V35_22_DETERMINISTIC_SOS_SHELL_HDMI_20260921
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(dirname "$HERE")}"
ROOT="$(cd "$ROOT" && pwd -P)"
if [[ -n "${GROOVEBOX_BUILD_ROOT:-}" ]]; then
  PIN="$(cd "$GROOVEBOX_BUILD_ROOT" && pwd -P)"
  [[ "$ROOT" == "$PIN" ]] || { echo "FAIL: build-root drift: $ROOT != $PIN" >&2; exit 78; }
fi
case "$ROOT" in */.local/share/Trash/*) echo "FAIL: refusing Trash build root: $ROOT" >&2; exit 78;; esac
BI="$ROOT/BUILD_ISO"
[[ -d "$BI" ]] || { echo 'FAIL: project root must contain BUILD_ISO' >&2; exit 3; }
echo "[v35.22] Groovebox root: $ROOT"
if ! grep -Fq 'GROOVEBOX_V35_22G_ACTIVE_BOOTSTRAP_20260921' "$BI/bootstrap_clean_tree_v33c.sh"; then
  echo 'FAIL: stale bootstrap would re-enter the broken embedded container provisioning path.' >&2
  exit 77
fi
echo '[v35.22g] standalone Debian runtime-setup path selected'
echo '[v35.22] validating deterministic player/browser/file shell + real udev/input/storage + Latitude 3510 HDMI'
python3 "$BI/verify_v35_22.py" "$BI"
python3 "$BI/verify_v35_18f.py" "$BI"
python3 "$BI/verify_input_priority_v34f.py" "$BI"
python3 "$BI/verify_installer_stage_v34g.py" "$BI"
python3 -m py_compile "$BI/bundle_kernel_input_modules_v32n.py" "$BI/verify_kernel_input_v32m.py"
grep -Fq 'GROOVEBOX_V34E_USRMERGE_SAFE_MODULE_STAGING_20260919' "$BI/bundle_kernel_input_modules_v32n.py" || { echo 'FAIL: v34e usrmerge module staging missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34N_BUSYBOX_ZERO_STATE_FIX_20260919' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34n BusyBox zero-state path missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34K_SOUNDDEVICE_FINDLIB_FIX_20260919' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34k PortAudio path missing' >&2; exit 4; }
echo 'PASS: v35.22 current-architecture preflight'

# Build from the known zero-state foundation using the CURRENT integrated builder
# files. Do not invoke historical v35.18e/v35.18f release wrappers: their old
# source-layout assertions are not authoritative for v35.22.
bash "$BI/RUN_ME_v34p.sh" "$ROOT"
SRC="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34p.iso"
[[ -s "$SRC" ]] || { echo "FAIL: zero-state base ISO missing after build: $SRC" >&2; exit 5; }
STAMP="$(date +%Y%m%d)"
DST="$BI/dist/Groovebox-sOS-x86_64-${STAMP}-GAME-READY-v35.22.iso"
cp -f "$SRC" "$DST"
sha256sum "$DST" > "$DST.sha256"
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
  g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"
  chown "$SUDO_USER:$g" "$DST" "$DST.sha256" 2>/dev/null || :
fi
echo
echo 'PASS: v35.22 standalone deterministic sOS ISO built'
echo "ISO: $DST"
echo "SHA-256: $(cut -d' ' -f1 "$DST.sha256")"
echo 'Boot checks: INPUT_READY|PASS, STORAGE_READY|PASS, HDMI_READY|CONNECTED or HDMI_READY|NO-CABLE'
