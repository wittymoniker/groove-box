#!/opt/pyvenv/bin/python3
# GROOVEBOX_R16_GPT_DISK_V32Q_20260918
from __future__ import annotations
import binascii, fcntl, os, pathlib, struct, sys, time, uuid

BLKGETSIZE64 = 0x80081272
BLKSSZGET = 0x1268
BLKRRPART = 0x125f
MIN_BYTES = 8 * 1024**3
EFI_BYTES = 512 * 1024**2
ALIGN_BYTES = 1024 * 1024
EFI_TYPE = uuid.UUID('c12a7328-f81f-11d2-ba4b-00a0c93ec93b')
LINUX_TYPE = uuid.UUID('0fc63daf-8483-4772-8e79-3d69d8477de4')

def sys_block_name(dev: str) -> str:
    return os.path.basename(os.path.realpath(dev))

def is_partition(name: str) -> bool:
    return pathlib.Path('/sys/class/block', name, 'partition').exists()

def size_bytes(dev: str) -> int:
    fd = os.open(dev, os.O_RDONLY | getattr(os, 'O_CLOEXEC', 0))
    try:
        return struct.unpack('Q', fcntl.ioctl(fd, BLKGETSIZE64, b'\0' * 8))[0]
    finally:
        os.close(fd)

def sector_size(dev: str) -> int:
    fd = os.open(dev, os.O_RDONLY | getattr(os, 'O_CLOEXEC', 0))
    try:
        return struct.unpack('I', fcntl.ioctl(fd, BLKSSZGET, b'\0' * 4))[0]
    finally:
        os.close(fd)

def model(name: str) -> str:
    p = pathlib.Path('/sys/class/block', name, 'device/model')
    try: return p.read_text(errors='replace').strip()
    except Exception: return ''

def mounted_devices() -> set[str]:
    out=set()
    try:
        for line in pathlib.Path('/proc/self/mounts').read_text(errors='replace').splitlines():
            dev=line.split()[0] if line.split() else ''
            if dev.startswith('/dev/'):
                out.add(os.path.realpath(dev))
    except Exception:
        pass
    return out

def child_names(name: str):
    base=pathlib.Path('/sys/class/block', name)
    try:
        for p in base.iterdir():
            if pathlib.Path('/sys/class/block', p.name, 'partition').exists():
                yield p.name
    except Exception:
        return

def list_disks():
    mounted=mounted_devices()
    for p in sorted(pathlib.Path('/sys/class/block').iterdir()):
        n=p.name
        if n.startswith(('loop','ram','zram','sr','fd','dm-','md')) or is_partition(n):
            continue
        dev='/dev/'+n
        if not os.path.exists(dev):
            continue
        try: sz=size_bytes(dev)
        except Exception: continue
        kids=list(child_names(n))
        busy=any(os.path.realpath('/dev/'+k) in mounted for k in kids) or os.path.realpath(dev) in mounted
        print(f"{dev}\t{sz}\t{model(n) or '-'}\t{'MOUNTED' if busy else 'available'}")

def validate(dev: str):
    real=os.path.realpath(dev)
    if not real.startswith('/dev/') or not os.path.exists(real):
        raise SystemExit(f'not a device: {dev}')
    name=sys_block_name(real)
    if is_partition(name):
        raise SystemExit(f'target must be a whole disk, not a partition: {real}')
    st=os.stat(real)
    if not stat_is_block(st.st_mode):
        raise SystemExit(f'not a block device: {real}')
    sz=size_bytes(real)
    if sz < MIN_BYTES:
        raise SystemExit(f'target is too small ({sz} bytes); at least 8 GiB is required')
    mounted=mounted_devices()
    if real in mounted:
        raise SystemExit(f'target is mounted: {real}')
    for k in child_names(name):
        kd=os.path.realpath('/dev/'+k)
        if kd in mounted:
            raise SystemExit(f'target child is mounted: {kd}')
    # Refuse the currently inserted Groovebox ISO media when udev exposed its
    # filesystem label. This remains only an additional guard; the destructive
    # confirmation is still required for every target.
    for lbl in ('GROOVEBOX_SOS','GROOVEBOX-SOS'):
        lp=pathlib.Path('/dev/disk/by-label',lbl)
        if lp.exists():
            src=os.path.realpath(lp)
            bn=os.path.basename(src)
            sp=pathlib.Path('/sys/class/block',bn)
            try:
                parent=sp.resolve().parent.name if (sp/'partition').exists() else bn
                if os.path.realpath('/dev/'+parent)==real:
                    raise SystemExit(f'refusing current Groovebox boot media: {real}')
            except OSError:
                pass
    print(real)

def stat_is_block(mode:int)->bool:
    import stat
    return stat.S_ISBLK(mode)

def protective_mbr(last_lba: int, sector: int) -> bytes:
    m=bytearray(sector)
    # One protective 0xEE partition starting at LBA 1, capped at 32-bit.
    count=min(last_lba, 0xffffffff)
    ent=bytearray(16)
    ent[0]=0x00
    ent[1:4]=b'\x00\x02\x00'
    ent[4]=0xEE
    ent[5:8]=b'\xff\xff\xff'
    ent[8:12]=struct.pack('<I',1)
    ent[12:16]=struct.pack('<I',count)
    m[446:462]=ent
    m[510:512]=b'\x55\xaa'
    return bytes(m)

def entry(type_guid: uuid.UUID, unique: uuid.UUID, first:int, last:int, name:str)->bytes:
    b=bytearray(128)
    b[0:16]=type_guid.bytes_le
    b[16:32]=unique.bytes_le
    b[32:40]=struct.pack('<Q',first)
    b[40:48]=struct.pack('<Q',last)
    b[48:56]=struct.pack('<Q',0)
    enc=name.encode('utf-16le')[:72]
    b[56:56+len(enc)]=enc
    return bytes(b)

def header(current:int, backup:int, first_usable:int, last_usable:int, disk_guid:uuid.UUID,
           entries_lba:int, entries_crc:int, sector:int, entries_count:int=128, entry_size:int=128)->bytes:
    h=bytearray(sector)
    h[0:8]=b'EFI PART'
    h[8:12]=struct.pack('<I',0x00010000)
    h[12:16]=struct.pack('<I',92)
    h[16:20]=b'\0\0\0\0'
    h[20:24]=b'\0\0\0\0'
    h[24:32]=struct.pack('<Q',current)
    h[32:40]=struct.pack('<Q',backup)
    h[40:48]=struct.pack('<Q',first_usable)
    h[48:56]=struct.pack('<Q',last_usable)
    h[56:72]=disk_guid.bytes_le
    h[72:80]=struct.pack('<Q',entries_lba)
    h[80:84]=struct.pack('<I',entries_count)
    h[84:88]=struct.pack('<I',entry_size)
    h[88:92]=struct.pack('<I',entries_crc)
    crc=binascii.crc32(h[:92]) & 0xffffffff
    h[16:20]=struct.pack('<I',crc)
    return bytes(h)

def part_paths(dev:str):
    return (dev+'p1',dev+'p2') if dev[-1:].isdigit() else (dev+'1',dev+'2')

def write_gpt(dev:str):
    validate(dev)
    dev=os.path.realpath(dev)
    sec=sector_size(dev)
    if sec not in (512,4096):
        raise SystemExit(f'unsupported logical sector size: {sec}')
    total=size_bytes(dev)//sec
    last=total-1
    entries_count=128; entry_size=128
    entries_bytes=entries_count*entry_size
    entries_secs=(entries_bytes+sec-1)//sec
    first_usable=2+entries_secs
    last_usable=last-entries_secs-1
    align=max(1,ALIGN_BYTES//sec)
    efi_start=((first_usable+align-1)//align)*align
    efi_len=EFI_BYTES//sec
    efi_end=efi_start+efi_len-1
    root_start=((efi_end+1+align-1)//align)*align
    root_end=last_usable
    if root_end-root_start+1 < (4*1024**3)//sec:
        raise SystemExit('target has insufficient room for root partition')
    disk_guid=uuid.uuid4(); efi_guid=uuid.uuid4(); root_guid=uuid.uuid4()
    ents=bytearray(entries_bytes)
    ents[0:128]=entry(EFI_TYPE,efi_guid,efi_start,efi_end,'sOS EFI')
    ents[128:256]=entry(LINUX_TYPE,root_guid,root_start,root_end,'sOS Root')
    ecrc=binascii.crc32(ents)&0xffffffff
    primary_entries_lba=2
    backup_entries_lba=last-entries_secs
    ph=header(1,last,first_usable,last_usable,disk_guid,primary_entries_lba,ecrc,sec)
    bh=header(last,1,first_usable,last_usable,disk_guid,backup_entries_lba,ecrc,sec)
    fd=os.open(dev,os.O_RDWR|os.O_SYNC)
    try:
        os.pwrite(fd,protective_mbr(last,sec),0)
        os.pwrite(fd,ph,sec)
        os.pwrite(fd,bytes(ents),primary_entries_lba*sec)
        os.pwrite(fd,bytes(ents),backup_entries_lba*sec)
        os.pwrite(fd,bh,last*sec)
        os.fsync(fd)
        try: fcntl.ioctl(fd,BLKRRPART,0)
        except OSError: pass
    finally:
        os.close(fd)
    efi,rootp=part_paths(dev)
    for _ in range(30):
        if os.path.exists(efi) and os.path.exists(rootp): break
        time.sleep(.2)
    if not (os.path.exists(efi) and os.path.exists(rootp)):
        raise SystemExit(f'partition nodes did not appear: {efi}, {rootp}')
    print(f'EFI={efi}')
    print(f'ROOT={rootp}')
    print(f'DISK_GUID={disk_guid}')
    print(f'EFI_GUID={efi_guid}')
    print(f'ROOT_GUID={root_guid}')

if __name__=='__main__':
    if len(sys.argv)<2: raise SystemExit('usage: gpt_disk_v32q.py list|validate DEV|write DEV')
    a=sys.argv[1]
    if a=='list': list_disks()
    elif a=='validate' and len(sys.argv)==3: validate(sys.argv[2])
    elif a=='write' and len(sys.argv)==3: write_gpt(sys.argv[2])
    else: raise SystemExit('usage: gpt_disk_v32q.py list|validate DEV|write DEV')
