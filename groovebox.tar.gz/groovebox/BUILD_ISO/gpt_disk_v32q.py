#!/opt/pyvenv/bin/python3
# GROOVEBOX_V35_18E_NVME_WHOLE_DISK_20260921
from __future__ import annotations
import binascii, fcntl, os, pathlib, stat, struct, sys, time, uuid

BLKGETSIZE64=0x80081272; BLKSSZGET=0x1268; BLKRRPART=0x125f
MIN_BYTES=8*1024**3; EFI_BYTES=512*1024**2; ALIGN_BYTES=1024*1024
EFI_TYPE=uuid.UUID('c12a7328-f81f-11d2-ba4b-00a0c93ec93b')
LINUX_TYPE=uuid.UUID('0fc63daf-8483-4772-8e79-3d69d8477de4')
SYS=pathlib.Path('/sys/class/block')

PSEUDO_PREFIX=('loop','ram','zram','sr','fd','dm-','md')

def realdev(dev:str)->str: return os.path.realpath(dev)
def sys_name(dev:str)->str: return os.path.basename(realdev(dev))
def is_partition_name(name:str)->bool: return (SYS/name/'partition').exists()
def is_block(dev:str)->bool:
    try: return stat.S_ISBLK(os.stat(dev).st_mode)
    except OSError: return False

def size_bytes(dev:str)->int:
    fd=os.open(dev,os.O_RDONLY|getattr(os,'O_CLOEXEC',0))
    try: return struct.unpack('Q',fcntl.ioctl(fd,BLKGETSIZE64,b'\0'*8))[0]
    finally: os.close(fd)
def sector_size(dev:str)->int:
    fd=os.open(dev,os.O_RDONLY|getattr(os,'O_CLOEXEC',0))
    try: return struct.unpack('I',fcntl.ioctl(fd,BLKSSZGET,b'\0'*4))[0]
    finally: os.close(fd)
def read_text(p:pathlib.Path)->str:
    try: return p.read_text(errors='replace').strip()
    except Exception: return ''
def model(name:str)->str: return read_text(SYS/name/'device/model') or read_text(SYS/name/'device/name')
def readonly(name:str)->bool: return read_text(SYS/name/'ro')=='1'

def whole_parent_name(name:str)->str:
    """Return containing whole disk for sdX1, nvme0n1p1, mmcblk0p1, etc."""
    if not is_partition_name(name): return name
    p=(SYS/name).resolve()
    # The partition symlink resolves below .../block/<disk>/<partition>.
    parent=p.parent.name
    if parent and (SYS/parent).exists(): return parent
    # Fallback by sysfs link ancestry.
    for anc in p.parents:
        if (SYS/anc.name).exists() and not is_partition_name(anc.name): return anc.name
    return name

def child_names(name:str):
    try:
        base=(SYS/name).resolve()
        for p in base.iterdir():
            if (SYS/p.name/'partition').exists(): yield p.name
    except Exception:
        return

def mounted_sources()->set[str]:
    out=set()
    for fn in ('/proc/self/mounts','/proc/mounts'):
        try:
            for line in pathlib.Path(fn).read_text(errors='replace').splitlines():
                fields=line.split()
                if fields and fields[0].startswith('/dev/'):
                    out.add(realdev(fields[0]))
        except Exception: pass
    return out

def live_media_disks()->set[str]:
    out=set()
    mounted=mounted_sources()
    for src in mounted:
        n=os.path.basename(src); parent=whole_parent_name(n)
        # Any mounted ISO/USB filesystem with a Groovebox/sOS label is live media.
        # Also protect devices mounted under common live/initramfs locations.
        try:
            for lbl in ('GROOVEBOX_SOS','GROOVEBOX-SOS','SOS_LIVE','sOS_LIVE'):
                lp=pathlib.Path('/dev/disk/by-label')/lbl
                if lp.exists() and whole_parent_name(os.path.basename(realdev(str(lp))))==parent:
                    out.add('/dev/'+parent)
        except Exception: pass
    # Protect explicit boot/live media references from kernel command line.
    cmd=read_text(pathlib.Path('/proc/cmdline'))
    for tok in cmd.split():
        val=tok.split('=',1)[1] if '=' in tok else ''
        if val.startswith('/dev/') and os.path.exists(val):
            out.add('/dev/'+whole_parent_name(os.path.basename(realdev(val))))
    return {realdev(x) for x in out}

def busy_disk(name:str,mounted:set[str])->bool:
    dev=realdev('/dev/'+name)
    if dev in mounted: return True
    return any(realdev('/dev/'+k) in mounted for k in child_names(name))

def eligible_disks():
    mounted=mounted_sources(); live=live_media_disks()
    if not SYS.exists(): return
    for p in sorted(SYS.iterdir(),key=lambda x:x.name):
        n=p.name
        if n.startswith(PSEUDO_PREFIX) or is_partition_name(n): continue
        dev='/dev/'+n
        if not os.path.exists(dev) or not is_block(dev) or readonly(n): continue
        try: sz=size_bytes(dev)
        except Exception: continue
        if sz<MIN_BYTES: continue
        if realdev(dev) in live: continue
        yield dev,sz,model(n) or '-',busy_disk(n,mounted)

def list_disks():
    found=0
    for dev,sz,mdl,busy in eligible_disks():
        found+=1
        print(f"{dev}\t{sz}\t{mdl}\t{'MOUNTED' if busy else 'available'}")
    return found

def validate(dev:str):
    real=realdev(dev)
    if not real.startswith('/dev/') or not os.path.exists(real): raise SystemExit(f'not a device: {dev}')
    if not is_block(real): raise SystemExit(f'not a block device: {real}')
    name=sys_name(real)
    if is_partition_name(name): raise SystemExit(f'target must be a whole disk, not a partition: {real}')
    if name.startswith(PSEUDO_PREFIX): raise SystemExit(f'refusing pseudo/optical device: {real}')
    if readonly(name): raise SystemExit(f'target is read-only: {real}')
    sz=size_bytes(real)
    if sz<MIN_BYTES: raise SystemExit(f'target is too small ({sz} bytes); at least 8 GiB is required')
    if real in live_media_disks(): raise SystemExit(f'refusing current Groovebox boot media: {real}')
    mounted=mounted_sources()
    if busy_disk(name,mounted): raise SystemExit(f'target or one of its partitions is mounted: {real}')
    print(real)

def protective_mbr(last_lba:int,sector:int)->bytes:
    m=bytearray(sector); count=min(last_lba,0xffffffff); ent=bytearray(16)
    ent[1:4]=b'\x00\x02\x00'; ent[4]=0xEE; ent[5:8]=b'\xff\xff\xff'; ent[8:12]=struct.pack('<I',1); ent[12:16]=struct.pack('<I',count)
    m[446:462]=ent; m[510:512]=b'\x55\xaa'; return bytes(m)
def entry(t:uuid.UUID,u:uuid.UUID,first:int,last:int,name:str)->bytes:
    b=bytearray(128); b[:16]=t.bytes_le; b[16:32]=u.bytes_le; b[32:40]=struct.pack('<Q',first); b[40:48]=struct.pack('<Q',last)
    enc=name.encode('utf-16le')[:72]; b[56:56+len(enc)]=enc; return bytes(b)
def header(current:int,backup:int,first:int,lastu:int,dg:uuid.UUID,elba:int,ecrc:int,sec:int)->bytes:
    h=bytearray(sec); h[:8]=b'EFI PART'; h[8:12]=struct.pack('<I',0x10000); h[12:16]=struct.pack('<I',92)
    h[24:32]=struct.pack('<Q',current); h[32:40]=struct.pack('<Q',backup); h[40:48]=struct.pack('<Q',first); h[48:56]=struct.pack('<Q',lastu)
    h[56:72]=dg.bytes_le; h[72:80]=struct.pack('<Q',elba); h[80:84]=struct.pack('<I',128); h[84:88]=struct.pack('<I',128); h[88:92]=struct.pack('<I',ecrc)
    h[16:20]=struct.pack('<I',binascii.crc32(h[:92])&0xffffffff); return bytes(h)
def part_paths(dev:str): return (dev+'p1',dev+'p2') if dev[-1:].isdigit() else (dev+'1',dev+'2')
def write_gpt(dev:str):
    validate(dev); dev=realdev(dev); sec=sector_size(dev)
    if sec not in (512,4096): raise SystemExit(f'unsupported logical sector size: {sec}')
    total=size_bytes(dev)//sec; last=total-1; entries_bytes=128*128; entries_secs=(entries_bytes+sec-1)//sec
    first=2+entries_secs; lastu=last-entries_secs-1; align=max(1,ALIGN_BYTES//sec)
    efi_start=((first+align-1)//align)*align; efi_end=efi_start+EFI_BYTES//sec-1; root_start=((efi_end+1+align-1)//align)*align; root_end=lastu
    if root_end-root_start+1<(4*1024**3)//sec: raise SystemExit('target has insufficient room for root partition')
    dg,eg,rg=uuid.uuid4(),uuid.uuid4(),uuid.uuid4(); ents=bytearray(entries_bytes)
    ents[:128]=entry(EFI_TYPE,eg,efi_start,efi_end,'sOS EFI'); ents[128:256]=entry(LINUX_TYPE,rg,root_start,root_end,'sOS Root'); ecrc=binascii.crc32(ents)&0xffffffff
    pe=2; be=last-entries_secs; ph=header(1,last,first,lastu,dg,pe,ecrc,sec); bh=header(last,1,first,lastu,dg,be,ecrc,sec)
    fd=os.open(dev,os.O_RDWR|os.O_SYNC)
    try:
        os.pwrite(fd,protective_mbr(last,sec),0); os.pwrite(fd,ph,sec); os.pwrite(fd,bytes(ents),pe*sec); os.pwrite(fd,bytes(ents),be*sec); os.pwrite(fd,bh,last*sec); os.fsync(fd)
        try: fcntl.ioctl(fd,BLKRRPART,0)
        except OSError: pass
    finally: os.close(fd)
    efi,rootp=part_paths(dev)
    for _ in range(50):
        if os.path.exists(efi) and os.path.exists(rootp): break
        time.sleep(.2)
    if not (os.path.exists(efi) and os.path.exists(rootp)): raise SystemExit(f'partition nodes did not appear: {efi}, {rootp}')
    print(f'EFI={efi}'); print(f'ROOT={rootp}'); print(f'DISK_GUID={dg}'); print(f'EFI_GUID={eg}'); print(f'ROOT_GUID={rg}')

if __name__=='__main__':
    if len(sys.argv)<2: raise SystemExit('usage: gpt_disk_v35_18e.py list|validate DEV|write DEV')
    cmd=sys.argv[1]
    if cmd=='list': list_disks()
    elif cmd=='validate' and len(sys.argv)==3: validate(sys.argv[2])
    elif cmd=='write' and len(sys.argv)==3: write_gpt(sys.argv[2])
    else: raise SystemExit('usage: gpt_disk_v35_18e.py list|validate DEV|write DEV')
