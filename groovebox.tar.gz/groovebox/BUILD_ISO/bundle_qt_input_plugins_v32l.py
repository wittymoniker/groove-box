#!/usr/bin/env python3
"""Validate Qt embedded input plugins and bundle optional missing non-core deps.

v32l deliberately keeps libinput optional: libinput is preferred when its plugin
can load, while Qt's evdev path remains the mandatory fallback.  This avoids
making a Fedora libinput ABI a hard boot dependency of the appliance.
"""
from __future__ import annotations
import os, re, shutil, subprocess, sys
from pathlib import Path

CORE={
 'libc.so.6','libm.so.6','libdl.so.2','libpthread.so.0','librt.so.1',
 'ld-linux-x86-64.so.2','libgcc_s.so.1','libstdc++.so.6','libresolv.so.2',
 'libutil.so.1','libnsl.so.1','libcrypt.so.1'
}
NEEDED_RE=re.compile(r'\(NEEDED\).*Shared library: \[(.+?)\]')

def needed(p:Path)->list[str]:
    r=subprocess.run(['readelf','-d',str(p)],text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    return NEEDED_RE.findall(r.stdout) if r.returncode==0 else []

def guest_index(root:Path):
    d={}
    for p in root.rglob('*'):
        if p.is_file() or p.is_symlink():
            if '.so' in p.name or p.name.startswith('ld-linux'): d.setdefault(p.name,p)
    return d

def host_index():
    d={}
    try: txt=subprocess.check_output(['ldconfig','-p'],text=True,stderr=subprocess.DEVNULL)
    except Exception: txt=''
    for ln in txt.splitlines():
        if '=>' not in ln: continue
        a,b=ln.split('=>',1); son=a.strip().split()[0] if a.strip() else ''; p=Path(b.strip())
        if son and p.exists(): d.setdefault(son,[]).append(p)
    return d

def choose_host(son,idx):
    c=idx.get(son,[])
    if not c: return None
    return sorted(c,key=lambda p:(('/lib64/' in str(p) or '/usr/lib64/' in str(p)),'x86_64' in str(p),-len(str(p))),reverse=True)[0]

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: bundle_qt_input_plugins_v32l.py ROOTFS')
    root=Path(sys.argv[1]).resolve(); guest=guest_index(root); host=host_index()
    generic=[]
    for p in root.glob('opt/pyvenv/**/plugins/generic/*.so'):
        n=p.name.lower()
        if any(x in n for x in ('evdev','libinput','tuio','touch')): generic.append(p)
    if not generic:
        raise SystemExit('FAIL: PyQt6 generic input plugins are absent from guest runtime')
    names=sorted({p.name for p in generic})
    evmouse=any('evdevmouse' in n.lower() for n in names)
    evkbd=any('evdevkeyboard' in n.lower() for n in names)
    if not (evmouse and evkbd):
        raise SystemExit('FAIL: Qt evdev mouse/keyboard generic plugins are missing: '+', '.join(names))
    dest=root/'usr/lib/x86_64-linux-gnu'; dest.mkdir(parents=True,exist_ok=True)
    copied=[]; unresolved=[]; q=list(generic); seen=set()
    while q:
        obj=q.pop(0); k=str(obj)
        if k in seen: continue
        seen.add(k)
        for son in needed(obj):
            if son in CORE: continue
            gp=guest.get(son)
            if gp and gp.exists(): q.append(gp); continue
            hp=choose_host(son,host)
            if hp is None:
                unresolved.append((son,obj.name)); continue
            # Optional libinput chain only. Do not replace guest Qt/system libs.
            # Copy only if the soname is not already available in the guest.
            dst=dest/son
            try:
                shutil.copy2(hp.resolve(),dst); os.chmod(dst,0o755)
            except Exception:
                unresolved.append((son,obj.name)); continue
            guest[son]=dst; q.append(dst); copied.append((son,str(hp.resolve()),str(dst.relative_to(root))))
    mf=root/'opt/sos/lib/qt-input-host-bundle-v32l.tsv'; mf.parent.mkdir(parents=True,exist_ok=True)
    mf.write_text('soname\thost_source\tguest_path\n'+'\n'.join('\t'.join(x) for x in copied)+'\n',encoding='utf-8')
    print('PASS: v32l Qt evdev mouse and keyboard plugins present')
    print('Qt embedded input plugins: '+', '.join(names))
    if copied: print(f'INFO: copied {len(copied)} optional input-plugin dependencies')
    if unresolved:
        print('INFO: optional input dependencies unresolved; evdev auto-discovery remains available:')
        for son,obj in unresolved: print(f'  {son} needed by {obj}')
    return 0
if __name__=='__main__': raise SystemExit(main())
