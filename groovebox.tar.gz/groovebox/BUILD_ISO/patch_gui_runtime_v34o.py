#!/usr/bin/env python3
# GROOVEBOX_V34O_GUI_RUNTIME_LAUNCH_FIX_20260919
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: patch_gui_runtime_v34o.py ROOTFS')
root = Path(sys.argv[1])
paths = [root/'usr/bin/groovebox-appliance.real', root/'usr/bin/groovebox-appliance']
changed = 0
for p in paths:
    if not p.exists():
        continue
    s = p.read_text(errors='surrogateescape')
    old = s
    s = s.replace("APP='/usr/bin/python3 /opt/groovebox/run_groovebox.py'", "PY=\"${GROOVEBOX_PYTHON:-/opt/pyvenv/bin/python3}\"\n[ -x \"$PY\" ] || PY=/usr/bin/python3\nAPP=\"$PY /opt/groovebox/run_groovebox.py\"")
    s = s.replace('if command -v gamescope >/dev/null 2>&1; then\n  export QT_QPA_PLATFORM=xcb', 'if [ -z "${QT_QPA_PLATFORM:-}" ] && command -v gamescope >/dev/null 2>&1; then\n  export QT_QPA_PLATFORM=xcb')
    block = '''if [ -n "${WAYLAND_DISPLAY:-}" ]; then\n  export QT_QPA_PLATFORM=wayland\nelif [ -n "${DISPLAY:-}" ]; then\n  export QT_QPA_PLATFORM=xcb\nelse\n  export QT_QPA_PLATFORM=linuxfb\nfi'''
    repl = '''if [ -z "${QT_QPA_PLATFORM:-}" ]; then\n  if [ -n "${WAYLAND_DISPLAY:-}" ]; then\n    export QT_QPA_PLATFORM=wayland\n  elif [ -n "${DISPLAY:-}" ]; then\n    export QT_QPA_PLATFORM=xcb\n  else\n    export QT_QPA_PLATFORM=linuxfb\n  fi\nfi'''
    s = s.replace(block, repl)
    if '# GROOVEBOX_V34O_GUI_RUNTIME_LAUNCH_FIX_20260919' not in s:
        s = s.replace('#!/bin/sh\n', '#!/bin/sh\n# GROOVEBOX_V34O_GUI_RUNTIME_LAUNCH_FIX_20260919\n', 1)
    if s != old:
        p.write_text(s, errors='surrogateescape')
        p.chmod(p.stat().st_mode | 0o111)
        changed += 1

real = root/'usr/bin/groovebox-appliance.real'
if not real.exists():
    raise SystemExit('FAIL: groovebox-appliance.real missing')
rs = real.read_text(errors='surrogateescape')
for needle, msg in [('/opt/pyvenv/bin/python3','venv Python'), ('if [ -z "${QT_QPA_PLATFORM:-}" ]','QPA preservation')]:
    if needle not in rs:
        raise SystemExit(f'FAIL: v34o patch missing {msg}')
print(f'PASS: v34o patched GUI runtime launcher(s): {changed}')
