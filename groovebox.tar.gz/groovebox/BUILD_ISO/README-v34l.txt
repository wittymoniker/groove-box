Groovebox BUILD_ISO v34l — Debian exact-module stdout fix — 2026-09-19

Fixes a v32n/v32x command-substitution bug seen after the Debian 6.12.96+deb13-amd64
package downloaded successfully. The automatic downloader printed the downloaded .deb
path to stdout, then the helper printed the extracted module-tree path to stdout. v32x
captures stdout as MODULE_TREE, so the variable contained two newline-separated paths and
failed its directory test even though extraction succeeded.

v34l keeps downloader status on stderr and reserves stdout for exactly one value: the
module-tree directory. No kernel package, module extraction, evdev, touchpad, Limine,
PortAudio, sCode, or zero-state runtime behavior is otherwise changed.
