#!/usr/bin/env python3
from __future__ import annotations
import os,re,shutil,sys,time
from pathlib import Path
MARK='GROOVEBOX_V35_18F_INPUT_STORAGE_FIX_20260921'
HERE=Path(__file__).resolve().parent
root=HERE if HERE.name=='BUILD_ISO' else HERE/'BUILD_ISO'
if not root.is_dir(): raise SystemExit('FAIL: put this patch inside the current BUILD_ISO tree')
backup=root/'.v35_18f-backup'/time.strftime('%Y%m%d-%H%M%S'); backup.mkdir(parents=True,exist_ok=True)
def bak(p):
    if not p.exists(): return
    q=backup/p.relative_to(root); q.parent.mkdir(parents=True,exist_ok=True)
    if not q.exists(): shutil.copy2(p,q)
def write(p,s,mode=None):
    bak(p); p.write_text(s); mode is not None and os.chmod(p,mode)

# Runtime must contain real udev tooling; libudev1 alone is not enough for wlroots/libinput discovery.
b=root/'bootstrap_clean_tree_v33c.sh'
s=b.read_text()
if 'GROOVEBOX_V35_18F_UDEV_RUNTIME_20260921' not in s:
    if 'libgl1 libegl1 libopengl0 libdrm2 libgbm1 libudev1 libinput10' in s:
        s=s.replace('libgl1 libegl1 libopengl0 libdrm2 libgbm1 libudev1 libinput10',
                    'libgl1 libegl1 libopengl0 libdrm2 libgbm1 libudev1 udev libinput10 libinput-tools seatd',1)
    elif 'libudev1' in s and 'libinput10' in s:
        s=s.replace('libudev1','libudev1 udev',1).replace('libinput10','libinput10 libinput-tools seatd',1)
    else: raise SystemExit('FAIL: could not locate runtime libudev/libinput package list')
    s=s.replace("say '[v34k] installing Debian runtime libraries and appliance tools'",
                "# GROOVEBOX_V35_18F_UDEV_RUNTIME_20260921\nsay '[v34k] installing Debian runtime libraries and appliance tools'",1)
    write(b,s,0o755)

# Replace old helper assets with v35.18f and add live-storage bundler/finalizer.
(root/'v35_18f').mkdir(exist_ok=True)
assets=Path(__file__).resolve().parent/'v35_18f'
for name in ('sos-input-ready-v35_18f','sos-storage-ready-v35_18f'):
    p=assets/name
    if not p.exists(): raise SystemExit(f'FAIL: missing asset {p}')

builder=root/'build_from_v31c_layered_cache_v32x.sh'
s=builder.read_text()
if MARK not in s:
    # Unconditional helper staging, after exact module tree is resolved. The v35.18e staging was accidentally nested in a launcher backup condition.
    anchor='echo "[v32x] exact module tree: $MODULE_TREE"\n'
    if anchor not in s: raise SystemExit('FAIL: exact-module-tree staging anchor not found')
    stage=f'''\n# {MARK}\n# Stage readiness helpers unconditionally; do not hide them inside a launcher-backup conditional.\ninstall -m 0755 "$HERE/v35_18f/sos-input-ready-v35_18f" "$ROOTFS/usr/bin/sos-input-ready"\ninstall -m 0755 "$HERE/v35_18f/sos-storage-ready-v35_18f" "$ROOTFS/usr/bin/sos-storage-ready"\n'''
    s=s.replace(anchor,anchor+stage,1)
    # Live rootfs itself needs internal-disk modules; installed-initramfs-only staging is too late for Copy-to-Disk discovery.
    inp='python3 "$HERE/bundle_kernel_input_modules_v32n.py" "$ROOTFS" "$TARGET_KVER" "$MODULE_TREE"\n'
    if inp not in s: raise SystemExit('FAIL: live input module staging anchor not found')
    s=s.replace(inp,inp+'echo \'[v35.18f] bundling exact-kernel LIVE storage dependency closure\'\npython3 "$HERE/bundle_live_storage_modules_v35_18f.py" "$ROOTFS" "$TARGET_KVER" "$MODULE_TREE"\n',1)
    # Patch the FINAL generated /init after v32w rewrites it, before any packing/verification.
    live='python3 "$HERE/patch_live_boot_v32w.py" "$ROOTFS"\n'
    if live in s:
        s=s.replace(live,live+'python3 "$HERE/patch_final_rootfs_v35_18f.py" "$ROOTFS"\n',1)
    else:
        pack='rm -f "$NEWCACHE" "$NEWCACHE.sha256"\n'
        if pack not in s: raise SystemExit('FAIL: final rootfs patch anchor not found')
        s=s.replace(pack,'python3 "$HERE/patch_final_rootfs_v35_18f.py" "$ROOTFS"\n'+pack,1)
    write(builder,s,0o755)

# Recovery copy with no argument should invoke the enumerating installer instead of only printing syntax.
r=root/'sos-recovery-shell-v32w'
s=r.read_text()
old="if [ -z \"$dev\" ]; then echo 'usage: copy /dev/nvme0n1'; else /usr/bin/sos-copy-to-disk --target \"$dev\"; fi"
if old in s:
    s=s.replace(old,"if [ -z \"$dev\" ]; then /usr/bin/sos-copy-to-disk; else /usr/bin/sos-copy-to-disk --target \"$dev\"; fi",1)
    write(r,s,0o755)

# Use the already-hardened NVMe-aware GPT helper; storage readiness will now ensure its devices exist.
oldg=root/'gpt_disk_v32q.py'; newg=root/'v35_18e/gpt_disk_v35_18e.py'
if newg.exists(): bak(oldg); shutil.copy2(newg,oldg); os.chmod(oldg,0o755)
(root/'V35_18F_INPUT_STORAGE_PATCHED.txt').write_text(MARK+'\nReal udev before wlroots + live NVMe/VMD/MMC/SATA staging and load.\nBackup: '+str(backup)+'\n')
print('PASS:',MARK); print('Backup:',backup)
