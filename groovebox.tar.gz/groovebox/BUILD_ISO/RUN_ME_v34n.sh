#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(dirname "$HERE")}" 
if [[ ! -d "$ROOT/BUILD_ISO" ]]; then
  for d in "$PWD" "$HOME/Documents/groovebox" "$HOME/Downloads/groovebox" "$HOME/Desktop/groovebox"; do
    if [[ -d "$d/BUILD_ISO" ]]; then ROOT="$(cd "$d" && pwd)"; break; fi
  done
fi
[[ -d "$ROOT/BUILD_ISO" ]] || { echo 'FAIL: run this from a Groovebox project root containing BUILD_ISO.' >&2; exit 3; }
BI="$ROOT/BUILD_ISO"

echo "[v34n] Groovebox root: $ROOT"
echo '[v34n] validating BusyBox installed-initramfs repair plus retained v34m fixes'
grep -Fq 'GROOVEBOX_V34M_SCODE_PIPEFAIL_SIGPIPE_FIX_20260919' "$BI/RUN_ME_v34m.sh" || { echo 'FAIL: v34m sCode preflight fix missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34N_BUSYBOX_ZERO_STATE_FIX_20260919' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34n zero-state BusyBox package fix missing' >&2; exit 4; }
grep -Fq 'busybox-static' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: busybox-static is not in zero-state runtime packages' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34N_BUSYBOX_STAGE_HOOK_20260919' "$BI/build_from_v31c_layered_cache_v32x.sh" || { echo 'FAIL: v34n BusyBox staging hook missing' >&2; exit 4; }
python3 -m py_compile "$BI/prepare_debian_busybox_v34n.py" "$BI/build_installed_initramfs_v32t.py"
# Offline fast-path smoke test: an already-present BusyBox must avoid networking.
t="$(mktemp -d)"; trap 'rm -rf "$t"' EXIT
mkdir -p "$t/root/bin" "$t/bi"
printf '#!/bin/sh\nexit 0\n' > "$t/root/bin/busybox"; chmod +x "$t/root/bin/busybox"
python3 "$BI/prepare_debian_busybox_v34n.py" "$t/root" "$t/bi" amd64 >/dev/null
rm -rf "$t"; trap - EXIT
echo 'PASS: v34n BusyBox staging fast path'

# v34m performs all previous preflights and starts the canonical v33c build.
bash "$BI/RUN_ME_v34m.sh" "$ROOT"

SRC="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34m.iso"
if [[ ! -s "$SRC" ]]; then SRC="$BI/dist/Groovebox-sOS-x86_64-20260918-LIMINE-SCODE-v33c.iso"; fi
if [[ -s "$SRC" ]]; then
  DST="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34n.iso"
  cp -f "$SRC" "$DST"
  sha256sum "$DST" > "$DST.sha256"
  if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"
    chown "$SUDO_USER:$g" "$DST" "$DST.sha256" 2>/dev/null || true
  fi
  echo
  echo 'PASS: v34n zero-state ISO built'
  echo "ISO: $DST"
  echo "SHA-256: $(cut -d' ' -f1 "$DST.sha256")"
fi
