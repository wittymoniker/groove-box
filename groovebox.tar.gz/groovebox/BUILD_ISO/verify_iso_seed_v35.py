#!/usr/bin/env python3
from pathlib import Path
import hashlib, gzip, sys, subprocess
bi=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent)
root=bi/'iso-root'
k=root/'boot/vmlinuz'; i=root/'boot/initramfs.img'; g=root/'boot/grub/grub.cfg'
need=[k,i,g]
missing=[str(p) for p in need if not p.is_file() or p.stat().st_size==0]
if missing: raise SystemExit('FAIL: ISO seed missing: '+', '.join(missing))
want='2302f2cb75b3ed35c55bf75d062a17fc4e88199c0bc00bce4d2dc3be90311d6a'
got=hashlib.sha256(k.read_bytes()).hexdigest()
if got!=want: raise SystemExit(f'FAIL: ISO seed kernel hash mismatch: {got}')
try:
    with gzip.open(i,'rb') as f: f.read(256)
except Exception as e:
    raise SystemExit(f'FAIL: ISO seed initramfs gzip invalid: {e}')
t=g.read_text(errors='replace')
for s in ('sos.mode=live','sos.mode=install','sos.mode=recovery','/boot/vmlinuz','/boot/initramfs.img'):
    if s not in t: raise SystemExit('FAIL: ISO seed grub.cfg missing '+s)
print('PASS: ISO seed kernel = Debian 6.12.96+deb13-amd64')
print('PASS: ISO seed live/install/recovery grub entries present')
print('PASS: ISO seed initramfs is gzip-valid and intentionally replaceable')
