#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-}"

pick_root() {
    local d
    for d in \
      "${ROOT:-}" \
      "$HERE" \
      "$(dirname "$HERE")" \
      "$PWD" \
      "$HOME/Desktop/groovebox"; do
        [[ -n "$d" ]] || continue
        if [[ -d "$d/BUILD_ISO" ]]; then
            (cd "$d" && pwd); return 0
        fi
    done
    d="$HERE"
    while [[ "$d" != / ]]; do
        if [[ -d "$d/BUILD_ISO" ]]; then (cd "$d" && pwd); return 0; fi
        d="$(dirname "$d")"
    done
    d="$PWD"
    while [[ "$d" != / ]]; do
        if [[ -d "$d/BUILD_ISO" ]]; then (cd "$d" && pwd); return 0; fi
        d="$(dirname "$d")"
    done
    return 1
}

ROOT="$(pick_root || true)"
[[ -n "$ROOT" ]] || {
  echo 'FAIL: could not locate Groovebox project root (directory containing BUILD_ISO).' >&2
  echo 'Run from ~/Desktop/groovebox or pass the project root as the first argument.' >&2
  exit 3
}

echo "[v33c] Groovebox root: $ROOT"
if [[ $EUID -ne 0 ]]; then exec sudo "$HERE/RUN_ME_v33c.sh" "$ROOT"; fi

# R24 incorrectly required the persisted cache before it was allowed to run.
# v33b bootstraps it from runtime-base/current initrd when necessary.
"$HERE/bootstrap_clean_tree_v33c.sh" "$ROOT"

BI="$ROOT/BUILD_ISO"
"$HERE/build_from_v31c_layered_cache_v32x.sh" "$ROOT"
BASE_INIT="$BI/dist/runtime-cache/initramfs.v32x-recovery-verifier-fix.img"
[[ -s "$BASE_INIT" ]] || { echo "FAIL: v32x runtime output missing: $BASE_INIT" >&2; exit 4; }
PATCHED="$BI/dist/runtime-cache/initramfs.v33c-limine-scode.img"
"$HERE/patch_initramfs_v33a.sh" "$BASE_INIT" "$PATCHED" "$HERE"

if [[ -f "$BI/iso-root/boot/grub/grub.cfg" ]]; then ISO_TREE="$BI/iso-root"
elif [[ -f "$ROOT/iso-root/boot/grub/grub.cfg" ]]; then ISO_TREE="$ROOT/iso-root"
else echo 'FAIL: iso-root not found' >&2; exit 5; fi
KERNEL="$(find "$ISO_TREE/boot" -maxdepth 2 -type f \( -name 'vmlinuz*' -o -name 'bzImage*' -o -name 'linux-*' \) -print | head -1 || true)"
[[ -s "$KERNEL" ]] || { echo 'FAIL: kernel not found in ISO tree' >&2; exit 5; }
OUT="$BI/dist/Groovebox-sOS-x86_64-20260918-LIMINE-SCODE-v33c.iso"
README_TMP="$BI/dist/.limine-v33c-readme.txt"
cat > "$README_TMP" <<TXT
Mathematician's Groovebox / sOS v33c
Boot manager: Limine v12.9.0
Boot: Firmware -> Limine -> Linux -> native sCode stage-0 ABI 9 -> Groovebox
v33c adds true clean-tree recovery: if the full runtime and runtime-base are absent, it restores the historical BUILD_ISO foundation from the public Groovebox repository, regenerates the current full runtime, then performs the v32x refresh.
TXT
python3 "$HERE/build_limine_iso_v33a.py" "$OUT.pre" "$KERNEL" "$PATCHED" "$HERE/limine-v12.9.0" "$HERE/limine-live.conf" "$README_TMP"
python3 - "$OUT.pre" "$OUT" <<'PY'
from pathlib import Path
import os, struct, sys
src,dst=map(Path,sys.argv[1:3])
layout={}
for line in Path(str(src)+'.layout').read_text().splitlines():
    if '=' in line:
        k,v=line.split('=',1); layout[k]=int(v)
start=layout['uefi_cd_lba']*4; count=layout['uefi_cd_sectors_512']
ent=bytearray(16); ent[1:4]=bytes([0,2,0]); ent[4]=0xEF; ent[5:8]=bytes([0xFE,0xFF,0xFF]); ent[8:12]=struct.pack('<I',start); ent[12:16]=struct.pack('<I',count)
os.replace(src,dst)
with dst.open('r+b') as f:
    f.seek(446); f.write(ent); f.write(b'\0'*48); f.write(b'\x55\xaa'); f.flush(); os.fsync(f.fileno())
print(f'[v33c] embedded UEFI FAT MBR partition: start512={start} count512={count} (streaming patch)')
PY
LIM="$HERE/limine-v12.9.0/limine"
if ! "$LIM" --version >/dev/null 2>&1; then
  command -v cc >/dev/null 2>&1 || { echo 'FAIL: bundled Limine host tool is incompatible and cc is missing' >&2; exit 6; }
  cc -O2 -std=gnu11 "$HERE/limine-v12.9.0/limine.c" -o "$BI/dist/.limine-host"
  LIM="$BI/dist/.limine-host"
fi
"$LIM" bios-install "$OUT"
rm -f "$OUT.pre" "$OUT.pre.layout" "$README_TMP"
sha256sum "$OUT" > "$OUT.sha256"
python3 "$HERE/verify_limine_iso_v33a.py" "$OUT" "$HERE/limine-v12.9.0/limine-uefi-cd.bin"
u="${SUDO_USER:-}"; if [[ -n "$u" ]]; then g="$(id -gn "$u" 2>/dev/null || printf '%s' "$u")"; chown "$u:$g" "$OUT" "$OUT.sha256" "$PATCHED" 2>/dev/null || true; fi

echo
echo 'PASS: v33c clean-tree + LIMINE + native sCode appliance ISO built'
echo "ISO: $OUT"
echo "SHA-256: $(cut -d' ' -f1 "$OUT.sha256")"
echo 'Secure Boot: keep disabled unless BOOTX64.EFI is separately signed/enrolled.'
