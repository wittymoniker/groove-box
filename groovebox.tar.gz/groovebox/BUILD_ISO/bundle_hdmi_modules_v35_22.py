#!/usr/bin/env python3
"""Stage exact-kernel Intel DRM/KMS + HDMI-audio modules for live sOS."""
from __future__ import annotations
import os,re,shutil,subprocess,sys
from pathlib import Path
WANTED=['drm','drm_kms_helper','i915','intel_gtt','video','snd','snd_pcm','snd_timer','snd_hda_core','snd_hda_codec','snd_hda_codec_hdmi','snd_hda_intel']
COMP=('.zst','.xz','.gz')
def norm(s):
    n=Path(s).name
    for e in COMP:
        if n.endswith(e): n=n[:-len(e)]
    if n.endswith('.ko'): n=n[:-3]
    return n.replace('-','_')
def run(cmd): return subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def idx(tree):
    out={}
    for p in tree.rglob('*.ko*'):
        if p.is_file() and re.search(r'\.ko(?:\.(?:xz|zst|gz))?$',p.name): out.setdefault(norm(p.name),p)
    return out
def builtins(tree):
    out=set(); f=tree/'modules.builtin'
    if f.is_file():
        for l in f.read_text(errors='ignore').splitlines():
            if l.strip(): out.add(norm(l.strip()))
    return out
def deps(p):
    r=run(['modinfo','-F','depends',str(p)])
    if r.returncode:return []
    return [x.strip().replace('-','_') for x in r.stdout.replace('\n',',').split(',') if x.strip()]
def guestlib(root):
    lib=root/'lib'
    if lib.is_symlink():
        t=os.readlink(lib)
        if t.startswith('/'):
            lib.unlink(); lib.symlink_to('usr/lib'); return root/'usr/lib'
        q=(lib.parent/t).resolve(); q.relative_to(root.resolve()); return q
    return lib
def main():
    if len(sys.argv)!=4: raise SystemExit('usage: bundle_hdmi_modules_v35_22.py ROOTFS KVER MODULE_TREE')
    root=Path(sys.argv[1]).resolve(); kver=sys.argv[2].strip(); tree=Path(sys.argv[3]).resolve()
    I=idx(tree); B=builtins(tree); target=guestlib(root)/'modules'/kver; target.mkdir(parents=True,exist_ok=True)
    copied=set(); status={}; visiting=set()
    def include(n):
        n=n.replace('-','_')
        if n in B:return 'builtin'
        p=I.get(n)
        if p is None:return 'missing'
        if n in visiting:return 'file'
        visiting.add(n)
        for d in deps(p):include(d)
        rel=p.relative_to(tree); dst=target/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dst)
        if dst.stat().st_size<=0: raise RuntimeError(f'empty staged module: {dst}')
        copied.add(str(dst.relative_to(root)).replace(os.sep,'/')); visiting.discard(n); return 'file'
    for n in WANTED: status[n]=include(n)
    for meta in ('modules.order','modules.builtin','modules.builtin.modinfo','modules.softdep','modules.devname'):
        p=tree/meta
        if p.is_file(): shutil.copy2(p,target/meta)
    dep=run(['depmod','-b',str(root),kver])
    if dep.returncode: sys.stderr.write(dep.stdout+dep.stderr); raise SystemExit('FAIL: depmod failed after HDMI staging')
    if status.get('i915')=='missing': raise SystemExit(f'FAIL: Intel i915 unavailable for exact kernel {kver}')
    if status.get('snd_hda_intel')=='missing' and status.get('snd_hda_codec_hdmi')=='missing':
        raise SystemExit(f'FAIL: Intel HDMI audio modules unavailable for exact kernel {kver}')
    mf=root/'opt/sos/lib/kernel-hdmi-modules-v35.22.txt'; mf.parent.mkdir(parents=True,exist_ok=True)
    mf.write_text('\n'.join([f'kernel={kver}',f'source={tree}',f'copied_files={len(copied)}']+[f'{n}={status[n]}' for n in WANTED]+['','files:']+sorted(copied))+'\n')
    print(f'[v35.22] HDMI/KMS modules: copied {len(copied)} files')
    for n in WANTED: print(f'[v35.22] {n}: {status[n]}')
if __name__=='__main__':main()
