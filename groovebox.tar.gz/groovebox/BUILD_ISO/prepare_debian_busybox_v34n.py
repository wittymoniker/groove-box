#!/usr/bin/env python3
# GROOVEBOX_V34N_BUSYBOX_STAGE_20260919
"""Ensure a static BusyBox exists inside the staged live rootfs.

The installed-root mini initramfs builder intentionally uses BusyBox for its
small /init environment.  Fresh Debian 13 zero-state runtimes may not contain
BusyBox, so stage Debian's busybox-static package on demand without modifying
Fedora or regenerating the live rootfs linker cache.
"""
from __future__ import annotations
import hashlib, lzma, os, pathlib, shutil, subprocess, sys, urllib.request

if len(sys.argv) != 4:
    raise SystemExit('usage: prepare_debian_busybox_v34n.py ROOTFS BUILD_ISO_DIR ARCH')
root=pathlib.Path(sys.argv[1]).resolve(); bi=pathlib.Path(sys.argv[2]).resolve(); arch=sys.argv[3]
if arch != 'amd64':
    raise SystemExit(f'FAIL: v34n BusyBox staging supports amd64, got {arch}')

candidates=[root/'bin/busybox', root/'usr/bin/busybox', root/'bin/busybox.static', root/'usr/bin/busybox.static']
for p in candidates:
    if p.is_file() and os.access(p, os.X_OK):
        print(f'[v34n-busybox] BusyBox already present: {p}')
        raise SystemExit(0)

cache=bi/'dist/installer-toolchain-cache/debian-trixie-amd64/busybox-static'
debdir=cache/'debs'; stage=cache/'stage'; debdir.mkdir(parents=True, exist_ok=True)
indexes=[
 'https://security.debian.org/debian-security/dists/trixie-security/main/binary-amd64/Packages.xz',
 'https://deb.debian.org/debian/dists/trixie-updates/main/binary-amd64/Packages.xz',
 'https://deb.debian.org/debian/dists/trixie/main/binary-amd64/Packages.xz',
]

def parse_index(text:str):
    for stanza in text.split('\n\n'):
        f={}; key=None
        for line in stanza.splitlines():
            if line[:1].isspace() and key:
                f[key] += ' ' + line.strip()
            elif ':' in line:
                key,val=line.split(':',1); f[key]=val.strip()
        if f.get('Package'): yield f

record=None; base=None
print('[v34n-busybox] locating Debian 13 busybox-static package')
for url in indexes:
    try:
        with urllib.request.urlopen(url, timeout=45) as r: raw=r.read()
        text=lzma.decompress(raw).decode('utf-8','replace')
    except Exception as e:
        print(f'[v34n-busybox] index unavailable: {url}: {e}', file=sys.stderr)
        continue
    for rec in parse_index(text):
        if rec.get('Package')=='busybox-static' and rec.get('Architecture')=='amd64':
            record=rec; base=url.split('/dists/',1)[0]+'/'; break
    if record: break
if not record or not base:
    raise SystemExit('FAIL: Debian 13 busybox-static package could not be located')

fn=record.get('Filename'); want=(record.get('SHA256') or '').lower()
if not fn: raise SystemExit('FAIL: busybox-static package index has no Filename')
out=debdir/pathlib.Path(fn).name
if not (out.is_file() and (not want or hashlib.sha256(out.read_bytes()).hexdigest()==want)):
    url=base+fn; tmp=out.with_suffix(out.suffix+'.part'); tmp.unlink(missing_ok=True)
    print(f'[v34n-busybox] downloading {url}')
    with urllib.request.urlopen(url, timeout=90) as r, tmp.open('wb') as f:
        while True:
            b=r.read(1024*1024)
            if not b: break
            f.write(b)
    if want and hashlib.sha256(tmp.read_bytes()).hexdigest()!=want:
        tmp.unlink(missing_ok=True); raise SystemExit('FAIL: busybox-static SHA256 mismatch')
    tmp.replace(out)

for tool in ('ar','tar'):
    if not shutil.which(tool): raise SystemExit(f'FAIL: host {tool} required for BusyBox staging')
if stage.exists(): shutil.rmtree(stage)
stage.mkdir(parents=True)
work=cache/'extract';
if work.exists(): shutil.rmtree(work)
work.mkdir(parents=True)
subprocess.run(['ar','x',str(out)],cwd=work,check=True,stdout=subprocess.DEVNULL)
data=sorted(work.glob('data.tar.*'))
if not data: raise SystemExit(f'FAIL: {out.name} has no data.tar.*')
subprocess.run(['tar','-xf',str(data[0]),'-C',str(stage)],check=True)

src=None
for p in (stage/'bin/busybox', stage/'usr/bin/busybox', stage/'bin/busybox.static', stage/'usr/bin/busybox.static'):
    if p.is_file(): src=p; break
if src is None:
    hits=[p for p in stage.rglob('busybox*') if p.is_file()]
    src=hits[0] if hits else None
if src is None: raise SystemExit('FAIL: busybox-static .deb did not contain a BusyBox executable')

(root/'bin').mkdir(parents=True, exist_ok=True)
dst=root/'bin/busybox'
shutil.copy2(src,dst); os.chmod(dst,0o755)
if not (dst.is_file() and os.access(dst,os.X_OK)):
    raise SystemExit('FAIL: staged BusyBox is not executable')
# busybox-static should not depend on the live runtime's shared-library closure.
readelf=shutil.which('readelf')
if readelf:
    ph=subprocess.run([readelf,'-l',str(dst)],text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    if 'Requesting program interpreter:' in ph.stdout:
        raise SystemExit('FAIL: Debian busybox-static unexpectedly has a dynamic interpreter')
print(f'PASS: v34n staged static BusyBox: {dst}')
