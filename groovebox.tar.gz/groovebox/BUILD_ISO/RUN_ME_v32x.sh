#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-}"
if [[ -z "$ROOT" ]]; then
  d="$HERE"
  while [[ "$d" != / ]]; do
    if [[ -s "$d/BUILD_ISO/dist/runtime-cache/initramfs.full.img" ]]; then ROOT="$d"; break; fi
    d="$(dirname "$d")"
  done
fi
if [[ -z "$ROOT" && -s "$HOME/Desktop/groovebox/BUILD_ISO/dist/runtime-cache/initramfs.full.img" ]]; then ROOT="$HOME/Desktop/groovebox"; fi
if [[ -z "$ROOT" ]]; then
  echo 'FAIL: could not find Groovebox root containing BUILD_ISO/dist/runtime-cache/initramfs.full.img' >&2
  exit 3
fi
echo "[v32x] Groovebox root: $ROOT"
if [[ $EUID -eq 0 ]]; then exec "$HERE/build_from_v31c_layered_cache_v32x.sh" "$ROOT"; else exec sudo "$HERE/build_from_v31c_layered_cache_v32x.sh" "$ROOT"; fi
