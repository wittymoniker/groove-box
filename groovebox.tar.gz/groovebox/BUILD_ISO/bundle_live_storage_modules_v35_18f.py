#!/usr/bin/env python3
# GROOVEBOX_V35_18F_LIVE_STORAGE_MODULES_20260921
from __future__ import annotations
import os,re,shutil,subprocess,sys
from pathlib import Path
WANTED=['vmd','nvme','nvme_core','ahci','libahci','ata_generic','scsi_mod','sd_mod','uas','usb_storage','xhci_pci','xhci_hcd','mmc_block','sdhci','sdhci_pci','virtio_pci','virtio_blk','virtio_scsi']
COMP=('.zst','.xz','.gz')
def norm(s):
    n=Path(s).name
    for e in COMP:
        if n.endswith(e): n=n[:-len(e)]
    if n.endswith('.ko'): n=n[:-3]
    return n.replace('-','_')
def run(cmd): return subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def idx(tree):
    out={}
    for p in tree.rglob('*.ko*'):
        if p.is_file() and re.search(r'\.ko(?:\.(?:xz|zst|gz))?$',p.name): out.setdefault(norm(p.name),p)
    return out
def builtins(tree):
    out=set(); f=tree/'modules.builtin'
    if f.is_file():
        for l in f.read_text(errors='ignore').splitlines():
            if l.strip(): out.add(norm(l.strip()))
    return out
def deps(p):
    r=run(['modinfo','-F','depends',str(p)])
    if r.returncode: return []
    return [x.strip().replace('-','_') for x in r.stdout.replace('\n',',').split(',') if x.strip()]
def guestlib(root):
    lib=root/'lib'
    if lib.is_symlink():
        t=os.readlink(lib)
        if t.startswith('/'):
            lib.unlink(); lib.symlink_to('usr/lib'); return root/'usr/lib'
        q=(lib.parent/t).resolve(); q.relative_to(root.resolve()); return q
    return lib
def main():
    if len(sys.argv)!=4: raise SystemExit('usage: bundle_live_storage_modules_v35_18f.py ROOTFS KVER MODULE_TREE')
    root=Path(sys.argv[1]).resolve(); kver=sys.argv[2].strip(); tree=Path(sys.argv[3]).resolve()
    if not root.is_dir() or not tree.is_dir() or not kver: raise SystemExit('FAIL: invalid rootfs/kernel/module tree')
    I=idx(tree); B=builtins(tree); target=guestlib(root)/'modules'/kver; target.mkdir(parents=True,exist_ok=True)
    copied=set(); status={}; visiting=set()
    def include(n):
        n=n.replace('-','_')
        if n in B: return 'builtin'
        p=I.get(n)
        if p is None: return 'missing'
        if n in visiting: return 'file'
        visiting.add(n)
        for d in deps(p): include(d)
        rel=p.relative_to(tree); dst=target/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dst)
        if not dst.is_file() or dst.stat().st_size<=0: raise RuntimeError(f'empty staged module: {dst}')
        copied.add(str(dst.relative_to(root)).replace(os.sep,'/')); visiting.discard(n); return 'file'
    for n in WANTED: status[n]=include(n)
    for meta in ('modules.order','modules.builtin','modules.builtin.modinfo','modules.softdep','modules.devname'):
        p=tree/meta
        if p.is_file(): shutil.copy2(p,target/meta)
    dep=run(['depmod','-b',str(root),kver])
    if dep.returncode: sys.stderr.write(dep.stdout+dep.stderr); raise SystemExit('FAIL: depmod failed after live storage staging')
    # Require at least one internal-disk transport family. VMD itself is optional.
    if all(status.get(x)=='missing' for x in ('nvme','ahci','sd_mod','mmc_block')):
        raise SystemExit(f'FAIL: no usable internal storage transport modules for {kver}')
    mf=root/'opt/sos/lib/kernel-live-storage-modules-v35.18f.txt'; mf.parent.mkdir(parents=True,exist_ok=True)
    mf.write_text('\n'.join([f'kernel={kver}',f'source={tree}',f'copied_files={len(copied)}']+[f'{n}={status[n]}' for n in WANTED]+['','files:']+sorted(copied))+'\n')
    print(f'[v35.18f] live storage modules: copied {len(copied)} files')
    for n in WANTED: print(f'[v35.18f] {n}: {status[n]}')
if __name__=='__main__': main()
