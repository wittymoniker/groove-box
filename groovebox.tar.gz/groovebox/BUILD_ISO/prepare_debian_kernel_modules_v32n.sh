#!/usr/bin/env bash
set -euo pipefail

# Prepare an exact Debian kernel module tree without installing that kernel on Fedora.
# v34l: keep all diagnostics off stdout because caller captures stdout as the module-tree path.
# GROOVEBOX_V34L_MODULE_TREE_STDOUT_FIX_20260919
# Usage: prepare_debian_kernel_modules_v32n.sh KERNEL_RELEASE PROJECT_ROOT BUILD_ISO_DIR
KVER="${1:?kernel release required}"
ROOT="${2:?project root required}"
BI="${3:?BUILD_ISO dir required}"
CACHE="$BI/dist/kernel-module-source/$KVER"
READY="$CACHE/READY_MODULE_TREE"

log(){ printf '[v32n-auto-deb] %s\n' "$*" >&2; }

# Reuse a previously extracted exact tree.
if [[ -s "$READY" ]]; then
  TREE="$(cat "$READY")"
  if [[ -d "$TREE" ]]; then
    log "reusing cached module tree: $TREE"
    printf '%s\n' "$TREE"
    exit 0
  fi
fi

# Work out the real user's home even though the ISO builder runs under sudo.
BUILD_USER="${SUDO_USER:-${USER:-}}"
USER_HOME=""
if [[ -n "$BUILD_USER" ]] && command -v getent >/dev/null 2>&1; then
  USER_HOME="$(getent passwd "$BUILD_USER" 2>/dev/null | awk -F: 'NR==1{print $6}')"
fi
[[ -n "$USER_HOME" ]] || USER_HOME="${HOME:-}"

# First accept an already-extracted exact tree, including one produced manually with ar/tar.
roots=("$ROOT" "$BI" "$(pwd)")
[[ -n "$USER_HOME" ]] && roots+=("$USER_HOME/Downloads" "$USER_HOME/Desktop" "$USER_HOME")
for r in "${roots[@]}"; do
  [[ -d "$r" ]] || continue
  found="$(find "$r" -maxdepth 5 -type d -path "*/lib/modules/$KVER" -print -quit 2>/dev/null || true)"
  if [[ -n "$found" ]]; then
    log "found an already-extracted exact module tree: $found"
    mkdir -p "$CACHE"
    printf '%s\n' "$found" > "$READY"
    printf '%s\n' "$found"
    exit 0
  fi
done

# Otherwise locate the matching Debian linux-image package automatically.
DEB=""
patterns=("linux-image-${KVER}_*.deb" "linux-image-*${KVER}*_amd64.deb")
for r in "${roots[@]}"; do
  [[ -d "$r" ]] || continue
  for pat in "${patterns[@]}"; do
    DEB="$(find "$r" -maxdepth 5 -type f -name "$pat" -print -quit 2>/dev/null || true)"
    [[ -n "$DEB" ]] && break 2
  done
done

if [[ -z "$DEB" ]]; then
  log "matching .deb is not local; trying the official Debian 13 repositories automatically"
  PKGCACHE="$BI/dist/kernel-package-cache"
  mkdir -p "$PKGCACHE"
  AUTO_DEB="$PKGCACHE/linux-image-${KVER}-auto.deb"
  if python3 - "$KVER" "$AUTO_DEB" <<'PYFETCH'
import hashlib, lzma, pathlib, sys, urllib.request
kver, out = sys.argv[1], pathlib.Path(sys.argv[2])
pkg = "linux-image-" + kver
indexes = [
    "https://security.debian.org/debian-security/dists/trixie-security/main/binary-amd64/Packages.xz",
    "https://deb.debian.org/debian/dists/trixie-updates/main/binary-amd64/Packages.xz",
    "https://deb.debian.org/debian/dists/trixie/main/binary-amd64/Packages.xz",
]
record = None
base = None
for url in indexes:
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            raw = r.read()
        text = lzma.decompress(raw).decode("utf-8", "replace")
    except Exception:
        continue
    for stanza in text.split("\n\n"):
        fields = {}
        for line in stanza.splitlines():
            if ": " in line:
                k, v = line.split(": ", 1); fields[k] = v
        if fields.get("Package") == pkg and fields.get("Filename"):
            record = fields
            base = url.split("/dists/",1)[0] + "/"
            break
    if record:
        break
if not record:
    raise SystemExit(2)
url = base + record["Filename"]
out.parent.mkdir(parents=True, exist_ok=True)
with urllib.request.urlopen(url, timeout=60) as r, out.open("wb") as f:
    while True:
        b = r.read(1024*1024)
        if not b: break
        f.write(b)
want = record.get("SHA256", "").lower()
if want:
    got = hashlib.sha256(out.read_bytes()).hexdigest()
    if got != want:
        out.unlink(missing_ok=True)
        raise SystemExit(3)
print(out, file=sys.stderr)
PYFETCH
  then
    DEB="$AUTO_DEB"
    log "downloaded matching Debian package automatically: $DEB"
  else
    cat >&2 <<MSG
FAIL: I could not find or automatically download the Debian kernel package for '$KVER'.

You still do NOT need to unpack or install it yourself.
Download a file named like:
  linux-image-${KVER}_..._amd64.deb
leave it in Downloads, then rerun the exact same v32n build command.
MSG
    exit 20
  fi
fi

for x in ar tar find; do
  command -v "$x" >/dev/null 2>&1 || { log "FAIL: required host tool missing: $x"; exit 21; }
done

log "found Debian kernel package: $DEB"
rm -rf "$CACHE"
mkdir -p "$CACHE/ar" "$CACHE/root"
(
  cd "$CACHE/ar"
  ar x "$DEB"
)
DATA="$(find "$CACHE/ar" -maxdepth 1 -type f -name 'data.tar.*' -print -quit)"
[[ -n "$DATA" ]] || { log 'FAIL: Debian package contains no data.tar.* payload'; exit 22; }
log "extracting $(basename "$DATA") automatically"
tar -xf "$DATA" -C "$CACHE/root"

TREE=""
for cand in \
  "$CACHE/root/usr/lib/modules/$KVER" \
  "$CACHE/root/lib/modules/$KVER"; do
  if [[ -d "$cand" ]]; then TREE="$cand"; break; fi
done
if [[ -z "$TREE" ]]; then
  TREE="$(find "$CACHE/root" -type d -path "*/lib/modules/$KVER" -print -quit 2>/dev/null || true)"
fi
[[ -n "$TREE" && -d "$TREE" ]] || {
  log "FAIL: package was extracted but no lib/modules/$KVER tree was found"
  exit 23
}

printf '%s\n' "$TREE" > "$READY"
log "exact module tree ready: $TREE"
printf '%s\n' "$TREE"
