#!/usr/bin/env python3
"""Build the Limine ISO preimage with bounded RAM usage.

Large kernel/initramfs payloads are copied into the ISO by seek+stream rather
than materializing the entire ISO and initramfs in Python memory.
"""
import os, struct, math, time, sys, shutil
from pathlib import Path
SECTOR=2048
CHUNK=1024*1024

def both16(n): return struct.pack('<H',n)+struct.pack('>H',n)
def both32(n): return struct.pack('<I',n)+struct.pack('>I',n)
def pad_ascii(s,n): return s.encode('ascii','replace')[:n].ljust(n,b' ')
def rec_date(ts=None):
    t=time.gmtime(ts or time.time()); return bytes([t.tm_year-1900,t.tm_mon,t.tm_mday,t.tm_hour,t.tm_min,t.tm_sec,0])
def vd_date(ts=None):
    t=time.gmtime(ts or time.time()); return time.strftime('%Y%m%d%H%M%S',t).encode()+b'00'+bytes([0])
def dir_record(extent,size,ident,isdir=False,ts=None):
    name=bytes([ident]) if isinstance(ident,int) else ident.encode('ascii'); n=len(name); length=33+n+(1 if n%2==0 else 0)
    b=bytearray(length); b[0]=length; b[1]=0; b[2:10]=both32(extent); b[10:18]=both32(size); b[18:25]=rec_date(ts)
    b[25]=2 if isdir else 0; b[26]=0; b[27]=0; b[28:32]=both16(1); b[32]=n; b[33:33+n]=name; return bytes(b)
def mk_dir(entries,self_extent,parent_extent):
    data=bytearray(); records=[dir_record(self_extent,SECTOR,0,True),dir_record(parent_extent,SECTOR,1,True)]+entries
    for r in records:
        off=len(data)%SECTOR
        if off and off+len(r)>SECTOR: data+=b'\0'*(SECTOR-off)
        data+=r
    if len(data)%SECTOR: data+=b'\0'*(SECTOR-len(data)%SECTOR)
    return bytes(data)
def path_entry(name,extent,parent,big=False):
    nb=b'\x00' if name=='' else name.encode('ascii'); n=1 if name=='' else len(nb); out=bytearray([n,0])
    out+=struct.pack('>I' if big else '<I',extent); out+=struct.pack('>H' if big else '<H',parent); out+=nb[:n]
    if n%2: out+=b'\0'
    return bytes(out)
def validation_entry():
    e=bytearray(32); e[0]=1; e[1]=0; e[4:28]=b'GROOVEBOX SOS LIMINE'.ljust(24,b' '); e[30]=0x55; e[31]=0xAA
    s=sum(struct.unpack('<16H',bytes(e)))&0xffff; e[28:30]=struct.pack('<H',(-s)&0xffff); return bytes(e)
def boot_entry(lba,sectors):
    e=bytearray(32); e[0]=0x88; e[1]=0; e[2:4]=b'\0\0'; e[4]=0; e[5]=0; e[6:8]=struct.pack('<H',sectors); e[8:12]=struct.pack('<I',lba); return bytes(e)
def section_header(platform,count,final=True,label=b'GROOVEBOX SOS UEFI'):
    e=bytearray(32); e[0]=0x91 if final else 0x90; e[1]=platform; e[2:4]=struct.pack('<H',count); e[4:32]=label[:28].ljust(28,b' '); return bytes(e)
def copy_at(outfh,lba,src):
    outfh.seek(lba*SECTOR)
    if isinstance(src,(bytes,bytearray)):
        outfh.write(src); return
    with open(src,'rb') as inf:
        shutil.copyfileobj(inf,outfh,length=CHUNK)

def main(out,kernel,initrd,limdir,conf,readme):
    kernel=Path(kernel); initrd=Path(initrd); limdir=Path(limdir)
    k_size=kernel.stat().st_size; i_size=initrd.stat().st_size
    bios_cd=(limdir/'limine-bios-cd.bin').read_bytes(); bios_sys=(limdir/'limine-bios.sys').read_bytes(); uefi_cd=(limdir/'limine-uefi-cd.bin').read_bytes()
    bootx64=(limdir/'BOOTX64.EFI').read_bytes(); license_b=(limdir/'LICENSE').read_bytes(); conf_b=Path(conf).read_bytes(); readme_b=Path(readme).read_bytes()
    PVD=16; BRD=17; TERM=18; LPT=19; MPT=20; ROOT=21; BOOTDIR=22; EFIDIR=23; EFIBOOTDIR=24; CAT=25; cur=26
    def alloc_size(n):
        nonlocal cur
        lba=cur; cur+=math.ceil(n/SECTOR); return lba
    bios_cd_lba=alloc_size(len(bios_cd)); uefi_cd_lba=alloc_size(len(uefi_cd)); bios_sys_lba=alloc_size(len(bios_sys)); conf_lba=alloc_size(len(conf_b)); readme_lba=alloc_size(len(readme_b)); license_lba=alloc_size(len(license_b))
    k_lba=alloc_size(k_size); i_lba=alloc_size(i_size); bootx_lba=alloc_size(len(bootx64)); total=cur+16
    root_entries=[dir_record(BOOTDIR,SECTOR,'BOOT',True),dir_record(EFIDIR,SECTOR,'EFI',True),dir_record(bios_cd_lba,len(bios_cd),'LIMINE-BIOS-CD.BIN;1'),dir_record(uefi_cd_lba,len(uefi_cd),'LIMINE-UEFI-CD.BIN;1'),dir_record(bios_sys_lba,len(bios_sys),'LIMINE-BIOS.SYS;1'),dir_record(conf_lba,len(conf_b),'LIMINE.CONF;1'),dir_record(readme_lba,len(readme_b),'README.TXT;1'),dir_record(license_lba,len(license_b),'LIMINE-LICENSE.TXT;1')]
    boot_entries=[dir_record(k_lba,k_size,'VMLINUZ;1'),dir_record(i_lba,i_size,'INITRAMF.IMG;1')]
    root_dir=mk_dir(root_entries,ROOT,ROOT); boot_dir=mk_dir(boot_entries,BOOTDIR,ROOT); efi_dir=mk_dir([dir_record(EFIBOOTDIR,SECTOR,'BOOT',True)],EFIDIR,ROOT); efib_dir=mk_dir([dir_record(bootx_lba,len(bootx64),'BOOTX64.EFI;1')],EFIBOOTDIR,EFIDIR)
    lpt=b''.join([path_entry('',ROOT,1),path_entry('BOOT',BOOTDIR,1),path_entry('EFI',EFIDIR,1),path_entry('BOOT',EFIBOOTDIR,3)])
    mpt=b''.join([path_entry('',ROOT,1,True),path_entry('BOOT',BOOTDIR,1,True),path_entry('EFI',EFIDIR,1,True),path_entry('BOOT',EFIBOOTDIR,3,True)])
    pathsize=len(lpt)
    p=bytearray(SECTOR); p[0]=1; p[1:6]=b'CD001'; p[6]=1; p[8:40]=pad_ascii('GROOVEBOX',32); p[40:72]=pad_ascii('GROOVEBOX_SOS_LIMINE',32); p[80:88]=both32(total); p[120:124]=both16(1); p[124:128]=both16(1); p[128:132]=both16(SECTOR); p[132:140]=both32(pathsize); p[140:144]=struct.pack('<I',LPT); p[148:152]=struct.pack('>I',MPT)
    rr=dir_record(ROOT,len(root_dir),0,True); p[156:156+len(rr)]=rr; p[190:318]=pad_ascii('MATHEMATICIANS GROOVEBOX',128); p[318:446]=pad_ascii('ESKI-WEB.ORG',128); p[446:574]=pad_ascii('OPENAI ASSISTED BUILD',128); p[574:702]=pad_ascii('SOS LIMINE SCODE',128)
    dt=vd_date(); p[813:830]=dt; p[830:847]=dt; p[847:864]=b'0'*16+b'\0'; p[864:881]=dt; p[881]=1
    br=bytearray(SECTOR); br[0]=0; br[1:6]=b'CD001'; br[6]=1; br[7:39]=b'EL TORITO SPECIFICATION'.ljust(32,b' '); br[71:75]=struct.pack('<I',CAT)
    term=bytearray(SECTOR); term[0]=255; term[1:6]=b'CD001'; term[6]=1
    cat=(validation_entry()+boot_entry(bios_cd_lba,4)+section_header(0xEF,1,True)+boot_entry(uefi_cd_lba,len(uefi_cd)//512)).ljust(SECTOR,b'\0')
    outp=Path(out)
    with open(outp,'w+b') as fh:
        fh.truncate(total*SECTOR)
        for lba,data in [(PVD,p),(BRD,br),(TERM,term),(LPT,lpt),(MPT,mpt),(ROOT,root_dir),(BOOTDIR,boot_dir),(EFIDIR,efi_dir),(EFIBOOTDIR,efib_dir),(CAT,cat),(bios_cd_lba,bios_cd),(uefi_cd_lba,uefi_cd),(bios_sys_lba,bios_sys),(conf_lba,conf_b),(readme_lba,readme_b),(license_lba,license_b)]: copy_at(fh,lba,data)
        copy_at(fh,k_lba,kernel); copy_at(fh,i_lba,initrd); copy_at(fh,bootx_lba,bootx64)
        fh.flush(); os.fsync(fh.fileno())
    layout=Path(str(outp)+'.layout')
    layout.write_text('\n'.join(f'{k}={v}' for k,v in {'volume_sectors_2048':total,'boot_catalog_lba':CAT,'bios_cd_lba':bios_cd_lba,'uefi_cd_lba':uefi_cd_lba,'uefi_cd_sectors_512':len(uefi_cd)//512,'kernel_lba':k_lba,'kernel_bytes':k_size,'initrd_lba':i_lba,'initrd_bytes':i_size,'root_lba':ROOT}.items())+'\n')
    print(f'ISO preimage: {out} {total*SECTOR} bytes / {total} sectors (streamed)')
    print(f'BIOS El Torito LBA {bios_cd_lba}; UEFI FAT image LBA {uefi_cd_lba} ({len(uefi_cd)//512} x 512-byte sectors)')
if __name__=='__main__':
    if len(sys.argv)!=7: print('usage: build_iso.py OUT KERNEL INITRD LIMINE_DIR CONF README',file=sys.stderr); sys.exit(2)
    main(*sys.argv[1:])
