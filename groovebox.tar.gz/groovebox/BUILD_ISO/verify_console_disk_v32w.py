#!/usr/bin/env python3
# GROOVEBOX_R23_VERIFY_CONSOLE_IO_V32X_20260918
from pathlib import Path
import sys
from newc_stream import scan_newc

NEED={
  'usr/bin/groovebox-appliance':b'GROOVEBOX_R19_CONSOLE_IO_GUI_RESTORE_V32T_20260918',
  'usr/bin/sos-install-appliance':b'GROOVEBOX_R19_CONSOLE_IO_DISK_V32T_20260918',
  'usr/bin/sos-recovery-shell':b'GROOVEBOX_R22_NOJOB_RECOVERY_MENU_V32W_20260918',
  'usr/lib/sos/sos-install-appliance.real-v32q':b'GROOVEBOX_R16_DISK_BACKEND_V32Q_20260918',
}

def verify(files):
    for name,mark in NEED.items():
        data=files.get(name)
        if not data: raise SystemExit(f'FAIL: v32x file missing: {name}')
        if mark not in data: raise SystemExit(f'FAIL: v32x marker missing: {name}')
    for name in ('usr/bin/groovebox-appliance','usr/bin/sos-install-appliance','usr/bin/sos-recovery-shell'):
        data=files[name]
        for bad in (b'cttyhack', b'/bin/sh -i', b' sh -i'):
            if bad in data: raise SystemExit(f'FAIL: job-control shell path remains in {name}: {bad!r}')
    install=files['usr/bin/sos-install-appliance']
    if b'<"$CONSOLE" >"$CONSOLE" 2>&1' not in install:
        raise SystemExit('FAIL: v32x Copy-to-Disk is not wired directly to console stdio')
    rec=files['usr/bin/sos-recovery-shell']
    if b'sOS recovery menu v32w' not in rec or b'while :' not in rec:
        raise SystemExit('FAIL: v32x v32w recovery menu missing')
    app=files['usr/bin/groovebox-appliance']
    for x in (b'GROOVEBOX_R14_CURSOR_SYNC_V32O_20260918',b'nocompress:grab=0',b'GROOVEBOX_SOFTWARE_CURSOR=1'):
        if x not in app: raise SystemExit(f'FAIL: v32x known-good v32o GUI path missing {x!r}')
    print('PASS: v32x accepts v32w non-shell recovery menu and retains direct-console disk + known-good v32o GUI path (streaming)')

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: verify_console_disk_v32w.py INITRAMFS_OR_ROOTFS')
    p=Path(sys.argv[1])
    if p.is_dir():
        files={}
        for name in NEED:
            q=p/name
            if q.exists() or q.is_symlink(): files[name]=q.read_bytes()
        verify(files); return
    _,files,_=scan_newc(p,capture=NEED.keys())
    verify(files)
if __name__=='__main__': main()
