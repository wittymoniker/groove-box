#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 "$HERE/APPLY_v35_18e_INPUT_NVME_FIX.py"
