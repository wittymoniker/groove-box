#!/usr/bin/env python3
from pathlib import Path
import sys
MARK='GROOVEBOX_V34G_INSTALLER_STAGE_NOHANG_20260919'
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
if root.name!='BUILD_ISO' and (root/'BUILD_ISO').is_dir(): root=root/'BUILD_ISO'
p=root/'build_from_v31c_layered_cache_v32x.sh'
t=p.read_text() if p.is_file() else ''
checks={
 'v34g marker': MARK in t,
 'rootfs formatter fast path': 'guest_has_tool_v34g mkfs.ext4 && guest_has_tool_v34g mkfs.vfat' in t,
 'redundant helper skip': 'skipping redundant v32t tool helper' in t,
 'bounded slow path': 'timeout 600s python3 -u "$HERE/prepare_debian_copy_tools_v32t.py"' in t,
 'continuation marker': 'formatter stage complete; continuing to installed-root initramfs' in t,
 'installed initramfs stage retained': "echo '[v32x] building installed-root boot initramfs from exact storage modules'" in t,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
raise SystemExit(0 if all(checks.values()) else 5)
