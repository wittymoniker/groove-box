#!/usr/bin/env python3
# GROOVEBOX_V34E_USRMERGE_SAFE_MODULE_STAGING_20260919
from __future__ import annotations
import sys
from pathlib import Path
from newc_stream import scan_newc

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: verify_kernel_input_v32m.py initramfs.img')
    cap=('opt/sos/lib/kernel-input-modules-v32m.txt','usr/bin/groovebox-kernel-input-prep')
    meta,bodies,_=scan_newc(Path(sys.argv[1]),capture=cap)
    req=['usr/bin/groovebox-kernel-input-prep','opt/sos/lib/kernel-input-modules-v32m.txt','usr/bin/groovebox-input-check']
    miss=[x for x in req if x not in meta or meta[x][1] <= 0]
    if miss: raise SystemExit('FAIL: v32m kernel-input payload missing: '+', '.join(miss))
    man=bodies['opt/sos/lib/kernel-input-modules-v32m.txt'].decode('utf-8','replace')
    vals={}
    for line in man.splitlines():
        if '=' in line and not line.startswith(('lib/','usr/lib/')):
            k,v=line.split('=',1); vals[k.strip()]=v.strip()
    if vals.get('evdev') not in ('file','builtin'):
        raise SystemExit('FAIL: v32m initramfs has no usable evdev kernel handler')
    ps2=vals.get('psmouse') in ('file','builtin')
    i2c=(vals.get('i2c_hid') in ('file','builtin') or vals.get('i2c_hid_acpi') in ('file','builtin'))
    if not (ps2 or i2c):
        raise SystemExit('FAIL: v32m initramfs has neither PS/2 nor I2C-HID pointer transport')
    prep=bodies['usr/bin/groovebox-kernel-input-prep'].decode('utf-8','replace')
    for token in ('modprobe "$m"','evdev mousedev','i8042 atkbd psmouse','i2c_hid i2c_hid_acpi','mdev -s'):
        if token not in prep: raise SystemExit('FAIL: v32m prep missing '+token)
    module_files=[k for k,(m,s) in meta.items() if (k.startswith('lib/modules/') or k.startswith('usr/lib/modules/')) and '.ko' in k and s>0]
    if vals.get('evdev')=='file' and not any('/evdev.ko' in k for k in module_files):
        raise SystemExit('FAIL: evdev marked file but module bytes are missing')
    if vals.get('psmouse')=='file' and not any('/psmouse.ko' in k for k in module_files):
        raise SystemExit('FAIL: psmouse marked file but module bytes are missing')
    print(f"PASS: v32m kernel input payload ({vals.get('kernel','?')}; {len(module_files)} kernel module files; streaming)")
if __name__=='__main__': main()
