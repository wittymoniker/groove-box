#!/usr/bin/env python3
from __future__ import annotations
import gzip,sys

# GROOVEBOX_V34E_USRMERGE_SAFE_INITRAMFS_VERIFY_20260919
from pathlib import Path

def parse_newc(blob:bytes):
    pos=0; files={}
    while pos+110<=len(blob):
        if blob[pos:pos+6] not in (b'070701', b'070702'): break
        h=blob[pos:pos+110]; pos+=110
        fs=[int(h[i:i+8],16) for i in range(6,110,8)]
        mode=fs[1]; fsize=fs[6]; namesize=fs[11]
        name=blob[pos:pos+namesize-1].decode('utf-8','replace'); pos+=namesize; pos=(pos+3)&~3
        data=blob[pos:pos+fsize]; pos+=fsize; pos=(pos+3)&~3
        if name=='TRAILER!!!':
            # Concatenated newc members are legal in initramfs images. Skip NUL/padding
            # and continue if another archive header follows.
            while pos < len(blob) and blob[pos] == 0: pos += 1
            if blob[pos:pos+6] in (b'070701', b'070702'): continue
            break
        files[name.lstrip('./')]=(mode,data)
    return files

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: verify_kernel_input_v32m.py initramfs.img')
    f=parse_newc(gzip.decompress(Path(sys.argv[1]).read_bytes()))
    req=['usr/bin/groovebox-kernel-input-prep','opt/sos/lib/kernel-input-modules-v32m.txt','usr/bin/groovebox-input-check']
    miss=[x for x in req if x not in f or not f[x][1]]
    if miss: raise SystemExit('FAIL: v32m kernel-input payload missing: '+', '.join(miss))
    man=f['opt/sos/lib/kernel-input-modules-v32m.txt'][1].decode('utf-8','replace')
    vals={}
    for line in man.splitlines():
        if '=' in line and not line.startswith('lib/'):
            k,v=line.split('=',1); vals[k.strip()]=v.strip()
    if vals.get('evdev') not in ('file','builtin'):
        raise SystemExit('FAIL: v32m initramfs has no usable evdev kernel handler')
    ps2=vals.get('psmouse') in ('file','builtin')
    i2c=(vals.get('i2c_hid') in ('file','builtin') or vals.get('i2c_hid_acpi') in ('file','builtin'))
    if not (ps2 or i2c):
        raise SystemExit('FAIL: v32m initramfs has neither PS/2 nor I2C-HID pointer transport')
    prep=f['usr/bin/groovebox-kernel-input-prep'][1].decode('utf-8','replace')
    for token in ('modprobe "$m"','evdev mousedev','i8042 atkbd psmouse','i2c_hid i2c_hid_acpi','mdev -s'):
        if token not in prep: raise SystemExit('FAIL: v32m prep missing '+token)
    module_files=[k for k in f if (k.startswith('lib/modules/') or k.startswith('usr/lib/modules/')) and ('.ko' in k)]
    if vals.get('evdev')=='file' and not any('/evdev.ko' in k for k in module_files):
        raise SystemExit('FAIL: evdev marked file but module bytes are missing')
    if vals.get('psmouse')=='file' and not any('/psmouse.ko' in k for k in module_files):
        raise SystemExit('FAIL: psmouse marked file but module bytes are missing')
    print(f"PASS: v32m kernel input payload ({vals.get('kernel','?')}; {len(module_files)} kernel module files)")
if __name__=='__main__': main()
