#!/usr/bin/env python3
from pathlib import Path
import re, subprocess, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
if root.name!='BUILD_ISO' and (root/'BUILD_ISO').is_dir(): root=root/'BUILD_ISO'
fail=[]
launchers=[]
for p in root.glob('groovebox-appliance-direct-*'):
    if not p.is_file(): continue
    s=p.read_text(errors='ignore')
    if 'QT_QPA_EVDEV_MOUSE_PARAMETERS' not in s: continue
    launchers.append(p)
    checks={
      'v35 relative marker':'GROOVEBOX_V35_RELATIVE_POINTER_20260919' in s,
      'requires both REL axes':'[ $((val & 3)) -eq 3 ]' in s,
      'no forced abs mouse':':abs:nocompress' not in s,
      'relative params':'$PTR_EVENT:nocompress:grab=0' in s,
      'libinput fallback note':'ABS-only touchpads are not coerced' in s,
    }
    for k,v in checks.items():
        print(('PASS' if v else 'FAIL')+f': {p.name}: {k}')
        if not v: fail.append(k)
    if subprocess.run(['/bin/sh','-n',str(p)]).returncode: fail.append('launcher shell syntax')
if not launchers: fail.append('no launcher')
cur=root/'qt_cursor_sync_sitecustomize_v32p.py'; cs=cur.read_text(errors='ignore') if cur.is_file() else ''
for k,v in {
 'modal cursor marker':'GROOVEBOX_V35_MODAL_CURSOR_SYNC_20260919' in cs,
 'active modal tracking':'activeModalWidget' in cs,
 'hide blocked-parent cursor':'_hide_other_overlays' in cs,
}.items(): print(('PASS' if v else 'FAIL')+': '+k); fail += ([] if v else [k])
init=root/'init-v33a'; ins=init.read_text(errors='ignore') if init.is_file() else ''
for k,v in {
 'init install marker':'GROOVEBOX_V35_INSTALL_DISPATCH_20260919' in ins,
 'kernel cmdline parser':'sos.mode=*) SOS_MODE=${x#sos.mode=}' in ins,
 'install branch':bool(re.search(r'^\s*install\)\s*$',ins,re.M)),
 'installer exec':'exec /usr/bin/sos-install-appliance' in ins,
}.items(): print(('PASS' if v else 'FAIL')+': '+k); fail += ([] if v else [k])
lim=[]
for p in root.rglob('*'):
    if p.is_file() and p.name.lower() in ('limine-live.conf','limine.conf'):
        t=p.read_text(errors='ignore')
        if 'sos.mode=live' in t: lim.append((p,t))
if not lim: fail.append('limine live config missing')
for p,t in lim:
    v='Install Groovebox / sOS to Disk' in t and 'sos.mode=install' in t
    print(('PASS' if v else 'FAIL')+f': {p.name}: real Install-to-Disk boot entry')
    if not v: fail.append('limine install entry')
backend=root/'sos-install-appliance-real-v32q'; bt=backend.read_text(errors='ignore') if backend.is_file() else ''
for tok in ('gpt_disk_v32q.py','mkfs.vfat','mkfs.ext4','copy_root_v32q.py'):
    v=tok in bt; print(('PASS' if v else 'FAIL')+': disk writer stage '+tok); fail += ([] if v else [tok])
if fail:
    print('FAIL: v35 game-ready verification: '+', '.join(sorted(set(fail))),file=sys.stderr); raise SystemExit(5)
print('PASS: v35 game-ready BUILD_ISO verification')
