#!/usr/bin/env bash
# GROOVEBOX_V35_22H_ROOT_PIN_EXEC_NORMALIZATION_20260921
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT="$(cd "$HERE/.." && pwd -P)"
case "$ROOT" in
  */.local/share/Trash/*)
    echo "FAIL: refusing to build from Trash: $ROOT" >&2
    echo "Use the project under ~/Downloads/groovebox instead." >&2
    exit 78
    ;;
esac
export GROOVEBOX_BUILD_ROOT="$ROOT"
# ZIP extraction does not reliably retain executable bits. Normalize every shell
# helper before entering the historical build chain.
find "$HERE" -maxdepth 1 -type f -name '*.sh' -exec chmod 0755 {} +
BOOT="$HERE/bootstrap_clean_tree_v33c.sh"
if ! grep -Fq 'GROOVEBOX_V35_22G_ACTIVE_BOOTSTRAP_20260921' "$BOOT" 2>/dev/null; then
  echo 'FAIL: stale BUILD_ISO bootstrap detected; v35.22g active bootstrap marker is missing.' >&2
  echo "Active file: $BOOT" >&2
  sha256sum "$BOOT" 2>/dev/null >&2 || true
  exit 77
fi
echo "[v35.22h] build root pinned: $ROOT"
echo '[v35.22h] shell helper executable bits normalized'
echo "[v35.22g] active bootstrap verified: $(sha256sum "$BOOT" | cut -d' ' -f1)"
exec bash "$HERE/RUN_ME_v35_22.sh" "$ROOT"
