#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(dirname "$HERE")}" 
exec "$HERE/RUN_ME_GAME_READY_v35.sh" "$ROOT"
