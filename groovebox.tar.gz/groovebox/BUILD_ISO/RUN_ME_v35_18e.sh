#!/usr/bin/env bash
# GROOVEBOX_V35_18E_FULL_INPUT_NVME_20260921
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(dirname "$HERE")}"
[[ -d "$ROOT/BUILD_ISO" ]] || { echo 'FAIL: project root must contain BUILD_ISO' >&2; exit 3; }
BI="$ROOT/BUILD_ISO"

echo "[v35.18e] Groovebox root: $ROOT"
echo '[v35.18e] validating cumulative zero-state + input/libinput + NVMe whole-disk path'
python3 "$BI/verify_v35_18e.py" "$BI"
python3 "$BI/verify_input_priority_v34f.py" "$BI"
python3 "$BI/verify_installer_stage_v34g.py" "$BI"
python3 -m py_compile "$BI/bundle_kernel_input_modules_v32n.py" "$BI/verify_kernel_input_v32m.py"
grep -Fq 'GROOVEBOX_V34E_USRMERGE_SAFE_MODULE_STAGING_20260919' "$BI/bundle_kernel_input_modules_v32n.py" || { echo 'FAIL: v34e usrmerge module staging missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34N_BUSYBOX_ZERO_STATE_FIX_20260919' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34n BusyBox zero-state path missing' >&2; exit 4; }
grep -Fq 'GROOVEBOX_V34K_SOUNDDEVICE_FINDLIB_FIX_20260919' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34k PortAudio path missing' >&2; exit 4; }

echo 'PASS: v35.18e cumulative static preflight'
bash "$BI/RUN_ME_v34p.sh" "$ROOT"

SRC="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34p.iso"
[[ -s "$SRC" ]] || { echo "FAIL: base ISO missing after build: $SRC" >&2; exit 5; }
STAMP="$(date +%Y%m%d)"
DST="$BI/dist/Groovebox-sOS-x86_64-${STAMP}-GAME-READY-INPUT-NVME-v35.18e.iso"
cp -f "$SRC" "$DST"
sha256sum "$DST" > "$DST.sha256"
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
  g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"
  chown "$SUDO_USER:$g" "$DST" "$DST.sha256" 2>/dev/null || true
fi
echo
echo 'PASS: v35.18e standalone Game-Ready ISO built'
echo "ISO: $DST"
echo "SHA-256: $(cut -d' ' -f1 "$DST.sha256")"
