#!/usr/bin/env python3
"""Bundle the *target kernel's* input modules into the Groovebox initramfs.

v32l fixed Qt's userspace input selection but could not create /dev/input/eventX
when the kernel-side evdev/trackpad drivers were absent from the initramfs.  This
script runs on the Fedora build host, resolves the exact module dependency
closure for the kernel used by the ISO, copies only those modules, and runs
`depmod -b` against the staged rootfs.
"""
from __future__ import annotations
import os, re, shutil, subprocess, sys
from pathlib import Path

WANTED = [
    # Linux input event / compatibility interfaces
    "evdev", "mousedev",
    # legacy PS/2 / serio laptop touchpads
    "psmouse", "serio_raw", "atkbd", "i8042",
    # USB/HID pointers + touch
    "hid", "hid_generic", "usbhid", "hid_multitouch",
    # I2C-HID touchpads used by newer Dell laptops
    "i2c_hid", "i2c_hid_acpi",
    # common Intel I2C / low-power / pinctrl glue for Latitude-era hardware
    "i2c_designware_core", "i2c_designware_platform", "i2c_i801",
    "intel_lpss", "intel_lpss_pci", "pinctrl_intel", "pinctrl_sunrisepoint",
]

def run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def resolve(host_kver: str, name: str) -> tuple[str, list[Path]]:
    """Return (status, dependency module files). status is file/builtin/missing."""
    p = run(["modprobe", "-D", "-S", host_kver, name])
    files: list[Path] = []
    if p.returncode == 0:
        for line in p.stdout.splitlines():
            m = re.match(r"\s*insmod\s+(\S+)", line)
            if m:
                q = Path(m.group(1))
                if q.is_file(): files.append(q)
        if files:
            return "file", files
    # modprobe --show-depends is silent for some built-ins; modinfo identifies them.
    mi = run(["modinfo", "-k", host_kver, "-F", "filename", name])
    if mi.returncode == 0:
        out = mi.stdout.strip()
        if out in {"(builtin)", "builtin"}:
            return "builtin", []
        if out:
            q = Path(out)
            if q.is_file():
                return "file", [q]
    return "missing", []

def copy_one(src: Path, rootfs: Path, kver: str) -> Path:
    # Normalize Fedora's /usr/lib/modules and /lib/modules to /lib/modules in guest.
    s = str(src)
    marker = f"/modules/{kver}/"
    if marker not in s:
        raise RuntimeError(f"module path does not match target kernel {kver}: {src}")
    rel = s.split(marker, 1)[1]
    dst = rootfs / "lib" / "modules" / kver / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return dst

def find_host_module_tree(kver: str) -> Path | None:
    for base in (Path("/lib/modules") / kver, Path("/usr/lib/modules") / kver):
        if base.exists(): return base
    return None

def main() -> int:
    if len(sys.argv) != 3:
        print("usage: bundle_kernel_input_modules_v32m.py ROOTFS KERNEL_RELEASE", file=sys.stderr)
        return 2
    rootfs = Path(sys.argv[1]).resolve(); kver = sys.argv[2].strip()
    if not rootfs.is_dir() or not kver:
        print("FAIL: invalid rootfs/kernel release", file=sys.stderr); return 2
    tree = find_host_module_tree(kver)
    if tree is None:
        print(f"FAIL: build host has no /lib/modules/{kver} or /usr/lib/modules/{kver}", file=sys.stderr)
        print(f"Install the matching Fedora kernel modules for {kver}, then rerun the builder.", file=sys.stderr)
        return 3

    target_tree = rootfs / "lib" / "modules" / kver
    target_tree.mkdir(parents=True, exist_ok=True)
    copied: set[str] = set(); status: dict[str, str] = {}
    for name in WANTED:
        st, paths = resolve(kver, name); status[name] = st
        for src in paths:
            dst = copy_one(src, rootfs, kver)
            copied.add(str(dst.relative_to(rootfs)))

    # Preserve built-in metadata so guest modprobe can correctly treat built-ins.
    for meta in ("modules.builtin", "modules.builtin.modinfo", "modules.builtin.alias.bin", "modules.devname"):
        src = tree / meta
        if src.is_file(): shutil.copy2(src, target_tree / meta)

    # evdev is non-negotiable. For the pointer transport require PS/2 or I2C-HID.
    if status.get("evdev") == "missing":
        print(f"FAIL: evdev is not available for target kernel {kver}; kernel cannot publish /dev/input/eventX.", file=sys.stderr)
        return 4
    ps2 = status.get("psmouse") != "missing"
    i2c = status.get("i2c_hid_acpi") != "missing" or status.get("i2c_hid") != "missing"
    if not (ps2 or i2c):
        print(f"FAIL: neither psmouse nor I2C-HID touchpad transport is available for {kver}.", file=sys.stderr)
        return 4

    dep = run(["depmod", "-b", str(rootfs), kver])
    if dep.returncode != 0:
        sys.stderr.write(dep.stdout + dep.stderr)
        print("FAIL: depmod failed for staged Groovebox rootfs", file=sys.stderr)
        return 5

    manifest = rootfs / "opt" / "sos" / "lib" / "kernel-input-modules-v32m.txt"
    manifest.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"kernel={kver}", f"source={tree}", f"copied_files={len(copied)}"]
    lines += [f"{n}={status[n]}" for n in WANTED]
    lines += ["", "files:"] + sorted(copied)
    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"[v32m] target kernel: {kver}")
    print(f"[v32m] host module tree: {tree}")
    for n in WANTED:
        print(f"[v32m] {n}: {status[n]}")
    print(f"[v32m] copied {len(copied)} module/dependency files")
    print(f"[v32m] manifest: {manifest}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
