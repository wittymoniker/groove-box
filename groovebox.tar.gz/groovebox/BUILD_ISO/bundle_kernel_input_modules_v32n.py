#!/usr/bin/env python3
"""Bundle input modules from an arbitrary exact-kernel module tree.

Unlike v32m, this does not require the Debian kernel to be installed into the
Fedora host's /lib/modules.  v32n can point directly at a linux-image .deb that
was unpacked into BUILD_ISO/dist/kernel-module-source.
"""
from __future__ import annotations
import os, re, shutil, subprocess, sys
from pathlib import Path

# GROOVEBOX_V34E_USRMERGE_SAFE_MODULE_STAGING_20260919

WANTED = [
    "evdev", "mousedev",
    "psmouse", "serio_raw", "atkbd", "i8042",
    "hid", "hid_generic", "usbhid", "hid_multitouch", "hid_rmi",
    "rmi_core", "rmi_smbus", "rmi_f03", "rmi_f11", "rmi_f30",
    "elan_i2c",
    "i2c_core", "i2c_smbus", "i2c_hid", "i2c_hid_acpi", "i2c_hid_of",
    "i2c_designware_core", "i2c_designware_platform", "i2c_i801",
    "intel_lpss", "intel_lpss_pci", "pinctrl_intel", "pinctrl_sunrisepoint",
]

COMP_SUFFIXES = (".zst", ".xz", ".gz")

def norm_name(s: str) -> str:
    n = Path(s).name
    for ext in COMP_SUFFIXES:
        if n.endswith(ext): n = n[:-len(ext)]
    if n.endswith(".ko"): n = n[:-3]
    return n.replace("-", "_")

def run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def module_index(tree: Path) -> dict[str, Path]:
    idx: dict[str, Path] = {}
    for p in tree.rglob("*.ko*"):
        if p.is_file() and re.search(r"\.ko(?:\.(?:xz|zst|gz))?$", p.name):
            idx.setdefault(norm_name(p.name), p)
    return idx

def builtin_names(tree: Path) -> set[str]:
    out: set[str] = set()
    f = tree / "modules.builtin"
    if f.is_file():
        for line in f.read_text(errors="ignore").splitlines():
            if line.strip(): out.add(norm_name(line.strip()))
    return out

def deps_for(path: Path) -> list[str]:
    # modinfo can inspect a module file directly, even if it belongs to a different kernel.
    p = run(["modinfo", "-F", "depends", str(path)])
    if p.returncode != 0:
        return []
    deps: list[str] = []
    for chunk in p.stdout.replace("\n", ",").split(","):
        d = chunk.strip().replace("-", "_")
        if d: deps.append(d)
    return deps

def _guest_module_base(rootfs: Path) -> Path:
    """Return a staging-safe module base inside ROOTFS on usrmerge or classic trees."""
    lib = rootfs / "lib"
    try:
        if lib.is_symlink():
            target = os.readlink(lib)
            # Guest absolute symlinks must not resolve against the host root.
            if target == "/usr/lib":
                lib.unlink()
                lib.symlink_to("usr/lib")
            resolved = (lib.parent / os.readlink(lib)).resolve()
            rr = rootfs.resolve()
            if resolved != rr and rr not in resolved.parents:
                raise RuntimeError(f"guest /lib escapes staged rootfs: {resolved}")
            return resolved / "modules"
    except OSError:
        pass
    return lib / "modules"

def copy_one(src: Path, tree: Path, rootfs: Path, kver: str) -> Path:
    rel = src.relative_to(tree)
    dst = _guest_module_base(rootfs) / kver / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    if not dst.is_file() or dst.stat().st_size <= 0:
        raise RuntimeError(f"staged kernel module is empty: {dst}")
    return dst

def main() -> int:
    if len(sys.argv) != 4:
        print("usage: bundle_kernel_input_modules_v32n.py ROOTFS KERNEL_RELEASE MODULE_TREE", file=sys.stderr)
        return 2
    rootfs = Path(sys.argv[1]).resolve()
    kver = sys.argv[2].strip()
    tree = Path(sys.argv[3]).resolve()
    if not rootfs.is_dir() or not kver or not tree.is_dir():
        print("FAIL: invalid rootfs/kernel/module tree", file=sys.stderr); return 2

    idx = module_index(tree)
    builtins = builtin_names(tree)
    if not idx and not builtins:
        print(f"FAIL: no kernel modules/builtins found in {tree}", file=sys.stderr); return 3

    target_tree = _guest_module_base(rootfs) / kver
    target_tree.mkdir(parents=True, exist_ok=True)
    copied: set[str] = set()
    status: dict[str, str] = {}
    visiting: set[str] = set()

    def include(name: str) -> str:
        name = name.replace("-", "_")
        if name in builtins:
            return "builtin"
        src = idx.get(name)
        if src is None:
            return "missing"
        if name in visiting:
            return "file"
        visiting.add(name)
        for dep in deps_for(src):
            include(dep)
        dst = copy_one(src, tree, rootfs, kver)
        copied.add(str(dst.relative_to(rootfs)))
        visiting.discard(name)
        return "file"

    for name in WANTED:
        status[name] = include(name)

    # Keep metadata required by depmod/modprobe and builtin detection.
    for meta in (
        "modules.order", "modules.builtin", "modules.builtin.modinfo",
        "modules.softdep", "modules.devname"
    ):
        src = tree / meta
        if src.is_file(): shutil.copy2(src, target_tree / meta)

    if status.get("evdev") == "missing":
        print(f"FAIL: evdev is unavailable for exact kernel {kver}", file=sys.stderr); return 4
    ps2 = status.get("psmouse") != "missing"
    i2c = status.get("i2c_hid_acpi") != "missing" or status.get("i2c_hid") != "missing"
    if not (ps2 or i2c):
        print(f"FAIL: neither psmouse nor I2C-HID is available for exact kernel {kver}", file=sys.stderr); return 4

    dep = run(["depmod", "-b", str(rootfs), kver])
    if dep.returncode != 0:
        sys.stderr.write(dep.stdout + dep.stderr)
        print("FAIL: depmod failed for staged Groovebox rootfs", file=sys.stderr); return 5

    manifest = rootfs / "opt" / "sos" / "lib" / "kernel-input-modules-v32m.txt"
    manifest.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"kernel={kver}", f"source={tree}", "source_mode=v32n-auto-deb", f"copied_files={len(copied)}"]
    lines += [f"{n}={status[n]}" for n in WANTED]
    lines += ["", "files:"] + sorted(copied)
    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"[v32n] target kernel: {kver}")
    print(f"[v32n] exact module tree: {tree}")
    for n in WANTED:
        print(f"[v32n] {n}: {status[n]}")
    print(f"[v32n] copied {len(copied)} module/dependency files")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
