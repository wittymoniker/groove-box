#!/usr/bin/env python3
from pathlib import Path
import py_compile,sys
root=Path(__file__).resolve().parent
fail=[]
def need(p,t=None):
    q=root/p
    if not q.exists(): fail.append('missing '+p); return
    if t and t not in q.read_text(errors='replace'): fail.append(p+' missing '+t)
need('V35_18E_INPUT_NVME_PATCHED.txt','GROOVEBOX_V35_18E_INPUT_NVME_PATCH_20260921')
need('v35_18e/sos-input-ready-v35_18e','INPUT_READY|PASS')
if (root/'gpt_disk_v32q.py').exists():
    need('gpt_disk_v32q.py','GROOVEBOX_V35_18E_NVME_WHOLE_DISK_20260921')
    try: py_compile.compile(str(root/'gpt_disk_v32q.py'),doraise=True)
    except Exception as e: fail.append('gpt_disk compile: '+str(e))
builders=[]
for p in root.rglob('*.sh'):
    if '.v35_18e-backup' in p.parts: continue
    s=p.read_text(errors='replace')
    if 'ROOTFS' in s and ('sos-input-ready-v35_18e' in s or 'sos-input-ready-v35_18f' in s): builders.append(p)
# v35.18f+ moved the authoritative injection into patch_final_rootfs_v35_18f.py.
if not builders and (root/'patch_final_rootfs_v35_18f.py').is_file():
    q=(root/'patch_final_rootfs_v35_18f.py').read_text(errors='replace')
    if 'sos-input-ready' in q: builders.append(root/'patch_final_rootfs_v35_18f.py')
if not builders: fail.append('no current builder/final-root patch stages sos-input-ready')
inits=[]
for p in root.glob('init*'):
    if not p.is_file(): continue
    q=p.read_text(errors='replace')
    if ('GROOVEBOX_V35_18E_INPUT_NVME_PATCH_20260921' in q or 'sos-input-ready' in q): inits.append(p)
# Current releases prove the generated final /init via verify_v35_22 instead of
# requiring the historical source init marker.
if not inits and not (root/'verify_v35_22.py').is_file(): fail.append('no init variant/current generated-init verifier has strict input gate')
if fail:
    print('FAIL: v35.18e verification')
    for x in fail: print(' -',x)
    raise SystemExit(1)
print('PASS: v35.18e source patch verification')
print('builders:',*[str(x.relative_to(root)) for x in builders])
print('init gates:',*[str(x.relative_to(root)) for x in inits])
