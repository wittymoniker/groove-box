#!/usr/bin/env bash
# GROOVEBOX_V34O_GUI_RUNTIME_QPA_FIX_20260919
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(dirname "$HERE")}" 
if [[ ! -d "$ROOT/BUILD_ISO" ]]; then
  for d in "$PWD" "$HOME/Documents/groovebox" "$HOME/Downloads/groovebox" "$HOME/Desktop/groovebox"; do
    if [[ -d "$d/BUILD_ISO" ]]; then ROOT="$(cd "$d" && pwd)"; break; fi
  done
fi
[[ -d "$ROOT/BUILD_ISO" ]] || { echo 'FAIL: run this from a Groovebox project root containing BUILD_ISO.' >&2; exit 3; }
BI="$ROOT/BUILD_ISO"
echo "[v34o] Groovebox root: $ROOT"
echo '[v34o] validating GUI runtime/QPA/recovery diagnostic repair'
python3 "$BI/verify_gui_runtime_v34o.py" "$BI"
/bin/sh -n "$BI/groovebox-runtime-check-v34o"
/bin/sh -n "$BI/source/rootfs/usr/bin/groovebox-appliance"
python3 -m py_compile "$BI/patch_gui_runtime_v34o.py" "$BI/verify_gui_runtime_v34o.py"
grep -Fq 'GROOVEBOX_V34N_BUSYBOX_ZERO_STATE_FIX_20260919' "$BI/bootstrap_clean_tree_v33c.sh" || { echo 'FAIL: v34n base missing' >&2; exit 4; }

echo 'PASS: v34o uses /opt/pyvenv Python for the actual Groovebox GUI'
echo 'PASS: v34o preserves the QPA backend/input environment selected by the successful probe'
echo 'PASS: v34o installs groovebox-runtime-check into the live rootfs'

bash "$BI/RUN_ME_v34n.sh" "$ROOT"

SRC="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34n.iso"
if [[ ! -s "$SRC" ]]; then SRC="$BI/dist/Groovebox-sOS-x86_64-20260918-LIMINE-SCODE-v33c.iso"; fi
if [[ -s "$SRC" ]]; then
  DST="$BI/dist/Groovebox-sOS-x86_64-20260919-ZERO-STATE-v34o.iso"
  cp -f "$SRC" "$DST"
  sha256sum "$DST" > "$DST.sha256"
  if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" ]]; then
    g="$(id -gn "$SUDO_USER" 2>/dev/null || printf '%s' "$SUDO_USER")"
    chown "$SUDO_USER:$g" "$DST" "$DST.sha256" 2>/dev/null || true
  fi
  echo
  echo 'PASS: v34o zero-state ISO built'
  echo "ISO: $DST"
  echo "SHA-256: $(cut -d' ' -f1 "$DST.sha256")"
fi
