# Mathematician's Groovebox Project Report

## Implementation

This directory contains a native sCode implementation intended to run through the single sCode 8 runtime. The GitHub source release keeps this project source-only and reproducible.

## Mathematical integration

MEUM; isn/ics/isx/isy; PHI; GOAVA chord weights; finite-infinity compiled source identity; canonical determinism contract.

All claims, formulas, and status distinctions are inherited from `../../docs/MATHEMATICS_AND_THEOREMS.md`. Project-defined claims are not relabeled as established external mathematics.

## Verification

`tests/run_all.sh` statically checks and compiles this application's `.sC` source. Runtime smoke tests are included for non-interactive applications and key interactive shells.
