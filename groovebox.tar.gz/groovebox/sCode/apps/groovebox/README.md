# Mathematician's Groovebox — native sCode

The authoritative native application entry is `groovebox_native_full.sC` on sCode 10.

It generates project state, deterministic PCM audio, a deterministic visual frame, MIDI, deterministic game/world data, and a cross-media bundle manifest without requiring Python, Julia, or C++.

Run from the repository root:

```sh
./run_groovebox_native.sh
```

Batch export:

```sh
GROOVEBOX_BATCH=1 GROOVEBOX_OUT_PREFIX=my_project ./run_groovebox_native.sh
```

Native defaults are Math Symbols ON and EQR 0.4014.

The older `groovebox.sC` and `groovebox_full_target.sC` are retained as compatibility examples; new work should target `groovebox_native_full.sC` and the modules under `scode/libs/groovebox/`.
