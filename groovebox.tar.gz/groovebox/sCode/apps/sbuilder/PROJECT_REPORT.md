# sbuilder Project Report

## Implementation

This directory contains a native sCode implementation intended to run through the single sCode 8 runtime. The GitHub source release keeps this project source-only and reproducible.

## Mathematical integration

Build orchestration itself is conventional process control; generated sCode artifacts use the Math-First runtime and finite-infinity index.

All claims, formulas, and status distinctions are inherited from `../../docs/MATHEMATICS_AND_THEOREMS.md`. Project-defined claims are not relabeled as established external mathematics.

## Verification

`tests/run_all.sh` statically checks and compiles this application's `.sC` source. Runtime smoke tests are included for non-interactive applications and key interactive shells.
