# sbuilder

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run sbuilder.sC
```

## Mathematics

Build orchestration itself is conventional process control; generated sCode artifacts use the Math-First runtime and finite-infinity index.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
