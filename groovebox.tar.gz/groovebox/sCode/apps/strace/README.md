# strace

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run strace.sC
```

## Mathematics

Uses finite-hash/grep source inspection and compiled token indexes for deterministic trace lookup.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
