# sgraph

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run sgraph.sC
```

## Mathematics

Deterministic graph identities can be mapped through finite.hash; graph topology is otherwise ordinary finite graph structure.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
