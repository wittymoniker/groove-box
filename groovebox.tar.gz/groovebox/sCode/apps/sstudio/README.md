# sstudio

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run sstudio.sC
```

## Mathematics

Uses sCode compilation and therefore embeds the finite-infinity grep index in generated .sbin artifacts.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
