# sgamelab

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run sgamelab.sC
```

## Mathematics

Uses MEUM, isn, finite.index and finite.hash for deterministic seed/world signatures.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
