# scompat project report
Uses the native sCode runtime and preserves the Math ABI boundary described in docs/MATH_TRANSITION_COMPATIBILITY.md.
