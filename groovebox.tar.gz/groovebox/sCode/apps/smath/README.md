# smath

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run smath.sC
```

## Mathematics

Direct workbench for MEUM, isn/ics/isx/isy, finite indexing/hashing; runtime also exposes selected OT and EQR primitives.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
