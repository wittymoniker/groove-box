# smedia

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run smedia.sC
```

## Mathematics

Uses the native direct-series trig path for deterministic WAV generation.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
