Place the verified native macos-arm64 sCode stage-0 here as scode0.

The first-run launcher installs it into sCode/bootstrap/macos-arm64/scode0 and requires
it to pass native executable-format, execution, and Groovebox optimizer ABI-9 probes.
The Linux ELF stage-0 must never be copied here.
