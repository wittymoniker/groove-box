Place the verified native windows-x86_64 sCode stage-0 here as scode0.exe.

The first-run launcher installs it into sCode/bootstrap/windows-x86_64/scode0.exe and requires
it to pass native executable-format, execution, and Groovebox optimizer ABI-9 probes.
The Linux ELF stage-0 must never be copied here.
