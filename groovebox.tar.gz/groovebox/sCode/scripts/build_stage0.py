#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, platform, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'bootstrap_src'/'scode0_host.c'

def key():
    s=platform.system().lower(); m=platform.machine().lower()
    if m=='amd64': m='x86_64'
    if m=='aarch64': m='arm64'
    return s,m

def target():
    s,m=key()
    if s=='windows': return ROOT/'bootstrap'/f'windows-{m}'/'scode0.exe'
    if s=='darwin': return ROOT/'bootstrap'/f'macos-{m}'/'scode0'
    if s=='linux': return ROOT/'bootstrap'/f'linux-{m}'/'scode0'
    raise SystemExit(f'unsupported host: {s}/{m}')

def run(cmd):
    print('[sCode builder]', ' '.join(map(str,cmd)), flush=True)
    subprocess.run(list(map(str,cmd)),check=True,cwd=ROOT.parent)

def build(force=False):
    out=target(); out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists() and not force:
        try:
            p=subprocess.run([str(out),'--version'],text=True,capture_output=True,timeout=10)
            if p.returncode==0 and 'portable-host' in p.stdout:
                print(f'[sCode builder] existing native stage-0 OK: {out}'); return out
        except Exception: pass
    s,_=key()
    if s=='windows':
        cl=shutil.which('cl'); clang=shutil.which('clang'); gcc=shutil.which('gcc')
        if cl: run([cl,'/nologo','/O2','/std:c11',str(SRC),f'/Fe:{out}'])
        elif clang: run([clang,'-std=c11','-O2',str(SRC),'-o',str(out)])
        elif gcc: run([gcc,'-std=c11','-O2',str(SRC),'-o',str(out)])
        else: raise RuntimeError('No C compiler found. Install Visual Studio Build Tools, LLVM/clang, or MinGW GCC.')
    else:
        cc=shutil.which('clang') or shutil.which('cc') or shutil.which('gcc')
        if not cc: raise RuntimeError('No C compiler found (clang/cc/gcc).')
        run([cc,'-std=c11','-O2',str(SRC),'-o',str(out)])
        out.chmod(out.stat().st_mode|0o755)
    p=subprocess.run([str(out),'--version'],text=True,capture_output=True,timeout=10)
    if p.returncode!=0 or 'portable-host' not in p.stdout:
        raise RuntimeError(f'sCode stage-0 verification failed: {p.stdout} {p.stderr}')
    # Functional compiler self-test: compile bundled sCode source through stage-0.
    example=ROOT/'examples'/'hello.sC'
    with tempfile.TemporaryDirectory(prefix='scode-stage0-') as td:
        ir=Path(td)/'hello.ir.json'
        q=subprocess.run([str(out),'compile',str(example),'-o',str(ir)],text=True,capture_output=True,timeout=30)
        if q.returncode or not ir.is_file():
            raise RuntimeError(f'sCode compile self-test failed: {q.stdout} {q.stderr}')
        data=json.loads(ir.read_text(encoding='utf-8'))
        if data.get('scode_ir_version') != 1:
            raise RuntimeError('sCode compile self-test produced unexpected IR')
    # Install a convenient project-local command too. The host searches upward
    # for scode_cli.py, so the same binary works from bin/.
    bindir=ROOT.parent/'bin'; bindir.mkdir(exist_ok=True)
    local=bindir/('scode.exe' if key()[0]=='windows' else 'scode')
    shutil.copy2(out,local)
    if key()[0] != 'windows': local.chmod(local.stat().st_mode|0o755)
    print(f'[sCode builder] installed and verified: {out}')
    print(f'[sCode builder] local command: {local}')
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--force',action='store_true'); a=ap.parse_args()
    try: build(a.force)
    except Exception as e:
        print(f'[sCode builder] ERROR: {e}',file=sys.stderr); raise SystemExit(2)
