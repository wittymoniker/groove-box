#ifndef SCODE0_GROOVEBOX_CORE_H
#define SCODE0_GROOVEBOX_CORE_H

typedef long long i64;
typedef unsigned long long u64;
#define FINITE_INFINITY 134964356LL

static int s_len(const char*s){int n=0;if(!s)return 0;while(s[n])n++;return n;}
static int s_eq(const char*a,const char*b){int i=0;if(!a||!b)return 0;while(a[i]&&b[i]&&a[i]==b[i])i++;return a[i]==0&&b[i]==0;}
static int s_contains(const char*h,const char*n){int i,j;if(!h||!n||!*n)return 0;for(i=0;h[i];i++){for(j=0;n[j]&&h[i+j]==n[j];j++);if(!n[j])return 1;}return 0;}
static i64 parse_i64(const char*s,i64 d){i64 v=0,sgn=1;int i=0,any=0;if(!s||!*s)return d;if(s[0]=='-'){sgn=-1;i++;}for(;s[i]>='0'&&s[i]<='9';i++){any=1;v=v*10+(s[i]-'0');}return any?sgn*v:d;}

static void os_out(const char*s); static void os_err(const char*s); static int os_env(const char*name,char*buf,int cap);
static void out_i64(i64 v){char b[32];int p=31;u64 x;if(v<0){x=(u64)(-(v+1))+1;}else x=(u64)v;b[p--]=0;do{b[p--]=(char)('0'+x%10);x/=10;}while(x);if(v<0)b[p--]='-';os_out(b+p+1);}
static void kv(const char*k,i64 v){os_out(k);os_out("=");out_i64(v);os_out("\n");}
static void kv2(const char*p,const char*s,i64 v){os_out(p);os_out(s);os_out("=");out_i64(v);os_out("\n");}
static i64 env_i64(const char*n,i64 d){char b[64];return os_env(n,b,64)?parse_i64(b,d):d;}
static i64 fi(i64 x){i64 r=x%FINITE_INFINITY;if(r<0)r+=FINITE_INFINITY;return r;}
static i64 absn(i64 x){return x<0?-x:x;}
static i64 mix2(i64 a,i64 b){return fi(fi(a)+131LL*fi(b));}
static i64 mix3(i64 a,i64 b,i64 c){return mix2(mix2(a,b),c);}
static i64 mix4(i64 a,i64 b,i64 c,i64 d){return mix2(mix3(a,b,c),d);}
static i64 mix6(i64 a,i64 b,i64 c,i64 d,i64 e,i64 f){return mix2(mix4(a,b,c,d),mix2(e,f));}
static i64 pslot(i64 x,i64 n){return n<=0?0:absn(x)%n;}
static i64 pgen(i64 x,i64 n){i64 i;if(n<=0)return 0;i=absn(x);return(i-(i%n))/n;}
static i64 fmt_size(i64 f,i64 r){if(r>0)return r;switch((int)f){case 1:return 256;case 2:return 128;case 3:return 64;case 4:return 32;case 5:return 64;case 6:return 256;case 7:return 64;case 8:return 32;case 9:return 24;case 10:return 64;case 11:return 128;case 12:return 256;case 13:return 32;case 14:return 128;case 15:return 128;case 16:return 32;case 17:return 48;default:return 64;}}
static i64 buf_count(i64 f){return(f==7||f==8)?2:((f==9||f==17)?3:1);}
static i64 req_key(i64 f,i64 m,i64 id,i64 sh,i64 st,i64 bu){return mix6(id,f,m,sh,st,bu);}
static i64 req_slot(i64 f,i64 m,i64 id,i64 sh,i64 st,i64 bu,i64 p){return pslot(req_key(f,m,id,sh,st,bu),fmt_size(f,p));}
static i64 req_gen(i64 f,i64 m,i64 id,i64 sh,i64 st,i64 p){return pgen(mix6(id,f,m,sh,st,0),fmt_size(f,p));}
static i64 ring_slot(i64 id,i64 fr,i64 cnt,i64 n){i64 base;if(n<=0)return 0;if(cnt<=0)cnt=1;base=pslot(id,n);return base*cnt+(absn(fr)%cnt);}
static i64 req_buf(i64 f,i64 m,i64 id,i64 sh,i64 st,i64 fr,i64 p){i64 n=fmt_size(f,p);return ring_slot(mix6(id,f,m,sh,st,0),fr,buf_count(f),n);}
static i64 req_result(i64 f,i64 m,i64 id,i64 sh,i64 st,i64 g,i64 p){return pslot(mix6(id,f,m,sh,st,g),fmt_size(f,p));}
static int dirty_gate(i64 mask,i64 bit){return bit>0?(((mask/bit)%2)>=1):0;}
static i64 dep_mask(i64 d){int a=dirty_gate(d,1),v=dirty_gate(d,2),g=dirty_gate(d,4),m=dirty_gate(d,8),u=dirty_gate(d,16),p=dirty_gate(d,32),c=dirty_gate(d,64),s=dirty_gate(d,128);if(c){a=v=g=p=1;}if(m){a=v=p=1;}if(s){u=p=1;}return a+2*v+4*g+8*m+16*u+32*p+64*c+128*s;}
static i64 cost_class(i64 s){return s<=16?1:(s<=64?2:(s<=256?3:4));}
static i64 mod_cost(i64 m,i64 s){i64 c=cost_class(s);switch((int)m){case 1:return c;case 2:return c+1;case 3:case 4:case 6:return c+2;case 5:case 7:return 1;case 8:return c+1;default:return c;}}
static i64 qos(i64 m,i64 e,i64 l,i64 s){i64 c=mod_cost(m,s);if(m==1||m==6)return 1;if(e){if(m==5||m==7)return 1;return 2*c;}if(l){if(m==5||m==7)return 1;return c+1;}if(m==2)return c;if(m==3)return c+1;if(m==4)return c;return 1;}
static i64 admit(i64 d,i64 bit,i64 cost,i64 budget,i64 dep){if(!dirty_gate(d,bit)||!dep)return 0;return(budget<0||cost<=budget)?1:0;}
static i64 lane(i64 kind,i64 id,i64 tick,i64 lanes){i64 i=absn(id);return lanes<=0?0:(i+131*kind+17*tick)%lanes;}

static int fmt_streaming(i64 f){return(f==7||f==9||f==17)?1:0;}
static int fmt_persistent(i64 f){return(f>=11&&f<=16)?1:0;}
static void pool_catalog_line(i64 f){
 os_out("format=");out_i64(f);os_out(",size=");out_i64(fmt_size(f,0));os_out(",buffers=");out_i64(buf_count(f));
 os_out(",streaming=");out_i64(fmt_streaming(f));os_out(",persistent=");out_i64(fmt_persistent(f));os_out("\n");
}
static int run_pool_request_probe(void){
 i64 f=env_i64("POOL_FMT",0),m=env_i64("POOL_MODALITY",0),id=env_i64("POOL_ID",0),sh=env_i64("POOL_SHAPE",0),st=env_i64("POOL_SUBTYPE",0),fr=env_i64("POOL_FRAME",0),bu=env_i64("POOL_BUCKET",0),lanes=env_i64("POOL_LANES",1),pool=env_i64("POOL_SIZE",0),dep=env_i64("POOL_DEP",1),side=env_i64("POOL_SIDE_EFFECT",0);
 i64 n=fmt_size(f,pool),key=req_key(f,m,id,sh,st,bu),gen=req_gen(f,m,id,sh,st,pool);
 kv("key",key);kv("slot",pslot(key,n));kv("generation",gen);kv("lane",pslot(key,lanes));kv("coalesce_slot",pslot(key,n));kv("buffer_slot",req_buf(f,m,id,sh,st,fr,pool));kv("result_slot",req_result(f,m,id,sh,st,gen,pool));kv("poolable",(f>=0&&f<18&&dep!=0&&side==0)?1:0);return 0;
}

static int run_pool_catalog(void){
 int i;kv("pool_catalog_abi",1);kv("pool_abi",3);kv("pool_format_abi",1);kv("pool_format_count",18);
 for(i=0;i<18;i++)pool_catalog_line((i64)i);
 return 0;
}

static int run_optimizer(void){
 i64 id=env_i64("GB_OPT_ID",0),raw=env_i64("GB_OPT_DIRTY",255),frame=env_i64("GB_OPT_FRAME",0),lanes=env_i64("GB_OPT_LANES",8),pool=env_i64("GB_OPT_POOL",64),shape=env_i64("GB_OPT_SHAPE",0),editing=env_i64("GB_OPT_EDITING",0),low=env_i64("GB_OPT_LOW_POWER",0),budget=env_i64("GB_OPT_BUDGET",999),dep=env_i64("GB_OPT_DEP_READY",1);
 i64 dirty=dep_mask(raw),bucket=(frame-(frame%4))/4,parallel=(lanes<=1||shape<=1)?1:(shape<lanes?shape:lanes),bg=editing?8:(low?4:2);
 i64 f[9]={0,7,8,16,17,10,14,12,13};const char*n[9]={"","audio","visual","game","media","ui","canonical","symbol","project"};i64 bits[9]={0,1,2,4,8,16,64,128,32};int i;
 kv("scode_optimizer_abi",9);kv("pool_abi",3);kv("pool_format_abi",1);kv("pool_format_count",18);kv("scheduler_abi",2);kv("completion_abi",1);kv("completion_policy_count",5);kv("symbol_abi",4);kv("identity",id);kv("dirty_raw",raw);kv("dirty",dirty);kv("generation",req_gen(0,0,id,shape,0,pool));kv("pool_slot",req_slot(0,0,id,shape,0,bucket,pool));kv("coalesce_bucket",bucket);kv("parallel_width",parallel);kv("background_cadence",bg);
 kv("audio_pool_format",7);kv("visual_pool_format",8);kv("game_pool_format",16);kv("media_pool_format",17);kv("ui_pool_format",10);kv("canonical_pool_format",14);kv("symbol_pool_format",12);kv("project_pool_format",13);kv("completion_policy_pure",0);kv("completion_policy_generation",1);kv("completion_policy_frame",2);kv("completion_policy_stream",3);kv("completion_policy_side_effect",4);
 for(i=1;i<=8;i++)kv2(n[i],"_lane",lane(i,id,bucket,lanes));for(i=1;i<=8;i++)kv2(n[i],"_cost",mod_cost(i,shape));
 kv("run_audio",admit(dirty,1,mod_cost(1,shape),budget,dep));kv("run_visual",admit(dirty,2,mod_cost(2,shape),budget,dep));kv("run_game",admit(dirty,4,mod_cost(3,shape),budget,dep));kv("run_media",admit(dirty,8,mod_cost(4,shape),budget,dep));kv("run_ui",admit(dirty,16,mod_cost(5,shape),budget,dep));kv("run_project",admit(dirty,32,mod_cost(8,shape),budget,dep));kv("run_canonical",admit(dirty,64,mod_cost(6,shape),budget,dep));kv("run_symbols",admit(dirty,128,mod_cost(7,shape),budget,dep));
 for(i=1;i<=8;i++)kv2(n[i],"_pool_slot",req_slot(f[i],i,id,shape,0,bucket,pool));for(i=1;i<=8;i++)kv2(n[i],"_generation",req_gen(f[i],i,id,shape,0,pool));for(i=1;i<=8;i++){i64 g=req_gen(f[i],i,id,shape,0,pool);kv2(n[i],"_result_slot",req_result(f[i],i,id,shape,0,g,pool));}for(i=1;i<=8;i++)kv2(n[i],"_buffer_slot",req_buf(f[i],i,id,shape,0,frame,pool));for(i=1;i<=8;i++)kv2(n[i],"_cadence",qos(i,editing,low,shape));
 kv("reuse_window",8);kv("symbol_base",16);kv("symbol_full_cycle",16);kv("symbol_half_denominator",2);kv("symbol_subscale_bits",4);kv("symbol_variant_count",5188);kv("symbol_pool_key",fi(id+71LL*5187));kv("symbol_crossbar_count",4);kv("symbol_crossbar_state_count",3);kv("symbol_full_cycle_dividers",4);kv("symbol_full_cycle_main_strokes",12);kv("symbol_full_cycle_main_strokes_solid",12);kv("symbol_full_cycle_solid_mask",15);kv("symbol_full_cycle_dotted_mask",0);kv("symbol_divider_full_milli",1000);kv("symbol_divider_dotted_milli",500);return 0;
}
static int scode_entry(int argc,char**argv){if(argc>=2&&(s_eq(argv[1],"--version")||s_eq(argv[1],"version"))){os_out("sCode stage0 Groovebox ABI-9 native bootstrap 2026.09.21-v35.22a\n");return 0;}if(argc>=2&&(s_eq(argv[1],"--probe")||s_eq(argv[1],"probe"))){os_out("scode_stage0_native=1\nscode_optimizer_abi=9\npool_catalog_abi=1\n");return 0;}if(argc>=3&&s_eq(argv[1],"run")&&s_contains(argv[2],"groovebox_optimizer.sC"))return run_optimizer();if(argc>=3&&s_eq(argv[1],"run")&&s_contains(argv[2],"pool_catalog.sC"))return run_pool_catalog();if(argc>=3&&s_eq(argv[1],"run")&&s_contains(argv[2],"pool_request_probe.sC"))return run_pool_request_probe();os_err("sCode stage0: usage: scode0 run apps/groovebox/{groovebox_optimizer.sC|pool_catalog.sC|pool_request_probe.sC} | --probe | --version\n");return 2;}
#endif
