param([switch]$Force)
$ErrorActionPreference='Stop'
$ROOT=Split-Path -Parent $MyInvocation.MyCommand.Path
$PROJECT=Split-Path -Parent $ROOT
Write-Host '==> sCode native installer: Windows'
$py=$null
if(Get-Command py -ErrorAction SilentlyContinue){ $py='py'; $args0=@('-3') }
elseif(Get-Command python -ErrorAction SilentlyContinue){ $py='python'; $args0=@() }
else { throw 'Python is required before building sCode.' }
if(-not (Get-Command cl -ErrorAction SilentlyContinue) -and -not (Get-Command clang -ErrorAction SilentlyContinue) -and -not (Get-Command gcc -ErrorAction SilentlyContinue)) {
  if(Get-Command winget -ErrorAction SilentlyContinue) {
    Write-Host '==> No C compiler found; installing LLVM/clang with winget...'
    winget install --id LLVM.LLVM --silent --accept-package-agreements --accept-source-agreements
    $llvm='C:\Program Files\LLVM\bin'; if(Test-Path $llvm){ $env:Path="$llvm;$env:Path" }
  }
}
$cmd=@($args0 + @((Join-Path $ROOT 'scripts\build_stage0.py')))
if($Force){ $cmd += '--force' }
& $py @cmd
if($LASTEXITCODE -ne 0){ exit $LASTEXITCODE }
Write-Host '==> sCode Windows native stage-0 installed and verified.'
