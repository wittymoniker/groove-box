# Bootstrap trust model

A source-pure self-hosting language still requires an executable seed on a machine that cannot yet execute its source. This repository separates authoritative `.sC` source, stage-0 seed binaries, and the future stage-1/stage-2 reproducible bootstrap-closure test.
