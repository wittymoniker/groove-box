# Cross-platform / architecture support

## sOS bootable operating system
Primary boot targets are Linux-compatible **x86-64** (AMD and Intel CPUs) and **AArch64/ARM64**. Hardware enablement still depends on the Linux kernel, firmware and drivers included in a particular image.

## Hosted sCode toolchain
The sCode compiler/runtime, sApp tooling and MathBridge are written in portable C++ and have build entrypoints for:
- Linux x86-64 / AMD64 (AMD or Intel)
- Linux AArch64
- Windows x86-64
- Windows ARM64 source/toolchain path
- macOS Intel x86-64
- macOS Apple Silicon arm64

Windows and macOS support means **hosted sCode/apps**, not booting the sOS Linux image natively as Windows/macOS.
