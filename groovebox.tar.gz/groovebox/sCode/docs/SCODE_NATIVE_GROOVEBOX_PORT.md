# sCode Native Groovebox Port

This release moves the executable Groovebox engine surface onto native sCode.

## Native now
- Meum / isn / ics / isx / isy / EQR / OT compatibility / Finite Infinity
- canonical deterministic frequency mapping and 64-bit hexadecimal project fingerprint
- dependency-free PCM WAV synthesis, up to 64 voices
- deterministic visual frame generation to portable PPM
- Standard MIDI File generation
- deterministic game/world-state JSON generation
- native MCC project document generation
- cross-media bundle manifest generation
- sCode source modules/imports for core, audio, visuals, MIDI, game, project, performance, and canonical engines
- native C host ABI used directly by the sCode runtime

## Defaults
Native sCode Groovebox defaults Math Symbols ON and EQR effect to 0.4014.

## Remaining parity work
The historical Qt implementation remains richer in interactive desktop GUI widgets, live device audio/MIDI, video codec integration, full game renderer, and all editor dialogs. Those are GUI/device/backend parity tasks, not a requirement for the native composition/export engine to operate.

The native release intentionally does not require Python, Julia, or C++.

## Additional native sCode compatibility modules
`sequencer.sC`, `automation.sC`, `hyperdrive.sC`, `samples.sC`, `symbols.sC`, `radio.sC`, `target_profile.sC`, and `goava.sC` expose the newer Groovebox concepts through the same native language layer. These are deterministic scalar/state kernels suitable for later GUI bindings; they do not silently introduce random state or hidden normalization.
