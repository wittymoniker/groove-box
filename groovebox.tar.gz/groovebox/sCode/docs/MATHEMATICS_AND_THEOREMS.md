# sOS / Groovebox Mathematics and Theorem Register

This document is the shared mathematical register for every project report in this repository. It separates **project-defined mathematics**, **implemented engineering rules**, **standard mathematics**, and **claims that require an independent proof before they should be presented as established mathematics**.

## 1. Meum constant

The project uses

```text
M ≈ 1.1975807343385265
```

with the root formulation

```text
F(x) = 2^x - x^4 - x^2 + x
F(M) = 0
```

and the equivalent project formulation involving `N^(M log_N 2)` when the logarithm/base expression is defined. The native runtime exposes `MEUM` and `meum.residual(x)`.

**Status:** numerical constant and residual are implemented. The project has discussed an existence/uniqueness argument for a root in `(1,2)` and an irrationality theorem. Those theorem claims should be cited as **project claims** unless a complete proof is included and independently checked. Runtime determinism does not itself prove irrationality.

## 2. Operator Theory (OT)

The project defines explicit reversible-operation semantics. Implemented native primitives include:

```text
ot.mul(a,b)
ot.div(a,b)
ot.pow(b,e)
ot.root(b,r)
ot.phase(x,k)
```

The recorded project conventions include:

```text
OT_MUL(0,0) = 1
OT_MUL(0,b) = OT_MUL(a,0) = 0 for a,b != 0
|OT_MUL(a,b)| = |ab|
```

with the project sign convention that positive×positive is positive and all other nonzero sign pairings are negative.

For division, the recorded project rules include:

```text
OT_DIV(0,0) = 1
|OT_DIV(a,b)| = |a|/|b| for b != 0
```

with sign taken from the numerator, and signed infinity for nonzero numerator divided by zero in OT mode.

For the phase operator:

```text
OT_I_PHASE(x,k) = -x for even k
OT_I_PHASE(x,k) = +x for odd k
```

**Status:** project-defined arithmetic/engineering semantics, not ordinary field arithmetic. The native implementation follows the recorded rules above. Any OT rule not explicitly listed here must not be inferred silently.

## 3. isn / ics / isx / isy

The project book-form definitions are:

```text
isn(theta) = 2 sin(theta/2)
ics(theta) = 2 cos(theta/2)
isn^-1(y) = 2 asin(y/2)
ics^-1(y) = 2 acos(y/2)
isx(gamma) = 1 - isn(gamma)
isy(gamma) = 1 - isn(gamma - pi/2)
```

The native sCode runtime calculates `isn` and `ics` with direct finite series after deterministic range reduction. `sin`, `cos`, and `tan` route through those project series. `isn_inv` / `ics_inv` use principal-domain inverse functions.

**Status:** implemented. The inverse real-domain restriction `|y/2| <= 1` is ordinary mathematics and is not an audio clipping statement.

## 4. Finite Infinity

The project reference is:

```text
I = 134964356
FINITE_INFINITY = 134964356
```

The native compiler/runtime uses it as a **finite indexing boundary** rather than as mathematical infinity. Native primitives include:

```text
finite.index(n)
finite.hash(text)
finite.window(start,count)
grep.contains(text,pattern)
grep.count(text,pattern)
compile.grep_count(token)
compile.grep_first(token)
```

### Compiler integration

sCode 8 builds a deterministic token index during compilation:

1. source is tokenized into normalized alphanumeric/underscore/dot tokens;
2. each token receives a deterministic FNV-style hash;
3. that hash is reduced modulo `134964356`;
4. line references are stored in the compiled `.sbin` artifact;
5. `scode index file.sbin` exposes the embedded index;
6. the runtime rebuilds the same index for source execution, so compile-time and source-run lookup use the same contract.

This is the repository's concrete implementation of the discussed **finite-infinity / grep-style logic**: logically large search spaces are represented by finite deterministic identities and bounded line-reference sets rather than by an actually infinite container.

**Status:** implemented as compiler metadata and runtime primitives. It is a deterministic indexing/search method; it is not a proof that arbitrary infinite mathematical structures can be represented without loss.

## 5. EQR / Reality tensor formulation

The documented project form is:

```text
P = (1/k) Sum[n=0..k] isn^-1((isn(d_n)+isn(t))/2)
E = (1/k) Sum[n=0..k] isn(theta_n)/d_n
D = (1/k) Sum[n=0..k] isn^-1(isn(theta_n) E/(I P))
Z = P E + D
```

with `I = 134964356` as the finite-infinity reference. The native runtime exposes the final composition operation as `eqr.z(P,E,D)`; the full sequence/tensor construction remains an application-level algorithm.

**Status:** project-defined model. It is not presented here as an established physical law.

## 6. GOAVA / Groovebox weights

The current recorded Groovebox chord amplitudes are:

```text
[0.3333333, 0.1975807343, 0.05479]
```

The native Groovebox renderer uses these values together with `MEUM`, `PHI`, and the Math-First trig path. GOAVA and related canonical generation claims are engineering algorithms unless accompanied by a separate mathematical proof.

## 7. Canonical determinism and congruence

A canonical generation may be described as **CLAIMED EXACT under the implementation contract** when all of the following are fixed:

1. canonical inputs and serialization order;
2. public constants;
3. deterministic formulas and integer/index rules;
4. canonical state fingerprint;
5. regression-test contract.

This supports reproducibility of an implementation. It does not, by itself, prove a new theorem about all numbers or all future implementations.

A standard fact used by the project is:

```text
a ≡ b (mod n) iff n divides (a-b)
p(i) = (a i + b) mod n
```

and `p` is a permutation of residue classes when `gcd(a,n)=1`. This standard result is distinct from project-specific Meum/OT claims.

## 8. Reporting rule

Every project report in this repository must identify:

- which of the items above it actually calls or implements;
- which are only architectural influences;
- which are project claims rather than independently established results;
- which tests demonstrate implementation-level behavior.

Groovebox reports must additionally map the mathematics to audio, visual, game, seed, canonical, compiler, and DSP paths where those paths are implemented.
