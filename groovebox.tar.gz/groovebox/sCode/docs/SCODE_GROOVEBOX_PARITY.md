# Can native sCode host the finalized Groovebox?

Not completely yet. The current native runtime is sufficient for deterministic math, finite indexing, filesystem/process helpers and offline WAV rendering. The finalized Python/Qt Groovebox additionally depends on a mature retained-mode GUI, image/graphics rendering, low-latency streaming audio, MIDI, video/FFmpeg integration, threading/jobs, networking, input/gamepad handling, richer collections/objects/exceptions and a large application framework.

This expanded tree establishes the ABI and source libraries needed to migrate those systems without discarding the project's math:
- `libs/mathbridge`: C ABI for Meum/isn/ics/EQR/Finite Infinity and legacy adaptation.
- `scode/libs/math_compat.sC`: standard-trig compatibility identities.
- `scode/libs/groovebox_math.sC`: Groovebox-specific Math ABI wrapper.
- `groovebox/reference/python-qt-full`: current full feature reference implementation.

A feature-for-feature sCode port should use those compatibility layers while native GUI/audio/video/game libraries are implemented. Therefore the answer is **architecture: yes; current runtime parity: no**.
