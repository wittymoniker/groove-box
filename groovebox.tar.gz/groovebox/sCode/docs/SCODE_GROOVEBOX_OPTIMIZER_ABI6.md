> Historical ABI document. Current required contract: `SCODE_GROOVEBOX_OPTIMIZER_ABI9.md`.

# sCode Groovebox Optimizer ABI 6

ABI 6 is the frozen optimizer/runtime contract used by the matching Groovebox appliance.
It is intentionally narrower than claiming the entire sCode language is fully self-hosted:
this document certifies the part of sCode required to optimize Groovebox.

## Concrete stage-0 contract

The bundled stage-0 must execute, without null planner fields:

- number/logic normalization and dirty masks;
- deterministic finite pool slots, generations and result slots;
- stable modality lanes and coalescing buckets;
- dependency propagation between canonical/media/symbol state and their consumers;
- cost classes, budget admission and editing/low-power QoS cadence;
- bounded parallel width;
- author-number symbol semantics;
- native Groovebox parity tests.

Modalities use stable IDs: audio 1, visual 2, game 3, media 4, UI 5,
canonical 6, symbols 7 and project 8.

Canonical changes make audio, visual, game and project state dirty. Media changes
make audio, visual and project state dirty. Symbol changes make UI and project state
dirty but never alter DSP/game semantics.

Realtime audio remains host-native. sCode plans work before the callback; no stage-0
subprocess or allocation is introduced into the audio callback itself.

## Author symbol correction

The semantic `16` / full-cycle cell has **four solid divider bars**. Each solid divider
counts as `1/1` in its ordered place. A dotted divider means `0.5`. Therefore the full
cycle has solid mask `15` (all four bars) and dotted mask `0`.

## Release gate

`scripts/test.sh` is authoritative for this optimizer contract. It runs source purity,
math, finite indexing, hardware modality, number/logic, ABI-6 optimizer, compiler
optimizer, symbol codec/fractions, native Groovebox parity, and a concrete host-plan
probe. A release must not promote ABI 6 if any host-consumed field is blank/null.
