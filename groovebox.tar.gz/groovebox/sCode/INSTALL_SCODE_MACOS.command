#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "==> sCode native installer: macOS"
if ! command -v clang >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then brew install llvm; export PATH="$(brew --prefix llvm)/bin:$PATH"; fi
fi
command -v clang >/dev/null 2>&1 || { echo "clang is required. Install Xcode Command Line Tools (xcode-select --install) or Homebrew LLVM." >&2; exit 2; }
python3 "$ROOT/scripts/build_stage0.py" "$@"
echo "==> sCode macOS native stage-0 installed and verified."
