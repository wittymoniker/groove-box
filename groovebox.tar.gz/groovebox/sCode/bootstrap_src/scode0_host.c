#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif
/* sCode portable native stage-0 host.
 *
 * This small native executable is intentionally platform-neutral C11.  Its job
 * is to provide a host-native bootstrap binary on Windows/macOS/Linux and route
 * bootstrap compiler commands into the bundled, auditable sCode stage-0 Python
 * implementation.  Higher native sCode artifacts can then be built from the
 * repository without copying a foreign ELF/Mach-O/PE binary between platforms.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#ifdef _WIN32
# include <windows.h>
# include <process.h>
# include <direct.h>
# define PATH_SEP '\\'
#else
# include <unistd.h>
# include <sys/types.h>
# include <sys/wait.h>
# include <limits.h>
# ifdef __APPLE__
#  include <mach-o/dyld.h>
# endif
# define PATH_SEP '/'
#endif

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static int get_exe(char *buf, size_t n) {
#ifdef _WIN32
    DWORD k=GetModuleFileNameA(NULL,buf,(DWORD)n);
    return (k>0 && k<n)?0:-1;
#elif defined(__APPLE__)
    uint32_t sz=(uint32_t)n;
    if (_NSGetExecutablePath(buf,&sz)==0) return 0;
    return -1;
#else
    ssize_t k=readlink("/proc/self/exe",buf,n-1);
    if(k<=0 || (size_t)k>=n) return -1;
    buf[k]='\0'; return 0;
#endif
}

static void dirname_inplace(char *p) {
    char *a=strrchr(p,'/'); char *b=strrchr(p,'\\');
    char *q=a ? (b && b>a ? b : a) : b; if(q) *q='\0';
}

static int exists(const char *p) {
    FILE *f=fopen(p,"rb"); if(!f) return 0; fclose(f); return 1;
}

static int root_from_exe(char *root, size_t n) {
    if(get_exe(root,n)!=0) return -1;
    dirname_inplace(root);
    /* Find the project root rather than assuming one install depth.  This lets
       the same native host run from sCode/bootstrap/... or project-local bin/. */
    for(int i=0;i<6;i++) {
        char probe[PATH_MAX];
#ifdef _WIN32
        snprintf(probe,sizeof(probe),"%s\\scode_cli.py",root);
#else
        snprintf(probe,sizeof(probe),"%s/scode_cli.py",root);
#endif
        if(exists(probe)) return 0;
        dirname_inplace(root);
    }
    return -1;
}

static int spawn_python(const char *python, int is_py_launcher, const char *script, int argc, char **argv) {
    int extra=is_py_launcher?2:1;
    char **av=(char**)calloc((size_t)argc+extra+2,sizeof(char*));
    int j=0; av[j++]=(char*)python;
    if(is_py_launcher) av[j++]=(char*)"-3";
    av[j++]=(char*)script;
    for(int i=1;i<argc;i++) {
        /* Native stage-0 accepts historical `build` as an alias for compiler `compile`. */
        if(i==1 && strcmp(argv[i],"build")==0) av[j++]=(char*)"compile";
        else av[j++]=argv[i];
    }
    av[j]=NULL;
#ifdef _WIN32
    intptr_t rc=_spawnvp(_P_WAIT,python,(const char * const*)av);
    free(av); return rc==-1?127:(int)rc;
#else
    pid_t pid=fork();
    if(pid==0) { execvp(python,av); _exit(127); }
    if(pid<0) { free(av); return 127; }
    int st=0; while(waitpid(pid,&st,0)<0 && errno==EINTR) {}
    free(av);
    if(WIFEXITED(st)) return WEXITSTATUS(st);
    return 128;
#endif
}

int main(int argc, char **argv) {
    if(argc>=2 && (!strcmp(argv[1],"--version") || !strcmp(argv[1],"version"))) {
        puts("sCode stage0 portable-host 0.1"); return 0;
    }
    char root[PATH_MAX], script[PATH_MAX];
    if(root_from_exe(root,sizeof(root))!=0) { fprintf(stderr,"scode0: cannot resolve executable path\n"); return 70; }
#ifdef _WIN32
    snprintf(script,sizeof(script),"%s\\scode_cli.py",root);
#else
    snprintf(script,sizeof(script),"%s/scode_cli.py",root);
#endif
    if(!exists(script)) { fprintf(stderr,"scode0: bundled compiler not found: %s\n",script); return 66; }
    const char *env=getenv("SCODE_PYTHON");
    if(env && *env) return spawn_python(env,0,script,argc,argv);
#ifdef _WIN32
    int rc=spawn_python("py",1,script,argc,argv); if(rc!=127) return rc;
    return spawn_python("python",0,script,argc,argv);
#else
    int rc=spawn_python("python3",0,script,argc,argv); if(rc!=127) return rc;
    return spawn_python("python",0,script,argc,argv);
#endif
}
