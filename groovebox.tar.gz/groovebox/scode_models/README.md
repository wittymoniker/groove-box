# sCode local model base

Place a locally licensed GGUF model under this directory (model files are not bundled).
`sCode.agent.LocalLLM` invokes `llama-cli` explicitly. Model inference has no implicit
shell/network/project-write capability. Adaptation/training is intentionally a separate,
confirm-required action; a later training backend can target LoRA/PEFT without changing
sCode programs.
