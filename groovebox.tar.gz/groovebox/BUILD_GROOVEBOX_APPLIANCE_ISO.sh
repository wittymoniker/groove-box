#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BI="$ROOT/BUILD_ISO"
[ -d "$BI" ] || { echo 'Missing BUILD_ISO in this full Groovebox package.' >&2; exit 2; }
[ -x "$BI/RUN_ME_GAME_READY_v35.sh" ] || { echo 'Missing v35 game-ready builder.' >&2; exit 2; }
exec "$BI/RUN_ME_GAME_READY_v35.sh" "$ROOT"
