#!/usr/bin/env python3
"""Verify/repair the complete Groovebox desktop Python runtime.

The selected interpreter is printed as the only stdout line on success so
shell/batch launchers can capture it. Diagnostics go to stderr.

Fedora note: use Fedora's synchronized PyQt6/QtWebEngine packages instead of
mixing pip Qt wheels with the distro Qt stack. The project .venv is created
with system-site-packages so those bindings are visible, while scientific/audio
packages may still be repaired locally with pip.
"""
from __future__ import annotations
import argparse
import os
import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / ".venv"
sys.path.insert(0, str(Path(__file__).resolve().parent))
from runtime_dependencies import REQUIRED, PIP_PACKAGES  # noqa: E402

QT_PIP_PACKAGES = {
    "PyQt6", "PyQt6-Qt6", "PyQt6-sip",
    "PyQt6-WebEngine", "PyQt6-WebEngine-Qt6",
}


def _log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def _is_fedora() -> bool:
    try:
        text = Path("/etc/os-release").read_text(errors="ignore").lower()
    except Exception:
        return False
    return "id=fedora" in text or "id_like=fedora" in text or " fedora" in text


def _runtime_env(prefer_system_qt: bool = False) -> dict[str, str]:
    env = os.environ.copy()
    if prefer_system_qt:
        # Fedora/RPM PyQt must not be shadowed by ~/.local pip wheels or an
        # arbitrary PYTHONPATH. This is the exact failure mode that produces
        # Qt_6_PRIVATE_API mismatches against Fedora libQt6Core.
        env["PYTHONNOUSERSITE"] = "1"
        env.pop("PYTHONPATH", None)
    return env


def _probe(py: str, prefer_system_qt: bool = False) -> tuple[bool, list[str], dict[str, str]]:
    missing: list[str] = []
    errors: dict[str, str] = {}
    for mod, pkg in REQUIRED:
        code = f"import {mod}; print('ok')"
        try:
            r = subprocess.run(
                [py, "-c", code], capture_output=True, text=True,
                timeout=30, check=False, env=_runtime_env(prefer_system_qt),
            )
            if r.returncode != 0:
                missing.append(pkg)
                detail = (r.stderr or r.stdout or "import failed").strip()
                # Keep the useful tail; Python tracebacks put the loader/import
                # cause at the end.
                errors[pkg] = "\n".join(detail.splitlines()[-8:])
        except Exception as e:
            missing.append(pkg)
            errors[pkg] = repr(e)
    missing = list(dict.fromkeys(missing))
    return (not missing, missing, errors)


def _venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def _create_venv(prefer_system_qt: bool = False) -> Path:
    vpy = _venv_python()
    if not vpy.exists():
        _log(f"[runtime] creating project environment: {VENV}")
        venv.EnvBuilder(with_pip=True, system_site_packages=True, clear=False).create(VENV)
    if prefer_system_qt:
        cfg = VENV / "pyvenv.cfg"
        try:
            text = cfg.read_text()
            lines = []
            found = False
            for line in text.splitlines():
                if line.lower().startswith("include-system-site-packages"):
                    lines.append("include-system-site-packages = true")
                    found = True
                else:
                    lines.append(line)
            if not found:
                lines.append("include-system-site-packages = true")
            cfg.write_text("\n".join(lines) + "\n")
        except OSError as e:
            _log(f"[runtime] WARNING: could not enable system-site-packages in {cfg}: {e}")
    return vpy


def _install(py: str, packages: tuple[str, ...] | list[str]) -> int:
    if not packages:
        return 0
    _log("[runtime] installing/updating: " + " ".join(packages))
    subprocess.run(
        [py, "-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--upgrade", "pip", "wheel"],
        cwd=str(ROOT), check=False, stdout=sys.stderr, stderr=sys.stderr, env=_runtime_env(_is_fedora()),
    )
    return subprocess.run(
        [py, "-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--upgrade-strategy", "only-if-needed", *packages],
        cwd=str(ROOT), check=False, stdout=sys.stderr, stderr=sys.stderr, env=_runtime_env(_is_fedora()),
    ).returncode


def _remove_local_qt_wheels(py: str) -> None:
    """Expose Fedora's matched Qt/PyQt stack inside a system-site venv.

    pip Qt wheels inside the venv take precedence over Fedora's bindings and can
    produce an otherwise mysterious WebEngine shared-library mismatch after a
    distro Qt update. Uninstalling here does not remove RPM-owned packages.
    """
    subprocess.run(
        [py, "-m", "pip", "uninstall", "-y", *sorted(QT_PIP_PACKAGES)],
        cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        check=False, env=_runtime_env(_is_fedora()),
    )


def _show_errors(errors: dict[str, str], missing: list[str]) -> None:
    for pkg in missing:
        detail = errors.get(pkg)
        if detail:
            _log(f"[runtime] import detail for {pkg}:\n{detail}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--force-install", action="store_true", help="refresh declared packages in the project environment")
    ap.add_argument("--prefer-system-qt", action="store_true", help="use distro PyQt6/QtWebEngine rather than pip Qt wheels")
    args = ap.parse_args()

    prefer_system_qt = args.prefer_system_qt or (sys.platform.startswith("linux") and _is_fedora())
    current = str(Path(sys.executable).resolve())
    current_ok, _current_missing, _current_errors = _probe(current, prefer_system_qt)
    if current_ok and not args.force_install:
        print(current)
        return 0

    vpy = _create_venv(prefer_system_qt)
    vpy_s = str(vpy.resolve())
    if prefer_system_qt:
        _remove_local_qt_wheels(vpy_s)

    ok, missing, errors = _probe(vpy_s, prefer_system_qt)
    if args.force_install:
        install = list(PIP_PACKAGES)
    else:
        install = list(missing)
    if prefer_system_qt:
        install = [p for p in install if p not in QT_PIP_PACKAGES]
    install = list(dict.fromkeys(install))

    if install:
        rc = _install(vpy_s, install)
        if rc:
            _log(f"[runtime] pip provisioning failed with exit code {rc}")
            return rc

    ok, missing, errors = _probe(vpy_s, prefer_system_qt)
    if not ok:
        _log("[runtime] ERROR: required imports still unavailable: " + ", ".join(missing))
        _show_errors(errors, missing)
        if prefer_system_qt and any(p in QT_PIP_PACKAGES for p in missing):
            _log("[runtime] Fedora Qt/WebEngine repair is required; run install_deps_linux.sh and retry.")
        else:
            _log("[runtime] On Linux this can indicate a missing native PortAudio/Qt library; run install_deps_linux.sh once and retry.")
        return 12

    print(vpy_s)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
