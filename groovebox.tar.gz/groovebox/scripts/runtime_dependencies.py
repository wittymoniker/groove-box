#!/usr/bin/env python3
"""Single source of truth for Groovebox desktop Python runtime dependencies."""
from __future__ import annotations

# (import target, pip distribution)
REQUIRED = (
    ("numpy", "numpy"),
    ("scipy", "scipy"),
    ("cffi", "cffi"),
    ("PyQt6.QtCore", "PyQt6"),
    ("PyQt6.QtWebEngineWidgets", "PyQt6-WebEngine"),
    ("sounddevice", "sounddevice"),
    ("PIL", "Pillow"),
)

PIP_PACKAGES = tuple(dict.fromkeys(pkg for _mod, pkg in REQUIRED))
IMPORT_MODULES = tuple(mod for mod, _pkg in REQUIRED)
