#!/usr/bin/env python3
"""Provision and verify the *native* sCode stage-0 for the current host.

This never substitutes the Linux ELF runtime on Windows/macOS and never falls
back to the Python sCode bridge.  A platform stage-0 can be:
  1. already bundled at sCode/bootstrap/<platform>/scode0[.exe]
  2. bundled under sCode/bootstrap_packages/<platform>/scode0[.exe]
  3. supplied by GROOVEBOX_SCODE_STAGE0_SOURCE=/path/to/native/runtime
  4. downloaded from GROOVEBOX_SCODE_STAGE0_URL, optionally pinned with
     GROOVEBOX_SCODE_STAGE0_SHA256.

Every installed candidate is checked for the host executable format, run with
`version`, then exercised against the Groovebox ABI-9 optimizer.
"""
from __future__ import annotations
import hashlib, os, platform, shutil, stat, subprocess, sys, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCODE = ROOT / "sCode"


def host_key():
    s = platform.system().lower()
    m = platform.machine().lower()
    if m == "amd64": m = "x86_64"
    if m == "aarch64": m = "arm64"
    if s == "darwin": return f"macos-{m}"
    if s == "windows": return f"windows-{m}"
    if s == "linux": return f"linux-{m}"
    return f"{s}-{m}"


def target_path():
    key = host_key()
    return SCODE / "bootstrap" / key / ("scode0.exe" if key.startswith("windows-") else "scode0")


def _sha256(p: Path):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def _format_ok(p: Path):
    try:
        b = p.read_bytes()[:8]
    except OSError:
        return False, "unreadable"
    s = platform.system().lower()
    if s == "windows":
        return (b[:2] == b"MZ", "expected PE/MZ")
    if s == "linux":
        return (b[:4] == b"\x7fELF", "expected ELF")
    if s == "darwin":
        # thin 32/64 and fat/universal Mach-O magics, both byte orders
        magics = {
            b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
            b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
            b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",
            b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca",
        }
        return (b[:4] in magics, "expected Mach-O")
    return False, "unsupported host"


def verify(p: Path, verbose=True):
    if not p.is_file():
        return False, f"missing: {p}"
    ok, why = _format_ok(p)
    if not ok:
        return False, f"wrong executable format ({why}): {p}"
    if os.name != "nt":
        try: p.chmod(p.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        except OSError: pass
    try:
        r = subprocess.run([str(p), "version"], cwd=SCODE, capture_output=True, text=True, timeout=15, check=False)
    except Exception as e:
        return False, f"cannot execute native stage-0: {e}"
    if r.returncode != 0:
        return False, f"stage-0 version probe exited {r.returncode}: {(r.stderr or r.stdout).strip()}"
    env = os.environ.copy()
    env.update({"GB_OPT_ID":"5","GB_OPT_DIRTY":"255","GB_OPT_FRAME":"0","GB_OPT_LANES":"4","GB_OPT_POOL":"64","GB_OPT_SHAPE":"1"})
    script = SCODE / "apps" / "groovebox" / "groovebox_optimizer.sC"
    try:
        q = subprocess.run([str(p), "run", str(script)], cwd=SCODE, env=env,
                           capture_output=True, text=True, timeout=30, check=False)
    except Exception as e:
        return False, f"optimizer probe could not run: {e}"
    text = (q.stdout or "") + "\n" + (q.stderr or "")
    if q.returncode != 0:
        return False, f"optimizer probe exited {q.returncode}: {text.strip()[:400]}"
    if "scode_optimizer_abi=9" not in text:
        return False, "native stage-0 did not produce Groovebox optimizer ABI 9"
    if verbose:
        print(f"[sCode] native stage-0 verified: {p}")
    return True, "ok"


def install_from(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".installing")
    shutil.copy2(src, tmp)
    if os.name != "nt": tmp.chmod(0o755)
    ok, why = verify(tmp, verbose=False)
    if not ok:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(why)
    os.replace(tmp, dst)
    if os.name != "nt": dst.chmod(0o755)


def main():
    dst = target_path()
    ok, why = verify(dst)
    if ok: return 0
    print(f"[sCode] native stage-0 needs provisioning: {why}")

    candidates = []
    envsrc = os.environ.get("GROOVEBOX_SCODE_STAGE0_SOURCE", "").strip()
    if envsrc: candidates.append(Path(envsrc).expanduser())
    candidates.append(SCODE / "bootstrap_packages" / host_key() / dst.name)

    for src in candidates:
        if src.is_file():
            try:
                print(f"[sCode] installing native stage-0 from {src}")
                install_from(src, dst)
                ok, why = verify(dst)
                if ok: return 0
            except Exception as e:
                print(f"[sCode] candidate rejected: {e}", file=sys.stderr)

    url = os.environ.get("GROOVEBOX_SCODE_STAGE0_URL", "").strip()
    expected = os.environ.get("GROOVEBOX_SCODE_STAGE0_SHA256", "").strip().lower()
    if url:
        dl = ROOT / (".scode0-download.exe" if os.name == "nt" else ".scode0-download")
        try:
            print(f"[sCode] downloading native stage-0 for {host_key()}")
            urllib.request.urlretrieve(url, dl)
            if expected and _sha256(dl).lower() != expected:
                raise RuntimeError("download SHA-256 does not match GROOVEBOX_SCODE_STAGE0_SHA256")
            install_from(dl, dst)
            ok, why = verify(dst)
            if ok: return 0
        except Exception as e:
            print(f"[sCode] download/install failed: {e}", file=sys.stderr)
        finally:
            dl.unlink(missing_ok=True)

    print("[sCode] ERROR: a genuine native sCode stage-0 is required for this host.", file=sys.stderr)
    print(f"[sCode] Expected installed path: {dst}", file=sys.stderr)
    print("[sCode] Supply the matching PE/Mach-O runtime in sCode/bootstrap_packages/", file=sys.stderr)
    print("[sCode] or set GROOVEBOX_SCODE_STAGE0_SOURCE / GROOVEBOX_SCODE_STAGE0_URL.", file=sys.stderr)
    print("[sCode] Linux scode0 is intentionally NOT used on Windows/macOS.", file=sys.stderr)
    return 11

if __name__ == "__main__":
    raise SystemExit(main())
