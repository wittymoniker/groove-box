#!/usr/bin/env python3
"""Compatibility entry point: export/browser deps are part of the full runtime."""
from __future__ import annotations
import os, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CHECK = ROOT / "scripts" / "ensure_runtime_dependencies.py"
raise SystemExit(subprocess.call([sys.executable, str(CHECK), *sys.argv[1:]], cwd=str(ROOT), env=os.environ.copy()))
