#!/usr/bin/env python3
from __future__ import annotations
import os, platform, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from platform_runtime import find_scode_stage0, stage0_binary_matches_host

def run(cmd):
    return subprocess.run(cmd,cwd=str(ROOT),capture_output=True,text=True,timeout=1800,check=False)

def _verify_optimizer(p:Path):
    if not p or not stage0_binary_matches_host(p):
        return False, '[sCode] wrong or missing executable format'
    env=os.environ.copy(); env.update(GB_OPT_ID='123456789',GB_OPT_DIRTY='255',GB_OPT_FRAME='17',GB_OPT_LANES='8',GB_OPT_POOL='64',GB_OPT_SHAPE='33',GB_OPT_EDITING='0',GB_OPT_LOW_POWER='0',GB_OPT_BUDGET='999',GB_OPT_DEP_READY='1')
    try:
        r=subprocess.run([str(p),'run','apps/groovebox/groovebox_optimizer.sC'],cwd=str(ROOT/'sCode'),env=env,capture_output=True,text=True,timeout=15,check=False)
    except Exception as exc:
        return False, str(exc)
    text=(r.stdout or '')+'\n'+(r.stderr or '')
    return (r.returncode==0 and 'scode_optimizer_abi=9' in text), text

def _verify_pool_catalog(p:Path):
    try:
        r=subprocess.run([str(p),'run','apps/groovebox/pool_catalog.sC'],cwd=str(ROOT/'sCode'),capture_output=True,text=True,timeout=15,check=False)
    except Exception as exc:
        return False, str(exc)
    text=(r.stdout or '')+'\n'+(r.stderr or '')
    good=(r.returncode==0 and 'pool_catalog_abi=1' in text and 'pool_abi=3' in text and 'pool_format_count=18' in text and text.count('format=')>=18)
    return good,text

def _build_for_host():
    system=platform.system().lower()
    if system=='windows':
        cmd=['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'scripts'/'build_scode_stage0_windows.ps1')]
    elif system=='darwin':
        cmd=['/bin/bash',str(ROOT/'scripts'/'build_scode_stage0_macos.sh')]
    else:
        cmd=['/bin/sh',str(ROOT/'sCode'/'scripts'/'build-stage0-linux.sh')]
    return run(cmd)

def ensure():
    p=find_scode_stage0(ROOT)
    opt_ok,opt_text=_verify_optimizer(p) if p else (False,'missing')
    cat_ok,cat_text=_verify_pool_catalog(p) if opt_ok else (False,'optimizer unavailable')
    if opt_ok and cat_ok:
        print(f'[sCode] native stage-0 + pool catalog verified: {p}')
        return 0
    # A stale ABI-9 binary is repairable from the bundled C source when a host
    # compiler exists. Try that before falling back to bridge compatibility.
    r=_build_for_host()
    if r.returncode==0:
        p=find_scode_stage0(ROOT)
        opt_ok,opt_text=_verify_optimizer(p) if p else (False,'missing after rebuild')
        cat_ok,cat_text=_verify_pool_catalog(p) if opt_ok else (False,'optimizer unavailable after rebuild')
        if opt_ok and cat_ok:
            print(f'[sCode] rebuilt native stage-0 + pool catalog: {p}')
            return 0
    # If ABI-9 optimization itself is healthy, scode_optimizer_bridge.py has an
    # exact frozen ABI-3 catalog mirror. This keeps Windows/macOS installations
    # usable even when no C compiler is installed, without relaxing optimizer ABI.
    p=find_scode_stage0(ROOT)
    opt_ok,opt_text=_verify_optimizer(p) if p else (False,'missing')
    if opt_ok:
        print('[sCode] WARNING: native stage-0 predates pool_catalog dispatch; deterministic compatibility catalog will be used.',file=sys.stderr)
        return 0
    print('[sCode] native stage-0 optimizer ABI-9 verification failed:\n'+opt_text,file=sys.stderr)
    if r.returncode:
        print((r.stdout or '')+(r.stderr or ''),file=sys.stderr)
    return 5

def verify(p:Path):
    opt_ok,opt_text=_verify_optimizer(p)
    if not opt_ok:
        print('[sCode] Groovebox optimizer ABI-9 execution failed:\n'+opt_text,file=sys.stderr); return 5
    cat_ok,cat_text=_verify_pool_catalog(p)
    if not cat_ok:
        print('[sCode] pool catalog dispatch unavailable; bridge compatibility remains valid:\n'+cat_text,file=sys.stderr)
    else:
        print('[sCode] pool catalog ABI-1 / 18 formats verified')
    print(f'[sCode] native stage-0 verified: {p}')
    return 0
if __name__=='__main__': raise SystemExit(ensure())
