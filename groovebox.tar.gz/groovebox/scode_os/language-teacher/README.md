# sCodeOS Language Teacher

sCodeOS is prepared to learn the author's invented language as versioned data.

Edit `../../scode_language/language_pack.json` directly or use:

```bash
python teach_scode.py validate
python teach_scode.py numeral 10 'YOUR_GLYPH' --key a
python teach_scode.py word keywords seed YOUR_WORD
python teach_scode.py word domain_words meum YOUR_MEUM_WORD
```

The pack controls:
- all 16 canonical numeral glyphs and keyboard transliteration;
- language keywords;
- operators;
- Meum/OT/GOAVA/canonical vocabulary;
- aliases and linguistic notes.

A future GUI can write the exact same format. The OS/compiler never needs a reinstall merely because the language changes.
