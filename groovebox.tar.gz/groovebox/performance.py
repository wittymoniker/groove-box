#!/usr/bin/env python3
"""
performance.py — Groovebox Performance workspace and device manager.

Provides an in-app:
  • Project + render file browser (browse / rename / delete / open)
  • Media playlister (queue WAV/MP3/FLAC/OGG/OPUS/MP4/WEBM/AVI)
  • Built-in game player (live composition game + packaged .zip games)
  • Parametric live remixer (drives host LiveDJ GOAVA / RAND PARAM amounts)
  • Batch re-render from linked project provenance (scale FPS / audio bitrate)

Designed for low-power ARM (Pi 4/5): short previews, subprocess players,
and quality controls that default conservative.
"""
from __future__ import annotations

import ast
import json
import math
from meum_constants import MEUM, MEUM_MINUS_1, MEUM_INV, PHI, PHI_INV
import os
import random
import re
import socket
import time
import secrets
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import shutil
import subprocess
import sys
import tempfile
import threading
import zipfile
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from groovebox_media_tools import resolve_local_tool

from PyQt6.QtCore import Qt, QTimer, QObject, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPixmap, QPainter, QPen
from PyQt6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QSlider,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

AUDIO_EXT = {".wav", ".flac", ".mp3", ".ogg", ".opus", ".aiff", ".aif", ".caf"}
VIDEO_EXT = {".mp4", ".webm", ".avi", ".mov", ".mkv"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff"}
PROJECT_EXT = {".mcc", ".mgpr", ".meum", ".mg", ".mgproject", ".mgsynth", ".mgprofile"}
GAME_EXT = {".zip"}
MEDIA_EXT = AUDIO_EXT | VIDEO_EXT | IMAGE_EXT

# Fine-grained stream classification, distinct from the AUDIO_EXT/VIDEO_EXT
# extension buckets above: a .mp4/.mkv/etc. container can hold audio-only,
# video-only (silent), or both — the extension alone can't tell you which.
KIND_AUDIO = "audio"        # audio file, or audio-only container: no video track
KIND_VIDEO = "video"        # video container with NO audio track ("audioless video")
KIND_AV = "av"              # video container WITH an audio track ("both")
KIND_IMAGE = "image"          # still/animated image shown for playlist duration
KIND_UNKNOWN = "unknown"    # couldn't probe (no ffprobe, or read error)
KIND_PENDING = "pending"    # probe queued/in flight; always shown regardless of filter


class _PerformanceMathBackground(QWidget):
    """Very light deterministic ParametricMathBackground for Performance.

    Paint cost is intentionally tiny: a sparse Meum/phi lattice with two curves.
    It never consumes host/game state and therefore cannot feed back into identity.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self._phase = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(180)  # ~5.5 fps: visual ambience, not a render surface
        self._timer.timeout.connect(self._advance)
        # LAG_AUDIT_20260909: no decorative timer ticks while Performance is hidden.
    def showEvent(self, event):
        try:
            if not self._timer.isActive(): self._timer.start()
        except Exception: pass
        return super().showEvent(event)
    def hideEvent(self, event):
        try: self._timer.stop()
        except Exception: pass
        return super().hideEvent(event)
    def _advance(self):
        if self.isVisible():
            self._phase = (self._phase + 0.04759) % math.tau
            self.update()
    def paintEvent(self, event):
        w,h=self.width(),self.height()
        if w < 2 or h < 2: return
        q=QPainter(self); q.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        q.setPen(QPen(QColor(68, 145, 174, 42), 1))
        step=max(48, min(w,h)//9)
        ox=int((self._phase/math.tau)*step)
        for x in range(-step+ox, w, step): q.drawLine(x,0,x,h)
        for y in range(-step+ox, h, step): q.drawLine(0,y,w,y)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        q.setPen(QPen(QColor(245, 211, 109, 58), 1))
        pts=[]
        for i in range(0, max(2,w), max(6,w//180 or 6)):
            t=i/max(1,w-1)
            y=h*(0.50 + 0.16*math.sin(math.tau*(MEUM*t)+self._phase)
                 +0.08*math.sin(math.tau*PHI*t-self._phase*PHI_INV))
            pts.append((i,int(y)))
        for a,b in zip(pts,pts[1:]): q.drawLine(a[0],a[1],b[0],b[1])
        q.end()


def _probe_media_kind_sync(path: str) -> str:
    """Classify a file's actual stream content (not just its extension).

    Plain audio extensions are audio by definition — no need to shell out.
    Anything with a video extension gets an ffprobe stream-type check, since
    a video container may or may not actually carry an audio track.
    """
    ext = os.path.splitext(path)[1].lower()
    if ext in AUDIO_EXT:
        return KIND_AUDIO
    if ext in IMAGE_EXT:
        return KIND_IMAGE
    if ext not in VIDEO_EXT:
        return KIND_UNKNOWN
    ffprobe = resolve_local_tool("ffprobe", required=False)
    if not ffprobe:
        return KIND_UNKNOWN
    try:
        proc = subprocess.run(
            [ffprobe, "-v", "quiet", "-show_entries", "stream=codec_type",
             "-of", "csv=p=0", path],
            capture_output=True, text=True, timeout=8,
        )
        types = {line.strip() for line in (proc.stdout or "").splitlines() if line.strip()}
        has_v = "video" in types
        has_a = "audio" in types
        if has_v and has_a:
            return KIND_AV
        if has_v:
            return KIND_VIDEO
        if has_a:
            return KIND_AUDIO
        return KIND_UNKNOWN
    except Exception:
        return KIND_UNKNOWN


def _analyze_signal_descriptor(path: str, cache: Dict[str, Tuple[float, int, Optional[dict]]]) -> Optional[dict]:
    """Real DSP analysis (fundamental/centroid/rms/zcr/etc.) via
    reverse_engineer.describe(), used for reverse-engineer-style matching
    between playlist tracks rather than name/size heuristics alone.
    Non-WAV media is down-mixed to a short mono WAV with ffmpeg first.
    Cached by (path, mtime, size) like the kind-probe cache."""
    try:
        st = os.stat(path)
        key = (st.st_mtime, st.st_size)
    except Exception:
        return None
    cached = cache.get(path)
    if cached is not None and cached[0] == key[0] and cached[1] == key[1]:
        return cached[2]
    result: Optional[dict] = None
    try:
        import reverse_engineer as _re
        ext = os.path.splitext(path)[1].lower()
        tmp_wav = None
        wav_path = path
        if ext != ".wav":
            from groovebox_media_tools import resolve_local_tool
            ffmpeg = resolve_local_tool("ffmpeg")
            if not ffmpeg:
                cache[path] = (key[0], key[1], None)
                return None
            tmp_wav = os.path.join(tempfile.gettempdir(), f"groovebox_analyze_{abs(hash(path))}.wav")
            subprocess.run(
                [ffmpeg, "-y", "-i", path, "-t", "30", "-ac", "1", "-ar", "22050", tmp_wav],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, check=True,
            )
            wav_path = tmp_wav
        x, sr = _re.load_wav_mono(wav_path)
        desc = _re.describe(x, sr)
        result = {
            "fundamental_hz": desc.fundamental_hz,
            "centroid_hz": desc.centroid_hz,
            "rms": desc.rms,
            "zcr": desc.zcr,
            "duration_s": desc.duration_s,
            "transient_density": desc.transient_density,
        }
        if tmp_wav:
            try:
                os.remove(tmp_wav)
            except OSError:
                pass
    except Exception:
        result = None
    cache[path] = (key[0], key[1], result)
    return result


def _pitch_class_distance(a_hz: float, b_hz: float) -> float:
    """Circular pitch-class distance in semitones (0..6), octave independent."""
    try:
        if float(a_hz) <= 0.0 or float(b_hz) <= 0.0:
            return 6.0
        a = (69.0 + 12.0 * math.log2(float(a_hz) / 440.0)) % 12.0
        b = (69.0 + 12.0 * math.log2(float(b_hz) / 440.0)) % 12.0
        d = abs(a - b)
        return min(d, 12.0 - d)
    except Exception:
        return 6.0


def _descriptor_distance(a: dict, b: dict) -> float:
    """Deterministic key/texture distance between analyzed tracks.

    Pitch uses circular pitch-class distance rather than raw-Hz subtraction so
    octave-equivalent material is treated as harmonically close. Remaining
    terms preserve brightness, loudness and rhythmic-density matching.
    """
    def norm(v, scale):
        return float(v) / scale if scale else 0.0
    d_key = _pitch_class_distance(a.get("fundamental_hz", 0.0), b.get("fundamental_hz", 0.0)) / 6.0
    # A small octave/register term keeps an exact-key bass line distinguishable
    # from an extreme-register equivalent without overpowering key identity.
    try:
        ar=max(float(a.get("fundamental_hz",0.0)),1e-9); br=max(float(b.get("fundamental_hz",0.0)),1e-9)
        d_register=min(4.0, abs(math.log2(ar/br))) / 4.0
    except Exception:
        d_register=1.0
    d_centroid = abs(norm(a.get("centroid_hz",0.0), 4000.0) - norm(b.get("centroid_hz",0.0), 4000.0))
    d_rms = abs(float(a.get("rms",0.0)) - float(b.get("rms",0.0)))
    d_zcr = abs(float(a.get("zcr",0.0)) - float(b.get("zcr",0.0)))
    d_trans = abs(float(a.get("transient_density",0.0)) - float(b.get("transient_density",0.0)))
    return d_key * 1.8 + d_register * 0.25 + d_centroid * 1.2 + d_rms + d_zcr * 0.6 + d_trans * 0.8


def _canonical_media_signature(path: str) -> dict:
    """Read deterministic Groovebox provenance for Canonical Match mode."""
    prov = _extract_json_comment(path) or {}
    if not isinstance(prov, dict):
        prov = {}
    nested = prov.get("canonical") if isinstance(prov.get("canonical"), dict) else {}
    def first(*keys):
        for key in keys:
            if key in prov and prov.get(key) not in (None, ""):
                return prov.get(key)
            if key in nested and nested.get(key) not in (None, ""):
                return nested.get(key)
        return None
    return {
        "fingerprint": str(first("fingerprint", "canonical_fingerprint", "composition_fingerprint") or ""),
        "canonical_id": str(first("canonical_id", "composition_id", "identity") or ""),
        "seed": first("seed", "canonical_seed"),
        "bpm": first("bpm", "tempo"),
        "eqr": first("eqr", "EQR"),
        "goava": first("goava", "GOAVA"),
    }


def _canonical_media_distance(a_path: str, b_path: str) -> Optional[float]:
    a=_canonical_media_signature(a_path); b=_canonical_media_signature(b_path)
    evidence=0; score=0.0
    if a["fingerprint"] and b["fingerprint"]:
        evidence += 1; score += 0.0 if a["fingerprint"] == b["fingerprint"] else 4.0
    if a["canonical_id"] and b["canonical_id"]:
        evidence += 1; score += 0.0 if a["canonical_id"] == b["canonical_id"] else 2.5
    for key,scale,weight in (("bpm",120.0,1.0),("eqr",1.0,0.8),("goava",1.0,0.6)):
        try:
            if a[key] is not None and b[key] is not None:
                evidence += 1; score += min(2.0, abs(float(a[key])-float(b[key]))/scale) * weight
        except Exception:
            pass
    try:
        if a["seed"] is not None and b["seed"] is not None:
            evidence += 1
            sa=int(float(a["seed"])) & 0x7fffffff; sb=int(float(b["seed"])) & 0x7fffffff
            score += (abs(sa-sb)/2147483647.0) * 0.5
    except Exception:
        pass
    return score if evidence else None


def _kind_icon(kind: str) -> str:
    return {
        KIND_AUDIO: "🔊", KIND_VIDEO: "🎬(mute)", KIND_AV: "🎬🔊", KIND_IMAGE: "🖼", KIND_PENDING: "⏳",
    }.get(kind, "📄")



class _NearbyBridge(QObject):
    result = pyqtSignal(str, object, str)
    progress = pyqtSignal(int, int, str)

class _KindProbeWorker(QObject):
    """Batch stream-probing off the UI thread (see _ProvenanceWorker above
    for why: ffprobe calls must never run on the UI thread). Probes an
    entire folder listing's video files sequentially in one background
    thread and emits one signal per completed file, plus a final batch_done
    so the browser can re-apply the active Audio/Video filter once every
    file in the folder has a real (non-pending) classification."""
    progress = pyqtSignal(int, str, str)  # generation, path, kind
    batch_done = pyqtSignal(int)          # generation

    def run_batch(self, generation: int, paths: List[str]):
        for p in paths:
            kind = _probe_media_kind_sync(p)
            self.progress.emit(generation, p, kind)
        self.batch_done.emit(generation)



def _safe_size_bytes(n: int) -> str:
    try: n=int(n)
    except Exception: return "?"
    for unit,div in (("GB",1<<30),("MB",1<<20),("KB",1<<10)):
        if n >= div: return f"{n/div:.1f} {unit}"
    return f"{n} B"


def _safe_size(path: str) -> str:
    try:
        n = os.path.getsize(path)
    except OSError:
        return "?"
    for unit, div in (("GB", 1 << 30), ("MB", 1 << 20), ("KB", 1 << 10)):
        if n >= div:
            return f"{n / div:.1f} {unit}"
    return f"{n} B"


def _find_player() -> Optional[List[str]]:
    for cand in ("mpv", "vlc", "ffplay"):
        p = shutil.which(cand)
        if p:
            if cand == "mpv":
                return [p, "--force-window=yes", "--keep-open=no"]
            if cand == "vlc":
                return [p, "--no-one-instance", "--no-video-title-show"]
            return [p, "-autoexit", "-nodisp"]
    return None


def _player_cmd_with_volume(volume_pct: int, want_video: bool = True) -> Optional[List[str]]:
    """Same player resolution as _find_player(), plus a per-track volume
    flag — needed so playlist "mix" mode can play several tracks at once
    with different levels instead of everything at 100%. want_video=False
    keeps ffplay's existing -nodisp behavior for audio-only mix members;
    True (video/av members) drops -nodisp so the video window still shows.
    """
    for cand in ("mpv", "vlc", "ffplay"):
        p = shutil.which(cand)
        if not p:
            continue
        vol = max(0, min(200, int(volume_pct)))
        if cand == "mpv":
            return [p, "--force-window=yes", "--keep-open=no", f"--volume={vol}"]
        if cand == "vlc":
            return [p, "--no-one-instance", "--no-video-title-show", f"--gain={vol / 100.0:.2f}"]
        # ffplay
        args = [p, "-autoexit", "-volume", str(min(100, vol))]
        if not want_video:
            args.append("-nodisp")
        return args
    return None


def _extract_wav_eqrf(path: str) -> Optional[bytes]:
    """Read optional 'eqrf' chunk from a Groovebox WAV without importing groovebox."""
    try:
        with open(path, "rb") as f:
            if f.read(4) != b"RIFF":
                return None
            f.read(4)
            if f.read(4) != b"WAVE":
                return None
            while True:
                hdr = f.read(8)
                if len(hdr) < 8:
                    break
                cid, sz = hdr[:4], int.from_bytes(hdr[4:8], "little")
                data = f.read(sz)
                if cid == b"eqrf":
                    return data
                if sz & 1:
                    f.read(1)
    except Exception:
        return None
    return None


def _extract_json_comment(path: str) -> Optional[dict]:
    """Best-effort provenance from WAV eqrf chunk or ffmpeg comment / sidecars."""
    try:
        raw = _extract_wav_eqrf(path)
        if raw:
            text = raw.decode("utf-8", errors="replace")
            if text.strip().startswith("{"):
                return json.loads(text)
    except Exception:
        pass
    # Sidecar .mgpr / .json next to media
    for suffix in (".mgpr", ".json", ".provenance.json"):
        side = path + suffix
        if os.path.isfile(side):
            try:
                with open(side, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        base, _ = os.path.splitext(path)
        side2 = base + suffix
        if os.path.isfile(side2):
            try:
                with open(side2, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    # ffprobe comment
    ffprobe = resolve_local_tool("ffprobe", required=False)
    if ffprobe and os.path.isfile(path):
        try:
            proc = subprocess.run(
                [ffprobe, "-v", "quiet", "-show_entries", "format_tags=comment",
                 "-of", "json", path],
                capture_output=True, text=True, timeout=12,
            )
            data = json.loads(proc.stdout or "{}")
            comment = (
                (data.get("format") or {}).get("tags") or {}
            ).get("comment") or ""
            if isinstance(comment, str) and comment.strip().startswith("{"):
                return json.loads(comment)
        except Exception:
            pass
    return None


class _ProvenanceWorker(QObject):
    """Runs the (potentially slow, ffprobe-shelling) provenance lookup off
    the UI thread.

    PERF_2026: `_extract_json_comment` can invoke `ffprobe` with up to a
    12-second timeout. It used to run directly inside
    `_on_selection_changed`, so clicking or arrow-keying through a folder of
    samples/videos froze the whole Performance for however long each ffprobe
    call took — the exact "lag while using the app" complaint on slower
    storage (SD cards, network shares). One QThread does the shelling out;
    results come back via a signal so Qt marshals them onto the UI thread
    safely, and a token lets the UI drop stale results if the user has
    already moved on to a different file.
    """
    done = pyqtSignal(int, str, object)  # token, path, provenance dict-or-None

    def lookup(self, token: int, path: str):
        prov = _extract_json_comment(path) if os.path.isfile(path) else None
        self.done.emit(token, path, prov)


class Performance(QDialog):
    """In-app file browser, playlister, game player, DJ remixer, batch re-render."""

    def _scroll_page(self, page: QWidget) -> QScrollArea:
        """Compatibility wrapper: every Performance tab remains reachable at any DPI/window size."""
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        area.setMinimumSize(320, 240)
        page.setMinimumSize(max(300, page.minimumWidth()), max(200, page.minimumHeight()))
        area.setWidget(page)
        return area

    def __init__(self, host, parent=None):
        super().__init__(parent or host)
        self.host = host
        self.setWindowTitle("Groovebox Performance — Media · Devices · Cutups · Game · Broadcast · Batch")
        self.setStyleSheet("""
            QDialog { background:rgba(7,16,25,232); color:#d9edf5; }
            QGroupBox { border:1px solid #284c62; border-radius:7px; margin-top:8px; padding-top:7px; font-weight:700; }
            QGroupBox::title { color:#f1ce68; subcontrol-origin:margin; left:9px; padding:0 4px; }
            QPushButton { background:#102838; color:#d9f7ff; border:1px solid #39708a; border-radius:11px; padding:8px 11px; font-weight:700; }
            QPushButton:hover { background:#17405a; border-color:#62bfd0; }
            QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit { background:#08141e; color:#e6f8ff; border:1px solid #335b70; border-radius:8px; padding:6px; }
            QTabWidget::pane { background:rgba(7,16,25,232); border:2px solid rgba(59,113,140,245); }
            QTabBar::tab { background:rgba(12,27,40,248); color:#b9d5df; padding:10px 12px; margin:2px; border:2px solid rgba(53,103,127,250); border-radius:9px; min-width:42px; }
            QTabBar::tab:hover { background:#122c3e; border-color:#4b879f; }
            QTabBar::tab:selected { background:#17354a; color:#f6d46d; border-color:#6ca6ba; }
        """)
        self.resize(920, 640)
        self.setMinimumSize(720, 480)
        # PERFORMANCE_MATH_BG_20260905: ambient, sparse, low-refresh background.
        self._math_background = _PerformanceMathBackground(self)
        self._math_background.lower()
        self._player_proc: Optional[subprocess.Popen] = None
        self._playlist: List[Dict[str, Any]] = []
        self._playlist_index = -1
        # TIMED_MEDIA_20260906: absolute timeline scheduling for any media type,
        # including still pictures routed to a selected external display.
        self._timed_playlist_timer = QTimer(self)
        self._timed_playlist_timer.setInterval(25)
        self._timed_playlist_timer.timeout.connect(self._timed_playlist_tick)
        self._timed_playlist_epoch = 0.0
        self._timed_playlist_pending: List[int] = []
        self._batch_cancel = False
        self._mix_procs: List[subprocess.Popen] = []
        # LIVE_MEDIA_2026: mpv JSON-IPC gives instant speed changes without
        # killing/restarting a file. One socket is reused for the active player.
        self._mpv_ipc_path: Optional[str] = None
        self._live_speed = 1.0
        # CONTINUOUS_PATTERN_2026: cheap deterministic control-rate scripting.
        self._pattern_phase = 0.0
        self._pattern_step = 0
        self._pattern_rng = random.Random(0)
        self._pattern_timer = QTimer(self)
        self._pattern_timer.setInterval(50)
        self._pattern_timer.timeout.connect(self._pattern_tick)
        # PERFORMANCE_BROADCAST_2026: one phaselocked clock fans the same event
        # state to replay, video/game state and optional Ethernet clients.
        self._performance_timer = QTimer(self)
        self._performance_timer.timeout.connect(self._performance_tick)
        self._performance_step = 0
        self._performance_media_path: Optional[str] = None
        self._performance_loop = False
        self._broadcast_state: Dict[str, Any] = {"active": False}
        self._remote_server = None
        self._remote_thread = None
        self._remote_token = secrets.token_urlsafe(12)
        self._remote_commands: List[Dict[str, Any]] = []
        self._remote_lock = threading.Lock()
        self._remote_timer = QTimer(self)
        self._remote_timer.setInterval(50)
        self._remote_timer.timeout.connect(self._drain_remote_commands)
        # Starts only with the Ethernet control server; idle Performance has no 20 Hz poll.

        # OUTPUT_ROUTER_2026: optional local display/audio routing plus LAN/Wi-Fi TV
        # sharing. Hardware discovery is refreshed on demand so hot-plugged HDMI,
        # VGA adapters, USB displays/audio and Bluetooth sinks can appear live.
        self._output_displays = []
        self._output_audio = []
        self._output_display = None
        self._output_audio_target = None
        self._media_share_server = None
        self._last_shared_game_url = None
        self._clone_share_server = None
        self._last_clone_bundle = None
        self._goava_radio_service = None
        self._radio_peer_timer = QTimer(self)
        self._radio_peer_timer.setInterval(1800)
        self._radio_peer_timer.timeout.connect(self._refresh_radio_peers)
        # NEARBY_GROOVEBOX_UI: networking is app-level; this UI only observes
        # and initiates transfers. Worker signals keep HTTP/hash/scan work off Qt.
        self._nearby_bridge = _NearbyBridge()
        self._nearby_bridge.result.connect(self._nearby_worker_result)
        self._nearby_bridge.progress.connect(self._nearby_worker_progress)
        self._nearby_peer_rows = []
        self._nearby_remote_rows = []
        self._nearby_ui_timer = QTimer(self)
        self._nearby_ui_timer.setInterval(1800)
        self._nearby_ui_timer.timeout.connect(self._refresh_nearby_ui)
        self._nearby_ui_timer.start()

        # Fine-grained (audio/video/av) stream-kind cache, keyed by path:
        # (mtime, size, kind) so a probe is only redone if the file changed.
        self._kind_cache: Dict[str, Tuple[float, int, str]] = {}
        # REAL_ANALYSIS_MATCH_2026: fundamental/centroid/rms/zcr descriptors
        # from reverse_engineer.describe(), used by the "Analyzed match"
        # arrangement mode and by the Player Window's Deck B suggestion —
        # actual signal measurement, not just filename/size heuristics.
        self._analysis_cache: Dict[str, Tuple[float, int, Optional[dict]]] = {}
        self._refresh_generation = 0
        self._kind_worker = _KindProbeWorker()
        self._kind_worker.progress.connect(self._on_kind_probe_progress)
        self._kind_worker.batch_done.connect(self._on_kind_probe_batch_done)

        # PERF_2026: provenance lookups (ffprobe) happen on a worker thread,
        # debounced so rapid arrow-key/click movement through a file list
        # doesn't queue up a subprocess call per keystroke. `_selection_token`
        # invalidates results for a selection the user has already left.
        self._selection_token = 0
        self._prov_worker = _ProvenanceWorker()
        self._prov_worker.done.connect(self._on_provenance_ready)
        self._selection_debounce = QTimer(self)
        self._selection_debounce.setSingleShot(True)
        self._selection_debounce.setInterval(150)
        self._selection_debounce.timeout.connect(self._start_provenance_lookup)

        projects = self._host_projects_dir()
        renders = self._host_exports_dir()
        games = self._host_games_dir()
        samples = self._host_samples_dir()
        self._roots = {
            "Projects": projects,
            "Renders": renders,
            "Games": games,
            "Samples": samples,
            "Both": None,
        }
        self._cwd = projects if os.path.isdir(projects) else renders

        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)
        brand_row = QHBoxLayout()
        self.lbl_perf_brand = QLabel()
        try:
            bp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "goava_radio_brand.png")
            pm = QPixmap(bp)
            if not pm.isNull():
                self.lbl_perf_brand.setPixmap(pm.scaled(310, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        except Exception:
            pass
        self.lbl_perf_brand.setStyleSheet("background:#030a10; border:1px solid #8b6b2c; border-radius:7px; padding:2px;")
        brand_row.addWidget(self.lbl_perf_brand)
        brand_title = QLabel("<b style='font-size:16pt;color:#f1ce68'>GOAVA RADIO · PERFORMANCE</b><br><span style='color:#77d8ef'>Live seeds · media · hardware · networked game state</span>")
        brand_row.addWidget(brand_title, 1)
        self.lbl_engine_qos = QLabel("⚡ Engine QoS: AUTO")
        self.lbl_engine_qos.setToolTip("Audio has priority; expensive Performance visuals are low-rate and may drop frames. Native C++ kernels are used when available.")
        self.lbl_engine_qos.setStyleSheet("background:rgba(5,18,24,245);color:#9dffb0;border:1px solid #4f8799;border-radius:8px;padding:6px;font-weight:800;")
        brand_row.addWidget(self.lbl_engine_qos)

        # MASTER_STUDIO_LAUNCHER_20260905: the player/performance surface is also
        # the natural front door into the complete authoring environment.  Reuse
        # the existing host studio when embedded; only spawn the canonical
        # run_groovebox.py entry point when this panel is actually standalone.
        self.btn_master_studio = QPushButton("🎛 Launch MatGroovebox Master Studio")
        self.btn_master_studio.setToolTip(
            "Open the complete Mathematician's Groovebox authoring/mastering studio. "
            "If this player is already hosted by the studio, the existing studio is "
            "raised instead of launching a duplicate process."
        )
        self.btn_master_studio.setStyleSheet(
            "QPushButton { background:#3a2510; color:#ffe8a6; border:2px solid #c99436; "
            "border-radius:9px; padding:8px 12px; font-weight:900; } "
            "QPushButton:hover { background:#553815; border-color:#f1ce68; }"
        )
        self.btn_master_studio.clicked.connect(self._launch_master_studio)
        brand_row.addWidget(self.btn_master_studio)
        root.addLayout(brand_row)

        # --- top bar: path + roots ---
        top = QHBoxLayout()
        self.cmb_root = QComboBox()
        self.cmb_root.addItems(["Projects", "Renders", "Games", "Samples", "Custom…"])
        self.cmb_root.currentIndexChanged.connect(self._on_root_changed)
        top.addWidget(QLabel("Root:"))
        top.addWidget(self.cmb_root)
        self.lbl_cwd = QLabel(self._cwd)
        self.lbl_cwd.setStyleSheet("color:#8ab4c8; font-size:9pt;")
        self.lbl_cwd.setWordWrap(True)
        top.addWidget(self.lbl_cwd, stretch=1)
        btn_up = QPushButton("⬆ Up")
        btn_up.clicked.connect(self._go_up)
        btn_refresh = QPushButton("↻")
        btn_refresh.clicked.connect(self.refresh)
        top.addWidget(btn_up)
        top.addWidget(btn_refresh)
        # BROWSE_FILES_MENU_2026: dedicated file-management window (rename,
        # delete, create/delete folder) separate from the always-visible
        # inline browser, with its own launcher into the Player Window.
        btn_browse_files = QPushButton("📁 Browse Files…")
        btn_browse_files.setToolTip(
            "Open a dedicated file-management window: rename, delete, "
            "create/delete folders, and launch the media Player Window "
            "directly on a selected file."
        )
        btn_browse_files.clicked.connect(self._open_file_manager)
        top.addWidget(btn_browse_files)
        root.addLayout(top)

        # --- filter/sort bar: audio vs video, audioless/videoless vs both ---
        filt = QHBoxLayout()
        filt.addWidget(QLabel("Kind:"))
        self.cmb_kind_filter = QComboBox()
        self.cmb_kind_filter.addItems([
            "All",
            "Audio only (videoless)",
            "Video only (audioless)",
            "Audio + Video (both)",
        ])
        self.cmb_kind_filter.currentIndexChanged.connect(lambda _i: self.refresh())
        filt.addWidget(self.cmb_kind_filter)
        filt.addWidget(QLabel("Sort:"))
        self.cmb_sort = QComboBox()
        self.cmb_sort.addItems(["Name", "Kind (Audio first)", "Kind (Video first)", "Size"])
        self.cmb_sort.currentIndexChanged.connect(lambda _i: self.refresh())
        filt.addWidget(self.cmb_sort)
        filt.addStretch(1)
        self.lbl_probe_status = QLabel("")
        self.lbl_probe_status.setStyleSheet("color:#8ab4c8; font-size:9pt;")
        filt.addWidget(self.lbl_probe_status)
        root.addLayout(filt)

        split = QSplitter(Qt.Orientation.Horizontal)

        # --- left: file list ---
        left = QWidget()
        left_l = QVBoxLayout(left)
        left_l.setContentsMargins(0, 0, 0, 0)
        self.file_list = QListWidget()
        self.file_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.file_list.itemDoubleClicked.connect(self._on_double_click)
        self.file_list.itemSelectionChanged.connect(self._on_selection_changed)
        left_l.addWidget(self.file_list, stretch=1)
        file_btns = QHBoxLayout()
        for text, slot in (
            ("Open", self._open_selected),
            ("Play", self._play_selected),
            ("→ Playlist", self._add_to_playlist),
            ("Delete", self._delete_selected),
            ("Reveal", self._reveal_selected),
        ):
            b = QPushButton(text)
            b.clicked.connect(slot)
            file_btns.addWidget(b)
        left_l.addLayout(file_btns)
        split.addWidget(left)

        # --- right: tabs ---
        right = QTabWidget()
        # PERFORMANCE_NAV_V38: vertical rail prevents tabs from running beyond margins.
        right.setTabPosition(QTabWidget.TabPosition.West)
        right.setUsesScrollButtons(True)
        right.tabBar().setExpanding(False)
        right.addTab(self._scroll_page(self._build_playlist_tab()), "♫ Playlist")
        right.addTab(self._scroll_page(self._build_game_tab()), "🎮 Game / Wi‑Fi")
        right.addTab(self._scroll_page(self._build_remix_tab()), "∿ Parametric Remix")
        right.addTab(self._scroll_page(self._build_cutup_tab()), "✂ Cutup Lab")
        try:
            from signal_lab import SignalLab
            right.addTab(self._scroll_page(SignalLab(self.host, self)), "✎ Draw / Signal Lab")
        except Exception as e:
            fallback = QWidget(); fl = QVBoxLayout(fallback); msg = QLabel(f"Signal Lab unavailable: {e}"); msg.setWordWrap(True); fl.addWidget(msg); fl.addStretch(1); right.addTab(self._scroll_page(fallback), "✎ Draw / Signal Lab")
        try:
            from video_clip_studio import VideoClipStudio
            self.video_clip_studio = VideoClipStudio(self.host, self)
            # VideoClipStudio already owns a full two-axis scroll viewport. Wrapping
            # it again creates nested viewport geometry that can make camera surfaces
            # appear over the drawing pane on some Qt/GStreamer combinations.
            right.addTab(self.video_clip_studio, "🎥 Record / Import / Draw Clip")
        except Exception as e:
            self.video_clip_studio = None
            fallback = QWidget(); fl = QVBoxLayout(fallback); msg = QLabel(f"Video Clip Studio unavailable: {e}"); msg.setWordWrap(True); fl.addWidget(msg); fl.addStretch(1); right.addTab(self._scroll_page(fallback), "🎥 Record / Import / Draw Clip")
        try:
            from web_browser_tab import WebBrowserTab
            right.addTab(WebBrowserTab(self), "🌐 Web Browser")
        except Exception as e:
            fallback = QWidget(); fl = QVBoxLayout(fallback); msg = QLabel(f"Web Browser unavailable: {e}"); msg.setWordWrap(True); fl.addWidget(msg); fl.addStretch(1); right.addTab(self._scroll_page(fallback), "🌐 Web Browser")
        right.addTab(self._scroll_page(self._build_performance_tab()), "◉ Live Broadcast")
        right.addTab(self._scroll_page(self._build_outputs_tab()), "▣ Device Manager")
        right.addTab(self._scroll_page(self._build_hardware_tab()), "⌨ Hardware")
        right.addTab(self._scroll_page(self._build_transfer_tab()), "⇄ Drive / Clone")
        right.addTab(self._scroll_page(self._build_storage_tab()), "🧹 Storage")
        right.addTab(self._scroll_page(self._build_mg_library_tab()), "⌬ .MG Related")
        right.addTab(self._scroll_page(self._build_box_tab()), "⚙ Box Mode")
        right.addTab(self._scroll_page(self._build_batch_tab()), "Batch Re-render")
        right.addTab(self._scroll_page(self._build_info_tab()), "Info")
        split.addWidget(right)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        root.addWidget(split, stretch=1)

        self.lbl_status = QLabel("Ready.")
        self.lbl_status.setStyleSheet("color:#9dffb0; font-size:9pt;")
        root.addWidget(self.lbl_status)

        close_row = QHBoxLayout()
        close_row.addStretch(1)
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        close_row.addWidget(btn_close)
        root.addLayout(close_row)

        self.refresh()
        self.restore_state((getattr(self.host, "media_workbench_state", {}) or {}).get("performance", {}))

    def resizeEvent(self, event):
        try:
            self._math_background.setGeometry(self.rect())
            self._math_background.lower()
        except Exception:
            pass
        return super().resizeEvent(event)

    # ------------------------------------------------------------------ host paths
    def _host_projects_dir(self) -> str:
        if hasattr(self.host, "_projects_dir"):
            try:
                return self.host._projects_dir()
            except Exception:
                pass
        import groovebox_paths
        return groovebox_paths.projects_dir()

    def _host_exports_dir(self) -> str:
        if hasattr(self.host, "_exports_dir"):
            try:
                return self.host._exports_dir()
            except Exception:
                pass
        import groovebox_paths
        return groovebox_paths.renders_dir(getattr(self.host, "_current_project_path", None))

    def _host_games_dir(self) -> str:
        if hasattr(self.host, "_games_dir"):
            try:
                return self.host._games_dir()
            except Exception:
                pass
        import groovebox_paths
        return groovebox_paths.games_dir(getattr(self.host, "_current_project_path", None))

    def _host_samples_dir(self) -> str:
        if hasattr(self.host, "_samples_dir"):
            try:
                return self.host._samples_dir()
            except Exception:
                pass
        import groovebox_paths
        return groovebox_paths.samples_dir(getattr(self.host, "_current_project_path", None))

    # ------------------------------------------------------------------ browser
    def _on_root_changed(self, idx: int):
        text = self.cmb_root.currentText()
        if text == "Projects":
            self._cwd = self._host_projects_dir()
        elif text == "Renders":
            self._cwd = self._host_exports_dir()
        elif text == "Games":
            self._cwd = self._host_games_dir()
        elif text == "Samples":
            self._cwd = self._host_samples_dir()
        else:
            path = QFileDialog.getExistingDirectory(self, "Choose folder", self._cwd or "")
            if path:
                self._cwd = path
            else:
                self.cmb_root.blockSignals(True)
                self.cmb_root.setCurrentIndex(0)
                self.cmb_root.blockSignals(False)
                return
        self.refresh()

    def _go_up(self):
        parent = os.path.dirname(self._cwd.rstrip(os.sep))
        if parent and parent != self._cwd:
            self._cwd = parent
            self.refresh()

    def _cached_kind(self, path: str) -> Optional[str]:
        """Return a cached fine-grained kind if the file hasn't changed since
        it was probed, else None (caller should treat as pending/needs-probe)."""
        try:
            st = os.stat(path)
        except OSError:
            return None
        cached = self._kind_cache.get(path)
        if cached and cached[0] == st.st_mtime and cached[1] == st.st_size:
            return cached[2]
        return None

    def refresh(self):
        self.file_list.clear()
        self.lbl_cwd.setText(self._cwd or "")
        if not self._cwd or not os.path.isdir(self._cwd):
            self.lbl_status.setText("Folder missing.")
            return
        try:
            entries = sorted(os.listdir(self._cwd), key=str.lower)
        except OSError as e:
            self.lbl_status.setText(f"List error: {e}")
            return
        # dirs first
        dirs = [e for e in entries if os.path.isdir(os.path.join(self._cwd, e)) and not e.startswith(".")]
        files = [e for e in entries if os.path.isfile(os.path.join(self._cwd, e))]

        kind_filter = self.cmb_kind_filter.currentText() if hasattr(self, "cmb_kind_filter") else "All"
        sort_mode = self.cmb_sort.currentText() if hasattr(self, "cmb_sort") else "Name"

        self._refresh_generation += 1
        generation = self._refresh_generation
        pending_probe: List[str] = []

        rows = []  # (name, full, ext, coarse_kind, fine_kind, size_bytes)
        for f in files:
            full = os.path.join(self._cwd, f)
            ext = os.path.splitext(f)[1].lower()
            coarse_kind = "file"
            if ext in PROJECT_EXT:
                coarse_kind = "project"
            elif ext in AUDIO_EXT:
                coarse_kind = "audio"
            elif ext in VIDEO_EXT:
                coarse_kind = "video"
            elif ext in GAME_EXT:
                coarse_kind = "game"

            fine_kind = KIND_UNKNOWN
            if ext in AUDIO_EXT:
                fine_kind = KIND_AUDIO
            elif ext in VIDEO_EXT:
                cached = self._cached_kind(full)
                if cached is not None:
                    fine_kind = cached
                else:
                    fine_kind = KIND_PENDING
                    pending_probe.append(full)
            try:
                size_bytes = os.path.getsize(full)
            except OSError:
                size_bytes = 0
            rows.append((f, full, ext, coarse_kind, fine_kind, size_bytes))

        # --- filter: audio-only vs audioless-video vs both, videoless-audio ---
        def _passes_filter(fine_kind: str, coarse_kind: str) -> bool:
            if kind_filter == "All":
                return True
            if coarse_kind not in ("audio", "video"):
                return True  # never hide dirs/projects/games behind a media filter
            if fine_kind == KIND_PENDING:
                return True  # show until probed, so files don't flicker away
            if kind_filter.startswith("Audio only"):
                return fine_kind == KIND_AUDIO
            if kind_filter.startswith("Video only"):
                return fine_kind == KIND_VIDEO
            if kind_filter.startswith("Audio + Video"):
                return fine_kind == KIND_AV
            return True

        rows = [r for r in rows if _passes_filter(r[4], r[3])]

        # --- sort ---
        if sort_mode == "Size":
            rows.sort(key=lambda r: r[5], reverse=True)
        elif sort_mode.startswith("Kind (Audio"):
            order = {KIND_AUDIO: 0, KIND_AV: 1, KIND_VIDEO: 2, KIND_PENDING: 3, KIND_UNKNOWN: 4}
            rows.sort(key=lambda r: (order.get(r[4], 5) if r[3] in ("audio", "video") else 5, r[0].lower()))
        elif sort_mode.startswith("Kind (Video"):
            order = {KIND_VIDEO: 0, KIND_AV: 1, KIND_AUDIO: 2, KIND_PENDING: 3, KIND_UNKNOWN: 4}
            rows.sort(key=lambda r: (order.get(r[4], 5) if r[3] in ("audio", "video") else 5, r[0].lower()))
        else:
            rows.sort(key=lambda r: r[0].lower())

        for d in dirs:
            item = QListWidgetItem(f"📁 {d}/")
            item.setData(Qt.ItemDataRole.UserRole, os.path.join(self._cwd, d))
            item.setData(Qt.ItemDataRole.UserRole + 1, "dir")
            self.file_list.addItem(item)
        for (f, full, ext, coarse_kind, fine_kind, size_bytes) in rows:
            if coarse_kind == "project":
                icon = "🎛"
            elif coarse_kind == "game":
                icon = "🕹"
            elif coarse_kind in ("audio", "video"):
                icon = _kind_icon(fine_kind)
            else:
                icon = "📄"
            item = QListWidgetItem(f"{icon} {f}  ({_safe_size(full)})")
            item.setData(Qt.ItemDataRole.UserRole, full)
            item.setData(Qt.ItemDataRole.UserRole + 1, coarse_kind)
            item.setData(Qt.ItemDataRole.UserRole + 2, fine_kind)
            self.file_list.addItem(item)
        self.lbl_status.setText(f"{len(dirs)} folders · {len(rows)} files")

        if pending_probe:
            self.lbl_probe_status.setText(f"Classifying {len(pending_probe)} video file(s)…")
            opt=getattr(self.host,'_scode_optimizer',None)
            if opt is not None and hasattr(opt,'submit_pooled'):
                paths=tuple(pending_probe)
                def probe_batch(): return [(p,_probe_media_kind_sync(p)) for p in paths]
                def probe_done(result,error):
                    if error is not None or generation != self._refresh_generation: return
                    for p,kind in (result or []): self._on_kind_probe_progress(generation,p,kind)
                    self._on_kind_probe_batch_done(generation)
                opt.submit_pooled('media_probe',(generation,paths),probe_batch,policy='frame',format_id='media_stream',frame=generation,callback=probe_done,qt_callback=True)
            else:
                threading.Thread(target=self._kind_worker.run_batch,args=(generation,pending_probe),daemon=True).start()
        else:
            self.lbl_probe_status.setText("")

    def _on_kind_probe_progress(self, generation: int, path: str, kind: str):
        if generation != self._refresh_generation:
            return  # user navigated away / re-sorted before this finished
        try:
            st = os.stat(path)
            self._kind_cache[path] = (st.st_mtime, st.st_size, kind)
        except OSError:
            self._kind_cache[path] = (0.0, 0, kind)
        # Update the visible row in place if it's still on screen — avoids a
        # full relist (and a fresh disk stat pass) for every single result.
        for i in range(self.file_list.count()):
            it = self.file_list.item(i)
            if it and it.data(Qt.ItemDataRole.UserRole) == path:
                coarse_kind = it.data(Qt.ItemDataRole.UserRole + 1)
                if coarse_kind in ("audio", "video"):
                    it.setData(Qt.ItemDataRole.UserRole + 2, kind)
                    name = os.path.basename(path)
                    it.setText(f"{_kind_icon(kind)} {name}  ({_safe_size(path)})")
                break

    def _on_kind_probe_batch_done(self, generation: int):
        if generation != self._refresh_generation:
            return
        self.lbl_probe_status.setText("")
        # If an Audio/Video-only filter is active, files that were shown as
        # "pending" may need to drop out (or newly-revealed ones appear) now
        # that every file in the folder has a real classification.
        kind_filter = self.cmb_kind_filter.currentText() if hasattr(self, "cmb_kind_filter") else "All"
        if kind_filter != "All":
            self.refresh()

    def _selected_paths(self) -> List[str]:
        out = []
        for item in self.file_list.selectedItems():
            p = item.data(Qt.ItemDataRole.UserRole)
            if p:
                out.append(str(p))
        return out

    def _on_double_click(self, item: QListWidgetItem):
        path = item.data(Qt.ItemDataRole.UserRole)
        kind = item.data(Qt.ItemDataRole.UserRole + 1)
        if kind == "dir" and path:
            self._cwd = path
            self.refresh()
            return
        if kind == "project":
            self._open_project(path)
        elif kind in ("audio", "video"):
            self._play_path(path)
        elif kind == "game":
            self._play_game_package(path)

    def _on_selection_changed(self):
        # Fast path only: show path + size immediately (both cheap, local
        # stat calls). The slow provenance/ffprobe part is debounced and
        # run off-thread in _start_provenance_lookup / _on_provenance_ready.
        self._selection_token += 1
        paths = self._selected_paths()
        if not paths:
            self.info_view.setPlainText("")
            self._selection_debounce.stop()
            return
        path = paths[0]
        self.info_view.setPlainText(f"{path}\nsize: {_safe_size(path)}\n(reading details…)")
        self._selection_debounce.start()

    def _start_provenance_lookup(self):
        paths = self._selected_paths()
        if not paths:
            return
        path = paths[0]
        token = self._selection_token
        opt=getattr(self.host,'_scode_optimizer',None)
        if opt is not None and hasattr(opt,'submit_pooled'):
            try:
                st=os.stat(path); identity=(path,st.st_mtime_ns,st.st_size)
            except OSError:
                identity=(path,0,0)
            def lookup(): return _extract_json_comment(path) if os.path.isfile(path) else None
            def done(result,error):
                if error is None: self._on_provenance_ready(token,path,result)
            opt.submit_pooled('media_provenance',identity,lookup,policy='pure',format_id='object',callback=done,qt_callback=True,max_entries=256)
        else:
            threading.Thread(target=self._prov_worker.lookup,args=(token,path),daemon=True).start()

    def _on_provenance_ready(self, token: int, path: str, prov: Optional[dict]):
        if token != self._selection_token:
            return  # user already moved on to a different selection
        lines = [path, f"size: {_safe_size(path)}"]
        if prov:
            lines.append("--- provenance ---")
            for k in ("seed", "bpm", "source_project_path", "sample_rate", "fps",
                      "audio_bitrate_kbps", "fingerprint", "doc"):
                if k in prov:
                    lines.append(f"{k}: {prov[k]}")
            sp = prov.get("source_project_path")
            if sp:
                lines.append(f"linked project exists: {os.path.isfile(str(sp))}")
        self.info_view.setPlainText("\n".join(lines))

    def _open_selected(self):
        for path in self._selected_paths():
            kind = "file"
            for i in range(self.file_list.count()):
                it = self.file_list.item(i)
                if it and it.data(Qt.ItemDataRole.UserRole) == path:
                    kind = it.data(Qt.ItemDataRole.UserRole + 1)
                    break
            if kind == "dir":
                self._cwd = path
                self.refresh()
            elif kind == "project":
                self._open_project(path)
            elif kind == "game":
                self._play_game_package(path)
            elif kind in ("audio", "video"):
                self._play_path(path)

    def _open_project(self, path: str):
        try:
            if hasattr(self.host, "load_project_dialog"):
                # Direct load if host supports path-based apply
                pass
            if hasattr(self.host, "_apply_project_snapshot") or hasattr(self.host, "load_project_dialog"):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                # Prefer apply_project_snapshot / restore path
                applied = False
                for name in ("_apply_project_snapshot", "apply_project_snapshot",
                             "_project_history_restore"):
                    fn = getattr(self.host, name, None)
                    if callable(fn):
                        try:
                            fn(data)
                            applied = True
                            break
                        except Exception:
                            continue
                if not applied:
                    # Fallback: set as current and ask user to use host Load
                    QMessageBox.information(
                        self, "Project",
                        f"Opened path recorded:\n{path}\n\n"
                        "Use host Load Project if auto-apply is unavailable."
                    )
                setattr(self.host, "_current_project_path", path)
                self.lbl_status.setText(f"Loaded project: {os.path.basename(path)}")
                self.cmb_game_status.setText(f"Project: {os.path.basename(path)}")
        except Exception as e:
            QMessageBox.warning(self, "Open project failed", str(e))

    def _play_selected(self):
        paths = [p for p in self._selected_paths() if os.path.isfile(p)]
        if not paths:
            return
        self._play_path(paths[0])

    # ------------------------------------------------------------------ Browse Files menu / Player Window
    def _open_file_manager(self):
        """Dedicated file-management window: rename, delete, create/delete
        folders. Independent window from the always-visible inline browser
        so file upkeep doesn't require leaving whatever tab is active."""
        dlg = FileManagerDialog(self, self._cwd)
        dlg.exec()
        self.refresh()

    def _open_player_window_for_playlist(self):
        """Launch the dedicated media Player Window, seeded with the current
        Performance playlist and destination device selection."""
        if not self._playlist:
            QMessageBox.information(self, "Player Window", "The playlist is empty. Add media first.")
            return
        start = self._playlist_index if self._playlist_index >= 0 else 0
        dlg = MediaPlayerWindow(self, list(self._playlist), start)
        dlg.exec()

    def _routed_player(self, cmd: list, want_video: bool = True):
        """Apply selected per-process display/audio routing without changing OS defaults."""
        env = os.environ.copy()
        try:
            from media_output_router import player_routing
            extra, overlay = player_routing(self._output_display, self._output_audio_target, want_video=want_video)
            if cmd and os.path.basename(cmd[0]).lower().startswith("mpv"):
                cmd = list(cmd) + list(extra)
            env.update(overlay)
        except Exception:
            pass
        return cmd, env

    def _play_path(self, path: str, volume_pct: int = 100, duration_s: float = 0.0):
        self._stop_player()
        ext = os.path.splitext(path)[1].lower()
        if ext in AUDIO_EXT and hasattr(self.host, "play_buffer"):
            # Prefer host buffer play for dry 1× WAV. At any other speed use
            # mpv so rate changes remain live/responsive through IPC.
            if ext == ".wav" and self._live_speed == 1.0:
                try:
                    self._play_wav_on_host(path)
                    self.lbl_status.setText(f"Playing on host: {os.path.basename(path)}")
                    return
                except Exception as e:
                    self.lbl_status.setText(f"Host play failed ({e}); external player…")
        want_video = ext in VIDEO_EXT or ext in IMAGE_EXT
        cmd = _player_cmd_with_volume(volume_pct, want_video=want_video) or _find_player()
        if not cmd:
            QMessageBox.warning(
                self, "No player",
                "Install mpv, vlc, or ffplay for media playback on this Pi."
            )
            return
        try:
            # Prefer mpv with IPC so live speed/pitch-independent time changes are
            # responsive while the file is already running. Other players retain
            # the existing fallback behavior.
            if cmd and os.path.basename(cmd[0]).startswith("mpv"):
                self._mpv_ipc_path = os.path.join(tempfile.gettempdir(), f"groovebox_mpv_{os.getpid()}_{id(self)}.sock")
                try:
                    os.unlink(self._mpv_ipc_path)
                except OSError:
                    pass
                cmd = list(cmd) + [f"--input-ipc-server={self._mpv_ipc_path}", f"--speed={self._live_speed:.6f}"]
            else:
                self._mpv_ipc_path = None
            if cmd and os.path.basename(cmd[0]).startswith("mpv"):
                if ext in IMAGE_EXT:
                    cmd = list(cmd) + [f"--image-display-duration={max(0.05, float(duration_s or 5.0)):.6f}", "--loop-file=no"]
                elif float(duration_s or 0.0) > 0.0:
                    cmd = list(cmd) + [f"--length={float(duration_s):.6f}"]
            cmd, penv = self._routed_player(cmd, want_video=want_video)
            self._player_proc = subprocess.Popen(cmd + [path], env=penv)
            try:
                if self._media_share_server is not None:
                    self._media_share_server.set_current(path)
            except Exception:
                pass
            self.lbl_status.setText(f"External play: {os.path.basename(path)} @{volume_pct}% · {self._live_speed:.2f}×")
        except Exception as e:
            QMessageBox.warning(self, "Play failed", str(e))

    def _check_player_launch(self, proc, path: str):
        try:
            rc = proc.poll()
            if rc is not None and proc is getattr(self, "_player_proc", None):
                self.lbl_status.setText(f"Player exited immediately (code {rc}): {os.path.basename(path)}")
        except Exception:
            pass

    def _play_wav_on_host(self, path: str):
        import numpy as np
        try:
            from audio_os_backend import wavfile
            sr, data = wavfile.read(path)
            if data.ndim > 1:
                data = data.mean(axis=1)
            if data.dtype == np.int16:
                buf = (data.astype(np.float32) / 32768.0)
            else:
                buf = np.asarray(data, dtype=np.float32)
                peak = float(np.max(np.abs(buf))) or 1.0
                buf = buf / peak
            with getattr(self.host, "play_lock", threading.Lock()):
                self.host.play_buffer = buf
                self.host.play_sample_rate = int(sr)
                self.host.play_cursor = 0
                self.host.is_playing = True
                self.host.is_paused = False
                self.host._audio_only_mode = True
            if hasattr(self.host, "audio_stream") and getattr(self.host, "HAS_SOUNDDEVICE", True):
                try:
                    from audio_os_backend import sd
                    if self.host.audio_stream is not None:
                        try:
                            self.host.audio_stream.stop()
                            self.host.audio_stream.close()
                        except Exception:
                            pass
                    self.host.audio_stream = sd.OutputStream(
                        samplerate=int(sr), channels=1, dtype="float32",
                        callback=self.host._audio_callback, blocksize=1024, latency="low",
                    )
                    self.host.audio_stream.start()
                except Exception:
                    pass
            if hasattr(self.host, "_scope_update_timer"):
                self.host._scope_update_timer.start()
        except Exception:
            raise

    def _stop_player(self):
        if self._player_proc is not None:
            try:
                self._player_proc.terminate()
            except Exception:
                pass
            self._player_proc = None
        if self._mpv_ipc_path:
            try:
                os.unlink(self._mpv_ipc_path)
            except OSError:
                pass
            self._mpv_ipc_path = None
        try:
            if getattr(self.host, "is_playing", False) and getattr(self.host, "_audio_only_mode", False):
                if hasattr(self.host, "stop_audio_playback"):
                    self.host.stop_audio_playback()
        except Exception:
            pass

    def _add_to_playlist(self):
        for path in self._selected_paths():
            if os.path.isfile(path) and not any(it["path"] == path for it in self._playlist):
                ext = os.path.splitext(path)[1].lower()
                if ext in MEDIA_EXT:
                    fine_kind = self._cached_kind(path)
                    if fine_kind is None:
                        fine_kind = _probe_media_kind_sync(path)
                        try:
                            st = os.stat(path)
                            self._kind_cache[path] = (st.st_mtime, st.st_size, fine_kind)
                        except OSError:
                            pass
                    self._playlist.append({"path": path, "volume": 100, "mix": False, "kind": fine_kind, "time_s": float(len(self._playlist) * 5.0), "duration_s": 5.0 if fine_kind == KIND_IMAGE else 0.0})
                elif ext in GAME_EXT:
                    self._playlist.append({"path": path, "volume": 100, "mix": False, "kind": KIND_UNKNOWN, "time_s": float(len(self._playlist) * 5.0), "duration_s": 0.0})
        self._refresh_playlist_widget(); self._sync_project_state()
        self.lbl_status.setText(f"Playlist: {len(self._playlist)} items")

    def _delete_selected(self):
        paths = self._selected_paths()
        if not paths:
            return
        reply = QMessageBox.question(
            self, "Delete",
            f"Delete {len(paths)} item(s)?\nThis cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        for path in paths:
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
                else:
                    os.remove(path)
            except Exception as e:
                QMessageBox.warning(self, "Delete failed", f"{path}\n{e}")
        self.refresh()

    def _reveal_selected(self):
        paths = self._selected_paths()
        if not paths:
            return
        path = paths[0]
        folder = path if os.path.isdir(path) else os.path.dirname(path)
        for cmd in (
            ["xdg-open", folder],
            ["pcmanfm", folder],
            ["thunar", folder],
            ["explorer.exe", folder],
        ):
            if shutil.which(cmd[0]):
                try:
                    subprocess.Popen(cmd)
                    return
                except Exception:
                    continue
        self.lbl_status.setText(folder)

    def _launch_master_studio(self):
        """Raise the existing MatGroovebox studio or launch its canonical entry point.

        Performance/player mode never constructs a second copy of the studio
        internally.  That keeps QApplication ownership, MCC file handling and
        native/audio initialization on the same supported startup path.
        """
        host = getattr(self, "host", None)
        try:
            # Performance is normally a separate top-level window owned logically
            # (not as a QWidget parent) by the already-running Master Studio.
            # On Wayland a compositor may ignore raise_/activateWindow() requests
            # from another top-level window.  Hiding Performance first makes the
            # existing studio reliably visible and avoids spawning a duplicate.
            if host is not None and host is not self:
                # Persist the live Performance controls before switching windows.
                try:
                    state = getattr(host, "media_workbench_state", None)
                    if not isinstance(state, dict):
                        state = {}
                        setattr(host, "media_workbench_state", state)
                    state["performance"] = self.export_state()
                except Exception:
                    pass

                # Restore from minimized state before requesting focus.
                normal = getattr(host, "showNormal", None)
                if callable(normal):
                    normal()
                show = getattr(host, "show", None)
                if callable(show):
                    show()

                # Hide this top-level window.  This is the reliable part on
                # Wayland; raise_/activateWindow() remain useful on X11/Windows.
                try:
                    self.hide()
                except Exception:
                    pass

                raise_ = getattr(host, "raise_", None)
                if callable(raise_):
                    raise_()
                activate = getattr(host, "activateWindow", None)
                if callable(activate):
                    activate()

                # Some WMs apply activation only after the current click event
                # unwinds. Queue one zero-delay retry without blocking the GUI.
                try:
                    QTimer.singleShot(0, lambda h=host: (h.raise_(), h.activateWindow()))
                except Exception:
                    pass
                self.lbl_status.setText("MatGroovebox Master Studio ready.")
                return host
        except Exception as exc:
            # Fall through to the canonical process launcher.
            try:
                self.lbl_status.setText(f"Studio focus unavailable ({exc}); launching studio…")
            except Exception:
                pass

        root = os.path.dirname(os.path.abspath(__file__))
        runner = os.path.join(root, "run_groovebox.py")
        if not os.path.isfile(runner):
            QMessageBox.warning(self, "Master Studio", f"Studio launcher not found:\n{runner}")
            return None
        try:
            cmd = [sys.executable, runner]
            kw = {"cwd": root}
            if os.name == "nt":
                try:
                    kw["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
                except Exception:
                    pass
            else:
                kw["start_new_session"] = True
            proc = subprocess.Popen(cmd, **kw)
            self._master_studio_process = proc
            self.lbl_status.setText(f"MatGroovebox Master Studio launched (PID {proc.pid}).")
            return proc
        except Exception as exc:
            QMessageBox.warning(self, "Master Studio", f"Could not launch MatGroovebox Master Studio:\n{exc}")
            return None

    # ------------------------------------------------------------------ playlist tab
    def _build_playlist_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        self.playlist_widget = QListWidget()
        self.playlist_widget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.playlist_widget.itemSelectionChanged.connect(self._on_playlist_selection_changed)
        lay.addWidget(self.playlist_widget, stretch=1)

        row = QHBoxLayout()
        btn_play = QPushButton("▶ Play")
        btn_next = QPushButton("⏭ Next")
        btn_stop = QPushButton("⏹ Stop")
        btn_clear = QPushButton("Clear")
        btn_play.clicked.connect(self._playlist_play)
        btn_next.clicked.connect(self._playlist_next)
        btn_stop.clicked.connect(self._stop_player)
        btn_clear.clicked.connect(self._playlist_clear)
        for b in (btn_play, btn_next, btn_stop, btn_clear):
            row.addWidget(b)
        lay.addLayout(row)

        # PLAYER_WINDOW_LAUNCH_2026: dedicated player window with its own
        # destination-device (display/audio sink) selector, seeded from this
        # playlist and the currently selected row.
        player_row = QHBoxLayout()
        btn_player_window = QPushButton("🖥 Open Player Window…")
        btn_player_window.setToolTip(
            "Open the playlist in a dedicated Player Window with its own "
            "destination display/audio-sink selection, independent of the "
            "always-on inline preview."
        )
        btn_player_window.clicked.connect(self._open_player_window_for_playlist)
        player_row.addWidget(btn_player_window)
        player_row.addStretch(1)
        lay.addLayout(player_row)

        arrange_row = QHBoxLayout()
        self.cmb_playlist_arrange = QComboBox()
        self.cmb_playlist_arrange.addItems([
            "Energy arc (size)", "Interleave A/V", "Deterministic shuffle", "Geometric phaselock seeded", "Name order",
            "Analyzed match (reverse-engineer)",
        ])
        self.spin_playlist_arrange_seed = QSpinBox()
        self.spin_playlist_arrange_seed.setRange(0, 2147483647)
        self.spin_playlist_arrange_seed.setValue(1975807343)
        btn_arrange = QPushButton("Arrange playlist")
        btn_arrange.clicked.connect(self._arrange_media_playlist)
        arrange_row.addWidget(QLabel("Arrange:"))
        arrange_row.addWidget(self.cmb_playlist_arrange, stretch=1)
        arrange_row.addWidget(QLabel("Seed"))
        arrange_row.addWidget(self.spin_playlist_arrange_seed)
        arrange_row.addWidget(btn_arrange)
        lay.addLayout(arrange_row)

        # --- per-item volume + mix flag, and simultaneous "mix" playback ---
        vol_row = QHBoxLayout()
        vol_row.addWidget(QLabel("Volume (selected):"))
        self.sld_playlist_volume = QSlider(Qt.Orientation.Horizontal)
        self.sld_playlist_volume.setRange(0, 150)
        self.sld_playlist_volume.setValue(100)
        self.sld_playlist_volume.setEnabled(False)
        self.sld_playlist_volume.valueChanged.connect(self._on_playlist_volume_changed)
        vol_row.addWidget(self.sld_playlist_volume, stretch=1)
        self.lbl_playlist_volume = QLabel("100%")
        self.lbl_playlist_volume.setMinimumWidth(40)
        vol_row.addWidget(self.lbl_playlist_volume)
        lay.addLayout(vol_row)

        mix_row = QHBoxLayout()
        btn_toggle_mix = QPushButton("Toggle Mix on selected")
        btn_toggle_mix.setToolTip(
            "Flag/unflag the selected rows for simultaneous playback via "
            "'Play Mix' — lets you layer audio + video + game audio at once "
            "instead of playing the queue one at a time."
        )
        btn_toggle_mix.clicked.connect(self._toggle_mix_selected)
        btn_play_mix = QPushButton("▶▶ Play Mix (simultaneous)")
        btn_play_mix.clicked.connect(self._playlist_play_mix)
        btn_stop_mix = QPushButton("⏹ Stop Mix")
        btn_stop_mix.clicked.connect(self._stop_mix)
        mix_row.addWidget(btn_toggle_mix)
        mix_row.addWidget(btn_play_mix)
        mix_row.addWidget(btn_stop_mix)
        lay.addLayout(mix_row)

        speed_row = QHBoxLayout()
        speed_row.addWidget(QLabel("Live file speed:"))
        self.sld_live_speed = QSlider(Qt.Orientation.Horizontal)
        self.sld_live_speed.setRange(25, 400)
        self.sld_live_speed.setValue(100)
        self.sld_live_speed.setToolTip("0.25×–4× live playback rate. With mpv this updates in-place through JSON IPC, without restarting the file.")
        self.sld_live_speed.valueChanged.connect(self._on_live_speed_changed)
        speed_row.addWidget(self.sld_live_speed, stretch=1)
        self.lbl_live_speed = QLabel("1.00×")
        self.lbl_live_speed.setMinimumWidth(52)
        speed_row.addWidget(self.lbl_live_speed)
        btn_speed_reset = QPushButton("1×")
        btn_speed_reset.clicked.connect(lambda: self.sld_live_speed.setValue(100))
        speed_row.addWidget(btn_speed_reset)
        lay.addLayout(speed_row)

        timing = QGroupBox("Timed external-display playlist")
        tf = QFormLayout(timing)
        self.spin_item_time = QDoubleSpinBox(); self.spin_item_time.setRange(0.0, 86400.0); self.spin_item_time.setDecimals(3); self.spin_item_time.setSuffix(" s")
        self.spin_item_duration = QDoubleSpinBox(); self.spin_item_duration.setRange(0.0, 86400.0); self.spin_item_duration.setDecimals(3); self.spin_item_duration.setValue(5.0); self.spin_item_duration.setSuffix(" s")
        self.spin_item_time.valueChanged.connect(self._on_playlist_timing_changed); self.spin_item_duration.valueChanged.connect(self._on_playlist_timing_changed)
        tf.addRow("Selected start time", self.spin_item_time); tf.addRow("Selected duration (0=natural)", self.spin_item_duration)
        tr = QHBoxLayout(); btn_timed = QPushButton("▶ Send Timed Playlist → Display"); btn_timed.clicked.connect(self._start_timed_playlist)
        btn_timed_stop = QPushButton("■ Stop Timed Playlist"); btn_timed_stop.clicked.connect(self._stop_timed_playlist)
        tr.addWidget(btn_timed); tr.addWidget(btn_timed_stop); tf.addRow(tr)
        lay.addWidget(timing)

        hint = QLabel(
            "Queue projects' renders here for sequential playback, or flag rows "
            "'[MIX]' and use Play Mix to layer several tracks (each at its own "
            "volume) at the same time — one OS-mixed output, e.g. a DJ backing "
            "track + a video's audio + a game's soundtrack together."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#8ab4c8; font-size:9pt;")
        lay.addWidget(hint)
        return w

    def _refresh_playlist_widget(self):
        """Rebuild playlist row text from self._playlist without losing the
        current selection (called after any volume/mix/add/remove change)."""
        selected_rows = {i.row() for i in self.playlist_widget.selectedIndexes()}
        self.playlist_widget.blockSignals(True)
        self.playlist_widget.clear()
        for it in self._playlist:
            name = os.path.basename(it["path"])
            ext = os.path.splitext(it["path"])[1].lower()
            if ext in GAME_EXT:
                icon = "🕹"
            else:
                icon = _kind_icon(it.get("kind", KIND_UNKNOWN))
            mix_tag = "  [MIX]" if it.get("mix") else ""
            mod_tag = ""
            if "pitch_semitones" in it or "rate" in it:
                mod_tag = f"  [P {float(it.get('pitch_semitones',0.0)):+.2f} st · R {float(it.get('rate',1.0)):.2f}× · {it.get('resample','preserve-duration')}]"
            timing_tag = f"  [T {float(it.get('time_s',0.0)):.3f}s · D {float(it.get('duration_s',0.0)):.3f}s]"
            self.playlist_widget.addItem(f"{icon} {name}  {it.get('volume', 100)}%{mix_tag}{timing_tag}{mod_tag}")
        self.playlist_widget.blockSignals(False)
        for row in selected_rows:
            if 0 <= row < self.playlist_widget.count():
                self.playlist_widget.item(row).setSelected(True)
        # If a TV host is active, playlist edits/seeded rearrangements become live
        # immediately without another explicit publish click.
        try:
            if self._media_share_server is not None:
                self._media_share_server.set_playlist(self._playlist)
        except Exception:
            pass

    def _arrange_media_playlist(self):
        if len(self._playlist) < 2:
            return
        mode = self.cmb_playlist_arrange.currentText()
        if mode == "Name order":
            self._playlist.sort(key=lambda it: os.path.basename(it["path"]).lower())
        elif mode == "Deterministic shuffle":
            rng = random.Random(int(self.spin_playlist_arrange_seed.value()))
            rng.shuffle(self._playlist)
        elif mode == "Geometric phaselock seeded":
            try:
                from media_cutup_engine import playlist_geometric_parameters
                seed = int(self.spin_playlist_arrange_seed.value())
                params = playlist_geometric_parameters(len(self._playlist), seed, pitch_range_st=7.0, rate_depth=0.24, phase_lock=4)
                decorated = []
                for item, param in zip(self._playlist, params):
                    item.update(param)
                    decorated.append((float(param["geometry_key"]), item))
                decorated.sort(key=lambda pair: pair[0])
                self._playlist = [item for _key, item in decorated]
            except Exception as e:
                self.lbl_status.setText(f"Geometric playlist error: {e}")
                return
        elif mode == "Analyzed match (reverse-engineer)":
            # Real-signal greedy nearest-neighbor chain: each next track is the
            # closest-measured match (pitch/brightness/loudness/rhythm) to the
            # previous one, via reverse_engineer.describe() rather than name
            # or file-size heuristics. The seed only picks the start when
            # several tracks tie or lack a usable descriptor (images, unreadable
            # media), so results stay reproducible.
            self.lbl_status.setText("Analyzing tracks (real signal descriptors)…")
            descs: Dict[int, dict] = {}
            for i, it in enumerate(self._playlist):
                if it.get("kind") in (KIND_AUDIO, KIND_VIDEO, KIND_AV) and os.path.isfile(it["path"]):
                    d = _analyze_signal_descriptor(it["path"], self._analysis_cache)
                    if d:
                        descs[i] = d
            rng = random.Random(int(self.spin_playlist_arrange_seed.value()))
            remaining = list(range(len(self._playlist)))
            analyzable = [i for i in remaining if i in descs]
            unanalyzable = [i for i in remaining if i not in descs]
            ordered: List[int] = []
            if analyzable:
                start = rng.choice(analyzable)
                pool = set(analyzable)
                pool.discard(start)
                ordered.append(start)
                while pool:
                    last = descs[ordered[-1]]
                    nxt = min(pool, key=lambda i: _descriptor_distance(last, descs[i]))
                    ordered.append(nxt)
                    pool.discard(nxt)
            rng.shuffle(unanalyzable)
            ordered.extend(unanalyzable)
            self._playlist = [self._playlist[i] for i in ordered]
            self.lbl_status.setText(f"Analyzed match: {len(analyzable)} track(s) measured, {len(unanalyzable)} placed by seed.")
        elif mode == "Interleave A/V":
            aud = [it for it in self._playlist if it.get("kind") == KIND_AUDIO]
            vis = [it for it in self._playlist if it.get("kind") in (KIND_VIDEO, KIND_AV)]
            other = [it for it in self._playlist if it not in aud and it not in vis]
            out = []
            while aud or vis:
                if aud: out.append(aud.pop(0))
                if vis: out.append(vis.pop(0))
            self._playlist = out + other
        else:
            # A deterministic low→high→low file-size arc: useful as a simple
            # media-intensity proxy on boxes where full analysis would be costly.
            seq = sorted(self._playlist, key=lambda it: os.path.getsize(it["path"]) if os.path.isfile(it["path"]) else 0)
            lo, hi, out = 0, len(seq) - 1, []
            take_low = True
            while lo <= hi:
                if take_low:
                    out.append(seq[lo]); lo += 1
                else:
                    out.append(seq[hi]); hi -= 1
                take_low = not take_low
            self._playlist = out
        self._playlist_index = 0
        self._refresh_playlist_widget()
        self.lbl_status.setText(f"Playlist arranged: {mode}")

    def _on_playlist_selection_changed(self):
        rows = [i.row() for i in self.playlist_widget.selectedIndexes()]
        if not rows:
            self.sld_playlist_volume.setEnabled(False)
            return
        self.sld_playlist_volume.setEnabled(True)
        # Show the first selected row's volume as the slider starting point.
        vol = self._playlist[rows[0]].get("volume", 100) if 0 <= rows[0] < len(self._playlist) else 100
        self.sld_playlist_volume.blockSignals(True)
        self.sld_playlist_volume.setValue(int(vol))
        self.sld_playlist_volume.blockSignals(False)
        self.lbl_playlist_volume.setText(f"{int(vol)}%")
        if hasattr(self, "spin_item_time") and 0 <= rows[0] < len(self._playlist):
            it = self._playlist[rows[0]]
            self.spin_item_time.blockSignals(True); self.spin_item_duration.blockSignals(True)
            self.spin_item_time.setValue(float(it.get("time_s", 0.0) or 0.0))
            self.spin_item_duration.setValue(float(it.get("duration_s", 0.0) or 0.0))
            self.spin_item_time.blockSignals(False); self.spin_item_duration.blockSignals(False)

    def _on_playlist_timing_changed(self, *_):
        rows = {i.row() for i in self.playlist_widget.selectedIndexes()}
        for row in rows:
            if 0 <= row < len(self._playlist):
                self._playlist[row]["time_s"] = float(self.spin_item_time.value())
                self._playlist[row]["duration_s"] = float(self.spin_item_duration.value())
        if rows:
            self._refresh_playlist_widget(); self._sync_project_state()

    def _on_playlist_volume_changed(self, value: int):
        self.lbl_playlist_volume.setText(f"{value}%")
        for row in {i.row() for i in self.playlist_widget.selectedIndexes()}:
            if 0 <= row < len(self._playlist):
                self._playlist[row]["volume"] = int(value)
        self._refresh_playlist_widget(); self._sync_project_state()

    def _toggle_mix_selected(self):
        rows = {i.row() for i in self.playlist_widget.selectedIndexes()}
        if not rows:
            return
        for row in rows:
            if 0 <= row < len(self._playlist):
                self._playlist[row]["mix"] = not self._playlist[row].get("mix", False)
        self._refresh_playlist_widget(); self._sync_project_state()

    def _mpv_command(self, command: list) -> bool:
        path = self._mpv_ipc_path
        if not path or not os.path.exists(path):
            return False
        payload = (json.dumps({"command": command}) + "\n").encode("utf-8")
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(0.06)
            sock.connect(path)
            sock.sendall(payload)
            sock.close()
            return True
        except Exception:
            return False

    def _on_live_speed_changed(self, value: int):
        self._live_speed = max(0.25, min(4.0, float(value) / 100.0))
        if hasattr(self, "lbl_live_speed"):
            self.lbl_live_speed.setText(f"{self._live_speed:.2f}×")
        if self._mpv_command(["set_property", "speed", self._live_speed]):
            self.lbl_status.setText(f"Live playback speed: {self._live_speed:.2f}×")

    def _playlist_clear(self):
        self._stop_mix()
        self._playlist.clear()
        self._playlist_index = -1
        self.playlist_widget.clear(); self._sync_project_state()

    def _playlist_play(self):
        if not self._playlist:
            return
        if self._playlist_index < 0:
            self._playlist_index = 0
        self._playlist_index = max(0, min(self._playlist_index, len(self._playlist) - 1))
        entry = self._playlist[self._playlist_index]
        path = entry["path"]
        self.playlist_widget.setCurrentRow(self._playlist_index)
        ext = os.path.splitext(path)[1].lower()
        if ext in GAME_EXT:
            self._play_game_package(path)
        else:
            if "rate" in entry and hasattr(self, "sld_live_speed"):
                self.sld_live_speed.setValue(max(25, min(400, int(round(float(entry.get("rate", 1.0)) * 100.0)))))
            self._play_path(path, volume_pct=entry.get("volume", 100), duration_s=float(entry.get("duration_s", 0.0) or 0.0))

    def _start_timed_playlist(self):
        if not self._playlist:
            return
        self._timed_playlist_pending = sorted(range(len(self._playlist)), key=lambda i: (float(self._playlist[i].get("time_s", 0.0) or 0.0), i))
        self._timed_playlist_epoch = time.monotonic()
        self._timed_playlist_timer.start()
        self.lbl_status.setText(f"Timed display playlist armed: {len(self._timed_playlist_pending)} item(s)")
        self._timed_playlist_tick()

    def _timed_playlist_tick(self):
        if not self._timed_playlist_pending:
            self._timed_playlist_timer.stop(); return
        elapsed = time.monotonic() - self._timed_playlist_epoch
        while self._timed_playlist_pending:
            idx = self._timed_playlist_pending[0]
            it = self._playlist[idx]
            if elapsed + 1e-6 < float(it.get("time_s", 0.0) or 0.0):
                break
            self._timed_playlist_pending.pop(0)
            self._playlist_index = idx; self.playlist_widget.setCurrentRow(idx)
            path = it.get("path", "")
            if os.path.isfile(path):
                self._play_path(path, volume_pct=int(it.get("volume",100)), duration_s=float(it.get("duration_s",0.0) or 0.0))
        if not self._timed_playlist_pending:
            self._timed_playlist_timer.stop()

    def _stop_timed_playlist(self):
        self._timed_playlist_timer.stop(); self._timed_playlist_pending = []; self._stop_player()
        self.lbl_status.setText("Timed display playlist stopped.")

    def _playlist_next(self):
        if not self._playlist:
            return
        self._playlist_index = (self._playlist_index + 1) % len(self._playlist)
        self._playlist_play()

    def _playlist_prev(self):
        if not self._playlist:
            return
        self._playlist_index = (self._playlist_index - 1) % len(self._playlist)
        self._playlist_play()

    def _set_live_speed(self, value: float):
        value = max(0.25, min(4.0, float(value)))
        if hasattr(self, "sld_live_speed"):
            self.sld_live_speed.setValue(int(round(value * 100.0)))
        else:
            self._live_speed = value
            self._mpv_command(["set_property", "speed", self._live_speed])

    def _playlist_play_mix(self):
        """Launch every [MIX]-flagged playlist row simultaneously, each in
        its own player process at its own volume. Real mixing happens at the
        OS audio layer (ALSA/Pulse), which is what actually lets a DJ track,
        a video's audio, and a game's soundtrack sound together on one HDMI
        output — no single subprocess player can do that alone."""
        self._stop_mix()
        mixed = [it for it in self._playlist if it.get("mix") and os.path.isfile(it["path"])]
        if not mixed:
            QMessageBox.information(
                self, "Play Mix",
                "No playlist rows are flagged for Mix.\n"
                "Select one or more rows and click 'Toggle Mix on selected' first."
            )
            return
        started = []
        for it in mixed:
            ext = os.path.splitext(it["path"])[1].lower()
            if ext in GAME_EXT:
                continue  # games launch through _play_game_package, not a media player
            want_video = it.get("kind") in (KIND_VIDEO, KIND_AV, KIND_UNKNOWN) and ext in VIDEO_EXT
            cmd = _player_cmd_with_volume(it.get("volume", 100), want_video=want_video)
            if not cmd:
                continue
            try:
                cmd, penv = self._routed_player(cmd, want_video=want_video)
                proc = subprocess.Popen(cmd + [it["path"]], env=penv)
                self._mix_procs.append(proc)
                started.append(f"{os.path.basename(it['path'])} @{it.get('volume', 100)}%")
            except Exception:
                continue
        if not started:
            QMessageBox.warning(
                self, "Play Mix",
                "Install mpv, vlc, or ffplay for media playback on this Pi."
            )
            return
        self.lbl_status.setText("Mixing: " + " · ".join(started))

    def _stop_mix(self):
        for proc in self._mix_procs:
            try:
                proc.terminate()
            except Exception:
                pass
        self._mix_procs = []

    # ------------------------------------------------------------------ game tab
    def _build_game_tab(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>🎮 Built-in game player · local Wi‑Fi multiplayer</b>"))
        self.cmb_game_status = QLabel("Uses live composition identity, or a packaged .zip game. LAN mode can be forced even when the seed classified the game as single-player.")
        self.cmb_game_status.setWordWrap(True); lay.addWidget(self.cmb_game_status)
        row = QHBoxLayout()
        btn_live = QPushButton("▶ Play Live Composition Game"); btn_live.clicked.connect(self._play_live_game)
        btn_pkg = QPushButton("🕹 Play Selected Package"); btn_pkg.clicked.connect(self._play_selected_game)
        row.addWidget(btn_live); row.addWidget(btn_pkg); lay.addLayout(row)

        net = QGroupBox("📶 Local Wi‑Fi / Ethernet game session")
        nf = QFormLayout(net)
        self.cmb_game_net_mode = QComboBox(); self.cmb_game_net_mode.addItems(["Solo", "Host on local network", "Join local network"]); nf.addRow("Mode", self.cmb_game_net_mode)
        self.spin_game_port = QSpinBox(); self.spin_game_port.setRange(1024,65535); self.spin_game_port.setValue(27777); nf.addRow("Port", self.spin_game_port)
        self.edit_game_connect = QLineEdit(); self.edit_game_connect.setPlaceholderText("host-ip:port  e.g. 192.168.1.42:27777"); nf.addRow("Join address", self.edit_game_connect)
        self.lbl_game_lan = QLabel(f"This box: {self._lan_ip()} · same Wi‑Fi/LAN required unless your router/firewall forwards the port.")
        self.lbl_game_lan.setWordWrap(True); self.lbl_game_lan.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); nf.addRow("Local address", self.lbl_game_lan)
        lay.addWidget(net)
        hint = QLabel("Host and Join use the game engine's authoritative TCP snapshot/input transport. This is live game-state networking—not merely sharing a .zip. Keyboard, mouse/gamepad and touch input remain local on each machine.")
        hint.setWordWrap(True); hint.setStyleSheet("color:#8ab4c8; font-size:9pt;"); lay.addWidget(hint)
        lay.addStretch(1); return w

    def _play_live_game(self):
        if hasattr(self.host, "_on_play_videogame"):
            try:
                mode = self.cmb_game_net_mode.currentIndex() if hasattr(self, "cmb_game_net_mode") else 0
                setattr(self.host, "_preferred_game_net_mode", int(mode))
                setattr(self.host, "_preferred_game_net_port", int(self.spin_game_port.value()) if hasattr(self, "spin_game_port") else 27777)
                setattr(self.host, "_preferred_game_connect", self.edit_game_connect.text().strip() if hasattr(self, "edit_game_connect") else "")
                self.host._on_play_videogame()
                self.lbl_status.setText("Live game dialog opened.")
            except Exception as e:
                QMessageBox.warning(self, "Game", str(e))
        else:
            QMessageBox.warning(self, "Game", "Host has no video-game player.")

    def _play_selected_game(self):
        for path in self._selected_paths():
            if path.lower().endswith(".zip"):
                self._play_game_package(path)
                return
        QMessageBox.information(self, "Game", "Select a .zip game package in the browser.")

    def _play_game_package(self, path: str):
        try:
            td = tempfile.mkdtemp(prefix="gb_game_pkg_")
            with zipfile.ZipFile(path, "r") as zf:
                zf.extractall(td)
            script = None
            for root, _dirs, files in os.walk(td):
                for f in files:
                    if f.endswith(".py") and ("game" in f.lower() or f.startswith("play")):
                        script = os.path.join(root, f)
                        break
                if script:
                    break
            if script is None:
                # any .py
                for root, _dirs, files in os.walk(td):
                    for f in files:
                        if f.endswith(".py"):
                            script = os.path.join(root, f)
                            break
                    if script:
                        break
            if not script:
                raise RuntimeError("No Python game script found inside the package.")
            args = [sys.executable, script]
            mode = self.cmb_game_net_mode.currentIndex() if hasattr(self, "cmb_game_net_mode") else 0
            port = int(self.spin_game_port.value()) if hasattr(self, "spin_game_port") else 27777
            if mode == 1:
                args += ["--host", f"--port={port}"]
            elif mode == 2:
                addr = self.edit_game_connect.text().strip() if hasattr(self, "edit_game_connect") else ""
                if not addr:
                    raise RuntimeError("Enter the host IP:port before joining a local-network game.")
                if ":" not in addr:
                    addr = f"{addr}:{port}"
                args.append(f"--connect={addr}")
            subprocess.Popen(args, cwd=os.path.dirname(script))
            self.lbl_status.setText(f"Game launched: {os.path.basename(path)}")
            self.cmb_game_status.setText(f"Running: {os.path.basename(path)}")
        except Exception as e:
            QMessageBox.warning(self, "Game package", str(e))

    # ------------------------------------------------------------------ remix tab
    def _build_remix_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Parametric live remixer</b>"))
        lay.addWidget(QLabel(
            "Drives the host Live DJ GOAVA morph + RAND PARAM macro on the play buffer."
        ))

        form = QFormLayout()
        self.sld_goava = QSlider(Qt.Orientation.Horizontal)
        self.sld_goava.setRange(0, 100)
        self.sld_goava.setValue(0)
        self.sld_goava.valueChanged.connect(self._queue_remix)
        form.addRow("GOAVA morph %", self.sld_goava)

        self.sld_rand = QSlider(Qt.Orientation.Horizontal)
        self.sld_rand.setRange(0, 100)
        self.sld_rand.setValue(0)
        self.sld_rand.valueChanged.connect(self._queue_remix)
        form.addRow("RAND PARAM %", self.sld_rand)

        self.spin_remix_pair_a = QSpinBox()
        self.spin_remix_pair_a.setRange(0, 47)
        self.spin_remix_pair_b = QSpinBox()
        self.spin_remix_pair_b.setRange(0, 47)
        self.spin_remix_pair_b.setValue(1)
        pair_row = QHBoxLayout()
        pair_row.addWidget(self.spin_remix_pair_a)
        pair_row.addWidget(QLabel("↔"))
        pair_row.addWidget(self.spin_remix_pair_b)
        form.addRow("Pair (A↔B)", pair_row)
        self.spin_remix_pair_a.valueChanged.connect(self._queue_remix)
        self.spin_remix_pair_b.valueChanged.connect(self._queue_remix)

        self.sld_boost = QSlider(Qt.Orientation.Horizontal)
        self.sld_boost.setRange(0, 100)
        self.sld_boost.setValue(0)
        self.sld_boost.valueChanged.connect(self._queue_remix)
        form.addRow("Boost hit %", self.sld_boost)

        lay.addLayout(form)

        row = QHBoxLayout()
        btn_apply = QPushButton("Apply to Live DJ")
        btn_apply.clicked.connect(self._push_remix)
        btn_arm = QPushButton("Arm GOAVA + RAND on host toggles")
        btn_arm.clicked.connect(self._arm_host_dj_toggles)
        row.addWidget(btn_apply)
        row.addWidget(btn_arm)
        btn_file = QPushButton("Render Parametric Remix → File…")
        btn_file.setToolTip("Non-destructively render the selected browser/playlist media through the current continuous remix script and deterministic DJ processor.")
        btn_file.clicked.connect(self._render_parametric_remix_file)
        row.addWidget(btn_file)
        lay.addLayout(row)

        self.lbl_remix = QLabel("Remix amounts at 0 — dry.")
        self.lbl_remix.setStyleSheet("color:#f5d97d;")
        lay.addWidget(self.lbl_remix)

        script_group = QGroupBox("Continuous Pattern Script")
        sg = QVBoxLayout(script_group)
        self.txt_pattern_script = QTextEdit()
        self.txt_pattern_script.setMaximumHeight(122)
        self.txt_pattern_script.setPlainText(
            "goava = 50 + 45*sin(t*0.73)\n"
            "rand = 25 + 25*sin(t*1.31 + 1.2)\n"
            "boost = 18 + 18*(sin(t*2.0)>0.72)\n"
            "speed = 1.0 + 0.22*sin(t*0.41)\n"
            "advance = (step % 64 == 0)"
        )
        self.txt_pattern_script.setToolTip(
            "Control-rate expressions. Available: t, step, sin/cos/tan, abs/min/max, "
            "sqrt, pi, rand(). Assign goava/rand/boost (0..100), speed (0.25..4), "
            "advance (true to go to next media-playlist item), and host (0..1 automation value)."
        )
        sg.addWidget(self.txt_pattern_script)
        sr = QHBoxLayout()
        self.spin_pattern_hz = QSpinBox()
        self.spin_pattern_hz.setRange(1, 60)
        self.spin_pattern_hz.setValue(20)
        self.spin_pattern_hz.setSuffix(" Hz")
        self.spin_pattern_hz.valueChanged.connect(self._set_pattern_rate)
        self.spin_pattern_seed = QSpinBox()
        self.spin_pattern_seed.setRange(0, 2147483647)
        self.spin_pattern_seed.setValue(1975807343)
        btn_pattern = QPushButton("▶ Run Pattern")
        btn_pattern.setCheckable(True)
        btn_pattern.toggled.connect(self._toggle_pattern_script)
        btn_pattern_once = QPushButton("Step once")
        btn_pattern_once.clicked.connect(self._pattern_tick)
        sr.addWidget(QLabel("Rate")); sr.addWidget(self.spin_pattern_hz)
        sr.addWidget(QLabel("Seed")); sr.addWidget(self.spin_pattern_seed)
        sr.addWidget(btn_pattern); sr.addWidget(btn_pattern_once)
        sg.addLayout(sr)
        self.chk_pattern_host_playlist = QCheckBox("Write continuous host playlist automation pattern")
        self.chk_pattern_host_playlist.setChecked(True)
        sg.addWidget(self.chk_pattern_host_playlist)
        self.lbl_pattern = QLabel("Pattern stopped.")
        self.lbl_pattern.setStyleSheet("color:#8ab4c8; font-size:9pt;")
        sg.addWidget(self.lbl_pattern)
        lay.addWidget(script_group)
        lay.addStretch(1)
        return w

    def _render_parametric_remix_file(self):
        paths = [p for p in self._selected_paths() if os.path.isfile(p) and os.path.splitext(p)[1].lower() in MEDIA_EXT]
        if not paths and 0 <= self._playlist_index < len(self._playlist):
            p = self._playlist[self._playlist_index].get("path", "")
            if os.path.isfile(p): paths = [p]
        if not paths:
            QMessageBox.information(self, "Parametric Remix", "Select an audio/video file in Performance, or select a playlist item first.")
            return
        src = paths[0]; ext = os.path.splitext(src)[1].lower()
        default_ext = ".wav" if ext in AUDIO_EXT else (".mp4" if ext in VIDEO_EXT else ".png")
        default = os.path.splitext(src)[0] + "_parametric_remix" + default_ext
        out, _ = QFileDialog.getSaveFileName(self, "Render Parametric Remix", default, "Media files (*.*)")
        if not out: return
        try:
            from parametric_file_remix import render_parametric_file
            result = render_parametric_file(
                src, out, self.txt_pattern_script.toPlainText(), int(self.spin_pattern_seed.value()),
                pair=(int(self.spin_remix_pair_a.value()), int(self.spin_remix_pair_b.value())),
                bpm=float(getattr(getattr(self.host, "spin_bpm", None), "value", lambda:120.0)()),
                control_hz=max(1, min(60, int(self.spin_pattern_hz.value()))),
            )
            self.lbl_status.setText("Parametric file edit: " + result)
            self._sync_project_state()
        except Exception as exc:
            QMessageBox.warning(self, "Parametric Remix", str(exc))

    def export_state(self) -> Dict[str, Any]:
        """JSON-safe Performance state used by normal Groovebox save/load."""
        display = getattr(self._output_display, "name", "") if self._output_display else ""
        audio = getattr(self._output_audio_target, "name", "") if self._output_audio_target else ""
        return {
            "version": 2,
            "playlist": json.loads(json.dumps(self._playlist, default=str)),
            "playlist_index": int(self._playlist_index),
            "live_speed": float(self._live_speed),
            "arrange": self.cmb_playlist_arrange.currentText() if hasattr(self,"cmb_playlist_arrange") else "Energy arc (size)",
            "arrange_seed": int(self.spin_playlist_arrange_seed.value()) if hasattr(self,"spin_playlist_arrange_seed") else 1975807343,
            "output_display": display, "output_audio": audio,
            "video_clip": self.video_clip_studio.export_state() if getattr(self, "video_clip_studio", None) is not None else {},
            "remix": {
                "goava": int(self.sld_goava.value()) if hasattr(self,"sld_goava") else 0,
                "rand": int(self.sld_rand.value()) if hasattr(self,"sld_rand") else 0,
                "boost": int(self.sld_boost.value()) if hasattr(self,"sld_boost") else 0,
                "pair_a": int(self.spin_remix_pair_a.value()) if hasattr(self,"spin_remix_pair_a") else 0,
                "pair_b": int(self.spin_remix_pair_b.value()) if hasattr(self,"spin_remix_pair_b") else 1,
                "script": self.txt_pattern_script.toPlainText() if hasattr(self,"txt_pattern_script") else "",
                "rate_hz": int(self.spin_pattern_hz.value()) if hasattr(self,"spin_pattern_hz") else 20,
                "seed": int(self.spin_pattern_seed.value()) if hasattr(self,"spin_pattern_seed") else 1975807343,
                "host_playlist": bool(self.chk_pattern_host_playlist.isChecked()) if hasattr(self,"chk_pattern_host_playlist") else True,
            },
        }

    def restore_state(self, state: Dict[str, Any]):
        if not isinstance(state, dict): return
        pl = state.get("playlist")
        if isinstance(pl, list):
            self._playlist = [dict(x) for x in pl if isinstance(x, dict) and x.get("path")]
            self._playlist_index = max(-1, min(int(state.get("playlist_index", -1)), len(self._playlist)-1))
            self._refresh_playlist_widget()
        if hasattr(self,"sld_live_speed"):
            self.sld_live_speed.setValue(max(25,min(400,int(round(float(state.get("live_speed",1.0))*100)))))
        if hasattr(self,"cmb_playlist_arrange") and state.get("arrange"):
            self.cmb_playlist_arrange.setCurrentText(str(state.get("arrange")))
        if hasattr(self,"spin_playlist_arrange_seed"):
            self.spin_playlist_arrange_seed.setValue(int(state.get("arrange_seed",1975807343)))
        r=state.get("remix") if isinstance(state.get("remix"),dict) else {}
        for name,key,default in (("sld_goava","goava",0),("sld_rand","rand",0),("sld_boost","boost",0),("spin_remix_pair_a","pair_a",0),("spin_remix_pair_b","pair_b",1),("spin_pattern_hz","rate_hz",20),("spin_pattern_seed","seed",1975807343)):
            if hasattr(self,name): getattr(self,name).setValue(int(r.get(key,default)))
        if hasattr(self,"txt_pattern_script") and "script" in r: self.txt_pattern_script.setPlainText(str(r.get("script") or ""))
        if hasattr(self,"chk_pattern_host_playlist"): self.chk_pattern_host_playlist.setChecked(bool(r.get("host_playlist",True)))
        if getattr(self, "video_clip_studio", None) is not None:
            try:
                self.video_clip_studio.restore_state(state.get("video_clip") if isinstance(state.get("video_clip"), dict) else {})
            except Exception:
                pass
        self._refresh_output_devices()
        dn=str(state.get("output_display") or ""); an=str(state.get("output_audio") or "")
        if dn and hasattr(self,"cmb_output_display"):
            for i,d in enumerate(self._output_displays):
                if getattr(d,"name","")==dn: self.cmb_output_display.setCurrentIndex(i); break
        if an and hasattr(self,"cmb_output_audio"):
            for i,a in enumerate(self._output_audio):
                if getattr(a,"name","")==an: self.cmb_output_audio.setCurrentIndex(i); break
        # OUTPUT_ROUTER_COMPAT_20260907: routing method was renamed from
        # _apply_output_selection() to _apply_output_routing().  Apply the
        # restored combo-box indices using the current implementation.
        self._apply_output_routing()

    def _apply_output_selection(self):
        """Backward-compatible alias for older Performance state/callback code.

        ABI9 briefly retained a call to this legacy method name after the
        output-router implementation was renamed.  Keep the alias so older
        project/session paths and third-party extensions cannot crash the
        Performance window while all routing remains centralized in
        ``_apply_output_routing``.
        """
        return self._apply_output_routing()

    def _sync_project_state(self):
        try:
            state=getattr(self.host,"media_workbench_state",None)
            if not isinstance(state,dict): state={}; setattr(self.host,"media_workbench_state",state)
            state["performance"]=self.export_state()
        except Exception:
            pass

    def _queue_remix(self, *_args):
        """Coalesce dense slider-drag events to at most one DJ update per GUI frame."""
        timer=getattr(self,'_remix_apply_timer',None)
        if timer is None:
            timer=QTimer(self); timer.setSingleShot(True); timer.setInterval(16)
            timer.timeout.connect(self._push_remix); self._remix_apply_timer=timer
        if not timer.isActive(): timer.start()

    def _push_remix(self, *_args):
        host = self.host
        goava = self.sld_goava.value() / 100.0
        rand = self.sld_rand.value() / 100.0
        boost = self.sld_boost.value() / 100.0
        a = int(self.spin_remix_pair_a.value())
        b = int(self.spin_remix_pair_b.value())
        try:
            eng = getattr(host, "_live_dj_engine", None)
            if eng is None:
                from dj_effects import LiveDJEffects
                sr = int(getattr(host, "play_sample_rate", 48000) or 48000)
                eng = LiveDJEffects(sample_rate=sr)
                host._live_dj_engine = eng
            seed = 0.0
            try:
                if hasattr(host, "get_numeric_seed"):
                    seed = float(host.get_numeric_seed())
            except Exception:
                pass
            eng.set_context(seed=seed, pair=(a, b),
                            sample_rate=int(getattr(host, "play_sample_rate", 48000) or 48000))
            eng.amount_goava = float(goava)
            eng.amount_random = float(rand)
            if boost > 0.0:
                # ~1 bar at 120 BPM default
                sr = float(getattr(host, "play_sample_rate", 48000) or 48000)
                interval = int(sr * 2.0)
                eng.set_boost(interval=interval, phase=0.0, amount=boost)
            else:
                eng.set_boost(0, 0.0, 0.0)
            host._live_dj_pair_ids = (a, b)
            self.lbl_remix.setText(
                f"GOAVA {goava*100:.0f}% · RAND {rand*100:.0f}% · boost {boost*100:.0f}% · pair {a}↔{b}"
            )
            self.lbl_status.setText("Parametric remix pushed to Live DJ engine.")
        except Exception as e:
            self.lbl_remix.setText(f"Remix error: {e}")

    @staticmethod
    def _safe_pattern_eval(expr: str, env: Dict[str, Any]) -> Any:
        node = ast.parse(expr, mode="eval")
        allowed = (ast.Expression, ast.Constant, ast.Name, ast.Load, ast.BinOp, ast.UnaryOp,
                   ast.BoolOp, ast.Compare, ast.Call, ast.Add, ast.Sub, ast.Mult, ast.Div,
                   ast.Mod, ast.Pow, ast.USub, ast.UAdd, ast.And, ast.Or, ast.Not,
                   ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE)
        for n in ast.walk(node):
            if not isinstance(n, allowed):
                raise ValueError(f"unsupported script syntax: {type(n).__name__}")
            if isinstance(n, ast.Call) and (not isinstance(n.func, ast.Name) or n.func.id not in env):
                raise ValueError("only listed math functions may be called")
        return eval(compile(node, "<media-pattern>", "eval"), {"__builtins__": {}}, env)

    def _compiled_pattern_program(self):
        """Compile the control script once per text identity, routed by sCode."""
        text=self.txt_pattern_script.toPlainText()
        def build():
            program=[]
            allowed_names={"t","step","pi","e","sin","cos","tan","sqrt","abs","min","max","rand",
                           "goava","rand","boost","speed","advance","host"}
            allowed_nodes=(ast.Expression,ast.Constant,ast.Name,ast.Load,ast.BinOp,ast.UnaryOp,
                           ast.BoolOp,ast.Compare,ast.Call,ast.Add,ast.Sub,ast.Mult,ast.Div,
                           ast.Mod,ast.Pow,ast.USub,ast.UAdd,ast.And,ast.Or,ast.Not,
                           ast.Eq,ast.NotEq,ast.Lt,ast.LtE,ast.Gt,ast.GtE)
            callable_names={"sin","cos","tan","sqrt","abs","min","max","rand"}
            for raw in text.splitlines():
                line=raw.split("#",1)[0].strip()
                if not line or "=" not in line: continue
                key,expr=line.split("=",1); key=key.strip().lower(); expr=expr.strip()
                if key not in {"goava","rand","boost","speed","advance","host"}: continue
                node=ast.parse(expr,mode="eval")
                for n in ast.walk(node):
                    if not isinstance(n,allowed_nodes): raise ValueError(f"unsupported script syntax: {type(n).__name__}")
                    if isinstance(n,ast.Name) and n.id not in allowed_names: raise ValueError(f"unknown pattern name: {n.id}")
                    if isinstance(n,ast.Call) and (not isinstance(n.func,ast.Name) or n.func.id not in callable_names):
                        raise ValueError("only listed math functions may be called")
                program.append((key,compile(node,"<media-pattern>","eval")))
            return tuple(program)
        opt=getattr(self.host,"_scode_optimizer",None)
        if opt is not None:
            return opt.memoized_result("ui_pattern_compile",text,build,max_entries=8)
        return build()

    def _set_pattern_rate(self, hz: int):
        self._pattern_timer.setInterval(max(16, int(round(1000.0 / max(1, hz)))))

    def _toggle_pattern_script(self, on: bool):
        if on:
            self._pattern_phase = 0.0
            self._pattern_step = 0
            self._pattern_rng.seed(int(self.spin_pattern_seed.value()))
            self._set_pattern_rate(self.spin_pattern_hz.value())
            self._pattern_timer.start()
            self.lbl_pattern.setText("Pattern running.")
        else:
            self._pattern_timer.stop()
            self.lbl_pattern.setText("Pattern stopped.")

    def _pattern_tick(self):
        hz=max(1,int(getattr(self,"spin_pattern_hz",None).value() if hasattr(self,"spin_pattern_hz") else 20))
        t=self._pattern_phase; step=self._pattern_step
        env={"t":t,"step":step,"pi":math.pi,"e":math.e,"sin":math.sin,"cos":math.cos,
             "tan":math.tan,"sqrt":math.sqrt,"abs":abs,"min":min,"max":max,"rand":self._pattern_rng.random}
        values:Dict[str,Any]={}
        try:
            for key,code in self._compiled_pattern_program():
                values[key]=eval(code,{"__builtins__":{}},dict(env,**values))

            # SCODE_FULL_ACCEL_V4: coalesce three slider signal cascades into one
            # live-DJ update. Numeric values are still identical to the old path.
            changed=False
            assignments=[]
            if "goava" in values: assignments.append((self.sld_goava,max(0,min(100,int(round(float(values["goava"])))))))
            if "rand" in values: assignments.append((self.sld_rand,max(0,min(100,int(round(float(values["rand"])))))))
            if "boost" in values: assignments.append((self.sld_boost,max(0,min(100,int(round(float(values["boost"])))))))
            for widget,val in assignments:
                if widget.value()!=val:
                    widget.blockSignals(True); widget.setValue(val); widget.blockSignals(False); changed=True
            if changed:
                self._push_remix()
            if "speed" in values and hasattr(self,"sld_live_speed"):
                sv=max(25,min(400,int(round(float(values["speed"])*100.0))))
                if self.sld_live_speed.value()!=sv:
                    self.sld_live_speed.setValue(sv)
            if bool(values.get("advance",False)) and self._playlist: self._playlist_next()
            if self.chk_pattern_host_playlist.isChecked():
                self._write_host_pattern_value(values.get("host",values.get("goava",0.0)/100.0),step)
            self.lbl_pattern.setText(f"t={t:.2f} · step={step} · G={self.sld_goava.value()} R={self.sld_rand.value()} B={self.sld_boost.value()} · speed={self._live_speed:.2f}×")
        except Exception as e:
            self.lbl_pattern.setText(f"Pattern error: {e}"); self._pattern_timer.stop()
        self._pattern_step+=1; self._pattern_phase+=1.0/float(hz)

    def _write_host_pattern_value(self, value: Any, step: int):
        """Write sparse, bounded control-rate data into the host playlist automation.
        This is intentionally tiny: one scalar per playlist row, refreshed in-place."""
        try:
            rows = getattr(self.host, "master_playlist_data", None) or []
            if not rows:
                return
            row = int(step) % len(rows)
            entry = rows[row]
            if not isinstance(entry, dict):
                entry = {}; rows[row] = entry
            v = max(0.0, min(1.0, float(value)))
            entry["media_hub_pattern"] = v
            entry["media_hub_pattern_step"] = int(step)
            # Also expose through playlist_automation without replacing canonical fields.
            pa = getattr(self.host, "playlist_automation", None)
            if isinstance(pa, list):
                while len(pa) <= row:
                    pa.append({})
                if not isinstance(pa[row], dict):
                    pa[row] = {}
                pa[row]["media_hub_pattern"] = v
        except Exception:
            pass

    def _arm_host_dj_toggles(self):
        self._push_remix()
        try:
            if hasattr(self.host, "btn_live_dj_goava") and self.sld_goava.value() > 0:
                self.host.btn_live_dj_goava.setChecked(True)
            if hasattr(self.host, "btn_live_dj_random") and self.sld_rand.value() > 0:
                self.host.btn_live_dj_random.setChecked(True)
        except Exception:
            pass

    # ------------------------------------------------------------------ cutup lab
    def _build_cutup_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Geometric Phaselocked Cutup Lab</b>"))
        intro = QLabel(
            "Load an audio file, optionally normalize its detected pitch, then create a deterministic beat/cutup. "
            "Slice choice, pitch, rate, reversal and resampling are generated from one seed on a phaselocked geometric lattice."
        )
        intro.setWordWrap(True)
        lay.addWidget(intro)

        src_row = QHBoxLayout()
        self.lbl_cutup_source = QLabel("No sample loaded")
        self.lbl_cutup_source.setWordWrap(True)
        btn_sel = QPushButton("Use selected audio")
        btn_sel.clicked.connect(self._cutup_use_selected)
        btn_browse = QPushButton("Load sample…")
        btn_browse.clicked.connect(self._cutup_browse)
        src_row.addWidget(self.lbl_cutup_source, stretch=1)
        src_row.addWidget(btn_sel)
        src_row.addWidget(btn_browse)
        lay.addLayout(src_row)
        self._cutup_source_path = None
        self._cutup_video_path = None
        self._cutup_events = []
        self._cutup_pitch_shift = 0.0

        vrow = QHBoxLayout()
        self.lbl_cutup_video = QLabel("No video source (optional)")
        self.lbl_cutup_video.setWordWrap(True)
        btn_vsel = QPushButton("Use selected video")
        btn_vsel.clicked.connect(self._cutup_use_selected_video)
        btn_vbrowse = QPushButton("Load video…")
        btn_vbrowse.clicked.connect(self._cutup_browse_video)
        vrow.addWidget(self.lbl_cutup_video, stretch=1); vrow.addWidget(btn_vsel); vrow.addWidget(btn_vbrowse)
        lay.addLayout(vrow)

        norm = QGroupBox("Pitch normalization")
        nf = QFormLayout(norm)
        self.spin_cutup_target_hz = QDoubleSpinBox()
        self.spin_cutup_target_hz.setRange(0.0, 20000.0)
        self.spin_cutup_target_hz.setDecimals(3)
        self.spin_cutup_target_hz.setValue(0.0)
        self.spin_cutup_target_hz.setSpecialValueText("Nearest C-major pitch")
        self.spin_cutup_target_hz.setToolTip("0 = detect a stable fundamental and move it to the nearest C-major pitch. Enter Hz for an exact target.")
        nf.addRow("Target pitch", self.spin_cutup_target_hz)
        nrow = QHBoxLayout()
        btn_an = QPushButton("Analyze pitch")
        btn_an.clicked.connect(self._cutup_analyze_pitch)
        btn_nr = QPushButton("Render normalized copy…")
        btn_nr.clicked.connect(self._cutup_render_normalized)
        nrow.addWidget(btn_an); nrow.addWidget(btn_nr)
        nf.addRow(nrow)
        self.lbl_cutup_pitch = QLabel("Pitch not analyzed.")
        self.lbl_cutup_pitch.setWordWrap(True)
        nf.addRow(self.lbl_cutup_pitch)
        lay.addWidget(norm)

        gen = QGroupBox("Seeded beat / file cutup")
        form = QFormLayout(gen)
        self.spin_cutup_bpm = QDoubleSpinBox(); self.spin_cutup_bpm.setRange(20.0, 400.0); self.spin_cutup_bpm.setValue(120.0); self.spin_cutup_bpm.setDecimals(2)
        self.spin_cutup_bars = QSpinBox(); self.spin_cutup_bars.setRange(1, 256); self.spin_cutup_bars.setValue(4)
        self.spin_cutup_steps = QSpinBox(); self.spin_cutup_steps.setRange(1, 64); self.spin_cutup_steps.setValue(16)
        self.spin_cutup_divs = QSpinBox(); self.spin_cutup_divs.setRange(1, 1024); self.spin_cutup_divs.setValue(32)
        self.spin_cutup_phase = QSpinBox(); self.spin_cutup_phase.setRange(1, 64); self.spin_cutup_phase.setValue(4)
        self.spin_cutup_seed = QSpinBox(); self.spin_cutup_seed.setRange(0, 2147483647); self.spin_cutup_seed.setValue(1975807343)
        self.spin_cutup_pitch_range = QDoubleSpinBox(); self.spin_cutup_pitch_range.setRange(0.0, 48.0); self.spin_cutup_pitch_range.setValue(7.0); self.spin_cutup_pitch_range.setSuffix(" st")
        self.spin_cutup_rate_depth = QDoubleSpinBox(); self.spin_cutup_rate_depth.setRange(0.0, 3.0); self.spin_cutup_rate_depth.setSingleStep(0.05); self.spin_cutup_rate_depth.setValue(0.20)
        self.spin_cutup_reverse = QDoubleSpinBox(); self.spin_cutup_reverse.setRange(0.0, 1.0); self.spin_cutup_reverse.setSingleStep(0.05); self.spin_cutup_reverse.setValue(0.12)
        self.cmb_cutup_resample = QComboBox(); self.cmb_cutup_resample.addItems(["preserve-duration", "tape"])
        form.addRow("BPM", self.spin_cutup_bpm)
        form.addRow("Bars", self.spin_cutup_bars)
        form.addRow("Steps / bar", self.spin_cutup_steps)
        form.addRow("Source slice divisions", self.spin_cutup_divs)
        form.addRow("Phase-lock group", self.spin_cutup_phase)
        form.addRow("Seed", self.spin_cutup_seed)
        form.addRow("Pitch modulation", self.spin_cutup_pitch_range)
        form.addRow("Rate depth", self.spin_cutup_rate_depth)
        form.addRow("Reverse probability", self.spin_cutup_reverse)
        form.addRow("Resampling", self.cmb_cutup_resample)
        lay.addWidget(gen)

        crow = QHBoxLayout()
        btn_gen = QPushButton("Generate cut pattern")
        btn_gen.clicked.connect(self._cutup_generate)
        btn_render = QPushButton("Render cutup / beat…")
        btn_render.clicked.connect(self._cutup_render)
        btn_playlist = QPushButton("Seed playlist from same geometry")
        btn_playlist.clicked.connect(self._cutup_seed_playlist)
        btn_av = QPushButton("Render A/V cutup…")
        btn_av.clicked.connect(self._cutup_render_av)
        btn_auto = QPushButton("▶ Auto render + replay/broadcast")
        btn_auto.clicked.connect(self._cutup_auto_perform)
        crow.addWidget(btn_gen); crow.addWidget(btn_render); crow.addWidget(btn_playlist); crow.addWidget(btn_av); crow.addWidget(btn_auto)
        lay.addLayout(crow)
        self.lbl_cutup_pattern = QLabel("No cut pattern generated.")
        self.lbl_cutup_pattern.setWordWrap(True)
        self.lbl_cutup_pattern.setStyleSheet("color:#8ab4c8; font-size:9pt;")
        lay.addWidget(self.lbl_cutup_pattern)
        lay.addStretch(1)
        return w

    def _cutup_use_selected(self):
        for path in self._selected_paths():
            if os.path.isfile(path) and os.path.splitext(path)[1].lower() in AUDIO_EXT:
                self._cutup_set_source(path)
                return
        QMessageBox.information(self, "Cutup Lab", "Select an audio file in the Performance browser first.")

    def _cutup_browse(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load sample", self._host_samples_dir(), "Audio (*.wav *.flac *.mp3 *.ogg *.opus *.aiff *.aif *.caf);;All files (*)")
        if path:
            self._cutup_set_source(path)

    def _cutup_use_selected_video(self):
        for path in self._selected_paths():
            if os.path.isfile(path) and os.path.splitext(path)[1].lower() in VIDEO_EXT:
                self._cutup_video_path = os.path.abspath(path)
                self.lbl_cutup_video.setText(os.path.basename(path))
                return
        QMessageBox.information(self, "Cutup Lab", "Select a video file in the Performance browser first.")

    def _cutup_browse_video(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load video source", self._host_exports_dir(), "Video (*.mp4 *.webm *.avi *.mov *.mkv);;All files (*)")
        if path:
            self._cutup_video_path = os.path.abspath(path)
            self.lbl_cutup_video.setText(os.path.basename(path))

    def _cutup_set_source(self, path: str):
        self._cutup_source_path = os.path.abspath(path)
        self._cutup_events = []
        self._cutup_pitch_shift = 0.0
        self.lbl_cutup_source.setText(os.path.basename(path))
        self.lbl_cutup_pitch.setText("Pitch not analyzed.")
        self.lbl_cutup_pattern.setText("Source loaded. Generate a pattern or analyze pitch.")

    def _cutup_analyze_pitch(self):
        path = self._cutup_source_path
        if not path or not os.path.isfile(path):
            self._cutup_use_selected(); path = self._cutup_source_path
        if not path:
            return
        try:
            from media_cutup_engine import pitch_normalization_shift
            target = float(self.spin_cutup_target_hz.value())
            detected, shift, msg = pitch_normalization_shift(path, target_hz=(target if target > 0 else None), root_midi=60)
            self._cutup_pitch_shift = float(shift)
            self.lbl_cutup_pitch.setText(msg)
            self.lbl_status.setText("Pitch analysis complete." if detected is not None else msg)
        except Exception as e:
            QMessageBox.warning(self, "Pitch analysis", str(e))

    def _cutup_render_normalized(self):
        path = self._cutup_source_path
        if not path or not os.path.isfile(path):
            self._cutup_use_selected(); path = self._cutup_source_path
        if not path:
            return
        self._cutup_analyze_pitch()
        base = os.path.splitext(os.path.basename(path))[0] + "_pitch_normalized.wav"
        out, _ = QFileDialog.getSaveFileName(self, "Render normalized sample", os.path.join(self._host_exports_dir(), base), "WAV (*.wav);;FLAC (*.flac)")
        if not out:
            return
        try:
            from media_cutup_engine import render_pitch_normalized
            out = render_pitch_normalized(path, out, self._cutup_pitch_shift, preserve_duration=True)
            self.lbl_status.setText(f"Pitch-normalized sample rendered: {os.path.basename(out)}")
            self.refresh()
        except Exception as e:
            QMessageBox.warning(self, "Pitch normalization", str(e))

    def _cutup_generate(self):
        path = self._cutup_source_path
        if not path or not os.path.isfile(path):
            self._cutup_use_selected(); path = self._cutup_source_path
        if not path:
            return
        try:
            from media_cutup_engine import generate_cut_events, probe_duration
            dur = probe_duration(path)
            if dur <= 0:
                raise RuntimeError("Could not determine sample duration")
            self._cutup_events = generate_cut_events(
                dur,
                bpm=float(self.spin_cutup_bpm.value()), bars=int(self.spin_cutup_bars.value()),
                steps_per_bar=int(self.spin_cutup_steps.value()), seed=int(self.spin_cutup_seed.value()),
                slice_divisions=int(self.spin_cutup_divs.value()), pitch_range_st=float(self.spin_cutup_pitch_range.value()),
                rate_depth=float(self.spin_cutup_rate_depth.value()), reverse_probability=float(self.spin_cutup_reverse.value()),
                normalize_shift_st=float(self._cutup_pitch_shift), phase_lock=int(self.spin_cutup_phase.value()),
            )
            ev = self._cutup_events[:4]
            preview = " · ".join(f"#{e.step}: {e.start_s:.2f}s {e.pitch_semitones:+.2f}st {e.rate:.2f}×{' REV' if e.reverse else ''}" for e in ev)
            self.lbl_cutup_pattern.setText(f"{len(self._cutup_events)} phaselocked events generated. {preview}")
            self.lbl_status.setText("Cutup pattern generated deterministically from seed.")
        except Exception as e:
            QMessageBox.warning(self, "Cutup pattern", str(e))

    def _cutup_render(self):
        if not self._cutup_events:
            self._cutup_generate()
        if not self._cutup_events or not self._cutup_source_path:
            return
        base = os.path.splitext(os.path.basename(self._cutup_source_path))[0] + f"_cutup_{int(self.spin_cutup_seed.value())}.wav"
        out, _ = QFileDialog.getSaveFileName(self, "Render cutup / beat", os.path.join(self._host_exports_dir(), base), "WAV (*.wav);;FLAC (*.flac);;MP3 (*.mp3);;Opus (*.opus);;OGG (*.ogg)")
        if not out:
            return
        try:
            from media_cutup_engine import render_cutup
            out = render_cutup(
                self._cutup_source_path, out, self._cutup_events,
                bpm=float(self.spin_cutup_bpm.value()), steps_per_bar=int(self.spin_cutup_steps.value()),
                sample_rate=int(getattr(self.host, "play_sample_rate", 48000) or 48000),
                resample_mode=self.cmb_cutup_resample.currentText(), normalize_peak=True,
            )
            self.lbl_status.setText(f"Cutup rendered: {os.path.basename(out)}")
            self.refresh()
        except Exception as e:
            QMessageBox.warning(self, "Cutup render", str(e))

    def _cutup_seed_playlist(self):
        if not self._playlist:
            self._add_to_playlist()
        if not self._playlist:
            QMessageBox.information(self, "Cutup Lab", "Add media to the Performance playlist first.")
            return
        try:
            from media_cutup_engine import playlist_geometric_parameters
            params = playlist_geometric_parameters(
                len(self._playlist), int(self.spin_cutup_seed.value()),
                pitch_range_st=float(self.spin_cutup_pitch_range.value()),
                rate_depth=float(self.spin_cutup_rate_depth.value()), phase_lock=int(self.spin_cutup_phase.value()),
            )
            decorated = []
            for item, param in zip(self._playlist, params):
                item.update(param)
                decorated.append((float(param["geometry_key"]), item))
            decorated.sort(key=lambda pair: pair[0])
            self._playlist = [item for _key, item in decorated]
            self._playlist_index = 0
            self._refresh_playlist_widget()
            self.lbl_status.setText("Playlist selection/pitch/rate/resampling seeded from Cutup Lab geometry.")
        except Exception as e:
            QMessageBox.warning(self, "Seed playlist", str(e))

    def _cutup_render_av(self, output_path: Optional[str] = None):
        if not self._cutup_events:
            self._cutup_generate()
        if not self._cutup_events or not self._cutup_source_path:
            return None
        if not self._cutup_video_path or not os.path.isfile(self._cutup_video_path):
            self._cutup_use_selected_video()
        if not self._cutup_video_path:
            return None
        if output_path is None:
            base = os.path.splitext(os.path.basename(self._cutup_source_path))[0] + f"_avcutup_{int(self.spin_cutup_seed.value())}.mp4"
            output_path, _ = QFileDialog.getSaveFileName(self, "Render audiovisual cutup", os.path.join(self._host_exports_dir(), base), "MP4 (*.mp4)")
            if not output_path:
                return None
        try:
            from media_cutup_engine import render_av_cutup
            out = render_av_cutup(
                self._cutup_source_path, self._cutup_video_path, output_path, self._cutup_events,
                bpm=float(self.spin_cutup_bpm.value()), steps_per_bar=int(self.spin_cutup_steps.value()),
                sample_rate=int(getattr(self.host, "play_sample_rate", 48000) or 48000),
                resample_mode=self.cmb_cutup_resample.currentText(),
                video_fps=int(getattr(self.host, "_last_export_fps", 30) or 30),
            )
            self.lbl_status.setText(f"A/V cutup rendered: {os.path.basename(out)}")
            self.refresh()
            return out
        except Exception as e:
            QMessageBox.warning(self, "A/V cutup render", str(e))
            return None

    def _cutup_auto_perform(self):
        """One-click deterministic render -> replay -> game/network broadcast."""
        if not self._cutup_events:
            self._cutup_generate()
        if not self._cutup_events:
            return
        os.makedirs(self._host_exports_dir(), exist_ok=True)
        seed = int(self.spin_cutup_seed.value())
        if self._cutup_video_path and os.path.isfile(self._cutup_video_path):
            out = os.path.join(self._host_exports_dir(), f"auto_avcutup_{seed}.mp4")
            rendered = self._cutup_render_av(out)
        else:
            out = os.path.join(self._host_exports_dir(), f"auto_cutup_{seed}.wav")
            try:
                from media_cutup_engine import render_cutup
                rendered = render_cutup(
                    self._cutup_source_path, out, self._cutup_events,
                    bpm=float(self.spin_cutup_bpm.value()), steps_per_bar=int(self.spin_cutup_steps.value()),
                    sample_rate=int(getattr(self.host, "play_sample_rate", 48000) or 48000),
                    resample_mode=self.cmb_cutup_resample.currentText(), normalize_peak=True,
                )
            except Exception as e:
                QMessageBox.warning(self, "Auto performance", str(e)); return
        if rendered:
            self._start_performance(rendered, loop=True)

    # ------------------------------------------------------------------ live performance / ethernet
    def _build_performance_tab(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Phaselocked Live Broadcast</b>"))
        txt = QLabel("Replays the generated beat/A/V cutup while broadcasting the exact same step, phase, pitch, rate and slice state to the game runtime and optional Ethernet clients.")
        txt.setWordWrap(True); lay.addWidget(txt)
        self.chk_perf_loop = QCheckBox("Loop replay continuously"); self.chk_perf_loop.setChecked(True); lay.addWidget(self.chk_perf_loop)
        self.chk_perf_game = QCheckBox("Broadcast canonical cutup state to game runtime"); self.chk_perf_game.setChecked(True); lay.addWidget(self.chk_perf_game)
        row = QHBoxLayout()
        bstart = QPushButton("▶ Start current cutup broadcast"); bstart.clicked.connect(lambda: self._start_performance(self._performance_media_path, self.chk_perf_loop.isChecked()))
        bstop = QPushButton("■ Stop broadcast"); bstop.clicked.connect(self._stop_performance)
        row.addWidget(bstart); row.addWidget(bstop); lay.addLayout(row)
        qos = QGroupBox("Live quality / canonical projection")
        qf = QFormLayout(qos)
        self.cmb_perf_qos = QComboBox(); self.cmb_perf_qos.addItems(["Auto (recommended)", "Low-latency", "Full detail"]); qf.addRow("Performance QoS", self.cmb_perf_qos)
        self.chk_relativity = QCheckBox("Relativity projection (downstream; preserves canonical ID)"); self.chk_relativity.setChecked(False); qf.addRow(self.chk_relativity)
        self.spin_relativity_beta = QDoubleSpinBox(); self.spin_relativity_beta.setRange(-0.99,0.99); self.spin_relativity_beta.setDecimals(4); self.spin_relativity_beta.setSingleStep(0.01); self.spin_relativity_beta.setValue(0.0); qf.addRow("β = v/c", self.spin_relativity_beta)
        self.spin_relativity_amount = QDoubleSpinBox(); self.spin_relativity_amount.setRange(0.0,8.0); self.spin_relativity_amount.setDecimals(3); self.spin_relativity_amount.setValue(1.0); qf.addRow("Projection amount", self.spin_relativity_amount)
        self.lbl_relativity_credit = QLabel("Standard SR math · NASA Trick/cFS/CML credited as simulation-engineering inspiration · no NASA code copied")
        self.lbl_relativity_credit.setWordWrap(True); self.lbl_relativity_credit.setStyleSheet("color:#91b9c9;font-size:8pt;"); qf.addRow(self.lbl_relativity_credit)
        lay.addWidget(qos)
        net = QGroupBox("Ethernet host"); nf = QFormLayout(net)
        self.spin_remote_port = QSpinBox(); self.spin_remote_port.setRange(1024, 65535); self.spin_remote_port.setValue(8765); nf.addRow("Port", self.spin_remote_port)
        self.lbl_remote = QLabel("Stopped"); self.lbl_remote.setWordWrap(True); nf.addRow("Status", self.lbl_remote)
        nr = QHBoxLayout(); bon = QPushButton("Start LAN host"); bon.clicked.connect(self._start_remote_server); boff = QPushButton("Stop LAN host"); boff.clicked.connect(self._stop_remote_server); nr.addWidget(bon); nr.addWidget(boff); nf.addRow(nr)
        lay.addWidget(net)
        radio = QGroupBox("◉ GOAVA LAN Radio · 192 kbps MP3")
        rf = QVBoxLayout(radio)
        self.lbl_radio_status = QLabel("Radio stopped")
        self.lbl_radio_status.setWordWrap(True); rf.addWidget(self.lbl_radio_status)
        rr = QHBoxLayout()
        rstart = QPushButton("▶ Start Radio + discovery"); rstart.clicked.connect(self._start_goava_radio)
        rstop = QPushButton("■ Stop Radio"); rstop.clicked.connect(self._stop_goava_radio)
        rrefresh = QPushButton("↻ Nearby Radios"); rrefresh.clicked.connect(self._refresh_radio_peers)
        rr.addWidget(rstart); rr.addWidget(rstop); rr.addWidget(rrefresh); rf.addLayout(rr)
        self.lst_radio_peers = QListWidget(); self.lst_radio_peers.setMaximumHeight(132); rf.addWidget(self.lst_radio_peers)
        hint = QLabel("OS/appliance helper can redirect TCP/80 → Radio :8780 so nearby devices can open http://device/ directly.")
        hint.setWordWrap(True); hint.setStyleSheet("color:#8ab4c8;font-size:9pt;"); rf.addWidget(hint)
        lay.addWidget(radio); lay.addStretch(1); return w

    def _start_goava_radio(self):
        try:
            from radio_station import RadioStationService
            if self._goava_radio_service is None:
                roots = [self._host_projects_dir(), self._host_exports_dir(), self._host_samples_dir()]
                self._goava_radio_service = RadioStationService(roots=roots, port=8780)
            url = self._goava_radio_service.start()
            self.lbl_radio_status.setText(f"Broadcasting: {url} · 192 kbps MP3")
            self._radio_peer_timer.start(); self._refresh_radio_peers()
        except Exception as e:
            QMessageBox.warning(self, "GOAVA Radio", str(e))

    def _stop_goava_radio(self):
        try:
            if self._goava_radio_service is not None: self._goava_radio_service.stop()
        except Exception: pass
        self._goava_radio_service = None
        self._radio_peer_timer.stop()
        if hasattr(self, "lbl_radio_status"): self.lbl_radio_status.setText("Radio stopped")

    def _refresh_radio_peers(self):
        if not hasattr(self, "lst_radio_peers"): return
        self.lst_radio_peers.clear()
        svc = self._goava_radio_service
        peers = svc.peer_list() if svc is not None else []
        if not peers:
            self.lst_radio_peers.addItem("No nearby Groovebox radios discovered yet.")
            return
        for p in peers:
            self.lst_radio_peers.addItem(f"{p.get('name','Radio')}  ·  {p.get('url','')}")

    def _start_performance(self, media_path: Optional[str] = None, loop: bool = True):
        if not self._cutup_events:
            self._cutup_generate()
        if not self._cutup_events:
            return
        if media_path and os.path.isfile(media_path):
            self._performance_media_path = media_path
            self._stop_player()
            cmd = _find_player()
            if cmd:
                player_name = os.path.basename(cmd[0]).lower()
                if player_name.startswith("mpv") and loop:
                    cmd = list(cmd) + ["--loop-file=inf"]
                elif player_name.startswith("vlc") and loop:
                    cmd = list(cmd) + ["--loop"]
                try:
                    cmd, penv = self._routed_player(cmd, want_video=(os.path.splitext(media_path)[1].lower() in VIDEO_EXT))
                    self._player_proc = subprocess.Popen(cmd + [media_path], env=penv)
                    # VLC can otherwise hand a file to an existing instance and make
                    # the child disappear immediately. --no-one-instance above avoids
                    # that; a short deferred poll still surfaces real launch failures.
                    QTimer.singleShot(450, lambda p=self._player_proc, mp=media_path: self._check_player_launch(p, mp))
                    try:
                        if self._media_share_server is not None:
                            self._media_share_server.set_current(media_path)
                    except Exception:
                        pass
                except Exception:
                    pass
        self._performance_loop = bool(loop)
        self._performance_step = 0
        step_ms = max(10, int(round((60.0 / float(self.spin_cutup_bpm.value()) * 4.0 / int(self.spin_cutup_steps.value())) * 1000.0)))
        self._performance_timer.setInterval(step_ms)
        self._performance_timer.start()
        self._broadcast_state = {"active": True, "step": 0, "seed": int(self.spin_cutup_seed.value())}
        self.lbl_status.setText("Phaselocked replay/game/Ethernet broadcast active.")

    def _performance_tick(self):
        if not self._cutup_events:
            self._stop_performance(); return
        idx = self._performance_step % len(self._cutup_events)
        ev = self._cutup_events[idx]
        state = {
            "active": True, "event_index": idx, "step": int(ev.step), "phase": float(ev.phase),
            "pitch_semitones": float(ev.pitch_semitones), "rate": float(ev.rate), "gain": float(ev.gain),
            "pan": float(ev.pan), "reverse": bool(ev.reverse), "source_start_s": float(ev.start_s),
            "source_duration_s": float(ev.duration_s), "seed": int(self.spin_cutup_seed.value()),
            "bpm": float(self.spin_cutup_bpm.value()), "timestamp": time.time(),
        }
        if getattr(self, "chk_relativity", None) is not None and self.chk_relativity.isChecked():
            try:
                from relativity_projection import project_event
                state = project_event(state, self.spin_relativity_beta.value(), self.spin_relativity_amount.value())
            except Exception as exc:
                state["relativity_error"] = str(exc)
        # QoS is representational only; receivers may skip expensive visuals, never audio/state.
        try:
            _q = self.cmb_perf_qos.currentText() if hasattr(self, "cmb_perf_qos") else "Auto (recommended)"
            state["performance_qos"] = "low" if _q.startswith("Low") else ("full" if _q.startswith("Full") else "auto")
        except Exception:
            state["performance_qos"] = "auto"
        self._broadcast_state = state
        if getattr(self, "chk_perf_game", None) is None or self.chk_perf_game.isChecked():
            try:
                setattr(self.host, "_performance_broadcast_state", dict(state))
                setattr(self.host, "_media_hub_broadcast_state", dict(state))
                cb = getattr(self.host, "on_media_hub_broadcast", None) or getattr(self.host, "_on_media_hub_broadcast", None)
                if callable(cb): cb(dict(state))
            except Exception:
                pass
        self._performance_step += 1
        if self._performance_step >= len(self._cutup_events) and not self._performance_loop:
            self._stop_performance()

    def _stop_performance(self):
        self._performance_timer.stop()
        self._broadcast_state = {"active": False, "timestamp": time.time()}
        try: setattr(self.host, "_performance_broadcast_state", dict(self._broadcast_state)); setattr(self.host, "_media_hub_broadcast_state", dict(self._broadcast_state))
        except Exception: pass
        self.lbl_status.setText("Live broadcast stopped.")

    def _lan_ip(self) -> str:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); sock.connect(("8.8.8.8", 80)); ip = sock.getsockname()[0]; sock.close(); return ip
        except Exception:
            return "127.0.0.1"

    def _start_remote_server(self):
        if self._remote_server is not None:
            return
        owner = self
        class Handler(BaseHTTPRequestHandler):
            def _json(self, code, payload):
                raw = json.dumps(payload).encode("utf-8"); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
            def do_GET(self):
                if self.path.split("?",1)[0] == "/status": self._json(200, dict(owner._broadcast_state)); return
                self._json(404, {"error":"not found"})
            def do_POST(self):
                if self.headers.get("X-Groovebox-Token", "") != owner._remote_token:
                    self._json(403, {"error":"bad token"}); return
                try:
                    n = min(4096, int(self.headers.get("Content-Length", "0") or 0)); payload = json.loads(self.rfile.read(n) or b"{}")
                except Exception:
                    self._json(400, {"error":"bad json"}); return
                with owner._remote_lock: owner._remote_commands.append(payload if isinstance(payload, dict) else {})
                self._json(202, {"queued": True})
            def log_message(self, *_args): pass
        try:
            self._remote_server = ThreadingHTTPServer(("0.0.0.0", int(self.spin_remote_port.value())), Handler)
            self._remote_thread = threading.Thread(target=self._remote_server.serve_forever, daemon=True); self._remote_thread.start()
            if not self._remote_timer.isActive(): self._remote_timer.start()
            self.lbl_remote.setText(f"http://{self._lan_ip()}:{self.spin_remote_port.value()}/status · control token: {self._remote_token}")
        except Exception as e:
            self._remote_server = None; QMessageBox.warning(self, "Ethernet host", str(e))

    def _stop_remote_server(self):
        try: self._remote_timer.stop()
        except Exception: pass
        with self._remote_lock:
            self._remote_commands.clear()
        srv = self._remote_server; self._remote_server = None
        if srv is not None:
            try: srv.shutdown(); srv.server_close()
            except Exception: pass
        if hasattr(self, "lbl_remote"): self.lbl_remote.setText("Stopped")

    def _drain_remote_commands(self):
        with self._remote_lock:
            cmds = self._remote_commands[:]; self._remote_commands.clear()
        for cmd in cmds:
            action = str(cmd.get("action", "")).lower()
            if action == "start": self._start_performance(self._performance_media_path, bool(cmd.get("loop", True)))
            elif action == "stop": self._stop_performance()
            elif action == "next": self._playlist_next()
            elif action == "previous": self._playlist_prev()
            elif action == "speed":
                try: self._set_live_speed(float(cmd.get("value", 1.0)))
                except Exception: pass

    # ------------------------------------------------------------------ outputs / Wi-Fi TV
    def _build_outputs_tab(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Device Outputs · Wi-Fi TV · Game Share</b>"))
        intro = QLabel(
            "Route the same Performance stream to hot-plugged HDMI/VGA/USB displays and "
            "PipeWire/Pulse audio sinks (including paired Bluetooth/USB/HDMI audio). A local "
            "Wi-Fi/LAN TV page can play the programmed mixed-type playlist; game .zip packages "
            "can be shared to another box without executing them on the receiver."
        )
        intro.setWordWrap(True); lay.addWidget(intro)

        dev = QGroupBox("Local device routing"); df = QFormLayout(dev)
        self.cmb_output_display = QComboBox(); df.addRow("Display", self.cmb_output_display)
        self.cmb_output_audio = QComboBox(); df.addRow("Audio sink", self.cmb_output_audio)
        drow = QHBoxLayout()
        bref = QPushButton("↻ Detect HDMI/VGA/USB/Bluetooth"); bref.clicked.connect(self._refresh_output_devices)
        bapply = QPushButton("Apply to new playback"); bapply.clicked.connect(self._apply_output_routing)
        drow.addWidget(bref); drow.addWidget(bapply); df.addRow(drow)
        self.lbl_output_devices = QLabel("Not scanned yet."); self.lbl_output_devices.setWordWrap(True); df.addRow("Detected", self.lbl_output_devices)
        lay.addWidget(dev)

        tv = QGroupBox("Wi-Fi / Ethernet TV output"); tf = QFormLayout(tv)
        self.spin_tv_port = QSpinBox(); self.spin_tv_port.setRange(1024, 65535); self.spin_tv_port.setValue(8780); tf.addRow("TV host port", self.spin_tv_port)
        self.lbl_tv_url = QLabel("Stopped"); self.lbl_tv_url.setWordWrap(True); self.lbl_tv_url.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); tf.addRow("TV URL", self.lbl_tv_url)
        trow = QHBoxLayout()
        btvon = QPushButton("Start TV host + publish playlist"); btvon.clicked.connect(self._start_tv_host)
        bpub = QPushButton("Republish playlist"); bpub.clicked.connect(self._publish_tv_playlist)
        btvoff = QPushButton("Stop TV host"); btvoff.clicked.connect(self._stop_tv_host)
        trow.addWidget(btvon); trow.addWidget(bpub); trow.addWidget(btvoff); tf.addRow(trow)
        crow = QHBoxLayout()
        bcast = QPushButton("Cast TV URL (catt/Chromecast)"); bcast.clicked.connect(self._cast_tv_url)
        bgame = QPushButton("Share selected game .zip"); bgame.clicked.connect(self._share_selected_game)
        crow.addWidget(bcast); crow.addWidget(bgame); tf.addRow(crow)
        self.lbl_game_share = QLabel("No game package shared."); self.lbl_game_share.setWordWrap(True); self.lbl_game_share.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); tf.addRow("Game share", self.lbl_game_share)
        lay.addWidget(tv)

        note = QLabel(
            "Display routing is per new mpv process; USB DisplayLink/VGA adapters appear when the OS exposes them as displays. "
            "Bluetooth must already be paired/connected by the OS. The TV page uses normal HTTP media with byte-range support, "
            "so it works without a proprietary receiver app when the TV/browser supports the file codecs."
        )
        note.setWordWrap(True); note.setStyleSheet("color:#8ab4c8; font-size:9pt;"); lay.addWidget(note)
        lay.addStretch(1)
        QTimer.singleShot(0, self._refresh_output_devices)
        return w

    def _refresh_output_devices(self):
        try:
            from media_output_router import detect_displays, detect_audio_targets
            self._output_displays = detect_displays(); self._output_audio = detect_audio_targets()
            self.cmb_output_display.clear()
            for d in self._output_displays:
                tags = []
                if d.primary: tags.append("primary")
                if d.geometry: tags.append(d.geometry)
                self.cmb_output_display.addItem(d.name + (" · " + ", ".join(tags) if tags else ""))
            self.cmb_output_audio.clear()
            for a in self._output_audio:
                tag = f" [{a.kind}]" if a.kind and a.kind != "default" else ""
                self.cmb_output_audio.addItem(a.description + tag)
            self.lbl_output_devices.setText(f"{len(self._output_displays)} display target(s) · {max(0, len(self._output_audio)-1)} explicit audio sink(s)")
            self._apply_output_routing()
        except Exception as e:
            self.lbl_output_devices.setText(f"Device scan unavailable: {e}")

    def _apply_output_routing(self):
        di = self.cmb_output_display.currentIndex() if hasattr(self, "cmb_output_display") else -1
        ai = self.cmb_output_audio.currentIndex() if hasattr(self, "cmb_output_audio") else -1
        self._output_display = self._output_displays[di] if 0 <= di < len(self._output_displays) else None
        self._output_audio_target = self._output_audio[ai] if 0 <= ai < len(self._output_audio) else None
        dname = getattr(self._output_display, "name", "default") if self._output_display else "default"
        aname = getattr(self._output_audio_target, "description", "System default") if self._output_audio_target else "System default"
        self.lbl_status.setText(f"Output routing: display={dname} · audio={aname}")

    def _start_tv_host(self):
        try:
            from media_output_router import MediaShareServer
            if self._media_share_server is not None:
                self._media_share_server.stop()
            self._media_share_server = MediaShareServer(int(self.spin_tv_port.value()))
            self._media_share_server.start()
            self._publish_tv_playlist()
            self.lbl_tv_url.setText(self._media_share_server.tv_url())
            self.lbl_status.setText("Wi-Fi/LAN TV host active; open the TV URL in a browser/network player.")
        except Exception as e:
            self._media_share_server = None
            QMessageBox.warning(self, "TV host", str(e))

    def _publish_tv_playlist(self):
        if self._media_share_server is None:
            return
        try:
            self._media_share_server.set_playlist(self._playlist)
            if self._performance_media_path and os.path.isfile(self._performance_media_path):
                self._media_share_server.set_current(self._performance_media_path)
            self.lbl_tv_url.setText(self._media_share_server.tv_url())
            self.lbl_status.setText(f"TV playlist published: {len(self._media_share_server.playlist)} media item(s).")
        except Exception as e:
            QMessageBox.warning(self, "Publish TV playlist", str(e))

    def _stop_tv_host(self):
        srv, self._media_share_server = self._media_share_server, None
        if srv is not None:
            try: srv.stop()
            except Exception: pass
        if hasattr(self, "lbl_tv_url"): self.lbl_tv_url.setText("Stopped")

    def _cast_tv_url(self):
        if self._media_share_server is None:
            self._start_tv_host()
        if self._media_share_server is None:
            return
        try:
            from media_output_router import cast_with_catt
            ok, msg = cast_with_catt(self._media_share_server.tv_url())
            if ok: self.lbl_status.setText(msg)
            else: QMessageBox.information(self, "Chromecast handoff", msg + "\n\nThe TV URL remains usable directly in a smart-TV browser.")
        except Exception as e:
            QMessageBox.warning(self, "Chromecast handoff", str(e))

    def _share_selected_game(self):
        path = None
        for p in self._selected_paths():
            if os.path.isfile(p) and os.path.splitext(p)[1].lower() in GAME_EXT:
                path = p; break
        if path is None:
            QMessageBox.information(self, "Game share", "Select a packaged .zip game in the Performance browser first.")
            return
        if self._media_share_server is None:
            self._start_tv_host()
        if self._media_share_server is None:
            return
        try:
            key = self._media_share_server.share_game(path)
            self._last_shared_game_url = self._media_share_server.game_url(key)
            self.lbl_game_share.setText(self._last_shared_game_url)
            self.lbl_status.setText(f"Game package shared on LAN: {os.path.basename(path)}")
        except Exception as e:
            QMessageBox.warning(self, "Game share", str(e))

    # ------------------------------------------------------------------ drive / cloning
    def _build_transfer_tab(self) -> QWidget:
        w=QWidget(); lay=QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Operation Station Drive · Clone · Transfer</b>"))
        note=QLabel("Move projects/modules/samples/exports or clone this Operation Station build over Wi-Fi, Ethernet, or mounted USB storage. Clone bundles carry SHA-256 manifests and do not auto-execute on the receiving machine.")
        note.setWordWrap(True); lay.addWidget(note)
        grp=QGroupBox("Version clone"); f=QFormLayout(grp)
        self.chk_clone_source=QCheckBox("Source code"); self.chk_clone_source.setChecked(True); f.addRow(self.chk_clone_source)
        self.chk_clone_exec=QCheckBox("Build/executable kit"); self.chk_clone_exec.setChecked(True); f.addRow(self.chk_clone_exec)
        self.chk_clone_deps=QCheckBox("Dependency/offline install assets"); self.chk_clone_deps.setChecked(True); f.addRow(self.chk_clone_deps)
        self.chk_clone_content=QCheckBox("Include my projects/samples/modules"); self.chk_clone_content.setChecked(False); f.addRow(self.chk_clone_content)
        row=QHBoxLayout(); b=QPushButton("Create V3 Clone Bundle"); b.clicked.connect(self._create_clone_bundle); row.addWidget(b)
        b=QPushButton("Verify Bundle"); b.clicked.connect(self._verify_clone_bundle); row.addWidget(b); f.addRow(row)
        self.lbl_clone=QLabel("No clone bundle yet."); self.lbl_clone.setWordWrap(True); self.lbl_clone.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); f.addRow("Bundle",self.lbl_clone)
        lay.addWidget(grp)
        net=QGroupBox("Wi-Fi / Ethernet share"); nf=QFormLayout(net)
        self.spin_clone_port=QSpinBox(); self.spin_clone_port.setRange(1024,65535); self.spin_clone_port.setValue(8783); nf.addRow("Port",self.spin_clone_port)
        nr=QHBoxLayout(); b=QPushButton("Start Clone Share"); b.clicked.connect(self._start_clone_share); nr.addWidget(b); b=QPushButton("Stop"); b.clicked.connect(self._stop_clone_share); nr.addWidget(b); nf.addRow(nr)
        self.lbl_clone_url=QLabel("Stopped"); self.lbl_clone_url.setWordWrap(True); self.lbl_clone_url.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); nf.addRow("Network URL",self.lbl_clone_url)
        lay.addWidget(net)

        nearby=QGroupBox("Nearby Grooveboxes · router-free Wi-Fi Share")
        nv=QVBoxLayout(nearby)
        nn=QLabel("Nearby presence is automatic whenever Groovebox is running. Devices may use an existing LAN or a self-hosted Groovebox Direct Wi-Fi link; Internet and a router are not required. Direct hotspot mode is explicit because some single-radio adapters must leave their current Wi-Fi to host it.")
        nn.setWordWrap(True); nv.addWidget(nn)
        self.chk_nearby_receive=QCheckBox("Allow incoming files from nearby Grooveboxes")
        self.chk_nearby_receive.setChecked(False); self.chk_nearby_receive.toggled.connect(self._nearby_set_receive); nv.addWidget(self.chk_nearby_receive)
        dr=QHBoxLayout()
        b=QPushButton("↻ Scan Nearby"); b.clicked.connect(self._nearby_scan_now); dr.addWidget(b)
        b=QPushButton("Start Direct Wi-Fi"); b.clicked.connect(self._nearby_start_direct); dr.addWidget(b)
        b=QPushButton("Stop Direct Wi-Fi"); b.clicked.connect(self._nearby_stop_direct); dr.addWidget(b)
        nv.addLayout(dr)
        self.lbl_nearby_direct=QLabel("Direct-link status: checking capabilities…"); self.lbl_nearby_direct.setWordWrap(True); nv.addWidget(self.lbl_nearby_direct)
        self.lst_nearby=QListWidget(); self.lst_nearby.setMinimumHeight(115); nv.addWidget(QLabel("Nearby Grooveboxes / Direct radios")); nv.addWidget(self.lst_nearby)
        pr=QHBoxLayout()
        b=QPushButton("Join Selected Direct Radio"); b.clicked.connect(self._nearby_join_selected); pr.addWidget(b)
        b=QPushButton("Browse Selected Groovebox"); b.clicked.connect(self._nearby_browse_selected); pr.addWidget(b)
        nv.addLayout(pr)
        hist=QLabel("Known Grooveboxes history (metadata only; received files are separate)"); hist.setWordWrap(True); nv.addWidget(hist)
        self.lst_nearby_history=QListWidget(); self.lst_nearby_history.setMinimumHeight(90); nv.addWidget(self.lst_nearby_history)
        hr=QHBoxLayout()
        b=QPushButton("Forget Selected"); b.clicked.connect(self._nearby_forget_selected_history); hr.addWidget(b)
        b=QPushButton("Reset Known Grooveboxes History"); b.clicked.connect(self._nearby_reset_history); hr.addWidget(b)
        nv.addLayout(hr)
        self.lst_nearby_files=QListWidget(); self.lst_nearby_files.setMinimumHeight(130); nv.addWidget(QLabel("Shared files on selected Groovebox")); nv.addWidget(self.lst_nearby_files)
        tr=QHBoxLayout()
        b=QPushButton("Receive Selected File"); b.clicked.connect(self._nearby_download_selected); tr.addWidget(b)
        b=QPushButton("Send File to Selected Groovebox"); b.clicked.connect(self._nearby_send_file); tr.addWidget(b)
        nv.addLayout(tr)
        self.lbl_nearby_progress=QLabel("Idle"); self.lbl_nearby_progress.setWordWrap(True); nv.addWidget(self.lbl_nearby_progress)
        lay.addWidget(nearby)
        QTimer.singleShot(0,self._refresh_nearby_ui)

        usb=QGroupBox("USB / mounted drive"); uf=QFormLayout(usb)
        self.cmb_clone_mount=QComboBox(); uf.addRow("Destination",self.cmb_clone_mount)
        ur=QHBoxLayout(); b=QPushButton("↻ Detect Drives"); b.clicked.connect(self._refresh_clone_mounts); ur.addWidget(b); b=QPushButton("Copy Clone to Drive"); b.clicked.connect(self._copy_clone_to_mount); ur.addWidget(b); uf.addRow(ur)
        lay.addWidget(usb); lay.addStretch(1); QTimer.singleShot(0,self._refresh_clone_mounts); return w

    def _nearby_service(self):
        return getattr(self.host, "_nearby_share_service", None)

    def _nearby_async(self, kind, fn):
        def run():
            try: self._nearby_bridge.result.emit(kind, fn(), "")
            except Exception as e: self._nearby_bridge.result.emit(kind, None, str(e))
        threading.Thread(target=run,name=f"nearby-{kind}",daemon=True).start()

    def _nearby_set_receive(self, checked):
        svc=self._nearby_service()
        if svc is not None: svc.set_incoming_enabled(bool(checked))
        self.lbl_nearby_progress.setText("Incoming file reception enabled." if checked else "Incoming file reception disabled; discovery remains active.")

    def _refresh_nearby_ui(self):
        svc=self._nearby_service()
        if svc is None or not hasattr(self,'lst_nearby'): return
        try:
            peers=svc.peer_list(); direct=svc.direct_candidate_list()
            old=self.lst_nearby.currentRow(); self.lst_nearby.clear(); self._nearby_peer_rows=[]
            for p in peers:
                item=QListWidgetItem(f"● {p.get('name','Groovebox')} · {p.get('ip','?')}:{p.get('port','?')} · {p.get('platform','')}")
                item.setData(Qt.ItemDataRole.UserRole,{"kind":"peer","data":p}); self.lst_nearby.addItem(item); self._nearby_peer_rows.append(p)
            for d in direct:
                item=QListWidgetItem(f"◉ {d.get('ssid','Groovebox Direct')} · signal {d.get('signal',0)}% · router-free")
                item.setData(Qt.ItemDataRole.UserRole,{"kind":"direct","data":d}); self.lst_nearby.addItem(item)
            if self.lst_nearby.count() and old >= 0: self.lst_nearby.setCurrentRow(min(old,self.lst_nearby.count()-1))
            if hasattr(self,'lst_nearby_history'):
                self.lst_nearby_history.clear()
                for h in svc.history_list():
                    seen=float(h.get('last_seen',0) or 0); when=time.strftime('%Y-%m-%d %H:%M',time.localtime(seen)) if seen else 'unknown'
                    item=QListWidgetItem(f"{h.get('name','Groovebox')} · last seen {when} · {h.get('platform','')}")
                    item.setData(Qt.ItemDataRole.UserRole,h); self.lst_nearby_history.addItem(item)
            caps=svc.direct.capabilities() if getattr(svc,'direct',None) is not None else {}
            self.lbl_nearby_direct.setText(f"Direct link: host={'yes' if caps.get('host') else 'no'} · scan={'yes' if caps.get('scan') else 'no'} · join={'yes' if caps.get('join') else 'no'} · SSID {caps.get('ssid','—')}" + (f"\n{caps.get('reason')}" if caps.get('reason') else ""))
        except Exception as e: self.lbl_nearby_progress.setText(f"Nearby refresh: {e}")

    def _nearby_forget_selected_history(self):
        svc=self._nearby_service(); it=self.lst_nearby_history.currentItem() if hasattr(self,'lst_nearby_history') else None
        if svc is None or it is None: return
        row=it.data(Qt.ItemDataRole.UserRole) or {}; name=row.get('name','Groovebox')
        if QMessageBox.question(self,"Forget Known Groovebox",f"Forget discovery history for {name}?\n\nThis does not delete any files received from that Groovebox.") != QMessageBox.StandardButton.Yes: return
        svc.forget_peer(str(row.get('node_id',''))); self._refresh_nearby_ui()

    def _nearby_reset_history(self):
        svc=self._nearby_service()
        if svc is None: return
        if QMessageBox.question(self,"Reset Known Grooveboxes History","Clear all remembered Groovebox discovery history?\n\nReceived files, projects, samples and the identity of this Groovebox are not changed.") != QMessageBox.StandardButton.Yes: return
        n=svc.reset_history(); self.lbl_nearby_progress.setText(f"Cleared {n} remembered Groovebox(es).")
        self._refresh_nearby_ui()

    def _nearby_scan_now(self):
        svc=self._nearby_service()
        if svc is None: return
        self.lbl_nearby_progress.setText("Scanning local IP peers and Groovebox Direct radios…")
        self._nearby_async("scan", lambda: svc.scan_direct_now())

    def _nearby_start_direct(self):
        svc=self._nearby_service()
        if svc is None: return
        ans=QMessageBox.question(self,"Start Groovebox Direct Wi-Fi",
            "Start a router-free Groovebox Wi-Fi network?\n\nOn some single-radio PCs/tablets this may disconnect the current Wi-Fi while the direct network is active.")
        if ans != QMessageBox.StandardButton.Yes: return
        self.lbl_nearby_progress.setText("Starting Groovebox Direct Wi-Fi…")
        self._nearby_async("direct_start", svc.start_direct_hotspot)

    def _nearby_stop_direct(self):
        svc=self._nearby_service()
        if svc is not None: self._nearby_async("direct_stop", svc.stop_direct_hotspot)

    def _nearby_selected_payload(self):
        it=self.lst_nearby.currentItem() if hasattr(self,'lst_nearby') else None
        return it.data(Qt.ItemDataRole.UserRole) if it is not None else None

    def _nearby_join_selected(self):
        svc=self._nearby_service(); sel=self._nearby_selected_payload()
        if svc is None or not sel or sel.get('kind')!='direct':
            QMessageBox.information(self,"Direct Link","Select a ◉ Groovebox Direct radio first."); return
        ssid=sel['data'].get('ssid',''); self.lbl_nearby_progress.setText(f"Joining {ssid}…")
        self._nearby_async("join",lambda:svc.join_direct(ssid))

    def _nearby_browse_selected(self):
        svc=self._nearby_service(); sel=self._nearby_selected_payload()
        if svc is None or not sel or sel.get('kind')!='peer':
            QMessageBox.information(self,"Browse Groovebox","Select a connected ● Groovebox peer first. If you only see a Direct radio, join it first."); return
        peer=sel['data']; self._nearby_active_peer=peer; self.lbl_nearby_progress.setText(f"Reading {peer.get('name','Groovebox')} catalog…")
        self._nearby_async("files",lambda:svc.fetch_files(peer))

    def _nearby_download_selected(self):
        svc=self._nearby_service(); peer=getattr(self,'_nearby_active_peer',None); it=self.lst_nearby_files.currentItem() if hasattr(self,'lst_nearby_files') else None
        if svc is None or peer is None or it is None: return
        row=it.data(Qt.ItemDataRole.UserRole); self.lbl_nearby_progress.setText(f"Receiving {row.get('name','file')}…")
        def progress(done,total,phase): self._nearby_bridge.progress.emit(int(done),int(total),phase)
        self._nearby_async("download",lambda:svc.download(peer,row,progress=progress))

    def _nearby_send_file(self):
        svc=self._nearby_service(); sel=self._nearby_selected_payload()
        if svc is None or not sel or sel.get('kind')!='peer':
            QMessageBox.information(self,"Send File","Select a connected ● Groovebox peer first."); return
        import groovebox_paths
        path,_=QFileDialog.getOpenFileName(self,"Send file to nearby Groovebox",self._cwd or groovebox_paths.base_dir(),"All files (*)")
        if not path:return
        peer=sel['data']; self._nearby_active_peer=peer; self.lbl_nearby_progress.setText(f"Sending {os.path.basename(path)}…")
        def progress(done,total,phase): self._nearby_bridge.progress.emit(int(done),int(total),phase)
        self._nearby_async("upload",lambda:svc.upload(peer,path,progress=progress))

    def _nearby_worker_progress(self,done,total,phase):
        pct=(100.0*done/total) if total else 0.0
        self.lbl_nearby_progress.setText(f"{phase.title()}: {pct:.1f}% · {_safe_size_bytes(done)} / {_safe_size_bytes(total) if total else '?'}")

    def _nearby_worker_result(self,kind,payload,error):
        if error:
            self.lbl_nearby_progress.setText(f"Nearby {kind} failed: {error}"); return
        if kind=='files':
            self._nearby_remote_rows=list(payload or []); self.lst_nearby_files.clear()
            for row in self._nearby_remote_rows:
                item=QListWidgetItem(f"{row.get('category','file')} · {row.get('path',row.get('name',''))} · {_safe_size_bytes(int(row.get('size',0) or 0))}")
                item.setData(Qt.ItemDataRole.UserRole,row); self.lst_nearby_files.addItem(item)
            self.lbl_nearby_progress.setText(f"{len(self._nearby_remote_rows)} shared file(s).")
        elif kind in ('direct_start','direct_stop','join'):
            ok,msg=payload if isinstance(payload,(list,tuple)) and len(payload)>=2 else (False,str(payload))
            self.lbl_nearby_progress.setText(("OK: " if ok else "Not available: ")+str(msg or kind))
        elif kind=='download': self.lbl_nearby_progress.setText(f"Received safely: {payload}")
        elif kind=='upload': self.lbl_nearby_progress.setText(f"Sent successfully: {payload.get('name','file') if isinstance(payload,dict) else payload}")
        elif kind=='scan': self.lbl_nearby_progress.setText(f"Direct radio scan found {len(payload or [])} Groovebox network(s).")
        self._refresh_nearby_ui()

    def _create_clone_bundle(self):
        try:
            from operation_station_transfer import create_clone_bundle
            import groovebox_paths
            outdir=Path(groovebox_paths.clones_dir()); outdir.mkdir(parents=True,exist_ok=True)
            stamp=time.strftime('%Y%m%d-%H%M%S'); out=outdir/f"MathematiciansGroovebox_V3_OperationStation_{stamp}.mgbclone.zip"
            self._last_clone_bundle=create_clone_bundle(os.path.dirname(__file__),str(out),include_source=self.chk_clone_source.isChecked(),include_executables=self.chk_clone_exec.isChecked(),include_dependencies=self.chk_clone_deps.isChecked(),include_user_content=self.chk_clone_content.isChecked(),user_data_root=groovebox_paths.base_dir())
            self.lbl_clone.setText(self._last_clone_bundle); self.lbl_status.setText("Versioned Operation Station clone created with SHA-256 manifest.")
        except Exception as e: QMessageBox.warning(self,"Create clone",str(e))

    def _verify_clone_bundle(self):
        path=self._last_clone_bundle
        if not path:
            import groovebox_paths
            path,_=QFileDialog.getOpenFileName(self,"Verify Operation Station clone",groovebox_paths.clones_dir(),"Groovebox clone (*.mgbclone.zip *.zip)")
        if not path: return
        try:
            from operation_station_transfer import verify_clone_bundle
            r=verify_clone_bundle(path); self.lbl_status.setText("Clone verified OK." if r['ok'] else "Clone verification failed: "+', '.join(r['bad'][:3]))
        except Exception as e: QMessageBox.warning(self,"Verify clone",str(e))

    def _start_clone_share(self):
        try:
            if not self._last_clone_bundle or not os.path.isfile(self._last_clone_bundle): self._create_clone_bundle()
            if not self._last_clone_bundle: return
            from operation_station_transfer import CloneShareServer
            self._stop_clone_share(); self._clone_share_server=CloneShareServer(os.path.dirname(self._last_clone_bundle),int(self.spin_clone_port.value()))
            urls=self._clone_share_server.start(); self.lbl_clone_url.setText('\n'.join(urls)); self.lbl_status.setText("Clone share active on Wi-Fi/Ethernet.")
        except Exception as e: QMessageBox.warning(self,"Clone share",str(e))

    def _stop_clone_share(self):
        srv,self._clone_share_server=self._clone_share_server,None
        if srv:
            try: srv.stop()
            except Exception: pass
        if hasattr(self,'lbl_clone_url'): self.lbl_clone_url.setText('Stopped')

    def _refresh_clone_mounts(self):
        try:
            from operation_station_transfer import detect_removable_mounts
            vals=detect_removable_mounts(); self.cmb_clone_mount.clear(); self.cmb_clone_mount.addItems(vals)
            if not vals: self.cmb_clone_mount.addItem(str(Path.home()))
        except Exception as e: self.lbl_status.setText(f"Drive detection: {e}")

    def _copy_clone_to_mount(self):
        if not self._last_clone_bundle or not os.path.isfile(self._last_clone_bundle): self._create_clone_bundle()
        if not self._last_clone_bundle: return
        try:
            from operation_station_transfer import copy_bundle
            dest=self.cmb_clone_mount.currentText().strip(); out=copy_bundle(self._last_clone_bundle,dest); self.lbl_status.setText(f"Clone copied: {out}")
        except Exception as e: QMessageBox.warning(self,"Copy clone",str(e))

    # ------------------------------------------------------------------ hardware
    # ------------------------------------------------------------------ storage maintenance
    def _build_storage_tab(self) -> QWidget:
        w=QWidget(); lay=QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Groovebox Storage Maintenance</b>"))
        note=QLabel("Storage cleanup keeps projects, imported originals, completed recordings and exports protected unless you explicitly choose a destructive category. Cache/temp/log cleanup is regenerable. Autosaves are managed separately so crash recovery is never silently erased.")
        note.setWordWrap(True); lay.addWidget(note)
        self.lbl_storage_summary=QLabel("Scanning storage…"); self.lbl_storage_summary.setWordWrap(True); self.lbl_storage_summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); lay.addWidget(self.lbl_storage_summary)
        row=QHBoxLayout()
        b=QPushButton("↻ Refresh Usage"); b.clicked.connect(self._refresh_storage_usage); row.addWidget(b)
        b=QPushButton("Emergency Free Space (Safe)"); b.clicked.connect(self._storage_safe_cleanup); row.addWidget(b)
        lay.addLayout(row)

        auto=QGroupBox("Autosaves / recovery files"); av=QVBoxLayout(auto)
        self.lst_storage_autosaves=QListWidget(); self.lst_storage_autosaves.setMinimumHeight(130); av.addWidget(self.lst_storage_autosaves)
        ar=QHBoxLayout(); b=QPushButton("Recover Selected"); b.clicked.connect(self._storage_recover_autosave); ar.addWidget(b); b=QPushButton("Delete Selected Autosave"); b.clicked.connect(self._storage_delete_autosave); ar.addWidget(b); av.addLayout(ar)
        lay.addWidget(auto)

        media=QGroupBox("Project media / exports"); mv=QVBoxLayout(media)
        mr=QHBoxLayout(); b=QPushButton("Find Unused Current-Project Media"); b.clicked.connect(self._storage_find_unused_media); mr.addWidget(b); b=QPushButton("Delete Listed Unused Media"); b.clicked.connect(self._storage_delete_unused_media); mr.addWidget(b); mv.addLayout(mr)
        self.lst_storage_unused=QListWidget(); self.lst_storage_unused.setMinimumHeight(115); mv.addWidget(self.lst_storage_unused)
        er=QHBoxLayout(); b=QPushButton("Delete Current Project Exports"); b.clicked.connect(self._storage_delete_project_exports); er.addWidget(b); b=QPushButton("Delete Global Exports"); b.clicked.connect(self._storage_delete_global_exports); er.addWidget(b); mv.addLayout(er)
        lay.addWidget(media); lay.addStretch(1)
        QTimer.singleShot(0,self._refresh_storage_usage)
        return w

    def _refresh_storage_usage(self):
        if not hasattr(self,'lbl_storage_summary'): return
        try:
            import groovebox_paths
            r=groovebox_paths.storage_report(); c=r['categories']; d=r['disk']; a=r['autosaves']
            parts=[f"Data root: {r['base']}", f"Groovebox data: {_safe_size_bytes(r['groovebox_bytes'])} in {r['groovebox_files']} files · disk free: {_safe_size_bytes(d['free'])}"]
            parts.append(" · ".join(f"{k.replace('_',' ').title()}: {_safe_size_bytes(v['bytes'])}" for k,v in c.items()))
            parts.append(f"Autosaves/recovery: {a['files']} · {_safe_size_bytes(a['bytes'])} (included within project data)")
            self.lbl_storage_summary.setText("\n".join(parts))
            if hasattr(self,'lst_storage_autosaves'):
                self.lst_storage_autosaves.clear()
                for row in a['items']:
                    when=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(float(row.get('mtime',0) or 0)))
                    notes=str(row.get('notes','') or '').strip().replace('\n',' ')
                    if len(notes)>90: notes=notes[:90]+'…'
                    text=f"{row.get('title','Untitled Project')} · {when} · {_safe_size_bytes(row.get('size',0))}"
                    if notes: text += f" · Notes: {notes}"
                    item=QListWidgetItem(text); item.setData(Qt.ItemDataRole.UserRole,row); self.lst_storage_autosaves.addItem(item)
        except Exception as e:
            self.lbl_storage_summary.setText(f"Storage scan failed: {e}")

    def _storage_safe_cleanup(self):
        if QMessageBox.question(self,"Emergency Free Space","Clear regenerable cache, temporary files, logs and incomplete recording scratch data?\n\nProjects, imported originals, completed recordings, autosaves and exports are preserved.") != QMessageBox.StandardButton.Yes: return
        try:
            import groovebox_paths
            r=groovebox_paths.cleanup_disposable(("cache","temp","logs","recording_scratch"))
            QMessageBox.information(self,"Storage cleanup",f"Freed {_safe_size_bytes(r['bytes'])} from {r['files']} file(s).")
            self._refresh_storage_usage()
        except Exception as e: QMessageBox.warning(self,"Storage cleanup failed",str(e))

    def _selected_storage_autosave(self):
        it=self.lst_storage_autosaves.currentItem() if hasattr(self,'lst_storage_autosaves') else None
        return it.data(Qt.ItemDataRole.UserRole) if it is not None else None

    def _storage_recover_autosave(self):
        row=self._selected_storage_autosave()
        if not row: return
        path=str(row.get('path','')); title=str(row.get('title','Untitled Project')); notes=str(row.get('notes','') or '')
        msg=f"Recover autosave for {title}?\n\nProject Notes:\n{notes[:1200] if notes else '(none)'}\n\nThis restores the working state without overwriting the last explicit save."
        if QMessageBox.question(self,"Recover Autosave",msg) != QMessageBox.StandardButton.Yes: return
        try:
            data=json.loads(Path(path).read_text(encoding='utf-8'))
            self.host._apply_project_snapshot(data)
            rp=Path(path)
            if rp.name=='autosave.MCC' and rp.parent.name=='metadata':
                proot=rp.parent.parent; mcc=sorted(proot.glob('*.MCC'))+sorted(proot.glob('*.mcc'))
                self.host._current_project_path=str(mcc[0] if mcc else proot/(title+'.MCC'))
            elif path.lower().endswith('.part'): self.host._current_project_path=path[:-5]
            try: self.host.reload_active_instrument_sequencer_ui()
            except Exception: pass
            try: self.host._refresh_after_file_input(reason='storage_recovery')
            except Exception: pass
            self.lbl_status.setText(f"Recovered working autosave: {title}")
        except Exception as e: QMessageBox.warning(self,"Recover failed",str(e))

    def _storage_delete_autosave(self):
        row=self._selected_storage_autosave()
        if not row: return
        if QMessageBox.question(self,"Delete Autosave",f"Delete only this recovery file for {row.get('title','Untitled Project')}?\n\nThe saved project and project media are not deleted.") != QMessageBox.StandardButton.Yes: return
        try:
            import groovebox_paths
            groovebox_paths.delete_autosave(str(row.get('path',''))); self._refresh_storage_usage()
        except Exception as e: QMessageBox.warning(self,"Delete autosave failed",str(e))

    def _storage_find_unused_media(self):
        if not hasattr(self,'lst_storage_unused'): return
        self.lst_storage_unused.clear(); self._storage_unused_candidates=[]
        path=str(getattr(self.host,'_current_project_path','') or '')
        if not path:
            QMessageBox.information(self,"Unused Media","Save or open the working project first so Groovebox can compare media references against its project document."); return
        try:
            import groovebox_paths
            rows=groovebox_paths.find_unreferenced_project_media(path); self._storage_unused_candidates=rows
            for row in rows:
                item=QListWidgetItem(f"{row.get('relative',row.get('path',''))} · {_safe_size_bytes(row.get('size',0))}"); item.setData(Qt.ItemDataRole.UserRole,row); self.lst_storage_unused.addItem(item)
            self.lbl_status.setText(f"Found {len(rows)} unreferenced media candidate(s); nothing was deleted.")
        except Exception as e: QMessageBox.warning(self,"Unused media scan failed",str(e))

    def _storage_delete_unused_media(self):
        rows=list(getattr(self,'_storage_unused_candidates',[]) or [])
        if not rows: return
        total=sum(int(r.get('size',0) or 0) for r in rows)
        if QMessageBox.question(self,"Delete Unused Media",f"Delete {len(rows)} listed unreferenced media file(s), totaling {_safe_size_bytes(total)}?\n\nOnly the files currently listed by the reference scan will be removed.") != QMessageBox.StandardButton.Yes: return
        try:
            import groovebox_paths
            r=groovebox_paths.delete_unreferenced_project_media(rows,str(getattr(self.host,'_current_project_path','') or ''))
            self._storage_unused_candidates=[]; self.lst_storage_unused.clear(); self._refresh_storage_usage(); self.refresh()
            QMessageBox.information(self,"Unused media",f"Deleted {r['files']} file(s), {_safe_size_bytes(r['bytes'])}.")
        except Exception as e: QMessageBox.warning(self,"Delete unused media failed",str(e))

    def _storage_delete_project_exports(self):
        path=str(getattr(self.host,'_current_project_path','') or '')
        if not path: QMessageBox.information(self,"Project Exports","No saved/open current project."); return
        if QMessageBox.question(self,"Delete Current Project Exports","Delete all generated exports for the current project?\n\nThe project, samples, recordings and autosaves are preserved.") != QMessageBox.StandardButton.Yes: return
        try:
            import groovebox_paths
            r=groovebox_paths.delete_project_exports(path); self._refresh_storage_usage(); self.refresh(); QMessageBox.information(self,"Project Exports",f"Deleted {r['files']} export file(s), {_safe_size_bytes(r['bytes'])}.")
        except Exception as e: QMessageBox.warning(self,"Delete exports failed",str(e))

    def _storage_delete_global_exports(self):
        if QMessageBox.question(self,"Delete Global Exports","Delete generated exports stored outside individual project folders?\n\nProject-local exports are not touched by this action.") != QMessageBox.StandardButton.Yes: return
        try:
            import groovebox_paths
            r=groovebox_paths.delete_all_global_exports(); self._refresh_storage_usage(); self.refresh(); QMessageBox.information(self,"Global Exports",f"Deleted {r['files']} file(s), {_safe_size_bytes(r['bytes'])}.")
        except Exception as e: QMessageBox.warning(self,"Delete exports failed",str(e))

    def _build_hardware_tab(self) -> QWidget:
        w=QWidget(); lay=QVBoxLayout(w)
        lay.addWidget(QLabel("<b>⌨ Hardware · keyboard · touch · controllers · audio · MIDI</b>"))
        intro=QLabel("Groovebox OS is intentionally dual-input: keyboard/mouse and touchscreen work together. This scanner reports the OS-visible devices; it never changes canonical composition state.")
        intro.setWordWrap(True); lay.addWidget(intro)
        self.txt_hardware=QTextEdit(); self.txt_hardware.setReadOnly(True); lay.addWidget(self.txt_hardware,1)
        row=QHBoxLayout(); b=QPushButton("↻ Rescan hardware"); b.clicked.connect(self._refresh_hardware); row.addWidget(b)
        b2=QPushButton("▣ Refresh media outputs"); b2.clicked.connect(self._refresh_output_devices); row.addWidget(b2); row.addStretch(1); lay.addLayout(row)
        QTimer.singleShot(0,self._refresh_hardware); return w

    def _refresh_hardware(self):
        try:
            from hardware_hub import scan, summary
            r=scan(); lines=[summary(r), "", "INPUT DEVICES"] + [f"  • {x}" for x in r.get("input_names",[])]
            lines += ["", "DISPLAYS"] + [f"  • {x}" for x in r.get("display_summary",[])]
            lines += ["", "AUDIO"] + [f"  • {x}" for x in r.get("audio_devices",[])[:24]]
            lines += ["", "MIDI"] + [f"  • {x}" for x in r.get("midi_inputs",[])[:24]]
            lines += ["", "BLUETOOTH"] + [f"  • {x}" for x in r.get("bluetooth_connected",[])[:24]]
            lines += ["", "TOOLS", "  " + " · ".join(f"{k}={'yes' if v else 'no'}" for k,v in r.get("tools",{}).items())]
            self.txt_hardware.setPlainText("\n".join(lines))
        except Exception as e:
            self.txt_hardware.setPlainText(f"Hardware scan failed: {e}")

    # ------------------------------------------------------------------ box mode
    def _build_box_tab(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Performance Box / Installation Mode</b>"))
        note = QLabel("Checks the small-PC/Pi runtime and generates a systemd service template. Device routing stays separate from canonical composition, so reconnecting HDMI/Bluetooth/LAN cannot change the seed result.")
        note.setWordWrap(True); lay.addWidget(note)
        self.lbl_box_status = QLabel("Not checked yet."); self.lbl_box_status.setWordWrap(True); lay.addWidget(self.lbl_box_status)
        row=QHBoxLayout()
        b=QPushButton("Check box readiness"); b.clicked.connect(self._check_box_readiness); row.addWidget(b)
        b2=QPushButton("Save systemd service template"); b2.clicked.connect(self._save_box_service); row.addWidget(b2)
        lay.addLayout(row)
        self.chk_box_autorecover=QCheckBox("Prefer automatic playback/device recovery after hot-plug"); self.chk_box_autorecover.setChecked(True); lay.addWidget(self.chk_box_autorecover)
        self.chk_box_preview_shed=QCheckBox("Protect audio first: shed preview/video quality before audio/event timing"); self.chk_box_preview_shed.setChecked(True); lay.addWidget(self.chk_box_preview_shed)
        lay.addStretch(1); QTimer.singleShot(0,self._check_box_readiness); return w

    def _check_box_readiness(self):
        try:
            from performance_box import status
            st=status(self._cwd or '.')
            self.lbl_box_status.setText(f"CPU threads: {st.cpu_count} · free storage: {st.free_gb:.1f} GB\nFFmpeg: {st.ffmpeg} · ffprobe: {st.ffprobe} · mpv: {st.mpv} · PipeWire/Pulse: {st.pipewire} · Bluetooth tools: {st.bluetoothctl}")
        except Exception as e: self.lbl_box_status.setText(f"Readiness check failed: {e}")

    def _save_box_service(self):
        try:
            from performance_box import systemd_unit
            import groovebox_paths
            path,_=QFileDialog.getSaveFileName(self,"Save Performance Box service",os.path.join(groovebox_paths.state_dir(),"groovebox-performance.service"),"systemd service (*.service)")
            if not path: return
            with open(path,'w',encoding='utf-8') as f: f.write(systemd_unit(os.path.dirname(__file__)))
            self.lbl_status.setText(f"Saved box service template: {path}")
        except Exception as e: QMessageBox.warning(self,"Box Mode",str(e))

    # ------------------------------------------------------------------ batch tab
    def _build_batch_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Batch re-render from linked project</b>"))
        lay.addWidget(QLabel(
            "Select exported media carrying source-project provenance OR select .mgpr projects directly. "
            "Project sets are rendered along an FPS/bitrate trend curve from the first item to the last."
        ))
        form = QFormLayout()
        self.spin_batch_fps = QSpinBox()
        self.spin_batch_fps.setRange(1, 120)
        self.spin_batch_fps.setValue(int(getattr(self.host, "_last_export_fps", 24) or 24))
        form.addRow("Target video FPS", self.spin_batch_fps)
        self.spin_batch_br = QSpinBox()
        self.spin_batch_br.setRange(32, 512)
        self.spin_batch_br.setValue(int(getattr(self.host, "_last_audio_bitrate_kbps", 192) or 192))
        self.spin_batch_br.setSuffix(" kbps")
        form.addRow("Target audio bitrate", self.spin_batch_br)
        self.spin_batch_fps_end = QSpinBox()
        self.spin_batch_fps_end.setRange(1, 120)
        self.spin_batch_fps_end.setValue(self.spin_batch_fps.value())
        form.addRow("Trend end FPS", self.spin_batch_fps_end)
        self.spin_batch_br_end = QSpinBox()
        self.spin_batch_br_end.setRange(32, 512)
        self.spin_batch_br_end.setValue(self.spin_batch_br.value())
        self.spin_batch_br_end.setSuffix(" kbps")
        form.addRow("Trend end bitrate", self.spin_batch_br_end)
        self.cmb_batch_curve = QComboBox()
        self.cmb_batch_curve.addItems(["Linear trend", "Ease-in", "Ease-out", "Smoothstep"])
        form.addRow("Project-set trend", self.cmb_batch_curve)
        self.cmb_batch_kind = QComboBox()
        self.cmb_batch_kind.addItems([
            "Audio WAV", "Audio MP3", "Audio Opus", "Audio OGG",
            "Video+Audio MP4", "Video-only MP4",
        ])
        form.addRow("Re-render as", self.cmb_batch_kind)
        self.chk_batch_preview = QCheckBox("Pi-safe: use preview rows for audio (faster)")
        self.chk_batch_preview.setChecked(True)
        form.addRow(self.chk_batch_preview)
        lay.addLayout(form)

        row = QHBoxLayout()
        btn_run = QPushButton("▶ Batch re-render selected")
        btn_run.clicked.connect(self._batch_rerender)
        btn_cancel = QPushButton("Cancel batch")
        btn_cancel.clicked.connect(lambda: setattr(self, "_batch_cancel", True))
        row.addWidget(btn_run)
        row.addWidget(btn_cancel)
        lay.addLayout(row)

        self.batch_log = QTextEdit()
        self.batch_log.setReadOnly(True)
        self.batch_log.setMaximumHeight(160)
        lay.addWidget(self.batch_log)
        return w

    def _batch_log(self, msg: str):
        self.batch_log.append(msg)
        self.lbl_status.setText(msg)

    def _batch_rerender(self):
        paths = [p for p in self._selected_paths() if os.path.isfile(p)]
        if not paths:
            QMessageBox.information(self, "Batch", "Select exported media or one/more .mgpr project files.")
            return
        self._batch_cancel = False
        fps0 = int(self.spin_batch_fps.value())
        br0 = int(self.spin_batch_br.value())
        fps1 = int(self.spin_batch_fps_end.value())
        br1 = int(self.spin_batch_br_end.value())
        kind = self.cmb_batch_kind.currentText()
        def trend(x: float) -> float:
            mode = self.cmb_batch_curve.currentText()
            x = max(0.0, min(1.0, x))
            if mode == "Ease-in": return x * x
            if mode == "Ease-out": return 1.0 - (1.0 - x) * (1.0 - x)
            if mode == "Smoothstep": return x * x * (3.0 - 2.0 * x)
            return x

        for idx, path in enumerate(paths):
            u = trend(0.0 if len(paths) <= 1 else idx / float(len(paths) - 1))
            fps = int(round(fps0 + (fps1 - fps0) * u))
            br = int(round(br0 + (br1 - br0) * u))
            setattr(self.host, "_last_export_fps", fps)
            setattr(self.host, "_last_audio_bitrate_kbps", br)
            if self._batch_cancel:
                self._batch_log("Batch cancelled.")
                break
            self._batch_log(f"→ {os.path.basename(path)}")
            project_path = path if os.path.splitext(path)[1].lower() in PROJECT_EXT else None
            prov = None if project_path else _extract_json_comment(path)
            if isinstance(prov, dict):
                project_path = prov.get("source_project_path") or prov.get("project_path")
            if not project_path or not os.path.isfile(str(project_path)):
                # Try same stem .mgpr beside media or in projects dir
                stem = os.path.splitext(os.path.basename(path))[0]
                candidates = [
                    os.path.splitext(path)[0] + ".mgpr",
                    os.path.join(self._host_projects_dir(), stem + ".mgpr"),
                    getattr(self.host, "_current_project_path", None),
                ]
                for c in candidates:
                    if c and os.path.isfile(c):
                        project_path = c
                        break
            if not project_path or not os.path.isfile(str(project_path)):
                self._batch_log(f"  skip: no linked project for {os.path.basename(path)}")
                continue
            try:
                with open(project_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                applied = False
                for name in ("_apply_project_snapshot", "apply_project_snapshot"):
                    fn = getattr(self.host, name, None)
                    if callable(fn):
                        fn(data)
                        applied = True
                        break
                if not applied:
                    self._batch_log(f"  skip: cannot apply project snapshot")
                    continue
                setattr(self.host, "_current_project_path", project_path)
                self._batch_log(f"  loaded {os.path.basename(project_path)} · trend fps={fps} bitrate={br}k")
            except Exception as e:
                self._batch_log(f"  load error: {e}")
                continue

            # Pi-safe preview rows for faster audio batch
            if self.chk_batch_preview.isChecked() and "Audio" in kind:
                if hasattr(self.host, "spin_preview_rows"):
                    try:
                        if self.host.spin_preview_rows.value() == 0:
                            self.host.spin_preview_rows.setValue(8)
                    except Exception:
                        pass

            try:
                if kind.startswith("Audio"):
                    fmt = kind.split()[-1].lower()
                    if hasattr(self.host, "export_mixdown_dialog"):
                        # Non-interactive path: render + write
                        self._batch_audio_export(fmt, br, path)
                    else:
                        self._batch_log("  no export_mixdown_dialog on host")
                elif "Video" in kind:
                    include_audio = "Video+Audio" in kind
                    if hasattr(self.host, "export_video_dialog"):
                        self._batch_log(
                            f"  opening video export UI (fps={fps}) — confirm path when prompted"
                        )
                        self.host.export_video_dialog(include_audio=include_audio, container="mp4")
                    else:
                        self._batch_log("  no export_video_dialog on host")
            except Exception as e:
                self._batch_log(f"  render error: {e}")

        self._batch_log("Batch finished.")
        self.refresh()

    def _batch_audio_export(self, fmt: str, bitrate_kbps: int, source_media: str):
        """Render mixdown and write next to source with quality suffix."""
        host = self.host
        max_rows = None
        if self.chk_batch_preview.isChecked() and hasattr(host, "_live_preview_max_rows"):
            max_rows = host._live_preview_max_rows()
        master, sr = host._render_mixdown_buffer(max_rows=max_rows)
        import numpy as np
        master = np.nan_to_num(np.asarray(master, dtype=np.float32), nan=0.0, posinf=1.0, neginf=-1.0)
        if hasattr(host, "_bake_dj_write"):
            master = host._bake_dj_write(master, sr)
        if hasattr(host, "_master_hardclip"):
            master, _ = host._master_hardclip(master, sr, apply_master_vol=True)
        pcm = (np.clip(master, -1.0, 1.0) * 32767.0).astype(np.int16)
        stem = os.path.splitext(os.path.basename(source_media))[0]
        dest_dir = self._host_exports_dir()
        out = os.path.join(dest_dir, f"{stem}_r{bitrate_kbps}k.{fmt}")
        prov = None
        try:
            prov = host._export_provenance_payload()
            if isinstance(prov, str):
                prov = prov.encode("utf-8")
        except Exception:
            prov = None
        host._write_audio_parts_and_final(
            out, sr, pcm, n_parts=1, provenance_bytes=prov,
            audio_format=fmt, audio_bitrate_kbps=bitrate_kbps if fmt in ("mp3", "opus", "ogg") else None,
        )
        self._batch_log(f"  wrote {out}")

    # ------------------------------------------------------------------ info tab
    def _mg_library_roots(self):
        roots=[]
        for fn in (self._host_projects_dir,self._host_samples_dir,self._host_exports_dir):
            try:
                p=fn()
                if p and p not in roots: roots.append(p)
            except Exception: pass
        return roots

    def _scan_mg_paths(self):
        out=[]
        for root in self._mg_library_roots():
            if not root or not os.path.isdir(root): continue
            for base,_,files in os.walk(root):
                for fn in files:
                    if fn.lower().endswith(('.mgproject','.mgsynth','.mgprofile','.mg')):
                        out.append(os.path.join(base,fn))
        return sorted(set(out),key=lambda x:os.path.basename(x).lower())

    def _build_mg_library_tab(self) -> QWidget:
        w=QWidget(); lay=QVBoxLayout(w)
        hdr=QLabel("<b style='color:#f1ce68'>.MG ID + Relationship Library</b><br>Project · Synth · Profile artifacts keep stable IDs while usage statistics and software-discovered relationships evolve separately.")
        hdr.setWordWrap(True); lay.addWidget(hdr)
        self.mg_list=QListWidget(); lay.addWidget(self.mg_list,1)
        row=QHBoxLayout()
        b_refresh=QPushButton("↻ Scan .MG"); b_refresh.clicked.connect(self._refresh_mg_library); row.addWidget(b_refresh)
        b_load=QPushButton("⬇ Load to relevant slot"); b_load.clicked.connect(self._load_selected_mg); row.addWidget(b_load)
        b_rel=QPushButton("⌬ Find Related"); b_rel.clicked.connect(self._show_related_mg); row.addWidget(b_rel)
        b_share=QPushButton("⇪ Share Identity"); b_share.setToolTip("Export a tiny portable identity/provenance card for another Groovebox user; the original .MG remains unchanged."); b_share.clicked.connect(self._share_selected_mg_identity); row.addWidget(b_share)
        b_exp=QPushButton("⇧ Export History"); b_exp.setToolTip("Export .MG provenance and analytics as JSON, CSV, or HTML without changing the artifact."); b_exp.clicked.connect(self._export_selected_mg_history); row.addWidget(b_exp)
        b_cmp=QPushButton("⇣ Compress History"); b_cmp.setToolTip("Keep longitudinal totals and strongest companion relationships while reducing detailed history."); b_cmp.clicked.connect(self._compress_selected_mg_history); row.addWidget(b_cmp)
        b_clr=QPushButton("⌫ Clear History"); b_clr.setToolTip("Clear mutable use/co-use/outcome history without changing the .MG Artifact ID or payload."); b_clr.clicked.connect(self._clear_selected_mg_history); row.addWidget(b_clr)
        lay.addLayout(row)
        self.mg_info=QTextEdit(); self.mg_info.setReadOnly(True); self.mg_info.setMaximumHeight(180); lay.addWidget(self.mg_info)
        self.mg_list.itemSelectionChanged.connect(self._mg_selection_changed)
        QTimer.singleShot(0,self._refresh_mg_library)
        return w

    def _refresh_mg_library(self):
        if not hasattr(self,'mg_list'): return
        self.mg_list.clear()
        try:
            from mg_artifacts import load
            for path in self._scan_mg_paths():
                try:
                    d=load(path,record_use=False); a=d.get('analytics',{}) or {}
                    text=f"{d.get('kind','?').upper()} · {d.get('title') or os.path.basename(path)} · uses {int(a.get('use_count',0))} · {d.get('artifact_id','')}"
                    it=QListWidgetItem(text); it.setData(Qt.ItemDataRole.UserRole,path); self.mg_list.addItem(it)
                except Exception: pass
            self.mg_info.setPlainText(f"{self.mg_list.count()} .MG artifact(s) found across Projects / Samples / Exports.")
        except Exception as e: self.mg_info.setPlainText(str(e))

    def _selected_mg_path(self):
        its=self.mg_list.selectedItems() if hasattr(self,'mg_list') else []
        return str(its[0].data(Qt.ItemDataRole.UserRole)) if its else ''

    def _mg_selection_changed(self):
        path=self._selected_mg_path()
        if not path: return
        try:
            from mg_artifacts import load
            d=load(path,record_use=False); a=d.get('analytics',{}) or {}; p=d.get('provenance',{}) or {}
            self.mg_info.setPlainText(
                f"{path}\nArtifact ID: {d.get('artifact_id')}\nProgram ID: {p.get('program_id')}\nComposition ID: {p.get('composition_id')}\n"
                f"uses: {a.get('use_count',0)} · loads: {a.get('load_count',0)} · saves: {a.get('save_count',0)}\n"
                f"first used: {a.get('first_used')} · last used: {a.get('last_used')}\ncompanions: {json.dumps(a.get('companions',{}),sort_keys=True)}")
        except Exception as e: self.mg_info.setPlainText(str(e))

    def _share_selected_mg_identity(self):
        path=self._selected_mg_path()
        if not path: return
        try:
            from mg_artifacts import load
            d=load(path,record_use=False); prov=d.get('provenance',{}) or {}
            card={
                'format':'MG-share-card-v1', 'kind':d.get('kind'), 'title':d.get('title'),
                'artifact_id':d.get('artifact_id'), 'program_id':prov.get('program_id'),
                'composition_id':prov.get('composition_id'), 'source_filename':os.path.basename(path),
                'payload_fingerprint':d.get('payload_fingerprint') or prov.get('payload_fingerprint'),
            }
            default=os.path.splitext(path)[0]+'.MGshare.json'
            out,_=QFileDialog.getSaveFileName(self,'Share .MG Identity',default,'Groovebox share card (*.MGshare.json);;JSON (*.json)')
            if not out: return
            with open(out,'w',encoding='utf-8') as f: json.dump(card,f,indent=2,sort_keys=True)
            self.lbl_status.setText(f"Shared identity card → {os.path.basename(out)}")
        except Exception as e:
            QMessageBox.warning(self,'Share identity failed',str(e))

    def _load_selected_mg(self):
        path=self._selected_mg_path()
        if not path: return
        try:
            fn=getattr(self.host,'_load_mg_path',None)
            if not callable(fn): raise RuntimeError('Host .MG loader unavailable')
            d=fn(path); self.lbl_status.setText(f"Loaded .MG {d.get('kind')} → relevant slot")
            self._refresh_mg_library(); self._show_related_mg()
        except Exception as e: QMessageBox.warning(self,".MG load failed",str(e))

    def _show_related_mg(self):
        path=self._selected_mg_path() or str(getattr(self.host,'_last_mg_artifact_path','') or '')
        if not path or not os.path.isfile(path): return
        try:
            from mg_artifacts import find_related
            rel=find_related(path,self._mg_library_roots(),limit=12)
            if not rel: self.mg_info.append("\nRelated: no comparable history yet."); return
            lines=["\nRelated / common results:"]
            for r in rel:
                a=r.get('analytics',{}) or {}
                lines.append(f"{r['score']:.3f} · {r['kind']} · {r['title']} · uses {a.get('use_count',0)} · {os.path.basename(r['path'])}")
            self.mg_info.append("\n".join(lines))
        except Exception as e: self.mg_info.append(f"\nRelated error: {e}")

    def _export_selected_mg_history(self):
        path=self._selected_mg_path()
        if not path: return
        base=os.path.splitext(os.path.basename(path))[0] + "_history"
        out,flt=QFileDialog.getSaveFileName(self,"Export .MG History",os.path.join(os.path.dirname(path),base+".json"),"JSON (*.json);;CSV (*.csv);;HTML (*.html)")
        if not out: return
        low=out.lower(); fmt='csv' if low.endswith('.csv') else ('html' if low.endswith(('.html','.htm')) else 'json')
        if not low.endswith(('.json','.csv','.html','.htm')): out += '.'+fmt
        try:
            from mg_artifacts import export_history
            final=export_history(path,out,fmt)
            self.mg_info.append(f"\nHistory exported: {final}")
        except Exception as e: QMessageBox.warning(self,"History export failed",str(e))

    def _compress_selected_mg_history(self):
        path=self._selected_mg_path()
        if not path: return
        try:
            from mg_artifacts import compress_history
            result=compress_history(path)
            self.mg_info.append(f"\nHistory compressed; Artifact ID unchanged: {result.get('artifact_id')}")
            self._refresh_mg_library()
        except Exception as e: QMessageBox.warning(self,"History compression failed",str(e))

    def _clear_selected_mg_history(self):
        path=self._selected_mg_path()
        if not path: return
        ans=QMessageBox.question(self,"Clear .MG History","Clear detailed usage/co-use/outcome history?\n\nThe .MG payload and Artifact ID will not change.")
        if ans != QMessageBox.StandardButton.Yes: return
        try:
            from mg_artifacts import clear_history
            result=clear_history(path,preserve_totals=True)
            self.mg_info.append(f"\nHistory cleared; Artifact ID unchanged: {result.get('artifact_id')}")
            self._refresh_mg_library()
        except Exception as e: QMessageBox.warning(self,"History clear failed",str(e))

    def _build_info_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        self.info_view = QTextEdit()
        self.info_view.setReadOnly(True)
        lay.addWidget(self.info_view)
        tip = QLabel(
            "Pi tips: set GROOVEBOX_SAMPLE_RATE=48000, enable UI lite, use Preview rows, "
            "batch-re-render at lower FPS/bitrate for field copies, full quality at home."
        )
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#8ab4c8; font-size:9pt;")
        lay.addWidget(tip)
        return w

    def closeEvent(self, event):
        # LAG/DEVICE_AUDIT_20260909: this is the authoritative Performance cleanup.
        # An older closeEvent earlier in this class was shadowed by this one, which
        # is why a stopped recording could leave QCamera allocated on Windows.
        try: self._sync_project_state()
        except Exception: pass
        for name in ('_timed_playlist_timer','_pattern_timer','_performance_timer','_radio_peer_timer','_nearby_ui_timer','_selection_debounce','_remote_timer','_remix_apply_timer'):
            try:
                t=getattr(self,name,None)
                if t is not None: t.stop()
            except Exception: pass
        try:
            if getattr(self,'_math_background',None) is not None: self._math_background._timer.stop()
        except Exception: pass
        try:
            studio=getattr(self,'video_clip_studio',None)
            if studio is not None: studio._release_capture_devices(True)
        except Exception: pass
        try: self._stop_goava_radio()
        except Exception: pass
        try: self._stop_performance()
        except Exception: pass
        try: self._stop_remote_server()
        except Exception: pass
        try: self._stop_tv_host()
        except Exception: pass
        try: self._stop_timed_playlist()
        except Exception: pass
        self._stop_player()
        super().closeEvent(event)


class _Deck:
    """One playback deck: an external mpv process (for live IPC control),
    its own destination-routing, volume, speed and a set of toggleable
    onboard DJ FX filters. VLC/ffplay remain usable for plain playback but
    only mpv exposes the runtime property/filter control DJ mixing needs."""

    AUDIO_FX = {
        "Echo": "aecho=0.8:0.9:1000:0.3",
        "Flanger": "flanger",
        "Bass Boost": "bass=g=15",
        "Telephone": "highpass=f=300,lowpass=f=3000",
        "Reverb": "aecho=0.8:0.88:60:0.4",
    }
    VIDEO_FX = {
        "Invert": "negate",
        "Hue Spin": "hue=h=120:s=2",
        "Strobe": "fps=6",
        "Mirror": "hflip",
        "Contrast Pop": "eq=contrast=1.6:saturation=1.4",
    }

    def __init__(self, name: str):
        self.name = name
        self.proc: Optional[subprocess.Popen] = None
        self.ipc_path: Optional[str] = None
        self.path: str = ""
        self.base_volume = 100.0     # 0..150, this deck's own fader
        self.mix_gain = 1.0          # 0..1, crossfader contribution
        self.speed = 1.0
        self.active_audio_fx: set = set()
        self.active_video_fx: set = set()
        self.want_video = True
        self.image_duration_s = 5.0

    def is_running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def _af_chain(self) -> str:
        # Sets store membership only. Emission follows declaration order so the
        # DSP/filter chain is bit-for-bit stable regardless of toggle history.
        return ",".join(self.AUDIO_FX[f] for f in self.AUDIO_FX if f in self.active_audio_fx)

    def _vf_chain(self) -> str:
        return ",".join(self.VIDEO_FX[f] for f in self.VIDEO_FX if f in self.active_video_fx)

    def effective_volume(self) -> int:
        return max(0, min(150, int(round(self.base_volume * self.mix_gain))))

    def send(self, command: list) -> bool:
        if not self.ipc_path or not os.path.exists(self.ipc_path):
            return False
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(0.06)
            sock.connect(self.ipc_path)
            sock.sendall((json.dumps({"command": command}) + "\n").encode("utf-8"))
            sock.close()
            return True
        except Exception:
            return False

    def play(self, path: str, routed: Callable[[list, bool], Tuple[list, dict]]):
        self.stop()
        self.path = path
        ext = os.path.splitext(path)[1].lower()
        self.want_video = ext in VIDEO_EXT or ext in IMAGE_EXT
        cmd = _player_cmd_with_volume(int(self.effective_volume()), want_video=self.want_video) or _find_player()
        if not cmd:
            return False, "Install mpv, vlc, or ffplay for media playback."
        is_mpv = os.path.basename(cmd[0]).startswith("mpv")
        self.ipc_path = None
        if is_mpv:
            self.ipc_path = os.path.join(tempfile.gettempdir(), f"groovebox_deck_{self.name}_{os.getpid()}_{id(self)}.sock")
            try:
                os.unlink(self.ipc_path)
            except OSError:
                pass
            extra = [f"--input-ipc-server={self.ipc_path}", f"--speed={self.speed:.6f}"]
            if ext in IMAGE_EXT:
                extra.extend([f"--image-display-duration={max(0.1,float(self.image_duration_s)):.3f}", "--loop-file=no"])
            af = self._af_chain()
            vf = self._vf_chain()
            if af:
                extra.append(f"--af={af}")
            if vf and self.want_video:
                extra.append(f"--vf={vf}")
            cmd = list(cmd) + extra
        cmd, env = routed(cmd, self.want_video)
        try:
            self.proc = subprocess.Popen(cmd + [path], env=env)
            return True, ""
        except Exception as e:
            return False, str(e)

    def stop(self):
        proc, self.proc = self.proc, None
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
        if self.ipc_path:
            try:
                os.unlink(self.ipc_path)
            except OSError:
                pass
        self.ipc_path = None

    def set_speed(self, speed: float):
        self.speed = max(0.25, min(4.0, speed))
        self.send(["set_property", "speed", self.speed])

    def set_mix_gain(self, gain: float):
        self.mix_gain = max(0.0, min(1.0, gain))
        self.send(["set_property", "volume", self.effective_volume()])

    def set_base_volume(self, vol: float):
        self.base_volume = max(0.0, min(150.0, vol))
        self.send(["set_property", "volume", self.effective_volume()])

    def toggle_audio_fx(self, name: str, on: bool):
        if on:
            self.active_audio_fx.add(name)
        else:
            self.active_audio_fx.discard(name)
        chain = self._af_chain()
        self.send(["af", "set", chain if chain else "@dj_af_none:!lavfi=[anull]"])

    def toggle_video_fx(self, name: str, on: bool):
        if on:
            self.active_video_fx.add(name)
        else:
            self.active_video_fx.discard(name)
        chain = self._vf_chain()
        self.send(["vf", "set", chain if chain else ""])


class MediaPlayerWindow(QDialog):
    """Dedicated media Player Window: destination device selection, a linear
    playback queue (Deck A), a second load-anything deck (Deck B) for live
    mixing, a crossfader, onboard DJ FX per deck, and an optional live sync
    to the Performance Parametric Remix panel (GOAVA/RAND/boost/speed).

    Self-contained: it re-detects displays/audio sinks via
    ``media_output_router`` rather than assuming the parent Performance
    dialog's routing state, so it works whether it was opened from the
    Playlist tab or straight from the Browse Files window on a single file.
    """

    def __init__(self, parent: Optional[QWidget], items: List[Dict[str, Any]], start_index: int = 0):
        super().__init__(parent)
        self.setWindowTitle("Groovebox Player · DJ Decks")
        self.resize(760, 720)
        self.setStyleSheet(
            "QDialog { background:rgba(7,16,25,232); color:#d9edf5; }"
            "QGroupBox { border:1px solid #284c62; border-radius:7px; margin-top:8px; padding-top:7px; font-weight:700; }"
            "QGroupBox::title { color:#f1ce68; subcontrol-origin:margin; left:9px; padding:0 4px; }"
            "QPushButton { background:#102838; color:#d9f7ff; border:1px solid #39708a; border-radius:11px; padding:6px 10px; font-weight:700; }"
            "QPushButton:hover { background:#17405a; border-color:#62bfd0; }"
            "QPushButton:checked { background:#5a3a12; border-color:#f1ce68; color:#ffe8a6; }"
            "QComboBox,QSpinBox,QLineEdit { background:#08141e; color:#e6f8ff; border:1px solid #335b70; border-radius:8px; padding:5px; }"
        )
        self._items: List[Dict[str, Any]] = [dict(it) if isinstance(it, dict) else {"path": it} for it in items]
        self._index = max(0, min(start_index, len(self._items) - 1)) if self._items else -1
        self._manual_stop = False
        self._paused = False
        self._displays: list = []
        self._audio_targets: list = []
        self._deckA = _Deck("A")
        self._deckB = _Deck("B")
        self._sync_enabled = False
        self._analysis_cache: Dict[str, Tuple[float, int, Optional[dict]]] = {}

        root = QVBoxLayout(self)

        dev = QGroupBox("Destination device")
        df = QFormLayout(dev)
        self.cmb_display = QComboBox()
        self.cmb_audio = QComboBox()
        df.addRow("Display", self.cmb_display)
        df.addRow("Audio sink", self.cmb_audio)
        btn_refresh_dev = QPushButton("↻ Detect devices")
        btn_refresh_dev.clicked.connect(self._refresh_devices)
        df.addRow(btn_refresh_dev)
        root.addWidget(dev)

        # -------------------------------------------------------------- Deck A (queue-driven)
        deckA_box = QGroupBox("Deck A · Queue")
        da = QVBoxLayout(deckA_box)
        self.lbl_now = QLabel("Nothing loaded")
        self.lbl_now.setWordWrap(True)
        self.lbl_now.setStyleSheet("color:#f1ce68; font-weight:700;")
        da.addWidget(self.lbl_now)
        self.queue_widget = QListWidget()
        self.queue_widget.setMaximumHeight(110)
        self.queue_widget.itemDoubleClicked.connect(self._on_queue_double_click)
        da.addWidget(self.queue_widget)
        transport = QHBoxLayout()
        self.btn_prev = QPushButton("⏮")
        self.btn_playpause = QPushButton("▶ Play")
        self.btn_stop = QPushButton("⏹ Stop")
        self.btn_next = QPushButton("⏭")
        self.btn_prev.clicked.connect(self._prev)
        self.btn_playpause.clicked.connect(self._toggle_play_pause)
        self.btn_stop.clicked.connect(self._stop)
        self.btn_next.clicked.connect(self._next)
        for b in (self.btn_prev, self.btn_playpause, self.btn_stop, self.btn_next):
            transport.addWidget(b)
        da.addLayout(transport)
        da.addLayout(self._build_deck_fx_row(self._deckA))
        root.addWidget(deckA_box)

        # -------------------------------------------------------------- Deck B (load-anything mix partner)
        deckB_box = QGroupBox("Deck B · Mix partner (load any video/music file)")
        db = QVBoxLayout(deckB_box)
        self.lbl_deckB = QLabel("Deck B empty — Browse Files → Add to Deck B, or use the button below.")
        self.lbl_deckB.setWordWrap(True)
        db.addWidget(self.lbl_deckB)
        b_row = QHBoxLayout()
        btn_load_b = QPushButton("📂 Load into Deck B…")
        btn_load_b.clicked.connect(self._load_deck_b_dialog)
        btn_play_b = QPushButton("▶ Play B")
        btn_play_b.clicked.connect(self._play_deck_b)
        btn_stop_b = QPushButton("⏹ Stop B")
        btn_stop_b.clicked.connect(lambda: self._deckB.stop())
        self.cmb_deck_b_match = QComboBox()
        self.cmb_deck_b_match.addItems(["Analyzed key/texture", "Canonical metadata"])
        self.cmb_deck_b_match.setToolTip("Analyzed mode uses deterministic pitch-class/texture distance. Canonical mode prefers Groovebox render provenance, then falls back to analyzed distance.")
        btn_suggest_b = QPushButton("🔬 Suggest Deck B")
        btn_suggest_b.setToolTip("Deterministically selects the closest queue partner using the selected matching mode.")
        btn_suggest_b.clicked.connect(self._suggest_deck_b_match)
        b_row.addWidget(btn_load_b); b_row.addWidget(btn_play_b); b_row.addWidget(btn_stop_b); b_row.addWidget(self.cmb_deck_b_match); b_row.addWidget(btn_suggest_b)
        db.addLayout(b_row)
        db.addLayout(self._build_deck_fx_row(self._deckB))
        root.addWidget(deckB_box)

        # -------------------------------------------------------------- Crossfader + live mixing
        mix_box = QGroupBox("Live mixing")
        mf = QFormLayout(mix_box)
        self.sld_crossfade = QSlider(Qt.Orientation.Horizontal)
        self.sld_crossfade.setRange(0, 100)
        self.sld_crossfade.setValue(0)
        self.sld_crossfade.setToolTip("0 = Deck A only, 100 = Deck B only. Both decks can play simultaneously through the OS mixer.")
        self.sld_crossfade.valueChanged.connect(self._on_crossfade_changed)
        mf.addRow("Crossfader A ↔ B", self.sld_crossfade)
        self.cmb_crossfade_curve = QComboBox()
        self.cmb_crossfade_curve.addItems(["Equal-power", "Linear"])
        self.cmb_crossfade_curve.setToolTip("Equal-power keeps perceived loudness steadier through the middle; Linear preserves the original arithmetic fade.")
        self.cmb_crossfade_curve.currentIndexChanged.connect(lambda _i: self._on_crossfade_changed(self.sld_crossfade.value()))
        mf.addRow("Crossfade curve", self.cmb_crossfade_curve)
        self.spin_player_image_duration = QDoubleSpinBox()
        self.spin_player_image_duration.setRange(0.25, 3600.0); self.spin_player_image_duration.setDecimals(2); self.spin_player_image_duration.setValue(5.0); self.spin_player_image_duration.setSuffix(" s")
        self.spin_player_image_duration.setToolTip("Still-image duration for Player queues and Deck B. Playlist rows with an explicit duration override this for Deck A.")
        mf.addRow("Still-image duration", self.spin_player_image_duration)
        xrow = QHBoxLayout()
        btn_auto_x = QPushButton("↔ Auto-crossfade to B (4s)")
        btn_auto_x.clicked.connect(lambda: self._auto_crossfade(1, 4.0))
        btn_auto_x_back = QPushButton("↔ Auto-crossfade to A (4s)")
        btn_auto_x_back.clicked.connect(lambda: self._auto_crossfade(0, 4.0))
        xrow.addWidget(btn_auto_x); xrow.addWidget(btn_auto_x_back)
        mf.addRow(xrow)

        self.chk_sync_remix = QCheckBox("🔗 Sync both decks to Performance Parametric Remix (GOAVA/RAND/boost → FX, speed → tempo)")
        self.chk_sync_remix.toggled.connect(self._on_toggle_sync)
        mf.addRow(self.chk_sync_remix)
        root.addWidget(mix_box)

        vol_row = QHBoxLayout()
        vol_row.addWidget(QLabel("Deck A"))
        self.sld_volume = QSlider(Qt.Orientation.Horizontal); self.sld_volume.setRange(0,150); self.sld_volume.setValue(100)
        self.sld_volume.valueChanged.connect(self._on_deckA_volume_changed); vol_row.addWidget(self.sld_volume, stretch=1)
        self.lbl_volume = QLabel("100%"); self.lbl_volume.setMinimumWidth(40); vol_row.addWidget(self.lbl_volume)
        vol_row.addWidget(QLabel("Deck B"))
        self.sld_volume_b = QSlider(Qt.Orientation.Horizontal); self.sld_volume_b.setRange(0,150); self.sld_volume_b.setValue(100)
        self.sld_volume_b.valueChanged.connect(self._on_deckB_volume_changed); vol_row.addWidget(self.sld_volume_b, stretch=1)
        self.lbl_volume_b = QLabel("100%"); self.lbl_volume_b.setMinimumWidth(40); vol_row.addWidget(self.lbl_volume_b)
        root.addLayout(vol_row)

        self.lbl_status = QLabel("Idle")
        self.lbl_status.setWordWrap(True)
        self.lbl_status.setStyleSheet("color:#8ab4c8; font-size:9pt;")
        root.addWidget(self.lbl_status)

        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(400)
        self._poll_timer.timeout.connect(self._poll_process)
        self._poll_timer.start()

        self._sync_timer = QTimer(self)
        self._sync_timer.setInterval(80)
        self._sync_timer.timeout.connect(self._apply_remix_sync)

        self._refresh_queue_widget()
        self._refresh_devices()
        if self._index >= 0:
            self._load_current(autoplay=False)

    # -- FX row builder ---------------------------------------------------
    def _build_deck_fx_row(self, deck: "_Deck") -> QHBoxLayout:
        row = QHBoxLayout()
        row.addWidget(QLabel("FX:"))
        for fx_name in deck.AUDIO_FX:
            b = QPushButton(fx_name)
            b.setCheckable(True)
            b.toggled.connect(lambda on, d=deck, n=fx_name: d.toggle_audio_fx(n, on))
            row.addWidget(b)
        for fx_name in deck.VIDEO_FX:
            b = QPushButton(fx_name)
            b.setCheckable(True)
            b.toggled.connect(lambda on, d=deck, n=fx_name: d.toggle_video_fx(n, on))
            row.addWidget(b)
        row.addStretch(1)
        return row

    # -- devices --------------------------------------------------------
    def _refresh_devices(self):
        try:
            from media_output_router import detect_displays, detect_audio_targets
            self._displays = detect_displays()
            self._audio_targets = detect_audio_targets()
            self.cmb_display.clear()
            for d in self._displays:
                tag = f" · {d.geometry}" if getattr(d, "geometry", None) else ""
                self.cmb_display.addItem(d.name + tag)
            self.cmb_audio.clear()
            for a in self._audio_targets:
                tag = f" [{a.kind}]" if getattr(a, "kind", None) and a.kind != "default" else ""
                self.cmb_audio.addItem(a.description + tag)
            self.lbl_status.setText(f"{len(self._displays)} display target(s) · {len(self._audio_targets)} audio target(s) detected.")
        except Exception as e:
            self.lbl_status.setText(f"Device scan unavailable: {e}")

    def _selected_display(self):
        i = self.cmb_display.currentIndex()
        return self._displays[i] if 0 <= i < len(self._displays) else None

    def _selected_audio(self):
        i = self.cmb_audio.currentIndex()
        return self._audio_targets[i] if 0 <= i < len(self._audio_targets) else None

    def _routed(self, cmd: list, want_video: bool) -> Tuple[list, dict]:
        env = os.environ.copy()
        try:
            from media_output_router import player_routing
            extra, overlay = player_routing(self._selected_display(), self._selected_audio(), want_video=want_video)
            if cmd and os.path.basename(cmd[0]).lower().startswith("mpv"):
                cmd = list(cmd) + list(extra)
            env.update(overlay)
        except Exception:
            pass
        return cmd, env

    # -- queue (Deck A) ------------------------------------------------
    def _refresh_queue_widget(self):
        self.queue_widget.clear()
        for i, it in enumerate(self._items):
            marker = "▶ " if i == self._index else "   "
            self.queue_widget.addItem(f"{marker}{os.path.basename(it.get('path', '?'))}")

    def _on_queue_double_click(self, item: QListWidgetItem):
        row = self.queue_widget.row(item)
        if 0 <= row < len(self._items):
            self._index = row
            self._load_current(autoplay=True)

    def _load_current(self, autoplay: bool):
        if not (0 <= self._index < len(self._items)):
            return
        path = self._items[self._index].get("path", "")
        self.lbl_now.setText(f"{self._index + 1}/{len(self._items)} · {os.path.basename(path)}")
        self._refresh_queue_widget()
        if autoplay:
            self._play_current()

    def _play_current(self):
        if not (0 <= self._index < len(self._items)):
            return
        self._stop()
        item = self._items[self._index]
        path = item.get("path", "")
        if not path or not os.path.isfile(path):
            self.lbl_status.setText(f"Missing file: {path}")
            return
        self._deckA.base_volume = float(self.sld_volume.value())
        explicit_duration = float(item.get("duration_s", 0.0) or 0.0)
        self._deckA.image_duration_s = explicit_duration if explicit_duration > 0 else float(self.spin_player_image_duration.value())
        ok, err = self._deckA.play(path, self._routed)
        if not ok:
            QMessageBox.warning(self, "Play failed", err)
            return
        self._paused = False
        self._manual_stop = False
        self.btn_playpause.setText("⏸ Pause")
        self._load_current(autoplay=False)
        dname = getattr(self._selected_display(), "name", "default") if self._selected_display() else "default"
        aname = getattr(self._selected_audio(), "description", "System default") if self._selected_audio() else "System default"
        self.lbl_status.setText(f"Deck A playing → display={dname} · audio={aname}")

    def _toggle_play_pause(self):
        if not self._deckA.is_running():
            self._play_current()
            return
        if self._deckA.ipc_path:
            self._paused = not self._paused
            self._deckA.send(["set_property", "pause", self._paused])
            self.btn_playpause.setText("▶ Play" if self._paused else "⏸ Pause")
            self.lbl_status.setText("Deck A paused" if self._paused else "Deck A playing")
        else:
            self._stop()
            self._play_current()

    def _stop(self):
        self._manual_stop = True
        self._deckA.stop()
        self._paused = False
        self.btn_playpause.setText("▶ Play")

    def _next(self):
        if not self._items:
            return
        self._index = (self._index + 1) % len(self._items)
        self._load_current(autoplay=True)

    def _prev(self):
        if not self._items:
            return
        self._index = (self._index - 1) % len(self._items)
        self._load_current(autoplay=True)

    def _poll_process(self):
        if self._deckA.proc is None:
            return
        rc = self._deckA.proc.poll()
        if rc is not None and not self._manual_stop:
            self._deckA.proc = None
            if self._index < len(self._items) - 1:
                self._next()
            else:
                self.lbl_status.setText("Queue finished.")
                self.btn_playpause.setText("▶ Play")

    def _on_deckA_volume_changed(self, v: int):
        self.lbl_volume.setText(f"{v}%")
        self._deckA.set_base_volume(float(v))

    def _on_deckB_volume_changed(self, v: int):
        self.lbl_volume_b.setText(f"{v}%")
        self._deckB.set_base_volume(float(v))

    # -- Deck B -----------------------------------------------------------
    def _load_deck_b_dialog(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load into Deck B")
        if path:
            self._deckB.path = path
            self.lbl_deckB.setText(f"Loaded: {os.path.basename(path)}")

    def load_deck_b(self, path: str):
        """External hook (e.g. from Browse Files) to load a file straight into Deck B."""
        self._deckB.path = path
        self.lbl_deckB.setText(f"Loaded: {os.path.basename(path)}")

    def _suggest_deck_b_match(self):
        if not (0 <= self._index < len(self._items)):
            QMessageBox.information(self, "Suggest Deck B", "Load something into Deck A's queue first.")
            return
        a_path = self._items[self._index].get("path", "")
        if not os.path.isfile(a_path):
            QMessageBox.information(self, "Suggest Deck B", "Deck A's current track is missing on disk.")
            return
        candidates = sorted(
            (it.get("path", "") for i,it in enumerate(self._items) if i != self._index and os.path.isfile(it.get("path", ""))),
            key=lambda x: (os.path.basename(x).casefold(), os.path.abspath(x)),
        )
        if not candidates:
            QMessageBox.information(self, "Suggest Deck B", "No other queue track is available.")
            return
        mode = self.cmb_deck_b_match.currentText() if hasattr(self,"cmb_deck_b_match") else "Analyzed key/texture"
        self.lbl_status.setText(f"Matching Deck B · {mode}…")
        a_desc = _analyze_signal_descriptor(a_path, self._analysis_cache)
        scored=[]
        for cand in candidates:
            canonical = _canonical_media_distance(a_path, cand) if mode.startswith("Canonical") else None
            d = _analyze_signal_descriptor(cand, self._analysis_cache)
            analyzed = _descriptor_distance(a_desc, d) if a_desc and d else 9999.0
            # Canonical evidence dominates when requested; deterministic analyzed
            # distance and then path provide stable fallbacks/tie breaks.
            primary = canonical if canonical is not None else analyzed
            scored.append((float(primary), float(analyzed), os.path.basename(cand).casefold(), os.path.abspath(cand), cand, canonical))
        best = min(scored)
        best_path=best[4]; canonical=best[5]
        if best[0] >= 9999.0:
            QMessageBox.information(self, "Suggest Deck B", "No analyzable/provenance-compatible track found in the queue.")
            return
        self._deckB.path = best_path
        if canonical is not None and mode.startswith("Canonical"):
            note=f"canonical distance {canonical:.3f}; analyzed {best[1]:.3f}"
        else:
            note=f"key/texture distance {best[1]:.3f}"
        self.lbl_deckB.setText(f"Suggested match: {os.path.basename(best_path)} ({note})")
        self.lbl_status.setText(f"Deck B suggestion loaded deterministically: {os.path.basename(best_path)}")

    def _play_deck_b(self):
        if not self._deckB.path or not os.path.isfile(self._deckB.path):
            QMessageBox.information(self, "Deck B", "Load a file into Deck B first.")
            return
        self._deckB.base_volume = float(self.sld_volume_b.value()) if hasattr(self,"sld_volume_b") else 100.0
        self._deckB.image_duration_s = float(self.spin_player_image_duration.value())
        ok, err = self._deckB.play(self._deckB.path, self._routed)
        if not ok:
            QMessageBox.warning(self, "Deck B play failed", err)
            return
        self.lbl_status.setText(f"Deck B playing: {os.path.basename(self._deckB.path)}")

    # -- crossfader / live mixing -----------------------------------------
    def _on_crossfade_changed(self, v: int):
        x = max(0.0, min(1.0, v / 100.0))
        curve = self.cmb_crossfade_curve.currentText() if hasattr(self,"cmb_crossfade_curve") else "Linear"
        if curve.startswith("Equal"):
            a_gain = math.cos(x * math.pi / 2.0)
            b_gain = math.sin(x * math.pi / 2.0)
        else:
            b_gain = x; a_gain = 1.0 - x
        self._deckA.set_mix_gain(a_gain); self._deckB.set_mix_gain(b_gain)
        self.lbl_status.setText(f"Crossfader ({curve}): A {a_gain*100:.0f}% · B {b_gain*100:.0f}%")

    def _auto_crossfade(self, target_side: int, duration_s: float):
        start = self.sld_crossfade.value()
        end = 100 if target_side == 1 else 0
        if start == end:
            return
        steps = max(1, int(duration_s * 20))
        delta = (end - start) / steps
        state = {"i": 0, "val": float(start)}
        timer = QTimer(self)
        timer.setInterval(int(1000 / 20))

        def tick():
            state["i"] += 1
            state["val"] += delta
            self.sld_crossfade.setValue(max(0, min(100, int(round(state["val"])))))
            if state["i"] >= steps:
                self.sld_crossfade.setValue(end)
                timer.stop()
                timer.deleteLater()
        timer.timeout.connect(tick)
        timer.start()

    # -- Parametric Remix sync --------------------------------------------
    def _on_toggle_sync(self, on: bool):
        self._sync_enabled = on
        if on:
            self._sync_timer.start()
            self.lbl_status.setText("Synced to Performance Parametric Remix.")
        else:
            self._sync_timer.stop()

    def _apply_remix_sync(self):
        """Read the parent Performance's GOAVA/RAND/boost/speed sliders (if
        present) each tick and translate them into deck tempo + FX intensity,
        so the same parametric-remix control surface driving the host's
        internal Live DJ engine also drives both external playback decks."""
        host = self.parent()
        if host is None:
            return
        try:
            goava = host.sld_goava.value() / 100.0 if hasattr(host, "sld_goava") else 0.0
            rand = host.sld_rand.value() / 100.0 if hasattr(host, "sld_rand") else 0.0
            boost = host.sld_boost.value() / 100.0 if hasattr(host, "sld_boost") else 0.0
            speed = host._live_speed if hasattr(host, "_live_speed") else 1.0
        except Exception:
            return
        self._deckA.set_speed(speed)
        self._deckB.set_speed(speed)
        # GOAVA morph amount -> echo/flanger intensity proxy (toggle at threshold)
        self._deckA.toggle_audio_fx("Echo", goava > 0.5)
        self._deckB.toggle_audio_fx("Flanger", rand > 0.5)
        if boost > 0.6:
            self._deckA.toggle_video_fx("Strobe", True)
        else:
            self._deckA.toggle_video_fx("Strobe", False)

    def closeEvent(self, event):
        self._sync_timer.stop()
        self._stop()
        self._deckB.stop()
        super().closeEvent(event)


class FileManagerDialog(QDialog):
    """Safe asynchronous Groovebox file manager.

    Normal mode is confined to Groovebox/home/removable-media roots, video
    probing never blocks Qt, destructive actions go to an app-local Trash with
    one-click Undo, and media/project/game actions validate their file types.
    System-wide browsing is explicit through Advanced/System Files.
    """
    def __init__(self, parent: Optional[QWidget], start_dir: str):
        super().__init__(parent)
        self.setWindowTitle("Browse Files")
        self.resize(650, 540)
        self.setStyleSheet(
            "QDialog { background:rgba(7,16,25,232); color:#d9edf5; }"
            "QPushButton { background:#102838; color:#d9f7ff; border:1px solid #39708a; border-radius:11px; padding:8px 11px; font-weight:700; }"
            "QPushButton:hover { background:#17405a; border-color:#62bfd0; }"
        )
        self._dir = os.path.abspath(start_dir if os.path.isdir(start_dir) else os.path.expanduser("~"))
        self._kind_cache: Dict[str, Tuple[float,int,str]] = {}
        self._kind_generation = 0
        self._kind_worker = _KindProbeWorker()
        self._kind_worker.progress.connect(self._on_probe_progress)
        self._kind_worker.batch_done.connect(self._on_probe_done)
        self._last_trash_moves: List[Tuple[str,str]] = []
        try:
            import groovebox_paths
            data_root=os.path.realpath(groovebox_paths.base_dir())
            self._trash_dir=os.path.join(data_root,"Trash")
        except Exception:
            data_root=os.path.realpath(os.path.expanduser("~"))
            self._trash_dir=os.path.join(data_root,".groovebox-trash")
        os.makedirs(self._trash_dir,exist_ok=True)
        roots=[data_root,os.path.realpath(os.path.expanduser("~"))]
        for x in ("/media","/run/media","/mnt"):
            if os.path.isdir(x): roots.append(os.path.realpath(x))
        if not any(self._inside(self._dir,r) for r in roots): roots.append(os.path.realpath(self._dir))
        self._safe_roots=tuple(dict.fromkeys(roots))

        root = QVBoxLayout(self)
        top = QHBoxLayout(); self.lbl_path=QLabel(self._dir); self.lbl_path.setWordWrap(True); self.lbl_path.setStyleSheet("color:#8ab4c8; font-size:9pt;"); top.addWidget(self.lbl_path,stretch=1)
        self.chk_advanced=QCheckBox("Advanced/System Files"); self.chk_advanced.setToolTip("Off = stay inside Groovebox/home/removable-media roots. On = allow navigation toward filesystem root."); top.addWidget(self.chk_advanced)
        btn_up=QPushButton("⬆ Up"); btn_up.clicked.connect(self._go_up); top.addWidget(btn_up); root.addLayout(top)
        self.list_widget=QListWidget(); self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection); self.list_widget.itemDoubleClicked.connect(self._on_double_click); root.addWidget(self.list_widget,stretch=1)
        row1=QHBoxLayout()
        for text,slot in (("New Folder…",self._new_folder),("Rename…",self._rename_selected),("Move to Trash",self._delete_selected),("↶ Undo Trash",self._undo_trash),("↻ Refresh",self.refresh)):
            b=QPushButton(text); b.clicked.connect(slot); row1.addWidget(b)
        root.addLayout(row1)
        row2=QHBoxLayout()
        btn_player=QPushButton("▶ Open in Player"); btn_player.clicked.connect(self._open_in_player)
        btn_add_playlist=QPushButton("→ Add to Performance Playlist"); btn_add_playlist.clicked.connect(self._add_to_performance_playlist)
        btn_open=QPushButton("Open Project / Launch Game"); btn_open.clicked.connect(self._open_project_or_game)
        row2.addWidget(btn_player); row2.addWidget(btn_add_playlist); row2.addWidget(btn_open); root.addLayout(row2)
        self.lbl_status=QLabel(""); self.lbl_status.setWordWrap(True); self.lbl_status.setStyleSheet("color:#8ab4c8; font-size:9pt;"); root.addWidget(self.lbl_status)
        self.refresh()

    @staticmethod
    def _inside(path: str, root: str) -> bool:
        try: return os.path.commonpath([os.path.realpath(path),os.path.realpath(root)]) == os.path.realpath(root)
        except Exception: return False
    def _allowed(self,path: str) -> bool:
        return self.chk_advanced.isChecked() or any(self._inside(path,r) for r in self._safe_roots)
    @staticmethod
    def _valid_leaf(name: str) -> bool:
        n=name.strip()
        return bool(n and n not in (".","..") and "\x00" not in n and "/" not in n and "\\" not in n and os.path.basename(n)==n)
    def _entries(self)->List[str]:
        try: return sorted(os.listdir(self._dir),key=lambda n:(not os.path.isdir(os.path.join(self._dir,n)),n.casefold()))
        except Exception as e: self.lbl_status.setText(f"Cannot list {self._dir}: {e}"); return []
    def _cached_kind(self,path: str)->str:
        ext=os.path.splitext(path)[1].lower()
        if ext in AUDIO_EXT:return KIND_AUDIO
        if ext in IMAGE_EXT:return KIND_IMAGE
        if ext not in VIDEO_EXT:return KIND_UNKNOWN
        try: st=os.stat(path); c=self._kind_cache.get(path); return c[2] if c and c[0]==st.st_mtime and c[1]==st.st_size else KIND_PENDING
        except OSError:return KIND_UNKNOWN
    def refresh(self):
        if not self._allowed(self._dir):
            self._dir=next((r for r in self._safe_roots if os.path.isdir(r)),os.path.expanduser("~"))
        self._kind_generation+=1; generation=self._kind_generation; self.lbl_path.setText(self._dir); self.list_widget.clear(); pending=[]
        for name in self._entries():
            full=os.path.join(self._dir,name)
            if os.path.isdir(full): kind="dir"; icon="📁 "
            else:
                kind=self._cached_kind(full); icon=_kind_icon(kind)+" "; pending.append(full) if kind==KIND_PENDING else None
            item=QListWidgetItem(icon+name); item.setData(Qt.ItemDataRole.UserRole,full); item.setData(Qt.ItemDataRole.UserRole+1,kind); self.list_widget.addItem(item)
        self.lbl_status.setText(f"{self.list_widget.count()} item(s)" + (f" · classifying {len(pending)} video file(s)…" if pending else ""))
        if pending: threading.Thread(target=self._kind_worker.run_batch,args=(generation,pending),daemon=True).start()
    def _on_probe_progress(self,generation:int,path:str,kind:str):
        if generation!=self._kind_generation:return
        try: st=os.stat(path); self._kind_cache[path]=(st.st_mtime,st.st_size,kind)
        except OSError:self._kind_cache[path]=(0.0,0,kind)
        for i in range(self.list_widget.count()):
            it=self.list_widget.item(i)
            if it and it.data(Qt.ItemDataRole.UserRole)==path:
                it.setData(Qt.ItemDataRole.UserRole+1,kind); it.setText(_kind_icon(kind)+" "+os.path.basename(path)); break
    def _on_probe_done(self,generation:int):
        if generation==self._kind_generation:self.lbl_status.setText(f"{self.list_widget.count()} item(s) · classification complete")
    def _selected_paths(self)->List[str]: return [str(it.data(Qt.ItemDataRole.UserRole)) for it in self.list_widget.selectedItems() if it.data(Qt.ItemDataRole.UserRole)]
    def _go_up(self):
        parent=os.path.dirname(self._dir.rstrip(os.sep)) or os.sep
        if parent==self._dir:return
        if not self._allowed(parent): self.lbl_status.setText("Normal mode stops at a safe root. Enable Advanced/System Files to go higher."); return
        self._dir=parent; self.refresh()
    def _on_double_click(self,item:QListWidgetItem):
        path=item.data(Qt.ItemDataRole.UserRole)
        if not path:return
        if os.path.isdir(path):
            if self._allowed(path): self._dir=path; self.refresh()
            return
        ext=os.path.splitext(path)[1].lower()
        if ext in MEDIA_EXT:self._open_in_player()
        elif ext in PROJECT_EXT or ext in GAME_EXT:self._open_project_or_game()
        else:self.lbl_status.setText("This file type is not a Groovebox media/project/game target.")
    def _new_folder(self):
        name,ok=QInputDialog.getText(self,"New Folder","Folder name:"); name=name.strip()
        if not ok:return
        if not self._valid_leaf(name): QMessageBox.warning(self,"New Folder","Use a simple folder name without path separators or '..'."); return
        dest=os.path.join(self._dir,name)
        if os.path.exists(dest): QMessageBox.warning(self,"New Folder","An item with that name already exists."); return
        try: os.mkdir(dest); self.refresh(); self.lbl_status.setText(f"Created folder: {name}")
        except Exception as e: QMessageBox.warning(self,"New Folder failed",str(e))
    def _rename_selected(self):
        paths=self._selected_paths()
        if len(paths)!=1: QMessageBox.information(self,"Rename","Select exactly one file or folder to rename."); return
        old_path=paths[0]; old_name=os.path.basename(old_path.rstrip(os.sep)); new_name,ok=QInputDialog.getText(self,"Rename","New name:",text=old_name); new_name=new_name.strip()
        if not ok or new_name==old_name:return
        if not self._valid_leaf(new_name): QMessageBox.warning(self,"Rename","Use a simple name without path separators or '..'."); return
        new_path=os.path.join(os.path.dirname(old_path.rstrip(os.sep)),new_name)
        if os.path.exists(new_path): QMessageBox.warning(self,"Rename","The destination already exists; nothing was overwritten."); return
        try: os.rename(old_path,new_path); self.refresh(); self.lbl_status.setText(f"Renamed to: {new_name}")
        except Exception as e: QMessageBox.warning(self,"Rename failed",str(e))
    def _trash_target(self,path:str)->str:
        stamp=time.strftime("%Y%m%d-%H%M%S"); base=os.path.basename(path.rstrip(os.sep)) or "item"; dest=os.path.join(self._trash_dir,f"{stamp}-{base}"); n=2
        while os.path.exists(dest): dest=os.path.join(self._trash_dir,f"{stamp}-{n}-{base}"); n+=1
        return dest
    def _delete_selected(self):
        paths=self._selected_paths()
        if not paths:return
        if QMessageBox.question(self,"Move to Trash",f"Move {len(paths)} item(s) to Groovebox Trash?\nYou can undo the most recent operation.",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:return
        moved=[]
        for path in paths:
            if os.path.realpath(path) in self._safe_roots: QMessageBox.warning(self,"Protected root",f"Will not move protected root:\n{path}"); continue
            try:
                dest=self._trash_target(path); shutil.move(path,dest); moved.append((dest,path))
            except Exception as e: QMessageBox.warning(self,"Trash failed",f"{path}\n{e}")
        self._last_trash_moves=moved; self.refresh(); self.lbl_status.setText(f"Moved {len(moved)} item(s) to Groovebox Trash.")
    def _undo_trash(self):
        if not self._last_trash_moves: self.lbl_status.setText("Nothing to undo."); return
        restored=0; remaining=[]
        for src,dst in reversed(self._last_trash_moves):
            try:
                if os.path.exists(dst): remaining.append((src,dst)); continue
                if os.path.exists(src): os.makedirs(os.path.dirname(dst),exist_ok=True); shutil.move(src,dst); restored+=1
            except Exception: remaining.append((src,dst))
        self._last_trash_moves=list(reversed(remaining)); self.refresh(); self.lbl_status.setText(f"Restored {restored} item(s) from Trash.")
    def _open_in_player(self):
        paths=[p for p in self._selected_paths() if os.path.isfile(p) and os.path.splitext(p)[1].lower() in MEDIA_EXT]
        if not paths: QMessageBox.information(self,"Open in Player","Select one or more supported audio/video/image files first."); return
        dlg=MediaPlayerWindow(self,[{"path":p,"duration_s":5.0 if os.path.splitext(p)[1].lower() in IMAGE_EXT else 0.0} for p in paths],0); dlg.exec()
    def _open_project_or_game(self):
        host=self.parent(); paths=[p for p in self._selected_paths() if os.path.isfile(p)]
        if not paths:return
        for path in paths:
            ext=os.path.splitext(path)[1].lower()
            try:
                if ext in PROJECT_EXT:
                    if host is not None and hasattr(host,"_open_project"): host._open_project(path)
                    elif host is not None and hasattr(host,"host") and hasattr(host.host,"open_project_path"): host.host.open_project_path(path)
                    else: raise RuntimeError("No project loader is available")
                elif ext in GAME_EXT:
                    if host is not None and hasattr(host,"_play_game_package"): host._play_game_package(path)
                    else: raise RuntimeError("No game player is available")
            except Exception as e: QMessageBox.warning(self,"Open failed",f"{path}\n{e}")
    def _add_to_performance_playlist(self):
        host=self.parent()
        if host is None or not hasattr(host,"_playlist"): QMessageBox.information(self,"Add to Playlist","No Performance playlist is available from this window."); return
        paths=[p for p in self._selected_paths() if os.path.isfile(p) and os.path.splitext(p)[1].lower() in MEDIA_EXT]
        if not paths: QMessageBox.information(self,"Add to Playlist","Select supported audio/video/image files first."); return
        added=0
        for path in paths:
            kind=self._cached_kind(path)
            if kind==KIND_PENDING: kind=KIND_UNKNOWN
            if not any(it["path"]==path for it in host._playlist):
                host._playlist.append({"path":path,"volume":100,"mix":False,"kind":kind,"time_s":float(len(host._playlist)*5.0),"duration_s":5.0 if kind==KIND_IMAGE else 0.0}); added+=1
        host._refresh_playlist_widget(); host._sync_project_state(); self.lbl_status.setText(f"Added {added} supported media item(s) to the Performance playlist.")


def open_performance(host) -> Performance:
    """Compatibility standalone opener; main Groovebox embeds Performance as a dock."""
    dlg = Performance(host, parent=host)
    dlg.setModal(False)
    dlg.show()
    return dlg


PiMediaHub = Performance

def open_pi_media_hub(host):
    return open_performance(host)
