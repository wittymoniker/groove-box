#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$ROOT/BUILD_ISO/RUN_ME_GAME_READY_v35.sh" "$ROOT"
