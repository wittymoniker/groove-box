Mathematician's Groovebox / sOS Game-Ready v35.2 — 2026-09-19

Fixes after v35.1:
- Restores current PID1 /init into staged live rootfs when the reusable runtime cache intentionally omits /init.
- Prevents inherited v34f touchpad-priority compatibility hooks from overwriting the v35 REL_X+REL_Y relative-pointer policy.
- Retains v35.1 low-memory streaming initramfs/ISO verification.
- Retains bundled ISO seed: Debian 6.12.96+deb13-amd64 kernel, gzip initramfs seed, GRUB menu, Limine BIOS/UEFI assets.
- Retains explicit Install-to-Disk boot mode (sos.mode=install) and self-contained disk writer stages.

Preferred build:
  sudo ./BUILD_ISO/RUN_ME_ZERO_STATE.sh
or:
  sudo ./BUILD_GROOVEBOX_APPLIANCE_ISO.sh

The first clean runtime provisioning may require network access and Podman/Docker.
Existing valid BUILD_ISO/dist/runtime-cache/initramfs.full.img is reusable.
