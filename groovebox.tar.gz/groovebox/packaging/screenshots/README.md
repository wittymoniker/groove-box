# Store screenshots

Add screenshots of the real current Linux application here before Flathub/Fedora submission.
Do not use the concept-art UI images as if they were screenshots of the shipping application.
