Mathematician's Groovebox — FULL GAME-READY v35 — 2026-09-19

This is a full Groovebox application package with bundled sCode and embedded BUILD_ISO.

Current defaults:
- Step Sequence Length: 12
- Automation Length: 12
- EQR: 0.4014

Game-ready appliance changes:
- Dell/trackpad direct-evdev selection requires REL_X + REL_Y; ABS-only touchpads are not coerced into whole-screen absolute mouse mapping.
- Bare-metal software cursor follows active modal dialogs instead of remaining attached to a blocked parent window.
- Limine includes a verified Install Groovebox / sOS to Disk mode using sos.mode=install.
- Installer source includes GPT creation, FAT/ext4 formatting, root copy, and exact destructive confirmation path.
- Top-level BUILD_GROOVEBOX_APPLIANCE_ISO.sh and BUILD_ISO/RUN_ME_ZERO_STATE.sh route through the v35 game-ready builder.
- APPLIANCE_ISO is intentionally not distributed.

Build the appliance ISO on Fedora/Linux:
  cd groovebox
  chmod +x BUILD_GROOVEBOX_APPLIANCE_ISO.sh BUILD_ISO/RUN_ME_ZERO_STATE.sh
  sudo ./BUILD_GROOVEBOX_APPLIANCE_ISO.sh

The first clean runtime build can require network access for Debian/Python runtime packages.
Secure Boot should remain disabled unless the bootloader is separately signed/enrolled.
A destructive physical disk install is not executed during packaging; test the Install-to-Disk menu on the target machine before relying on it for production use.
