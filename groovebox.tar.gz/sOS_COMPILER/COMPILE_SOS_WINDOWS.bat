@echo off
set ROOT=%~dp0..
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py "%~dp0sos_compiler.py" --root "%ROOT%" %*
) else (
  python "%~dp0sos_compiler.py" --root "%ROOT%" %*
)
pause
