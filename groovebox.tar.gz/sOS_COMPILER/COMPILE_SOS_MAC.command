#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
exec python3 "$ROOT/sOS_COMPILER/sos_compiler.py" --root "$ROOT" "$@"
