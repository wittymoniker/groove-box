#!/usr/bin/env python3
"""
sOS host compiler 0.4

Cross-platform compiler/planner for the sOS source tree.
Runs on Windows, macOS, and Linux with Python 3.

What it does on every host:
- reads sOS/scode/system.sC
- validates required sOS source files
- emits deterministic sos.sir.json plan
- emits SHA-256 manifest
- creates a redistributable sOS source payload

What it does only on Linux:
- optionally invokes sOS/scripts/build_rootfs.sh
- optionally invokes sOS/scripts/build_iso.sh

The actual current sOS target is Linux, so Windows/macOS are host compiler
platforms, not native sOS kernel targets.
"""
from __future__ import annotations
import argparse, hashlib, json, os, platform, re, shutil, subprocess, sys, zipfile
from pathlib import Path

def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def parse_system_scode(text: str):
    # Deliberately conservative parser for the current data-like sOS declaration.
    system = re.search(r'^\s*system\s+([A-Za-z_][\w]*)\s*\{', text, re.M)
    version = re.search(r'^\s*version\s*=\s*([^\s#]+)', text, re.M)
    kernel = re.search(r'^\s*kernel\s*=\s*([^\s#]+)', text, re.M)
    init = re.search(r'^\s*init\s*=\s*([^\s#]+)', text, re.M)
    apps = re.findall(r'^\s*app\s+([A-Za-z_][\w]*)\s*\{', text, re.M)
    assistants = re.findall(r'^\s*assistant\s+([A-Za-z_][\w]*)\s*\{', text, re.M)
    return {
        "system": system.group(1) if system else None,
        "version": version.group(1) if version else None,
        "kernel": kernel.group(1) if kernel else None,
        "init": init.group(1) if init else None,
        "apps": apps,
        "assistants": assistants,
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None, help="Universal redistributable root")
    ap.add_argument("--out", default=None, help="Compiler output directory")
    ap.add_argument("--build-rootfs", action="store_true")
    ap.add_argument("--build-iso", action="store_true")
    ns = ap.parse_args()

    here = Path(__file__).resolve().parent
    root = Path(ns.root).resolve() if ns.root else here.parent
    sos = root / "sOS"
    out = Path(ns.out).resolve() if ns.out else root / "build_sos"
    out.mkdir(parents=True, exist_ok=True)

    required = [
        sos / "scode/system.sC",
        sos / "bin/sos-run",
        sos / "systemd/sos-groovebox.service",
        sos / "scripts/build_rootfs.sh",
        sos / "scripts/build_iso.sh",
    ]
    missing = [str(p.relative_to(root)) for p in required if not p.exists()]
    if missing:
        print("Missing required sOS inputs:", file=sys.stderr)
        for p in missing:
            print("  " + p, file=sys.stderr)
        return 2

    system_text = (sos / "scode/system.sC").read_text("utf-8")
    model = parse_system_scode(system_text)
    if model["system"] != "sOS":
        print("system.sC does not declare system sOS", file=sys.stderr)
        return 3

    manifest = {}
    for p in sorted(sos.rglob("*")):
        if p.is_file():
            manifest[str(p.relative_to(sos))] = sha256(p)

    plan = {
        "format": "sOS-sIR-plan-0.4",
        "host": {
            "system": platform.system(),
            "machine": platform.machine(),
            "python": platform.python_version(),
        },
        "target": {
            "kernel": model["kernel"],
            "init": model["init"],
            "architecture": "amd64",
            "os_family": "Linux",
        },
        "declaration": model,
        "runtime_order": [
            "groovebox.sbin",
            "groovebox.sC",
            "run_groovebox.py",
            "groovebox.py",
        ],
        "source_manifest": manifest,
    }

    (out / "sos.sir.json").write_text(json.dumps(plan, indent=2), "utf-8")
    (out / "SHA256SUMS.json").write_text(json.dumps(manifest, indent=2), "utf-8")

    source_zip = out / "sOS-source-payload.zip"
    with zipfile.ZipFile(source_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(sos.rglob("*")):
            if p.is_file():
                z.write(p, Path("sOS") / p.relative_to(sos))

    print("sOS compile/validation: PASS")
    print("Plan:", out / "sos.sir.json")
    print("Payload:", source_zip)

    if ns.build_rootfs or ns.build_iso:
        if platform.system() != "Linux":
            print("Rootfs/ISO building targets Linux and can only run on a Linux host.", file=sys.stderr)
            return 4

    if ns.build_rootfs:
        subprocess.run(["bash", str(sos / "scripts/build_rootfs.sh")], check=True)
    if ns.build_iso:
        subprocess.run(["bash", str(sos / "scripts/build_iso.sh")], check=True)

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
