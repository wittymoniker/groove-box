Current working interpretation

- Integer indices stay ordinary indices unless program semantics prove otherwise.
- Meum powers are treated as perspective transforms/reflections on a target, not as replacement indices.
- Interval/min/max comparison supplies local direction and turning-point evidence.
- Candidate relation:
    X_n --target perspective M^p--> Y_p(X_n)
  compared across known interval anchors x_min, x_mid, x_max and neighboring indices.
- Reverse-grep accepts a collapse only after numeric + dependency + cross-resolution/behavioral checks.
- Book isn/ics and EQR isn/ics remain distinct unless explicitly proven equivalent for the tested route.

Useful next search:
1. Keep n as the normal address/index.
2. For p in a small signed set (for example -3..3), compute target-perspective transforms using M^p.
3. Compare transformed values against interval endpoints, extrema, and neighboring known points.
4. Detect direction agreement/reversal and extrema crossings.
5. Reverse-grep only the methods whose semantic family and directional behavior match.
6. Preserve a why() certificate for every accepted mapping.
