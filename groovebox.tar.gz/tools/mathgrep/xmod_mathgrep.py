#!/usr/bin/env python3
from __future__ import annotations
import ast, json, math, hashlib, statistics, collections, sys
from pathlib import Path

MEUM = 1.1975807343385265
M1 = MEUM - 1.0
MINV = 1.0 / MEUM

SIN_NAMES = {"sin","math.sin","ot_equiv_sin","ot_sin_via_isn","vg_sin","np.sin","numpy.sin"}
COS_NAMES = {"cos","math.cos","ot_equiv_cos","ot_cos_via_ics","vg_cos","np.cos","numpy.cos"}
BOOK_ISN = {"ot_book_isn"}
BOOK_ICS = {"ot_book_ics"}
EQR_ISN = {"eqr_isn","isn_scalar","isn_vec"}
EQR_ICS = {"eqr_ics","ics_scalar","ics_vec"}
PHASE_NAMES = {"meum_phase_field","_meum_phase_modulation","ot_equiv_i_pow","OT_I_PHASE"}
SPATIAL_NAMES = {"compositional_xyz","eski_fractal_field_sample","eski_fractal_iterate_z"}
CONTEXT_NAMES = {"_contextual_feature_vector","_contextual_numerology"}

FAMILIES = {
    "sin_projection": SIN_NAMES,
    "cos_projection": COS_NAMES,
    "book_isn": BOOK_ISN,
    "book_ics": BOOK_ICS,
    "eqr_isn": EQR_ISN,
    "eqr_ics": EQR_ICS,
    "phase": PHASE_NAMES,
    "spatial": SPATIAL_NAMES,
    "context": CONTEXT_NAMES,
}
REV = {n:k for k,v in FAMILIES.items() for n in v}

XMODS = [
    ("identity", 1.0),
    ("M", MEUM),
    ("M-1", M1),
    ("1/M", MINV),
    ("2(M-1)", 2*M1),
    ("3(M-1)", 3*M1),
    ("2/M", 2*MINV),
    ("3/M", 3*MINV),
]


def fname(fn):
    if isinstance(fn, ast.Name): return fn.id
    if isinstance(fn, ast.Attribute):
        parts=[]; q=fn
        while isinstance(q, ast.Attribute):
            parts.append(q.attr); q=q.value
        if isinstance(q, ast.Name): parts.append(q.id)
        return ".".join(reversed(parts))
    return ""

def strip_prefix(name):
    return name.split(".")[-1]

def h(x): return hashlib.blake2b(repr(x).encode(),digest_size=10).hexdigest()

def main(path:str):
    p=Path(path); src=p.read_text(encoding='utf-8',errors='replace'); lines=src.splitlines()
    tree=ast.parse(src, filename=str(p))
    funcs=[]
    stack=[]
    class FV(ast.NodeVisitor):
        def visit_ClassDef(self,n):
            stack.append(n.name); self.generic_visit(n); stack.pop()
        def visit_FunctionDef(self,n):
            q='.'.join(stack+[n.name]); funcs.append((n.lineno,getattr(n,'end_lineno',n.lineno),q))
            stack.append(n.name); self.generic_visit(n); stack.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
    FV().visit(tree)
    def enc(line):
        cand=[x for x in funcs if x[0]<=line<=x[1]]
        if not cand:return '<module>'
        return min(cand,key=lambda x:x[1]-x[0])[2]

    rows=[]; structural=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Call):
            nm=fname(n.func); short=strip_prefix(nm); fam=REV.get(nm) or REV.get(short)
            if not fam: continue
            line=getattr(n,'lineno',0); arg=n.args[0] if n.args else None
            atxt=(ast.get_source_segment(src,arg) or '') if arg is not None else ''
            calltxt=(ast.get_source_segment(src,n) or '')
            base={"line":line,"function":enc(line),"syntax":nm,"family":fam,
                  "arg":' '.join(atxt.split())[:180],"call":' '.join(calltxt.split())[:240]}
            base["x"] = h((fam, base["arg"], base["function"]))
            # XMOD supplies candidate nearby coordinates, not proofs.
            probes=[]
            for label,scale in XMODS:
                for k in (1,2,3):
                    probes.append({"label":label,"k":k,"scale":scale,
                                   "gap":k*scale,
                                   "gap_mod_2pi":math.fmod(k*scale,2*math.pi)})
            base["probes"]=probes
            rows.append(base)
        elif isinstance(n,ast.BinOp):
            # Structural grep for explicit Meum-bearing arithmetic even when not in a recognized call.
            txt=ast.get_source_segment(src,n) or ''
            if any(tok in txt for tok in ("MEUM","MEUM_INV","MEUM_MINUS_1","MEUM_NORM")):
                structural.append({"line":getattr(n,'lineno',0),"function":enc(getattr(n,'lineno',0)),
                                   "expr":' '.join(txt.split())[:240]})

    byfam=collections.Counter(r['family'] for r in rows)
    byfunc=collections.Counter(r['function'] for r in rows)
    # Cross-modulation data points: pair recognized call sites inside same function and neighboring line window.
    samefunc_pairs=0; near_pairs=0; cross_family_pairs=0; pair_examples=[]
    grouped=collections.defaultdict(list)
    for r in rows: grouped[r['function']].append(r)
    for fn,g in grouped.items():
        g=sorted(g,key=lambda r:r['line'])
        for i,a in enumerate(g):
            for b in g[i+1:]:
                samefunc_pairs+=1
                if abs(a['line']-b['line'])<=12:
                    near_pairs+=1
                    if a['family']!=b['family']:
                        cross_family_pairs+=1
                        if len(pair_examples)<40:
                            pair_examples.append({"function":fn,"lines":[a['line'],b['line']],
                                                  "families":[a['family'],b['family']],
                                                  "syntax":[a['syntax'],b['syntax']]})
    # Number of candidate data points after xmod expansion.
    probe_points=sum(len(r['probes']) for r in rows)
    unique_x=len({r['x'] for r in rows})
    semantic_y=len(byfam)
    out={
      "source":str(p),"lines":len(lines),
      "recognized_math_calls":len(rows),"unique_X_addresses":unique_x,
      "semantic_Y_families":semantic_y,"family_counts":dict(byfam),
      "functions_with_recognized_math":len(byfunc),
      "explicit_meum_arithmetic_nodes":len(structural),
      "xmod_basis_count":len(XMODS),"escape_depths":[1,2,3],
      "xmod_probe_points":probe_points,
      "same_function_call_pairs":samefunc_pairs,
      "nearby_pairs_within_12_lines":near_pairs,
      "nearby_cross_family_pairs":cross_family_pairs,
      "top_math_functions":byfunc.most_common(25),
      "cross_family_examples":pair_examples,
      "structural_meum_examples":structural[:40],
      "notes":[
        "XMOD probes are candidate coordinates only; they are not equivalence certificates.",
        "Book isn/ics and EQR isn/ics remain separate semantic families.",
        "The 1/2/3 escape should only be promoted after numerical, dependency, and cross-run equivalence checks."
      ]
    }
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main(sys.argv[1])
