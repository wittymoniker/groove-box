#!/usr/bin/env python3
from __future__ import annotations
import ast, collections, json, sys
from pathlib import Path
CLASSES={
'book_sin_projection':['math.sin','ot_equiv_sin','ot_sin_via_isn','vg_sin'],
'book_cos_projection':['math.cos','ot_equiv_cos','ot_cos_via_ics','vg_cos'],
'book_isn':['ot_book_isn'],'book_ics':['ot_book_ics'],
'eqr_isn_distinct':['eqr_isn','isn_scalar','isn_vec'],
'eqr_ics_distinct':['eqr_ics','ics_scalar','ics_vec'],
'meum_phase':['meum_phase_field','_meum_phase_modulation'],
'shared_spatial':['compositional_xyz'],
'context_math':['_contextual_feature_vector','_contextual_numerology']}
REV={n:y for y,names in CLASSES.items() for n in names}
def callname(n):
 q=n.func; p=[]
 while isinstance(q,ast.Attribute): p.append(q.attr); q=q.value
 if isinstance(q,ast.Name): p.append(q.id)
 return '.'.join(reversed(p)) if p else ''
def main(path):
 p=Path(path); tree=ast.parse(p.read_text(encoding='utf-8',errors='replace'),filename=str(p)); rows=[]
 for n in ast.walk(tree):
  if not isinstance(n,ast.Call): continue
  name=callname(n); y=REV.get(name) or REV.get(name.split('.')[-1])
  if y: rows.append({'x_line':getattr(n,'lineno',0),'syntax':name,'y_meaning':y,'sCode_target':y})
 groups=collections.defaultdict(list)
 for r in rows: groups[r['y_meaning']].append(r)
 print(json.dumps({'source':str(p),'matches':len(rows),'groups':dict(sorted(groups.items())),
 'contract':{'book_isn':'isn(theta)=2*sin(theta/2)','book_ics':'ics(theta)=2*cos(theta/2)',
 'sin_route':'sin(theta)=isn(2*theta)/2','cos_route':'cos(theta)=ics(2*theta)/2',
 'warning':'eqr_isn/eqr_ics remain distinct Meum-normalized blends'}},indent=2))
if __name__=='__main__':
 if len(sys.argv)!=2: raise SystemExit('usage: math_reverse_grep.py Groovebox/groovebox.py')
 main(sys.argv[1])
