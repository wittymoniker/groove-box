#!/usr/bin/env python3
import ast,json,math,hashlib,collections,sys
from pathlib import Path
MEUM=1.1975807343385265; M1=MEUM-1.; MINV=1./MEUM
FAMS={
'sin_projection':{'sin','math.sin','ot_equiv_sin','ot_sin_via_isn','vg_sin','np.sin','numpy.sin'},
'cos_projection':{'cos','math.cos','ot_equiv_cos','ot_cos_via_ics','vg_cos','np.cos','numpy.cos'},
'book_isn':{'ot_book_isn'},'book_ics':{'ot_book_ics'},
'eqr_isn':{'eqr_isn','isn_scalar','isn_vec'},'eqr_ics':{'eqr_ics','ics_scalar','ics_vec'},
'phase':{'meum_phase_field','_meum_phase_modulation','ot_equiv_i_pow','OT_I_PHASE'},
'spatial':{'compositional_xyz','eski_fractal_field_sample','eski_fractal_iterate_z'},
'context':{'_contextual_feature_vector','_contextual_numerology'}}
REV={n:k for k,v in FAMS.items() for n in v}
XMODS=[('identity',1.),('M',MEUM),('M-1',M1),('1/M',MINV),('2(M-1)',2*M1),('3(M-1)',3*M1),('2/M',2*MINV),('3/M',3*MINV)]
def fnm(q):
    if isinstance(q,ast.Name):return q.id
    if isinstance(q,ast.Attribute):
        a=[]
        while isinstance(q,ast.Attribute):a.append(q.attr);q=q.value
        if isinstance(q,ast.Name):a.append(q.id)
        return '.'.join(reversed(a))
    return ''
def H(x):return hashlib.blake2b(repr(x).encode(),digest_size=10).hexdigest()
def run(path):
 p=Path(path);src=p.read_text(encoding='utf8',errors='replace');tree=ast.parse(src);rows=[];struct=[];stack=[]
 class V(ast.NodeVisitor):
  def visit_ClassDef(self,n):stack.append(n.name);self.generic_visit(n);stack.pop()
  def visit_FunctionDef(self,n):stack.append(n.name);self.generic_visit(n);stack.pop()
  visit_AsyncFunctionDef=visit_FunctionDef
  def visit_Call(self,n):
   nm=fnm(n.func);fam=REV.get(nm) or REV.get(nm.split('.')[-1])
   if fam:
    line=getattr(n,'lineno',0);arg=n.args[0] if n.args else None;at=ast.get_source_segment(src,arg) if arg else ''
    q='.'.join(stack) or '<module>'; x=H((fam,' '.join((at or '').split())[:180],q))
    rows.append((line,q,nm,fam,x))
   self.generic_visit(n)
  def visit_BinOp(self,n):
   txt=ast.get_source_segment(src,n) or ''
   if 'MEUM' in txt and len(txt)<500:struct.append((getattr(n,'lineno',0),'.'.join(stack) or '<module>', ' '.join(txt.split())[:240]))
   self.generic_visit(n)
 V().visit(tree)
 byf=collections.Counter(r[3] for r in rows);byfn=collections.Counter(r[1] for r in rows);grp=collections.defaultdict(list)
 for r in rows:grp[r[1]].append(r)
 same=near=cross=0;ex=[]
 for q,g in grp.items():
  g.sort()
  m=len(g);same+=m*(m-1)//2
  # only sliding window for <=12 lines
  j=0
  for i,a in enumerate(g):
   while j<m and g[j][0]<a[0]-12:j+=1
   for b in g[max(i+1,j):]:
    if b[0]-a[0]>12:break
    near+=1
    if a[3]!=b[3]:
     cross+=1
     if len(ex)<40:ex.append({'function':q,'lines':[a[0],b[0]],'families':[a[3],b[3]],'syntax':[a[2],b[2]]})
 return {'source':str(p),'lines':src.count('\n')+1,'recognized_math_calls':len(rows),'unique_X_addresses':len({r[4] for r in rows}),'semantic_Y_families':len(byf),'family_counts':dict(byf),'functions_with_recognized_math':len(byfn),'explicit_meum_arithmetic_nodes':len(struct),'xmod_basis_count':len(XMODS),'escape_depths':[1,2,3],'xmod_probe_points':len(rows)*len(XMODS)*3,'same_function_call_pairs':same,'nearby_pairs_within_12_lines':near,'nearby_cross_family_pairs':cross,'top_math_functions':byfn.most_common(25),'cross_family_examples':ex,'structural_meum_examples':[{'line':a,'function':b,'expr':c} for a,b,c in struct[:40]],'xmod_basis':[{'name':n,'value':v} for n,v in XMODS], 'notes':['candidate probes, not proofs','book and EQR isn/ics remain distinct','promote 1/2/3 escape only after equivalence tests']}
if __name__=='__main__':print(json.dumps(run(sys.argv[1]),indent=2))
