LINEAR MEUM LOGIC SEARCH
========================
1. normalize with 2-M = 1-(M-1)
2. locate ambiguity with 1/M powers
3. predict powered interval/reflection with (M-1)^p
4. use 2^M only to compare already-equivalent target representations
5. use other book constants as additional locator coordinates
6. verify interval direction, extrema, dependencies and behavior
7. reverse-grep and emit the smallest sCode form

This is a search/routing method. Numeric coincidences alone are not proofs.
