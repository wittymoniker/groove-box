# Groovebox Math Reverse-Grep Trial

Targeted scan of current `groovebox.py`:

- Math-bearing functions: **416**
- Math-bearing call sites: **884**
- sine projection routes: **186**
- cosine projection routes: **85**
- direct book isn: **2**
- direct book ics: **2**
- EQR isn family (kept distinct): **18**
- EQR ics family (kept distinct): **9**
- Meum phase: **4**
- shared spatial: **4**
- context math: **9**

## Abstraction result

The first useful quotient is nine semantic Y families, not one giant trig family. Ordinary/OT/video-game sine and cosine routes can share Y only where the project contract states numerical equivalence. EQR isn/ics remain separate. The next pass should reverse-grep each Python X address to Y, then try the Meum 1/2/3 displacement escape only inside those already-scoped families.
