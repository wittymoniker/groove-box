#!/usr/bin/env python3
from __future__ import annotations
import itertools, json, math, sys
from pathlib import Path
M = 1.1975807343385265
BOOK = {
'Tetta':1.8795,'Letta':1.8393,'P':1.813,'Setta':1.7768,'Detta':1.7549,'J':1.7569,
'Itta':1.7286,'O':1.7221,'o':1.6938,'Hetta':1.678,'Xetta':1.6603,'Qetta':1.63960,
'Etta':1.5652,'Zetta':1.5549,'Ketta':1.5204,'Netta':1.4966,'Yetta':1.4656,
'Wetta':1.4534,'Fetta':1.44138,'Rutta':1.4364,'f':1.4343,'Betta':1.38152,
'Atta':1.3660,'Utta':1.3392,'Cetta':1.2488,'G':1.1993,'Meum':M,'Metta':1.19743,
'Retta':0.4759,'Vetta':0.4360,'n':0.2324}
ROLES={'M-1':M-1,'2-M':2-M,'1/M':1/M,'2^M':2**M}

def main(out):
    hits=[]
    for (a,va),(b,vb) in itertools.permutations(BOOK.items(),2):
        ops=[(f'{a}-{b}',va-vb),(f'{a}/{b}',va/vb if vb else float('nan')),(f'{a}*{b}',va*vb)]
        for expr,v in ops:
            if not math.isfinite(v): continue
            for role,target in ROLES.items():
                rel=abs(v-target)/max(abs(target),1e-15)
                if rel < 0.002:
                    hits.append({'relative_error':rel,'expr':expr,'value':v,'role':role,'target':target})
    hits.sort(key=lambda h:h['relative_error'])
    d={'M':M,'roles':ROLES,'hits_under_0_2_percent':hits,
       'warning':'Rounded book constants make these locator hypotheses, not proofs. Require interval/dependency/behavioral verification.'}
    Path(out).write_text(json.dumps(d,indent=2))
    print(json.dumps({'hits':len(hits),'top':hits[:12]},indent=2))
if __name__=='__main__': main(sys.argv[1] if len(sys.argv)>1 else 'MEUM_BOOK_CONNECTIONS.json')
