#!/usr/bin/env python3
"""Build a translation Problem Tensor [source behavior, unresolved work, target form]."""
from __future__ import annotations
import argparse, ast, json
from pathlib import Path

def target_shape(fn):
    # Conservative target-language abstraction; this is a routing suggestion.
    tags=[]
    s=fn.name.lower()
    if any(x in s for x in ('render','audio','synth','mix')): tags.append('audio')
    if any(x in s for x in ('video','visual','frame','scene')): tags.append('visual')
    if any(x in s for x in ('game','world','npc','terrain')): tags.append('game')
    if any(x in s for x in ('seed','canonical','project','save','load')): tags.append('state')
    if any(x in s for x in ('meum','isn','ics','phase','math','operator')): tags.append('math')
    return {'language':'sCode','form':'rule/op/state','tags':tags}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('source'); ap.add_argument('-o','--output')
    a=ap.parse_args(); p=Path(a.source); txt=p.read_text(errors='replace'); t=ast.parse(txt)
    cells=[]
    for fn in [n for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]:
        calls=sum(isinstance(n,ast.Call) for n in ast.walk(fn))
        branches=sum(isinstance(n,(ast.If,ast.Match)) for n in ast.walk(fn))
        loops=sum(isinstance(n,(ast.For,ast.While)) for n in ast.walk(fn))
        source={'name':fn.name,'line':fn.lineno,'end':getattr(fn,'end_lineno',fn.lineno),
                'calls':calls,'branches':branches,'loops':loops}
        remaining={'semantic_decision': bool(branches or loops),
                   'behavioral_parity_required': True,
                   'priority': (1+calls)*(1+branches+2*loops)}
        cells.append([source,remaining,target_shape(fn)])
    cells.sort(key=lambda c:c[1]['priority'], reverse=True)
    out={'schema':'scode-problem-tensor-3d-1','axes':['source_behavior','remaining_work','target_form'],
         'source':str(p),'shape':[len(cells),3],'cells':cells}
    s=json.dumps(out,indent=2)
    if a.output: Path(a.output).write_text(s)
    else: print(s)
if __name__=='__main__': main()
