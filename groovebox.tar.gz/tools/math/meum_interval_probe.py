#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math
M = 1.1975807343385265188
M1 = M - 1.0

def direction(vals, eps=1e-12):
    ds=[b-a for a,b in zip(vals, vals[1:])]
    pos=any(d>eps for d in ds); neg=any(d<-eps for d in ds)
    if pos and not neg: return 'up'
    if neg and not pos: return 'down'
    if not pos and not neg: return 'flat'
    return 'mixed'

def probe(points, powers):
    out=[]
    for p in powers:
        scale=M1**p
        ys=[x*scale for x in points]
        out.append({'power':p,'scale':scale,'values':ys,'min':min(ys),'max':max(ys),
                    'direction':direction(ys),'net':ys[-1]-ys[0]})
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('points', nargs='+', type=float)
    ap.add_argument('--powers', default='-3,-2,-1,0,1,2,3')
    a=ap.parse_args(); ps=[int(x) for x in a.powers.split(',')]
    r={'M':M,'M1':M1,'source_points':a.points,'source_direction':direction(a.points),
       'reflections':probe(a.points,ps)}
    print(json.dumps(r,indent=2))
if __name__=='__main__': main()
