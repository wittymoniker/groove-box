#!/usr/bin/env python3
"""Reverse-decode mature Groovebox Python into query-targeted sCode structs.

The Python implementation is treated as the reference behavior.  This tool does
not claim semantic equivalence merely from syntax: it extracts a progressively
refinable dependency/problem tensor that sCode can use as a translation map.
"""
from __future__ import annotations
import ast, argparse, json, re, hashlib
from pathlib import Path
from collections import defaultdict, Counter

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "groovebox.py"
DEFAULT_OUT = ROOT / "generated"

UI_PREFIXES = ("QPushButton","QCheckBox","QSlider","QSpinBox","QDoubleSpinBox","QComboBox","QLineEdit","QTextEdit","QTableWidget","QListWidget","QDial","QTabWidget","QProgressBar")
DOMAINS = {
    "audio": ("audio","wav","sound","synth","voice","freq","sample","dsp","mix","render_audio"),
    "visual": ("visual","video","frame","paint","image","scene","geometry","color","render_frame"),
    "game": ("game","player","npc","quest","terrain","collision","world"),
    "sequencer": ("sequence","sequencer","playlist","step","phase","random","euclid","goava"),
    "state": ("canonical","state","snapshot","project","save","load","restore","fingerprint"),
    "ui": ("widget","button","slider","dialog","window","layout","panel","tab","menu","label"),
    "media": ("media","carrier","ffmpeg","video","wav","sample","playhead"),
    "math": ("meum","operator","ot_","isn","ics","finite","infinity","fractal","math_"),
}

# Mechanical-phase deployment: high-risk scopes are expanded first.  These are
# intentionally behavioral names, not assumptions that the implementation is correct.
KEY_SCOPES = {
    "randomize_restore": "randomize sequence restore local global toggle undo defaults",
    "seed_authority": "seed fullweight voice authority canonical blend",
    "audio_render_parity": "render mixdown phase carry play export canonical audio",
    "save_load_fingerprint": "project snapshot save load restore fingerprint recovery",
    "visual_determinism": "visual geometry instrument count determinism render frame",
    "media_carrier": "media carrier sample wav video load route playhead",
    "performance_identity": "performance canonical identity target profile reference",
    "game_bridge": "game videogame player world npc quest canonical",
}

DYNAMIC_RISK_NAMES = {
    "eval", "exec", "getattr", "setattr", "delattr", "globals", "locals",
    "threading.Thread", "QTimer.singleShot", "os.replace", "json.load", "json.dump",
}

def clean(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.:-]+", "_", s)[:180] or "anon"

def domain_for(name: str) -> list[str]:
    n=name.lower(); out=[]
    for d,keys in DOMAINS.items():
        if any(k in n for k in keys): out.append(d)
    return out or ["core"]

class Visitor(ast.NodeVisitor):
    def __init__(self):
        self.classes={}
        self.functions={}
        self.current_class=None
        self.current_func=None
        self.calls=defaultdict(set)
        self.reads=defaultdict(set)
        self.writes=defaultdict(set)
        self.ui=defaultdict(set)
        self.constants={}
        self.branches=defaultdict(int)
        self.raises=defaultdict(int)
        self.try_blocks=defaultdict(int)

    def visit_ClassDef(self,node):
        old=self.current_class; self.current_class=node.name
        self.classes[node.name]={"line":node.lineno,"bases":[ast.unparse(b) for b in node.bases],"methods":[]}
        for n in node.body:
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
                self.classes[node.name]["methods"].append(n.name)
        self.generic_visit(node); self.current_class=old

    def visit_FunctionDef(self,node): self._func(node)
    def visit_AsyncFunctionDef(self,node): self._func(node)
    def _func(self,node):
        owner=self.current_class or "<module>"; q=f"{owner}.{node.name}"
        old=self.current_func; self.current_func=q
        self.functions[q]={"line":node.lineno,"end":getattr(node,"end_lineno",node.lineno),"args":[a.arg for a in node.args.args],"domains":domain_for(q)}
        self.generic_visit(node); self.current_func=old

    def visit_If(self,node):
        if self.current_func: self.branches[self.current_func] += 1
        self.generic_visit(node)

    def visit_For(self,node):
        if self.current_func: self.branches[self.current_func] += 1
        self.generic_visit(node)

    def visit_While(self,node):
        if self.current_func: self.branches[self.current_func] += 1
        self.generic_visit(node)

    def visit_Try(self,node):
        if self.current_func: self.try_blocks[self.current_func] += 1
        self.generic_visit(node)

    def visit_Raise(self,node):
        if self.current_func: self.raises[self.current_func] += 1
        self.generic_visit(node)

    def visit_Call(self,node):
        if self.current_func:
            try: self.calls[self.current_func].add(ast.unparse(node.func))
            except Exception: pass
        self.generic_visit(node)

    def visit_Attribute(self,node):
        if self.current_func:
            try:
                base=ast.unparse(node.value)
                if base=="self":
                    if isinstance(node.ctx,ast.Store): self.writes[self.current_func].add(node.attr)
                    elif isinstance(node.ctx,ast.Load): self.reads[self.current_func].add(node.attr)
            except Exception: pass
        self.generic_visit(node)

    def visit_Assign(self,node):
        # detect self.foo = QWidgetLike(...)
        if self.current_func and isinstance(node.value,ast.Call):
            try: ctor=ast.unparse(node.value.func)
            except Exception: ctor=""
            if ctor.startswith(UI_PREFIXES):
                for t in node.targets:
                    if isinstance(t,ast.Attribute) and isinstance(t.value,ast.Name) and t.value.id=="self":
                        self.ui[self.current_class or "<module>"].add((t.attr,ctor))
        # module constants
        if self.current_class is None and self.current_func is None:
            for t in node.targets:
                if isinstance(t,ast.Name):
                    try:
                        if isinstance(node.value,(ast.Constant,ast.List,ast.Tuple,ast.Dict)):
                            self.constants[t.id]=ast.literal_eval(node.value)
                    except Exception: pass
        self.generic_visit(node)

def relevance(item,target):
    if not target: return 1.0
    terms=[t.lower() for t in re.findall(r"[A-Za-z0-9_]+",target) if len(t)>1]
    s=json.dumps(item,sort_keys=True).lower()
    hit=sum(1 for t in terms if t in s)
    return hit/max(1,len(terms))

def build(source: Path,target: str="",resolution: int=4):
    text=source.read_text(encoding="utf-8",errors="replace")
    tree=ast.parse(text,filename=str(source))
    v=Visitor(); v.visit(tree)
    funcs=[]
    for q,f in v.functions.items():
        item=dict(id=q,**f,calls=sorted(v.calls[q]),reads=sorted(v.reads[q]),writes=sorted(v.writes[q]),
                  branches=v.branches[q],try_blocks=v.try_blocks[q],raises=v.raises[q])
        item["relevance"]=round(relevance(item,target),4)
        callset=set(item["calls"])
        dyn=sum(1 for c in callset if c in DYNAMIC_RISK_NAMES or c.endswith(".connect") or c.startswith("getattr") or c.startswith("setattr"))
        span=max(1,item["end"]-item["line"]+1)
        # Static semantic-risk score. It is a scoping priority, not a correctness score.
        risk=(min(span,400)/40.0 + item["branches"]*0.35 + item["try_blocks"]*0.45 + len(item["writes"])*0.18 + dyn*1.4)
        item["semantic_risk"]=round(risk,3)
        item["dynamic_risk_calls"]=dyn
        # resolution grows around relevant paths but never deletes coarse identity
        if target and item["relevance"]==0 and resolution<8:
            item["calls"] = [] if resolution<5 else item["calls"][:8]
            item["reads"] = [] if resolution<4 else item["reads"][:8]
            item["writes"] = [] if resolution<4 else item["writes"][:8]
        funcs.append(item)
    funcs.sort(key=lambda x:(-x["relevance"],x["line"],x["id"]))
    classes=[]
    for name,c in v.classes.items():
        classes.append(dict(id=name,domains=domain_for(name),ui=[{"id":a,"type":b} for a,b in sorted(v.ui[name])],**c))
    # shared-state edges: writer -> reader. This is our first reverse semantic graph.
    writers=defaultdict(list); readers=defaultdict(list)
    for f in funcs:
        for s in f["writes"]: writers[s].append(f["id"])
        for s in f["reads"]: readers[s].append(f["id"])
    edges=[]
    for state in sorted(set(writers)|set(readers)):
        for a in writers[state][:64]:
            for b in readers[state][:64]:
                if a!=b: edges.append({"kind":"state_flow","state":state,"from":a,"to":b})
                if len(edges)>20000: break
            if len(edges)>20000: break
        if len(edges)>20000: break
    # Cross-struct holdings: shared state whose producer and consumer live in different structs.
    cross_struct=[]
    for e in edges:
        a=e["from"].split('.')[0]; b=e["to"].split('.')[0]
        if a != b:
            cross_struct.append(e)

    # A function is mechanically ready only in the narrow static sense that the decoder
    # found no obvious dynamic/large-scope hazard. Behavioral parity still requires tests.
    for f in funcs:
        cross=sum(1 for e in cross_struct if e["from"]==f["id"] or e["to"]==f["id"])
        f["cross_struct_edges"]=cross
        f["mechanical_static_ready"] = bool(
            f["semantic_risk"] < 6.0 and f["dynamic_risk_calls"] == 0 and
            (f["end"]-f["line"]+1) <= 120 and cross <= 24
        )

    # problem tensor cells = functions not yet declared as native/pure sCode implementation.
    problems=[]
    for f in funcs:
        complexity=max(1,(f["end"]-f["line"]+1)) + len(f["calls"])*2 + len(f["writes"])*3
        problems.append({"id":f["id"],"owner":f["id"].split('.')[0],"domains":f["domains"],"line":f["line"],"complexity":complexity,"relevance":f["relevance"],"status":"reference_python","target":"scode_struct"})
    out={
        "format":"sCode.reverse_translation_tensor.v1",
        "source":source.name,"source_sha256":hashlib.sha256(text.encode()).hexdigest(),
        "target_query":target,"resolution":resolution,
        "summary":{"lines":len(text.splitlines()),"classes":len(classes),"functions":len(funcs),"ui_controls":sum(len(c["ui"]) for c in classes),"state_flow_edges":len(edges),"cross_struct_edges":len(cross_struct),"problem_cells":len(problems),
                   "mechanical_static_ready":sum(1 for f in funcs if f["mechanical_static_ready"]),
                   "semantic_review_needed":sum(1 for f in funcs if not f["mechanical_static_ready"])},
        "classes":classes,"functions":funcs,"edges":edges,"cross_struct_edges":cross_struct,"problems":problems,
    }
    return out

def build_scope_plan(source: Path):
    plans=[]
    for name,query in KEY_SCOPES.items():
        d=build(source,query,7)
        relevant=[f for f in d["functions"] if f["relevance"]>0]
        # Highest-risk relevant functions are expanded first; low-risk agreement can stay compressed.
        ranked=sorted(relevant,key=lambda f:(-f["semantic_risk"],-f["cross_struct_edges"],f["line"]))
        plans.append({
            "scope":name,"query":query,"relevant_functions":len(relevant),
            "mechanical_static_ready":sum(1 for f in relevant if f["mechanical_static_ready"]),
            "review_needed":sum(1 for f in relevant if not f["mechanical_static_ready"]),
            "top_review_targets":[{k:f[k] for k in ("id","line","end","semantic_risk","cross_struct_edges","dynamic_risk_calls")} for f in ranked[:16]],
        })
    return plans

def render_scope_plan_md(plans):
    lines=["# Mechanical Phase Scope Plan","",
           "Static scoping only: `mechanical_static_ready` means no obvious AST-level hazard; it is not a behavioral-parity certificate.",""]
    for p in plans:
        lines += [f"## {p['scope']}", f"- relevant functions: {p['relevant_functions']}",
                  f"- statically mechanical: {p['mechanical_static_ready']}", f"- semantic review first: {p['review_needed']}", "", "Priority targets:"]
        for f in p["top_review_targets"]:
            lines.append(f"- `{f['id']}` L{f['line']}-{f['end']} — risk {f['semantic_risk']}, cross-struct {f['cross_struct_edges']}, dynamic calls {f['dynamic_risk_calls']}")
        lines.append("")
    return "\n".join(lines)+"\n"

def build_holdings(data, plans):
    return {
      "format":"sCode.mechanical_holdings.v1",
      "source":data["source"],"source_sha256":data["source_sha256"],
      "policy":{
        "python":"reference_behavior",
        "scode":"target_semantics",
        "math":"specification_or_experimental_transform; never auto-promote to parity",
        "mechanical":"emit syntax only after scoped semantic agreement and differential tests"
      },
      "verified_holdings":[],
      "static_holdings":{
        "classes":data["summary"]["classes"],"functions":data["summary"]["functions"],
        "state_flow_edges":data["summary"]["state_flow_edges"],"cross_struct_edges":data["summary"]["cross_struct_edges"],
      },
      "scope_plan":plans
    }


def build_hub_triangulation(data, pair_count=8):
    """Probe multiple hub entry points from both related and deliberately distant hubs.

    This is a structural/scoping diagnostic.  It looks for whether independent entry
    points converge on the same shared-state neighborhood, and whether related hubs
    expose compatible scopes.  It is not a behavioral-equivalence proof.
    """
    funcs={f["id"]:f for f in data["functions"]}
    adj=defaultdict(Counter)
    direct_states=defaultdict(set)
    for e in data["edges"]:
        a,b,st=e["from"],e["to"],e["state"]
        adj[a][b]+=1; adj[b][a]+=1
        direct_states[tuple(sorted((a,b)))].add(st)
    degree={n:sum(c.values()) for n,c in adj.items()}
    # High-leverage hubs only; avoid tiny leaf functions dominating pair selection.
    hubs=[n for n,_ in sorted(degree.items(), key=lambda kv:(-kv[1],kv[0]))[:80] if n in funcs]

    def domains(n): return set(funcs[n].get("domains",[]))
    def neigh(n): return set(adj.get(n,{}))
    def jacc(a,b):
        u=a|b
        return len(a&b)/len(u) if u else 0.0
    def radius(start, r=2):
        seen={start}; frontier={start}
        for _ in range(r):
            nxt=set()
            for x in frontier: nxt.update(adj.get(x,{}))
            nxt-=seen; seen|=nxt; frontier=nxt
            if not frontier: break
        return seen
    def entry_points(n, limit=6):
        return [{"id":m,"shared_state_edges":w,"domains":sorted(domains(m))}
                for m,w in adj.get(n,{}).most_common(limit)]
    def pair_record(a,b,kind):
        ra,rb=radius(a,2),radius(b,2)
        ov=ra&rb
        shared=direct_states.get(tuple(sorted((a,b))),set())
        # Nodes independently reached from both entry hubs are particularly useful
        # cross-check points. Rank by total structural degree.
        conv=sorted(ov-{a,b}, key=lambda n:(-degree.get(n,0),n))[:12]
        return {
            "kind":kind,"hub_a":a,"hub_b":b,
            "degree_a":degree.get(a,0),"degree_b":degree.get(b,0),
            "domains_a":sorted(domains(a)),"domains_b":sorted(domains(b)),
            "domain_similarity":round(jacc(domains(a),domains(b)),4),
            "neighbor_similarity":round(jacc(neigh(a),neigh(b)),4),
            "direct_shared_states":sorted(shared)[:24],
            "radius2_a":len(ra),"radius2_b":len(rb),"radius2_overlap":len(ov),
            "radius2_overlap_ratio":round(len(ov)/max(1,len(ra|rb)),4),
            "entry_points_a":entry_points(a),"entry_points_b":entry_points(b),
            "convergence_points":[{"id":n,"degree":degree.get(n,0),"domains":sorted(domains(n))} for n in conv],
        }

    candidates=[]
    for i,a in enumerate(hubs):
        for b in hubs[i+1:]:
            ds=jacc(domains(a),domains(b)); ns=jacc(neigh(a),neigh(b))
            direct=1.0 if direct_states.get(tuple(sorted((a,b)))) else 0.0
            class_same=1.0 if a.split('.')[0]==b.split('.')[0] else 0.0
            related=2.2*ds+2.6*ns+1.4*direct+0.3*class_same
            # Deliberately prefer different structs/domains and no direct edge for distant probes,
            # while retaining high degree on both ends.
            distant=(1-ds)*2.0+(1-ns)*2.4+(1-direct)*1.2+(1-class_same)*0.5
            leverage=(degree.get(a,0)+degree.get(b,0))/max(1,max(degree.values())*2)
            candidates.append((related+0.35*leverage,"related",a,b))
            if not direct and a.split('.')[0]!=b.split('.')[0]:
                candidates.append((distant+0.35*leverage,"distant",a,b))
    related=[]; distant=[]; used_rel=set(); used_dist=set()
    for score,kind,a,b in sorted(candidates,key=lambda x:(-x[0],x[2],x[3])):
        target=related if kind=="related" else distant
        used=used_rel if kind=="related" else used_dist
        if len(target)>=pair_count: continue
        # Encourage multiple independent entry hubs instead of repeating one superstar.
        # For distant probes require disjoint endpoints so the sample really enters
        # the graph from multiple unrelated places. Related probes may reuse one
        # endpoint, but not both, because a shared family hub can be informative.
        if kind == "distant":
            if a in used or b in used: continue
        elif a in used and b in used:
            continue
        target.append(pair_record(a,b,kind)); used.update((a,b))
        if len(related)>=pair_count and len(distant)>=pair_count: break
    return {
        "format":"sCode.hub_triangulation.v1",
        "policy":"structural multi-entry scoping; related + deliberately distant hubs; not behavioral proof",
        "hub_count_considered":len(hubs),
        "related_pairs":related,"distant_pairs":distant,
    }

def render_hub_triangulation_md(h):
    lines=["# Multi-entry Hub Triangulation","",
           "This pass deliberately enters the shared-state graph from both similar/related hubs and distant/unrelated hubs. Convergence is useful evidence for scoping, not a behavioral-parity certificate.",""]
    for title,key in (("Related hub probes","related_pairs"),("Distant / nominally unrelated hub probes","distant_pairs")):
        lines += [f"## {title}",""]
        for i,p in enumerate(h[key],1):
            lines += [f"### {i}. `{p['hub_a']}` ↔ `{p['hub_b']}`",
                      f"- degrees: {p['degree_a']} / {p['degree_b']}",
                      f"- domain similarity: {p['domain_similarity']}; neighbor similarity: {p['neighbor_similarity']}",
                      f"- radius-2 overlap: {p['radius2_overlap']} ({p['radius2_overlap_ratio']:.4f} of union)",
                      f"- direct shared states: {', '.join(p['direct_shared_states']) if p['direct_shared_states'] else 'none'}"]
            conv=[x['id'] for x in p['convergence_points'][:8]]
            lines.append(f"- convergence points: {', '.join(conv) if conv else 'none within radius 2'}")
            ea=[x['id'] for x in p['entry_points_a'][:4]]; eb=[x['id'] for x in p['entry_points_b'][:4]]
            lines.append(f"- A entry points: {', '.join(ea) if ea else 'none'}")
            lines.append(f"- B entry points: {', '.join(eb) if eb else 'none'}")
            lines.append("")
    return "\n".join(lines)+"\n"

def emit_scode(data):
    q=data.get("target_query") or "whole_groovebox"
    s=data["summary"]
    lines=["# Generated by tools/reverse_decode_groovebox.py", "program GrooveboxReverseDecoded {", "  use core", "  use math", "  use media", "  use system", "  use game", "  permit studio.launch", "  theorem_policy exact_or_fallback", f"  reverse_target {clean(q)}", f"  reverse_resolution {data['resolution']:X}", f"  reference_sha256 {data['source_sha256']}", "", "  reverse_summary python_reference {", f"    lines {s['lines']:X}", f"    classes {s['classes']:X}", f"    functions {s['functions']:X}", f"    ui_controls {s['ui_controls']:X}", f"    state_edges {s['state_flow_edges']:X}", "  }"]
    for c in data["classes"]:
        lines += ["", f"  struct {clean(c['id'])} {{", f"    source_line {c['line']:X}"]
        for d in c["domains"]: lines.append(f"    domain {clean(d)}")
        for m in c["methods"]: lines.append(f"    method {clean(m)}")
        for u in c["ui"]: lines.append(f"    control {clean(u['id'])} type={clean(u['type'])}")
        lines.append("  }")
    # high-relevance function detail only; coarse class identity is always retained.
    detail=[f for f in data["functions"] if (not q or f["relevance"]>0 or data["resolution"]>=8)]
    for f in detail[:4000]:
        lines += ["", f"  reverse_fn {clean(f['id'])} {{", f"    source_line {f['line']:X}", f"    source_end {f['end']:X}"]
        for d in f["domains"]: lines.append(f"    domain {clean(d)}")
        for r in f["reads"][:32]: lines.append(f"    reads {clean(r)}")
        for w in f["writes"][:32]: lines.append(f"    writes {clean(w)}")
        for c in f["calls"][:32]: lines.append(f"    calls {clean(c)}")
        lines.append("  }")
    lines += ["", "  # Mature reference remains the execution backend for unsupported structs.", "  bridge python_reference groovebox.py", "  launch master_studio", "}"]
    return "\n".join(lines)+"\n"

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--source",default=str(DEFAULT_SOURCE)); ap.add_argument("--target",default=""); ap.add_argument("--resolution",type=int,default=6); ap.add_argument("--out",default=str(DEFAULT_OUT)); a=ap.parse_args()
    out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    data=build(Path(a.source),a.target,max(0,min(15,a.resolution)))
    plans=build_scope_plan(Path(a.source))
    holdings=build_holdings(data,plans)
    hubs=build_hub_triangulation(data)
    holdings["hub_triangulation"]={"related_pairs":len(hubs["related_pairs"]),"distant_pairs":len(hubs["distant_pairs"])}
    (out/"groovebox_translation_tensor.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
    (out/"mechanical_scope_plan.json").write_text(json.dumps(plans,indent=2),encoding="utf-8")
    (out/"mechanical_scope_plan.md").write_text(render_scope_plan_md(plans),encoding="utf-8")
    (out/"mechanical_holdings.json").write_text(json.dumps(holdings,indent=2),encoding="utf-8")
    (out/"hub_triangulation.json").write_text(json.dumps(hubs,indent=2),encoding="utf-8")
    (out/"hub_triangulation.md").write_text(render_hub_triangulation_md(hubs),encoding="utf-8")
    (out/"groovebox_finished_stab.sC").write_text(emit_scode(data),encoding="utf-8")
    print(json.dumps(data["summary"],indent=2)); print(out/"groovebox_finished_stab.sC"); print(out/"mechanical_scope_plan.md"); print(out/"hub_triangulation.md")
if __name__=="__main__": main()
