from pathlib import Path
import os, tempfile, hashlib, sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"sCode/native_data"))
from snative import pack, unpack, read_container
with tempfile.TemporaryDirectory() as td:
    td=Path(td); src=td/"weird.bin"; src.write_bytes(os.urandom(65537))
    box=td/"weird.sndata"; out=td/"out.bin"
    pack(src,box,"file:binary"); m,_=read_container(box); unpack(box,out)
    assert src.read_bytes()==out.read_bytes()
    assert hashlib.sha256(src.read_bytes()).hexdigest()==m["sha256"]
print("sNativeData roundtrip PASS")
