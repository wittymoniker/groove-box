"""Deterministic sCode -> sIR compiler."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
from .parser import parse_program

IR_VERSION=1
RADIX=16

def _node(n):
    return {
        "kind": n.kind,
        "name": n.name,
        "args": list(n.args),
        "attrs": dict(sorted(n.attrs.items())),
        "children": [_node(c) for c in n.children],
    }

def canonical_ir_bytes(ir):
    clean={k:v for k,v in ir.items() if k not in {"source","sha256"}}
    return json.dumps(clean,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")

def compile_text(text, source="<memory>"):
    program=parse_program(text)
    ir={
        "scode_ir_version":IR_VERSION,
        "radix":RADIX,
        "source_language":"sCode",
        "nodes":[_node(n) for n in program.nodes],
    }
    digest=hashlib.sha256(canonical_ir_bytes(ir)).hexdigest()
    ir["source"]=source
    ir["sha256"]=digest
    return ir,digest

def compile_file(path):
    p=Path(path)
    ir,_=compile_text(p.read_text(encoding="utf-8"),p.name)
    return ir

def write_ir(ir, output):
    p=Path(output)
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+".tmp")
    tmp.write_text(json.dumps(ir,sort_keys=True,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    tmp.replace(p)
    return p

def validate_file(path):
    compile_file(path)
    return True
