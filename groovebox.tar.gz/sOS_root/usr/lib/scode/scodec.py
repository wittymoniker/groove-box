#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from scode.compiler import compile_file,write_ir,validate_file

def build_parser():
    ap=argparse.ArgumentParser(prog="scodec",description="sCode compiler")
    ap.add_argument("--version",action="version",version="scodec 0.2.0")
    sub=ap.add_subparsers(dest="cmd",required=True)
    c=sub.add_parser("compile"); c.add_argument("source"); c.add_argument("-o","--output")
    v=sub.add_parser("check"); v.add_argument("source")
    i=sub.add_parser("inspect"); i.add_argument("source")
    h=sub.add_parser("hash"); h.add_argument("source")
    return ap

def main(argv=None):
    a=build_parser().parse_args(argv)
    try:
        if a.cmd=="check":
            validate_file(a.source); print(f"{a.source}: valid sCode"); return 0
        ir=compile_file(a.source)
        if a.cmd=="inspect":
            print(json.dumps(ir,sort_keys=True,indent=2,ensure_ascii=False)); return 0
        if a.cmd=="hash":
            print(ir["sha256"]); return 0
        out=Path(a.output) if a.output else Path(a.source).with_suffix(".sir")
        write_ir(ir,out)
        print(f"compiled {a.source} -> {out}")
        print(f"sIR sha256 {ir['sha256']}")
        return 0
    except (SyntaxError,ValueError,OSError) as exc:
        print(f"scodec: error: {exc}",file=sys.stderr); return 1

if __name__=="__main__":
    raise SystemExit(main())
