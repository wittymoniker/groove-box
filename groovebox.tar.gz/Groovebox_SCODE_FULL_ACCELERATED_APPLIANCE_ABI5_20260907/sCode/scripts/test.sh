#!/usr/bin/env sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
"$root/scripts/check-source-purity.sh"
scode0=$($root/scripts/find-scode0.sh)
if [ -x "$scode0" ]; then
  "$scode0" run "$root/examples/hello.sC"
  "$scode0" run "$root/tests/math_kernel_test.sC"
  "$scode0" run "$root/tests/finite_grep_test.sC"
  "$scode0" run "$root/tests/hardware_modality_test.sC"
else
  echo "SKIP runtime tests: no stage-0 executable for this platform"
fi
