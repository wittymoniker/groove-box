include(joinpath(@__DIR__, "GrooveboxHybrid.jl"))
using .GrooveboxHybrid
p = collect(range(0.0, 1.0; length=4096))
freq, ph, am = meum_modulation(p; am_depth=0.3, am_rate=1.7, fm_depth=0.2, fm_rate=0.9, pm_depth=0.25, pm_rate=1.1, pm_feedback=0.2, meum_depth=0.4)
@assert length(freq) == length(p) == length(ph) == length(am)
v = voice_synth(p, 0.63, 0.71, 0.4, 0.9, 12, 5, 0, 0, 0.2, 12345, 7)
vc = cpp_voice(Float64.(p), 0.63, 0.71, 0.4, 0.9, 12, 5, 0, 0, 0.2, 12345, 7)
@assert maximum(abs.(v .- vc)) == 0f0
println("Julia/C++ smoke: PASS")
println("C++ library: ", cpp_library())
