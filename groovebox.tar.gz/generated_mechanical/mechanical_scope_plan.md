# Mechanical Phase Scope Plan

Static scoping only: `mechanical_static_ready` means no obvious AST-level hazard; it is not a behavioral-parity certificate.

## randomize_restore
- relevant functions: 370
- statically mechanical: 183
- semantic review first: 187

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33134-34710 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20174-20623 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 13, dynamic calls 4
- `PaintbrushTable.engage_paint` L16327-17056 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39732-40094 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35118-35373 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19970-20172 — risk 24.425, cross-struct 0, dynamic calls 0
- `MasterControlPatchbayPage.__init__` L15501-15680 — risk 21.74, cross-struct 58, dynamic calls 10
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32337-32569 — risk 21.565, cross-struct 6, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31969-32171 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 5, dynamic calls 1
- `<module>.idealized_operator_struct` L4869-5023 — risk 20.125, cross-struct 0, dynamic calls 2
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26395-26606 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36761-36913 — risk 19.305, cross-struct 0, dynamic calls 1

## seed_authority
- relevant functions: 264
- statically mechanical: 102
- semantic review first: 162

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33134-34710 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20174-20623 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 10, dynamic calls 4
- `PaintbrushTable.engage_paint` L16327-17056 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35118-35373 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19970-20172 — risk 24.425, cross-struct 0, dynamic calls 0
- `VisualOscilloscope.paintEvent` L5405-5680 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32337-32569 — risk 21.565, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31969-32171 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 4, dynamic calls 1
- `<module>.idealized_operator_struct` L4869-5023 — risk 20.125, cross-struct 0, dynamic calls 2
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26395-26606 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25050-25193 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._apply_provenance_payload` L37442-37579 — risk 18.1, cross-struct 0, dynamic calls 1

## audio_render_parity
- relevant functions: 455
- statically mechanical: 239
- semantic review first: 216

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33134-34710 — risk 99.21, cross-struct 4, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38892-39334 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20174-20623 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 13, dynamic calls 4
- `PaintbrushTable.engage_paint` L16327-17056 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39732-40094 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35118-35373 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19970-20172 — risk 24.425, cross-struct 0, dynamic calls 0
- `VisualOscilloscope.paintEvent` L5405-5680 — risk 22.93, cross-struct 21, dynamic calls 1
- `MasterControlPatchbayPage.__init__` L15501-15680 — risk 21.74, cross-struct 59, dynamic calls 10
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32337-32569 — risk 21.565, cross-struct 6, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31969-32171 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 5, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26395-26606 — risk 19.73, cross-struct 1, dynamic calls 1

## save_load_fingerprint
- relevant functions: 174
- statically mechanical: 67
- semantic review first: 107

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38892-39334 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 10, dynamic calls 4
- `PaintbrushTable.engage_paint` L16327-17056 — risk 35.87, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39732-40094 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35118-35373 — risk 27.87, cross-struct 0, dynamic calls 1
- `VisualOscilloscope.paintEvent` L5405-5680 — risk 22.93, cross-struct 15, dynamic calls 1
- `MasterControlPatchbayPage.__init__` L15501-15680 — risk 21.74, cross-struct 57, dynamic calls 10
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 5, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36761-36913 — risk 19.305, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25050-25193 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._apply_provenance_payload` L37442-37579 — risk 18.1, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_seeded_harmonic_randomization` L30587-30766 — risk 17.93, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._open_global_algo_panel` L39356-39585 — risk 17.68, cross-struct 0, dynamic calls 6
- `MathematiciansGrooveboxApp._clear_project_memory` L28663-28792 — risk 16.98, cross-struct 4, dynamic calls 1

## visual_determinism
- relevant functions: 415
- statically mechanical: 191
- semantic review first: 224

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33134-34710 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38892-39334 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20174-20623 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 13, dynamic calls 4
- `PaintbrushTable.engage_paint` L16327-17056 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39732-40094 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35118-35373 — risk 27.87, cross-struct 0, dynamic calls 1
- `VisualOscilloscope.paintEvent` L5405-5680 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32337-32569 — risk 21.565, cross-struct 6, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31969-32171 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 5, dynamic calls 1
- `<module>.idealized_operator_struct` L4869-5023 — risk 20.125, cross-struct 0, dynamic calls 2
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26395-26606 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36761-36913 — risk 19.305, cross-struct 0, dynamic calls 1

## media_carrier
- relevant functions: 285
- statically mechanical: 147
- semantic review first: 138

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33134-34710 — risk 99.21, cross-struct 4, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38892-39334 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 12, dynamic calls 4
- `VisualOscilloscope.paintEvent` L5405-5680 — risk 22.93, cross-struct 21, dynamic calls 1
- `MasterControlPatchbayPage.__init__` L15501-15680 — risk 21.74, cross-struct 58, dynamic calls 10
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25050-25193 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._apply_provenance_payload` L37442-37579 — risk 18.1, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_seeded_harmonic_randomization` L30587-30766 — risk 17.93, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._clear_project_memory` L28663-28792 — risk 16.98, cross-struct 3, dynamic calls 1
- `VideoSynthEngine.__init__` L6035-6173 — risk 16.395, cross-struct 91, dynamic calls 0
- `MathematiciansGrooveboxApp._contextual_feature_vector` L18940-19086 — risk 15.275, cross-struct 0, dynamic calls 3
- `MathematiciansGrooveboxApp._deactivate_engine_generated_content` L28297-28423 — risk 14.755, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._restore_project_ui_state` L28860-28942 — risk 14.595, cross-struct 0, dynamic calls 1

## performance_identity
- relevant functions: 196
- statically mechanical: 61
- semantic review first: 135

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33134-34710 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20174-20623 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 10, dynamic calls 4
- `PaintbrushTable.engage_paint` L16327-17056 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39732-40094 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35118-35373 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19970-20172 — risk 24.425, cross-struct 0, dynamic calls 0
- `VisualOscilloscope.paintEvent` L5405-5680 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32337-32569 — risk 21.565, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31969-32171 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26395-26606 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36761-36913 — risk 19.305, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25050-25193 — risk 18.53, cross-struct 0, dynamic calls 1

## game_bridge
- relevant functions: 172
- statically mechanical: 53
- semantic review first: 119

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20635-23830 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33134-34710 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29183-29556 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38892-39334 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20174-20623 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18227-18597 — risk 39.815, cross-struct 10, dynamic calls 4
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35118-35373 — risk 27.87, cross-struct 0, dynamic calls 1
- `VisualOscilloscope.paintEvent` L5405-5680 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32337-32569 — risk 21.565, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31969-32171 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31652-31847 — risk 20.44, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26395-26606 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25050-25193 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_seeded_harmonic_randomization` L30587-30766 — risk 17.93, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._open_global_algo_panel` L39356-39585 — risk 17.68, cross-struct 0, dynamic calls 6
- `MathematiciansGrooveboxApp._clear_project_memory` L28663-28792 — risk 16.98, cross-struct 3, dynamic calls 1

