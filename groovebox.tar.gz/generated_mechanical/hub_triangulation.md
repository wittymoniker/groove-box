# Multi-entry Hub Triangulation

This pass deliberately enters the shared-state graph from both similar/related hubs and distant/unrelated hubs. Convergence is useful evidence for scoping, not a behavioral-parity certificate.

## Related hub probes

### 1. `AutomationPatternPage.__init__` ↔ `DrumMatrixPage.__init__`
- degrees: 79 / 79
- domain similarity: 1.0; neighbor similarity: 0.9661
- radius-2 overlap: 87 (1.0000 of union)
- direct shared states: container, grid, scroll
- convergence points: VideoSynthEngine.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, SynthModulePage.__init__, VideoSynthViewer.__init__, GranularFXPage.__init__, MasterControlPatchbayPage.__init__, InstrumentVisualObject.__init__
- A entry points: DrumMatrixPage.__init__, GranularFXPage.__init__, SynthModulePage.__init__, DrumMatrixPage.refresh_drum_grid
- B entry points: GranularFXPage.__init__, AutomationPatternPage.__init__, SynthModulePage.__init__, DrumMatrixPage.refresh_drum_grid

### 2. `GranularFXPage.__init__` ↔ `AutomationPatternPage.__init__`
- degrees: 81 / 79
- domain similarity: 1.0; neighbor similarity: 0.95
- radius-2 overlap: 87 (0.9560 of union)
- direct shared states: container, grid, scroll
- convergence points: VideoSynthEngine.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, SynthModulePage.__init__, VideoSynthViewer.__init__, MasterControlPatchbayPage.__init__, DrumMatrixPage.__init__, InstrumentVisualObject.__init__
- A entry points: DrumMatrixPage.__init__, AutomationPatternPage.__init__, SynthModulePage.__init__, DrumMatrixPage.refresh_drum_grid
- B entry points: DrumMatrixPage.__init__, GranularFXPage.__init__, SynthModulePage.__init__, DrumMatrixPage.refresh_drum_grid

### 3. `AdditiveSynthNode.generate_block` ↔ `FormantSynthNode.generate_block`
- degrees: 23 / 23
- domain similarity: 1.0; neighbor similarity: 0.875
- radius-2 overlap: 39 (1.0000 of union)
- direct shared states: phase
- convergence points: VideoSynthEngine.__init__, MathematiciansGrooveboxApp._render_mixdown_buffer, VisualOscilloscope.__init__, VisualOscilloscope.paintEvent, MeumModulatedOscillator.__init__, StandardSynthInstance.__init__, WavetableProjector.paintEvent, VisualOscilloscope.set_seed_hud
- A entry points: StandardWaveSynthNode.__init__, StandardSynthInstance.__init__, MeumModulatedOscillator.render, StandardWaveSynthNode.generate_block
- B entry points: StandardWaveSynthNode.__init__, StandardSynthInstance.__init__, MeumModulatedOscillator.render, StandardWaveSynthNode.generate_block

### 4. `MathematiciansGrooveboxApp.play_audio_only` ↔ `MathematiciansGrooveboxApp.stop_audio_playback`
- degrees: 37 / 27
- domain similarity: 1.0; neighbor similarity: 0.75
- radius-2 overlap: 200 (1.0000 of union)
- direct shared states: audio_stream, is_paused, is_playing
- convergence points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp._apply_project_snapshot, MathematiciansGrooveboxApp._clear_project_memory, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp._rebuild_active_canonical_playlist, MathematiciansGrooveboxApp._render_mixdown_buffer, MathematiciansGrooveboxApp.spawn_floating_window
- A entry points: MathematiciansGrooveboxApp.toggle_playback, MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.stop_playback, MathematiciansGrooveboxApp.stop_audio_playback
- B entry points: MathematiciansGrooveboxApp.toggle_playback, MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.play_audio_only, MathematiciansGrooveboxApp.stop_playback

### 5. `MathematiciansGrooveboxApp.play_audio_only` ↔ `MathematiciansGrooveboxApp._audio_callback`
- degrees: 37 / 25
- domain similarity: 1.0; neighbor similarity: 0.75
- radius-2 overlap: 200 (1.0000 of union)
- direct shared states: is_playing, play_buffer, play_cursor
- convergence points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp._apply_project_snapshot, MathematiciansGrooveboxApp._clear_project_memory, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp._rebuild_active_canonical_playlist, MathematiciansGrooveboxApp._render_mixdown_buffer, MathematiciansGrooveboxApp.spawn_floating_window
- A entry points: MathematiciansGrooveboxApp.toggle_playback, MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.stop_playback, MathematiciansGrooveboxApp.stop_audio_playback
- B entry points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.toggle_playback, MathematiciansGrooveboxApp.play_audio_only, MathematiciansGrooveboxApp._update_scope_from_playhead

### 6. `MasterControlPatchbayPage.__init__` ↔ `AutomationPatternPage.__init__`
- degrees: 80 / 79
- domain similarity: 1.0; neighbor similarity: 0.8507
- radius-2 overlap: 87 (0.7016 of union)
- direct shared states: engine
- convergence points: VideoSynthEngine.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, SynthModulePage.__init__, VideoSynthViewer.__init__, GranularFXPage.__init__, DrumMatrixPage.__init__, InstrumentVisualObject.__init__
- A entry points: MasterControlPatchbayPage._load_project, MasterControlPatchbayPage._apply_equation_scale, MasterControlPatchbayPage._randomize_song_action, MasterControlPatchbayPage._on_bpm_changed
- B entry points: DrumMatrixPage.__init__, GranularFXPage.__init__, SynthModulePage.__init__, DrumMatrixPage.refresh_drum_grid

### 7. `MasterControlPatchbayPage.__init__` ↔ `ActiveEngineClock.__init__`
- degrees: 80 / 63
- domain similarity: 1.0; neighbor similarity: 0.7971
- radius-2 overlap: 88 (0.7097 of union)
- direct shared states: engine
- convergence points: VideoSynthEngine.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, SynthModulePage.__init__, VideoSynthViewer.__init__, GranularFXPage.__init__, AutomationPatternPage.__init__, DrumMatrixPage.__init__
- A entry points: MasterControlPatchbayPage._load_project, MasterControlPatchbayPage._apply_equation_scale, MasterControlPatchbayPage._randomize_song_action, MasterControlPatchbayPage._on_bpm_changed
- B entry points: ActiveEngineClock.tick_clock, ActiveEngineClock.evaluate_drum_trigger, ActiveEngineClock.evaluate_sequencer_gate, InstrumentVisualObject.color

### 8. `MathematiciansGrooveboxApp.toggle_playback` ↔ `MathematiciansGrooveboxApp.stop_playback`
- degrees: 42 / 34
- domain similarity: 1.0; neighbor similarity: 0.6667
- radius-2 overlap: 200 (0.7905 of union)
- direct shared states: audio_stream, is_paused, is_playing, play_cursor
- convergence points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp._apply_project_snapshot, MathematiciansGrooveboxApp._clear_project_memory, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp._rebuild_active_canonical_playlist, MathematiciansGrooveboxApp._render_mixdown_buffer, MathematiciansGrooveboxApp.spawn_floating_window
- A entry points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.play_audio_only, MathematiciansGrooveboxApp.stop_playback, MathematiciansGrooveboxApp.stop_audio_playback
- B entry points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.toggle_playback, MathematiciansGrooveboxApp.play_audio_only, MathematiciansGrooveboxApp.stop_audio_playback

## Distant / nominally unrelated hub probes

### 1. `MathematiciansGrooveboxApp.init_ui_components` ↔ `VideoSynthEngine.__init__`
- degrees: 582 / 262
- domain similarity: 0.0; neighbor similarity: 0.0033
- radius-2 overlap: 141 (0.2712 of union)
- direct shared states: none
- convergence points: MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp._apply_project_snapshot, MathematiciansGrooveboxApp._clear_project_memory, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp._rebuild_active_canonical_playlist, GrooveboxEngine.__init__, GrooveboxEngine.serialize_project
- A entry points: MathematiciansGrooveboxApp._apply_project_snapshot, MathematiciansGrooveboxApp._render_mixdown_buffer, MathematiciansGrooveboxApp._update_scope_from_playhead, MathematiciansGrooveboxApp._push_visualizer_seed_hud
- B entry points: VideoSynthEngine._meum_state, VideoSynthEngine._collect_fit_points, VideoSynthEngine._update_scenograph_module_schedule, VideoSynthEngine._draw_canonical_constellation

### 2. `MathematiciansGrooveboxApp.__init__` ↔ `InstrumentVisualObject.__init__`
- degrees: 248 / 75
- domain similarity: 0.0; neighbor similarity: 0.0
- radius-2 overlap: 70 (0.1496 of union)
- direct shared states: none
- convergence points: VideoSynthEngine.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, SynthModulePage.__init__, VideoSynthViewer.__init__, MasterControlPatchbayPage.__init__, WavetableCanvas.__init__, InfinitePlaylistCanvas.__init__
- A entry points: MathematiciansGrooveboxApp._apply_project_snapshot, MathematiciansGrooveboxApp._clear_project_memory, MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp._render_mixdown_buffer
- B entry points: InstrumentVisualObject.geometry, InstrumentVisualObject.draw, InstrumentVisualObject.vector, InstrumentVisualObject.color

### 3. `MathematiciansGrooveboxApp._apply_project_snapshot` ↔ `SynthModulePage.__init__`
- degrees: 151 / 86
- domain similarity: 0.0; neighbor similarity: 0.0
- radius-2 overlap: 11 (0.0268 of union)
- direct shared states: none
- convergence points: VideoSynthEngine.__init__, MathematiciansGrooveboxApp.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp.spawn_floating_window, MathematiciansGrooveboxApp._apply_sequence_panels_to_live, MathematiciansGrooveboxApp._apply_mg_synth_payload, MathematiciansGrooveboxApp._mark_generated_synth_context
- A entry points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp.apply_playlist_automation_to_ui, MathematiciansGrooveboxApp._apply_mg_synth_payload
- B entry points: DrumMatrixPage.__init__, GranularFXPage.__init__, AutomationPatternPage.__init__, SynthModulePage.refresh_synth_grid

### 4. `MathematiciansGrooveboxApp._clear_project_memory` ↔ `VideoSynthViewer.__init__`
- degrees: 127 / 84
- domain similarity: 0.0; neighbor similarity: 0.0
- radius-2 overlap: 11 (0.0280 of union)
- direct shared states: none
- convergence points: VideoSynthEngine.__init__, MathematiciansGrooveboxApp.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp.spawn_floating_window, MathematiciansGrooveboxApp._apply_sequence_panels_to_live, MathematiciansGrooveboxApp._apply_mg_synth_payload, MathematiciansGrooveboxApp._mark_generated_synth_context
- A entry points: MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp._apply_mg_synth_payload, MathematiciansGrooveboxApp._apply_goava_to_canonical_playlist
- B entry points: VideoSynthViewer._request_async_frame, VideoSynthViewer._on_async_frame_ready, VideoSynthViewer.mouseMoveEvent, VideoSynthViewer._apply_manual_camera

### 5. `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` ↔ `GranularFXPage.__init__`
- degrees: 102 / 81
- domain similarity: 0.0; neighbor similarity: 0.0
- radius-2 overlap: 10 (0.0274 of union)
- direct shared states: none
- convergence points: VideoSynthEngine.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp.spawn_floating_window, MathematiciansGrooveboxApp._apply_sequence_panels_to_live, MathematiciansGrooveboxApp._apply_mg_synth_payload, MathematiciansGrooveboxApp._mark_generated_synth_context, MathematiciansGrooveboxApp._canonical_sequence_reconcile
- A entry points: MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp._clear_project_memory, MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist, MathematiciansGrooveboxApp._apply_goava_to_canonical_playlist
- B entry points: DrumMatrixPage.__init__, AutomationPatternPage.__init__, SynthModulePage.__init__, DrumMatrixPage.refresh_drum_grid

### 6. `MathematiciansGrooveboxApp._on_synth_count_changed` ↔ `VisualOscilloscope.__init__`
- degrees: 116 / 48
- domain similarity: 0.0; neighbor similarity: 0.0
- radius-2 overlap: 3 (0.0089 of union)
- direct shared states: none
- convergence points: VideoSynthEngine.__init__, _VideoRenderTask.__init__, MeumModulatedOscillator.__init__
- A entry points: MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp._apply_mg_synth_payload, MathematiciansGrooveboxApp._clear_project_memory
- B entry points: VisualOscilloscope.paintEvent, VisualOscilloscope.set_seed_hud, SpectrumAnalyzer.paintEvent, VideoSynthEngine._meum_state

### 7. `_VideoRenderTask.__init__` ↔ `MathematiciansGrooveboxApp.toggle_playback`
- degrees: 122 / 42
- domain similarity: 0.0; neighbor similarity: 0.0
- radius-2 overlap: 85 (0.1820 of union)
- direct shared states: none
- convergence points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.__init__, MathematiciansGrooveboxApp._apply_project_snapshot, MathematiciansGrooveboxApp._clear_project_memory, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp._rebuild_active_canonical_playlist, MathematiciansGrooveboxApp._render_mixdown_buffer, MathematiciansGrooveboxApp.spawn_floating_window
- A entry points: _VideoRenderTask.run, VideoSynthViewer._request_async_frame, VideoSynthViewer.update_from_audio, VideoSynthViewer.set_mode
- B entry points: MathematiciansGrooveboxApp.init_ui_components, MathematiciansGrooveboxApp.play_audio_only, MathematiciansGrooveboxApp.stop_playback, MathematiciansGrooveboxApp.stop_audio_playback

### 8. `MasterControlPatchbayPage.__init__` ↔ `GrooveboxEngine.serialize_project`
- degrees: 80 / 58
- domain similarity: 0.0; neighbor similarity: 0.0
- radius-2 overlap: 11 (0.0396 of union)
- direct shared states: none
- convergence points: VideoSynthEngine.__init__, MathematiciansGrooveboxApp.__init__, _VideoRenderTask.__init__, MathematiciansGrooveboxApp._on_synth_count_changed, MathematiciansGrooveboxApp.spawn_floating_window, MathematiciansGrooveboxApp._apply_sequence_panels_to_live, MathematiciansGrooveboxApp._apply_mg_synth_payload, MathematiciansGrooveboxApp._mark_generated_synth_context
- A entry points: MasterControlPatchbayPage._load_project, MasterControlPatchbayPage._apply_equation_scale, MasterControlPatchbayPage._randomize_song_action, MasterControlPatchbayPage._on_bpm_changed
- B entry points: GrooveboxEngine.__init__, GrooveboxEngine.deserialize_project, GrooveboxEngine.randomize_song, GrooveboxEngine.randomize_synth_routing

