# OS / Standalone Simplification Audit — 2026-09-05

Active top-level runtime files scanned: **45**.

## Runtime dependency policy

- **NumPy retained intentionally** as contiguous array/buffer ABI and fallback vector layer. Hot Meum/OT/DSP kernels continue to prefer the native C++ accelerator.
- **SciPy removed from normal runtime requirements.** PCM WAV I/O is now handled by `audio_os_backend.py` using Python's `wave` module + NumPy; non-WAV media continues through the existing FFmpeg route.
- **sounddevice centralized** in `audio_os_backend.py` as the optional/bundled realtime PortAudio bridge. Active runtime modules should not import it directly.
- **PyQt6 retained** as the desktop GUI toolkit and bundled by standalone builds.
- **Pillow retained** where image decoding/manipulation is needed and bundled by standalone builds.
- Julia/mido remain optional extension paths rather than core startup requirements.

## Import classification

{'stdlib/os': 375, 'local': 108, 'bundled-runtime': 53, 'optional': 2}

Third-party top-level imports observed in active runtime: [('PyQt6', 31), ('numpy', 20), ('PIL', 1), ('juliacall', 1), ('mido', 1), ('sounddevice', 1)]

## Enforced simplifications

1. Build-time import-policy check rejects direct SciPy imports and direct sounddevice imports outside `audio_os_backend.py`.
2. PyInstaller collection no longer forces SciPy into standalone distributions.
3. Requirements no longer install SciPy.
4. MCC writes retain the previous committed generation (`.prev`), use an atomic `.part` replacement, fsync file data and POSIX directory metadata, and use a short-lived cross-process commit lock.
5. Finite-Infinity exact shortcuts are available in `finite_infinity.py`: affine O(log n) jump, modular jump, exact deterministic cycle collapse, and canonical duplicate-state BFS. Unsupported shortcuts return `must_iterate`.

## Validation performed

- Active Python tree compile check: PASS.
- Standalone import audit: PASS.
- Direct active SciPy import scan: zero.
- OS/stdlib WAV backend round-trip smoke test: PASS.
- MCC filetype test: PASS.
- Finite-Infinity exact-jump tests: PASS.

## Remaining external/runtime boundaries

The project is **not dependency-free**. NumPy, PyQt6, sounddevice/PortAudio, and Pillow remain bundled runtime components. FFmpeg/ffprobe remain external binaries unless the local `bin/` copies are bundled by the build kit. The goal of this pass is standalone packaging and removal of unnecessary heavyweight dependencies, not replacing mature array/UI/device layers with slower pure Python equivalents.
