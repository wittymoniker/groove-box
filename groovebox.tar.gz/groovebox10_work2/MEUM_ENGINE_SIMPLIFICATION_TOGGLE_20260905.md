# Engines simplified by Meum toggle

Default: ON.

ON uses a composite deterministic dispatcher that computes the shared canonical
seed once and dispatches the unchanged GOAVA, Randomizer, Phase Lock, Euclidean,
and Seeded engine implementations in the same sorted order and with the same
per-engine RNG derivation.

OFF uses the retained original per-engine dispatcher.

No canonical engine was deleted or replaced. The switch is saved in MCC project
state and included in undo/redo button-state snapshots.
