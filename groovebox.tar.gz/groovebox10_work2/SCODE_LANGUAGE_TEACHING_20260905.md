# sCodeOS teachable-language architecture

The language is no longer assumed to be fixed by the compiler.

`scode_language/language_pack.json` is the source of truth for the author's linguistic surface:
numerals, keyboard mappings, keywords, operators, domain vocabulary, aliases, and linguistic notes.

The compiler/runtime can retain stable internal semantic concept IDs while the author changes the visible
language. This separates *meaning* from *spelling*, which makes future language evolution and migration safer.

Base 16 remains a semantic invariant. The sixteen glyphs themselves are author-configurable.

Activation policy: validate the pack, run language tests, then promote it. Keep the previous revision for rollback.
