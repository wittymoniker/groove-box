# Master Studio launcher

The Performance/player window now contains **Launch MatGroovebox Master Studio** in its top header.

- When Performance is embedded in MatGroovebox, the button raises and focuses the existing studio.
- When Performance is used standalone, the button launches the canonical `run_groovebox.py` entry point.
- It does not instantiate a second QApplication or fork an alternate studio implementation.
- The player/performance workflow remains unchanged.
