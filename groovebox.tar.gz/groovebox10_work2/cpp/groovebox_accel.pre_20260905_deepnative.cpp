#include <cmath>
#include <cstddef>
#include <algorithm>
#if defined(_OPENMP)
#include <omp.h>
#endif
#if defined(_WIN32)
#define GB_EXPORT extern "C" __declspec(dllexport)
#else
#define GB_EXPORT extern "C" __attribute__((visibility("default")))
#endif
static constexpr double TAU=6.283185307179586476925286766559;
GB_EXPORT void gb_meum_modulation_f32(const double*t,std::size_t n,double meum_norm,double meum_inv,double phase_shift,double am_depth,double am_rate,double fm_depth,double fm_rate,double pm_depth,double pm_rate,double pm_feedback,double meum_depth,float*freq_ratio,float*phase_offset,float*am_gain){
 am_depth=std::clamp(am_depth,0.0,1.0); am_rate=std::max(0.0,am_rate); fm_depth=std::clamp(fm_depth,-0.95,0.95); fm_rate=std::max(0.0,fm_rate); pm_depth=std::clamp(pm_depth,-TAU/2.0,TAU/2.0); pm_rate=std::max(0.0,pm_rate); pm_feedback=std::clamp(pm_feedback,-1.0,1.0); meum_depth=std::clamp(meum_depth,0.0,1.0);
#if defined(_OPENMP)
 #pragma omp parallel for if(n >= 4096) schedule(static)
#endif
 for(std::size_t i=0;i<n;++i){double tt=t[i]; auto field=[&](double rate){double a=std::sin(TAU*tt*rate),b=std::sin(TAU*tt*rate*meum_inv);return .5*(a+meum_norm*b);}; double fm=std::sin(TAU*tt*fm_rate+phase_shift); double fr=1.0+fm_depth*(fm+meum_depth*field(fm_rate)); double pm=std::sin(TAU*tt*pm_rate+phase_shift); double po=phase_shift+pm_depth*pm+pm_feedback*meum_depth*field(pm_rate); double am=std::sin(TAU*tt*am_rate+phase_shift); double ag=1.0+am_depth*(am+meum_depth*field(am_rate)); freq_ratio[i]=(float)fr; phase_offset[i]=(float)po; am_gain[i]=(float)ag;}
}

GB_EXPORT void gb_voice_synth_f32(const double* phase, std::size_t n,
    double entropy, double k1, double k3, double k4, int n_harm, int n_inh,
    int waveform_code, int goava, double pm_depth, long long seed_int, int voice_index,
    double meum, double meum_norm, float* out) {
    (void)k3;
    const double tau = TAU;
#if defined(_OPENMP)
    #pragma omp parallel for if(n >= 4096) schedule(static)
#endif
    for (std::size_t i=0;i<n;++i) {
        const double ph = phase[i];
        double harm = 0.0;
        if (goava) {
            harm = std::sin(ph);
            if (std::fabs(pm_depth) > 0.05) harm += 0.08 * std::fabs(pm_depth) * std::sin(2.0 * ph);
        } else if (waveform_code != 0) {
            auto wf = [&](double x)->double {
                double u = x / tau;
                u -= std::floor(u);
                if (waveform_code == 1) return 2.0*u - 1.0;                 // saw
                if (waveform_code == 2) return u < 0.5 ? 1.0 : -1.0;       // square
                if (waveform_code == 3) return 4.0*std::fabs(u - 0.5) - 1.0; // triangle
                if (waveform_code == 4) return std::cos(x)*meum_norm + std::cos(x*meum)*(1.0-meum_norm); // ics/cos
                return std::sin(x)*meum_norm + std::sin(x*meum)*(1.0-meum_norm); // isn fallback
            };
            harm = wf(ph);
            int lim = std::min(n_harm, 5);
            for (int h=2; h<=lim; ++h) harm += (0.12 / h) * wf(ph*h);
        } else {
            harm = std::sin(ph);
            for (int h=2; h<=n_harm; ++h) {
                double roll = 1.0 + (1.0-entropy)*1.2;
                double amp_h = (0.35 + 0.55*(1.0-entropy)) / std::pow((double)h, roll);
                long long mod = seed_int % 97; if (mod < 0) mod += 97;
                double det = 1.0 + 1e-4 * ((double)mod - 48.0) * (h-1) * (0.3 + 0.7*entropy);
                long long q = (seed_int * (long long)h * 13 + (long long)voice_index * 7) % 1000; if (q < 0) q += 1000;
                double ph0 = ((double)q / 1000.0) * tau;
                harm += amp_h * std::sin(ph*h*det + ph0);
            }
        }
        double inh = 0.0;
        for (int h=1; h<=n_inh; ++h) {
            double arg = ((double)seed_int + (double)h*17.0) * meum_norm;
            double ratio = 1.0 + (double)h * (1.0 + 0.37*std::sin(arg));
            ratio = 1.0 + (ratio-1.0) * (0.4 + 0.6*entropy);
            double amp_i = (0.25 + 0.6*entropy) / std::pow((double)h, 0.9 + 0.4*entropy);
            long long q = (seed_int * (long long)h * 31 + (long long)voice_index * 11) % 1000; if (q < 0) q += 1000;
            double ph0 = ((double)q / 1000.0) * tau;
            inh += amp_i * std::sin(ph*ratio + ph0);
        }
        if (entropy > 0.1) {
            long long q = seed_int % 19; if (q < 0) q += 19;
            double fm_ratio = 1.0 + ((double)q / 19.0) * 3.0 * entropy;
            double fm_depth = (0.05 + 0.55*entropy) * (0.5 + 0.5*k1);
            harm *= std::cos(fm_depth * std::sin(ph*fm_ratio));
        }
        double v = (1.0-entropy)*harm + entropy*inh;
        out[i] = (float)v;
    }
}

GB_EXPORT void gb_hardclip_f32(const float*src,float*dst,std::size_t n,float gain,float*metrics){float peak=0;std::size_t before=0,after=0;for(std::size_t i=0;i<n;++i){float x=src[i],ax=std::fabs(x);if(ax>.99f)++before;float y=x*gain;if(y>1)y=1;else if(y<-1)y=-1;float ay=std::fabs(y);if(ay>peak)peak=ay;if(ay>=.999f)++after;dst[i]=y;}if(metrics){metrics[0]=peak;metrics[1]=n?(float)before/(float)n:0;metrics[2]=n?(float)after/(float)n:0;}}

// Explicit tensor-style band contraction reference. Kept separate from the
// canonical master path so allocation-free production code remains fast.
GB_EXPORT void gb_ot_band_tensor_f32(const double* x, std::size_t n, float* out) {
    for (std::size_t i=0; i<n; ++i) {
        const double a=std::fabs(x[i]);
        const double b=(a<=1.0)?1.0:((a<=2.0)?2.0:((a<=3.0)?3.0:1.0));
        out[i]=(float)(std::copysign(b,x[i]));
    }
}

// PERF_NATIVE_20260905_V2: build FM-integrated + PM-offset phase in one pass.
// This replaces NumPy temporary inst_freq + cumsum + two phase additions.
// It intentionally does not clamp frequency ratios or phase values; negative
// ratio is a valid phase-direction reversal. Returns the wrapped carry only.
GB_EXPORT double gb_phase_build_f64(const float* freq_ratio, const float* pm_offset,
    std::size_t n, double f0, double detune, double dt, double carry,
    double voice_phase0, double canonical_phase, double* out_phase) {
    double acc = carry;
    const double step = TAU * f0 * (1.0 + detune) * dt;
    const double static_phase = voice_phase0 + canonical_phase;
    for (std::size_t i=0; i<n; ++i) {
        acc += step * static_cast<double>(freq_ratio[i]);
        out_phase[i] = acc + static_cast<double>(pm_offset[i]) + static_phase;
    }
    if (n == 0) return std::fmod(carry, TAU);
    double wrapped = std::fmod(acc, TAU);
    if (wrapped < 0.0) wrapped += TAU;
    return wrapped;
}

// Allocation-free AXPY for large audio buses: dst += gain * src.
GB_EXPORT void gb_accumulate_f32(float* dst, const float* src, std::size_t n, float gain) {
#if defined(_OPENMP)
    #pragma omp parallel for if(n >= 65536) schedule(static)
#endif
    for (std::size_t i=0; i<n; ++i) dst[i] += gain * src[i];
}

// Operator-Theory vector division helper. Policy is selected explicitly by the
// owning calculation instead of epsilon substitution:
// 0 -> zero, 1 -> one, 2 -> signed infinity, 3 -> numerator, 4 -> fallback.
GB_EXPORT void gb_ot_div_f64(const double* num, const double* den, std::size_t n,
    int zero_policy, double fallback, double* out) {
#if defined(_OPENMP)
    #pragma omp parallel for if(n >= 65536) schedule(static)
#endif
    for (std::size_t i=0; i<n; ++i) {
        const double a=num[i], b=den[i];
        if (b != 0.0) { out[i] = a / b; continue; }
        if (a == 0.0) { out[i] = 1.0; continue; } // project OT identity
        switch (zero_policy) {
            case 0: out[i]=0.0; break;
            case 1: out[i]=1.0; break;
            case 2: out[i]=std::copysign(INFINITY, a); break;
            case 3: out[i]=a; break;
            default: out[i]=fallback; break;
        }
    }
}
