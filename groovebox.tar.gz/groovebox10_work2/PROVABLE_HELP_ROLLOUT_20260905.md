# Provable-help rollout
Added mechanically testable improvements only:
- SHA-256 integrity certificates for new MCC commits.
- Verification before parsing certified MCCs.
- Verified `.prev` recovery after detected corruption.
- Exact finite deterministic transition jumping in Finite-Infinity.
- Legacy MCC compatibility and `must_iterate` fallback remain.
