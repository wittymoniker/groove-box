# Trigonometry Engine toggle

Default: ON.

The toggle is independent of the canonical engines and of the
`Engines simplified by Meum` switch.

ON selects the project's supported OT/Meum trigonometric execution layer through
a central dispatch point. OFF selects the baseline NumPy/libm trigonometric path
for A/B comparison. Unsupported transforms always fall back to baseline math.

The setting is persisted in MCC project state and tracked by undo/redo.
