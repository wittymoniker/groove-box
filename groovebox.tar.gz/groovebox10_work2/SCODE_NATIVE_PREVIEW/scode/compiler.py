"""Deterministic sCode -> sIR compiler with root-entry dependency closure.

FILE.sC is the entry program ("it").  Connected source is resolved recursively
from use/import/include/connect/requires declarations and compiled into the same
sIR image.  Dependencies never become competing entrypoints.
"""
from __future__ import annotations
import hashlib, json
from pathlib import Path
from .parser import parse_program, Node

IR_VERSION=2
RADIX=16
BUILTIN_USES={"core","math","media","system","game"}
CONNECT_KINDS={"use","import","include","connect","requires"}
SOURCE_EXTS=(".sC",".scode")

def _node(n):
    return {
        "kind": n.kind,
        "name": n.name,
        "args": list(n.args),
        "attrs": dict(sorted(n.attrs.items())),
        "children": [_node(c) for c in n.children],
    }

def canonical_ir_bytes(ir):
    clean={k:v for k,v in ir.items() if k not in {"source","sha256"}}
    return json.dumps(clean,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")

def _iter_nodes(nodes):
    for n in nodes:
        yield n
        yield from _iter_nodes(n.children)

def _connection_names(program):
    for n in _iter_nodes(program.nodes):
        if n.kind.lower() not in CONNECT_KINDS:
            continue
        vals=[]
        if n.name:
            vals.append(n.name)
        vals.extend(n.args)
        for v in vals:
            s=str(v).strip()
            if s and s.lower() not in {"on","off"}:
                yield s

def _candidate_paths(name:str, owner:Path, roots:list[Path]):
    raw=Path(name).expanduser()
    names=[]
    if raw.suffix.lower() in {".sc",".scode"}:
        names=[raw.name]
    else:
        names=[raw.name+ext for ext in SOURCE_EXTS]
    # explicit relative/absolute path first
    if raw.is_absolute():
        yield raw
    elif raw.parent != Path('.'):
        yield (owner.parent/raw)
    # sibling and search roots
    for nm in names:
        yield owner.parent/nm
        for root in roots:
            yield root/nm
            yield root/'scode'/'libs'/nm
            yield root/'libs'/nm

def _resolve_connection(name:str, owner:Path, roots:list[Path]):
    if name.lower() in BUILTIN_USES:
        return None, "builtin"
    seen=set()
    for c in _candidate_paths(name,owner,roots):
        try: c=c.resolve()
        except Exception: continue
        if c in seen: continue
        seen.add(c)
        if c == owner.resolve():
            continue
        if c.is_file(): return c,"source"
    return None,"unresolved"

def _compile_graph(entry:Path, extra_roots=None):
    entry=entry.resolve()
    project_root=Path(__file__).resolve().parents[1]
    roots=[entry.parent,project_root]
    for r in extra_roots or []:
        q=Path(r).expanduser().resolve()
        if q not in roots: roots.append(q)
    queue=[entry]
    parsed={}
    order=[]
    edges=[]
    unresolved=[]
    builtins=[]
    while queue:
        src=queue.pop(0).resolve()
        if src in parsed: continue
        program=parse_program(src.read_text(encoding='utf-8'))
        parsed[src]=program; order.append(src)
        for depname in _connection_names(program):
            dep,status=_resolve_connection(depname,src,roots)
            if status=="builtin":
                builtins.append((src,depname)); continue
            if status=="unresolved":
                unresolved.append((src,depname)); continue
            edges.append((src,dep))
            if dep not in parsed and dep not in queue: queue.append(dep)
    return entry,order,parsed,edges,builtins,unresolved

def compile_text(text, source="<memory>"):
    program=parse_program(text)
    ir={
        "scode_ir_version":IR_VERSION,
        "radix":RADIX,
        "source_language":"sCode",
        "entrypoint":source,
        "connected_sources":[],
        "nodes":[_node(n) for n in program.nodes],
    }
    digest=hashlib.sha256(canonical_ir_bytes(ir)).hexdigest()
    ir["source"]=source
    ir["sha256"]=digest
    return ir,digest

def compile_file(path, extra_roots=None):
    entry,order,parsed,edges,builtins,unresolved=_compile_graph(Path(path),extra_roots)
    root_program=parsed[entry]
    nodes=[_node(n) for n in root_program.nodes]
    # Append dependencies under explicit connected_code wrappers.  This keeps
    # FILE.sC the sole entry identity while making every connected declaration
    # available in the same executable image.
    for src in order[1:]:
        rel=src.name
        try: rel=str(src.relative_to(Path(__file__).resolve().parents[1]))
        except Exception: pass
        wrapper=Node("connected_code",src.stem,[],{"source":rel,"runs_as":entry.name},parsed[src].nodes)
        nodes.append(_node(wrapper))
    ir={
        "scode_ir_version":IR_VERSION,
        "radix":RADIX,
        "source_language":"sCode",
        "entrypoint":entry.name,
        "entrypoint_path":str(entry),
        "run_as":entry.name,
        "connected_sources":[str(x) for x in order[1:]],
        "dependency_edges":[[str(a),str(b)] for a,b in edges],
        "builtin_connections":[[str(a),b] for a,b in builtins],
        "unresolved_connections":[[str(a),b] for a,b in unresolved],
        "nodes":nodes,
    }
    digest=hashlib.sha256(canonical_ir_bytes(ir)).hexdigest()
    ir["source"]=entry.name
    ir["sha256"]=digest
    return ir

def write_ir(ir, output):
    p=Path(output)
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+".tmp")
    tmp.write_text(json.dumps(ir,sort_keys=True,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    tmp.replace(p)
    return p

def validate_file(path):
    compile_file(path)
    return True
