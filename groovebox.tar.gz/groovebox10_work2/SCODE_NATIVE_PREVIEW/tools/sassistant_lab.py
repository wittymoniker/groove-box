#!/usr/bin/env python3
"""Deterministic sAssistant development-lab helper.

This is a bootstrap reasoning tool, not a claim of a trained autonomous model.
It turns the current sCode project into a small evidence report, runs safe local
checks when requested, and proposes the smallest next implementation step.
"""
from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def sh(cmd):
    p=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    return p.returncode,p.stdout

def source_inventory():
    files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():
            continue
        if any(x in p.parts for x in ('.git','__pycache__')): continue
        if p.suffix.lower() in {'.sc','.scode','.cpp','.hpp','.py','.sh'}:
            try: text=p.read_text(errors='ignore')
            except Exception: continue
            files.append({'path':str(p.relative_to(ROOT)),'lines':text.count('\n')+1,'bytes':p.stat().st_size})
    return files

def feature_evidence():
    targets={
      'entry_graph':['connected_sources','run as it'],
      'seed_authority':['SeedAuthority','voice_interference'],
      'infinity_logic':['infinity_logic','LPlot'],
      'native_gui':['run_gui','XCreateSimpleWindow'],
      'sos_identity':['program sOS','development_workbench'],
      'assistant_identity':['program sAssistant','verify before_promote'],
      'audio_demo':['groovebox_native_demo.wav','wav('],
    }
    hay='\n'.join(p.read_text(errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in {'.sc','.scode','.cpp','.hpp','.py','.md'})
    return {name:all(tok in hay for tok in toks) for name,toks in targets.items()}

def connected_ir(app):
    appp=ROOT/app
    if not appp.exists(): return {'error':'missing'}
    out=ROOT/'build'/f'{appp.stem}.lab.sir'; sb=ROOT/'build'/f'{appp.stem}.lab.sbin'
    rc,log=sh(['python3','translator/source_to_sbin.py',str(appp),str(sb),str(out)])
    if rc: return {'error':log[-2000:]}
    d=json.loads(out.read_text())
    
    def count_nodes(ns):
        return sum(1 + count_nodes(n.get('children',[])) for n in ns)
    return {'records':count_nodes(d.get('nodes',[])),'connected_sources':d.get('connected_sources',[]),'unresolved':d.get('unresolved_connections',[])}

def choose_next(ev, groove):
    # Math-first: choose the first missing prerequisite in dependency order.
    if not ev['entry_graph']: return 'finish entry-graph resolution before adding OS services'
    if not ev['seed_authority']: return 'finish canonical seed authority before broad render parity'
    if not ev['native_gui']: return 'finish native window/input primitives'
    unresolved=groove.get('unresolved') or []
    if unresolved: return f'resolve {len(unresolved)} unresolved Groovebox connection(s) before deeper conversion'
    return 'port the mature Groovebox UI/state class graph onto canonical sCode state; then use its parity tests as the next gate'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--run-tests',action='store_true'); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
    inv=source_inventory(); ev=feature_evidence(); groove=connected_ir('examples/groovebox.sC'); assistant=connected_ir('apps/sAssistant.sC'); sos=connected_ir('apps/sOS.sC')
    tests={}
    if a.run_tests:
        for name,cmd in [('native',['bash','test_native.sh']),('entry',['bash','test_entry_graph.sh'])]:
            if (ROOT/cmd[-1]).exists():
                rc,out=sh(cmd); tests[name]={'pass':rc==0,'tail':'\n'.join(out.splitlines()[-12:])}
    report={'inventory':{'files':len(inv),'lines':sum(x['lines'] for x in inv)},'evidence':ev,'groovebox':groove,'assistant':assistant,'sos':sos,'tests':tests}
    report['next']=choose_next(ev,groove)
    (ROOT/'reports').mkdir(exist_ok=True)
    (ROOT/'reports'/'sassistant_state.json').write_text(json.dumps(report,indent=2))
    md=['# sAssistant development report','',f"Scanned **{report['inventory']['files']}** implementation files / **{report['inventory']['lines']}** lines.",'','## Verified local evidence']
    md += [f"- {'PASS' if ok else 'MISSING'} — {k}" for k,ok in ev.items()]
    md += ['', '## sCode entry graphs', f"- Groovebox records: {groove.get('records','?')}; connected: {len(groove.get('connected_sources',[]))}", f"- sAssistant records: {assistant.get('records','?')}; connected: {len(assistant.get('connected_sources',[]))}", f"- sOS records: {sos.get('records','?')}; connected: {len(sos.get('connected_sources',[]))}", '', '## Smallest next step', report['next']]
    if tests:
        md += ['', '## Tests'] + [f"- {k}: {'PASS' if v['pass'] else 'FAIL'}" for k,v in tests.items()]
    (ROOT/'reports'/'sassistant_report.md').write_text('\n'.join(md)+'\n')
    if a.json: print(json.dumps(report,indent=2))
    else:
        print('sAssistant development lab')
        print(f"files={report['inventory']['files']} lines={report['inventory']['lines']}")
        for k,v in ev.items(): print(f"{k}: {'PASS' if v else 'MISSING'}")
        print('next:',report['next'])
        print('report:',ROOT/'reports'/'sassistant_report.md')

if __name__=='__main__': main()
