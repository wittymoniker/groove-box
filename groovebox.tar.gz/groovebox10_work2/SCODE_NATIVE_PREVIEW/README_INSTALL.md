# sCode Ecosystem 1.0 Preview — Installer Kit

Run one command from this folder:

    ./INSTALL_EVERYTHING.sh

Then launch **Mathematician's Groovebox (sCode)** from the application menu or run:

    sCode run find groovebox.sC run as it

Try the language with:

    sCode run examples/hello.sC run as it

`find` browses the user's normal files for the entry file. `run as it` means the chosen FILE.sC remains the one application identity while all connected sCode is compiled into and run as that application.

This preview targets Linux/X11. The installer is user-level except when packages are missing, in which case the system package manager may request sudo.

## 1.1.2 runner behavior
Desktop-opened `.sC`, `.scode`, and `.sbin` files now use a native persistent X11 runner. The runner captures stdout/stderr and stays open after the sCode program exits. `Run Again`/F5 reruns the program, `Open Source` opens the file with the desktop editor, and `Stop` terminates a currently running child. This no longer depends on terminal-emulator hold behavior.
