#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p bin build
c++ -std=c++17 -O3 -DNDEBUG native/scode_native.cpp -o bin/scode-native $(pkg-config --libs x11 2>/dev/null || echo -lX11)
c++ -std=c++17 -O2 -DNDEBUG native/scode_source_runner.cpp -o bin/scode-source-runner $(pkg-config --libs x11 2>/dev/null || echo -lX11)
python3 translator/source_to_sbin.py examples/GrooveboxTabletOS.scode build/GrooveboxTabletOS.sbin examples/GrooveboxTabletOS.sir
cp build/GrooveboxTabletOS.sbin bin/
echo "Built native runtime and source translator"
