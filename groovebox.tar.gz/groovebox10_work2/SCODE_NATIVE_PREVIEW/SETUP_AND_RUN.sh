#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

say(){ printf '\n==> %s\n' "$*"; }
need(){ command -v "$1" >/dev/null 2>&1; }

say "Mathematician's Groovebox / sCode one-shot setup"

# Install only missing build prerequisites. The package manager will ask for sudo
# in the normal way if installation is required.
missing=()
need python3 || missing+=(python3)
need c++ || missing+=(c++)

if ((${#missing[@]})); then
  say "Missing prerequisites: ${missing[*]}"
  if need apt-get; then
    sudo apt-get update
    sudo apt-get install -y python3 build-essential
  elif need dnf; then
    sudo dnf install -y python3 gcc-c++ make
  elif need pacman; then
    sudo pacman -S --needed --noconfirm python gcc make
  elif need zypper; then
    sudo zypper --non-interactive install python3 gcc-c++ make
  else
    echo "Could not identify a supported package manager. Install Python 3 and a C++17 compiler, then rerun this script." >&2
    exit 1
  fi
fi

say "Preparing scripts"
chmod +x sCode build_native.sh run_native.sh test_native.sh

say "Building native sCode runtime"
./build_native.sh

say "Running native regression tests"
./test_native.sh

say "Installing the user-level sCode command and .sC/.scode desktop association"
./sCode install-user

# Make sCode visible to this shell immediately even if ~/.local/bin was not yet
# present in the user's login PATH.
export PATH="$HOME/.local/bin:$PATH"

say "Running groovebox.sC through the native runtime"
./sCode run find groovebox.sC run as it

say "Generating Infinity Logic L-plot"
mkdir -p build
./sCode analyze examples/groovebox.sC \
  --lplot build/groovebox_logic.svg \
  --jump 1000000000

say "Compiling a standalone native Groovebox ELF"
./sCode compile examples/groovebox.sC \
  -o build/Groovebox \
  --ir build/groovebox.sir

say "Running the standalone executable"
./build/Groovebox

say "Creating double-clickable source shortcut"
./sCode shortcut examples/groovebox.sC

say "Setup complete"
printf '%s\n' \
  "Standalone executable: $ROOT/build/Groovebox" \
  "Intermediate sIR:      $ROOT/build/groovebox.sir" \
  "Infinity L-plot:       $ROOT/build/groovebox_logic.svg" \
  "Desktop launcher:      $ROOT/examples/groovebox.desktop" \
  "sCode command:         $HOME/.local/bin/sCode" \
  "" \
  "Run Groovebox again with:" \
  "  $ROOT/build/Groovebox" \
  "" \
  "Or run source with:" \
  "  sCode run find groovebox.sC run as it"
