#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec ./bin/scode-native ./bin/GrooveboxTabletOS.sbin
