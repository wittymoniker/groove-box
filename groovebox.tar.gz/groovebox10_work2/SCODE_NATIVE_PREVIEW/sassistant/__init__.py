"""sAssistant: desktop AI assistant for sCode and sOS."""
__version__="0.1.0"
