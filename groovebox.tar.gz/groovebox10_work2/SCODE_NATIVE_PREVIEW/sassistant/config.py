from __future__ import annotations
from pathlib import Path
import json, copy

DEFAULT_CONFIG = {
    "assistant_name": "sAssistant",
    "model": {"backend": "mock", "model_path": "", "context": 8192, "temperature": 0.2},
    "capabilities": {
        "read_project": True,
        "write_project": False,
        "run_scodec": True,
        "run_tests": False,
        "shell": "confirm",
        "network": "confirm"
    },
    "scodec": "scodec",
    "workspace": "."
}

def load_config(path=None):
    out=copy.deepcopy(DEFAULT_CONFIG)
    if path is None: return out
    p=Path(path)
    if not p.exists(): return out
    data=json.loads(p.read_text(encoding="utf-8"))
    for k,v in data.items():
        if isinstance(v,dict) and isinstance(out.get(k),dict):
            out[k].update(v)
        else:
            out[k]=v
    return out
