from pathlib import Path
from .config import load_config
from .models import create_backend
from .translators import get_translator
from .permissions import require
from .tools.scodec import run_scodec

class SAssistant:
    def __init__(self,config=None):
        self.config=config or load_config()
        self.model=create_backend(self.config)

    def translate_text(self,text,language):
        return get_translator(language).translate(text)

    def translate_file(self,path,language=None,write=False):
        require(self.config,"read_project")
        p=Path(path)
        lang=language or self._infer(p)
        result=self.translate_text(p.read_text(encoding="utf-8"),lang)
        if write:
            require(self.config,"write_project")
            out=p.with_suffix(".scode")
            out.write_text(result.scode,encoding="utf-8")
            return result,out
        return result,None

    def check_scode(self,text):
        return run_scodec(self.config,text,"check")

    def explain(self,text):
        return self.model.complete(text)

    @staticmethod
    def _infer(p):
        return {
            ".py":"python",".cpp":"cpp",".cc":"cpp",".c":"c",".jl":"julia",
            ".js":"javascript",".ts":"typescript",".rs":"rust",".go":"go",".java":"java"
        }.get(p.suffix.lower(),"text")
