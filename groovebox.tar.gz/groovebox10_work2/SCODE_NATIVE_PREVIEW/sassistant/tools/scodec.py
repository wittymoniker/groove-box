import shutil, subprocess, tempfile
from pathlib import Path
from ..permissions import require

def run_scodec(config,source_text,mode="check"):
    require(config,"run_scodec")
    exe=config.get("scodec","scodec")
    if shutil.which(exe) is None:
        raise RuntimeError(f"scodec not found: {exe}")
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"assistant.scode"
        p.write_text(source_text,encoding="utf-8")
        cp=subprocess.run([exe,mode,str(p)],text=True,capture_output=True)
        return {"returncode":cp.returncode,"stdout":cp.stdout,"stderr":cp.stderr}
