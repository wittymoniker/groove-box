import ast
from .base import Translator, TranslationResult

class PythonTranslator(Translator):
    language="python"

    def translate(self,text):
        notes=[]
        try:
            tree=ast.parse(text)
        except SyntaxError as exc:
            return TranslationResult("python",text,"",["Python parse failed: "+str(exc)],"failed")

        out=["# sCode translation draft generated from Python"]
        for node in tree.body:
            if isinstance(node,ast.Import):
                for a in node.names: out.append(f"import {a.name}")
            elif isinstance(node,ast.ImportFrom):
                out.append(f"import {node.module or 'module'}")
            elif isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                args=", ".join(a.arg for a in node.args.args)
                out.append(f"function {node.name}({args}) {{")
                out.extend("    "+x for x in self._body(node.body,notes))
                out.append("}")
            elif isinstance(node,ast.ClassDef):
                out.append(f"type {node.name} {{")
                for item in node.body:
                    if isinstance(item,ast.FunctionDef):
                        args=", ".join(a.arg for a in item.args.args)
                        out.append(f"    function {item.name}({args})")
                out.append("}")
            elif isinstance(node,(ast.Assign,ast.AnnAssign)):
                out.append(self._assign(node,notes))
            else:
                notes.append(f"Untranslated top-level Python node: {type(node).__name__}")
                out.append(f"# TODO translate {type(node).__name__}")
        return TranslationResult("python",text,"\n".join(out)+"\n",notes,"draft")

    def _expr(self,n,notes):
        try: return ast.unparse(n)
        except Exception:
            notes.append(f"Expression needs manual translation: {type(n).__name__}")
            return "TODO"

    def _assign(self,n,notes):
        if isinstance(n,ast.Assign):
            lhs=", ".join(self._expr(t,notes) for t in n.targets)
            return f"{lhs} = {self._expr(n.value,notes)}"
        return f"{self._expr(n.target,notes)} = {self._expr(n.value,notes) if n.value else 'none'}"

    def _body(self,nodes,notes):
        out=[]
        for n in nodes:
            if isinstance(n,ast.Return):
                out.append("return "+(self._expr(n.value,notes) if n.value else ""))
            elif isinstance(n,(ast.Assign,ast.AnnAssign)):
                out.append(self._assign(n,notes))
            elif isinstance(n,ast.Expr):
                out.append(self._expr(n.value,notes))
            elif isinstance(n,ast.If):
                out.append(f"if {self._expr(n.test,notes)} {{")
                out.extend("    "+x for x in self._body(n.body,notes))
                out.append("}")
            elif isinstance(n,ast.For):
                out.append(f"for {self._expr(n.target,notes)} in {self._expr(n.iter,notes)} {{")
                out.extend("    "+x for x in self._body(n.body,notes))
                out.append("}")
                notes.append("Verify loop semantics after translation.")
            elif isinstance(n,ast.While):
                out.append(f"while {self._expr(n.test,notes)} {{")
                out.extend("    "+x for x in self._body(n.body,notes))
                out.append("}")
                notes.append("Verify loop semantics after translation.")
            else:
                notes.append(f"Untranslated Python statement: {type(n).__name__}")
                out.append(f"# TODO {type(n).__name__}")
        return out
