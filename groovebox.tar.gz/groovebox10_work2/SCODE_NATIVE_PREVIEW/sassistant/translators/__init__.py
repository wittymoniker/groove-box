from .python import PythonTranslator
from .generic import GenericTranslator

def get_translator(language):
    l=language.lower()
    if l in {"python","py"}: return PythonTranslator()
    return GenericTranslator(l)
