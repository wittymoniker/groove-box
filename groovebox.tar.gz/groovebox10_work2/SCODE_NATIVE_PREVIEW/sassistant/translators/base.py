from dataclasses import dataclass

@dataclass
class TranslationResult:
    language: str
    source: str
    scode: str
    notes: list[str]
    confidence: str = "draft"

class Translator:
    language="text"
    def translate(self,text:str)->TranslationResult:
        raise NotImplementedError
