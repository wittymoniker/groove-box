class PermissionDenied(RuntimeError): pass

def allowed(config, capability):
    return config.get("capabilities",{}).get(capability) is True

def requires_confirmation(config, capability):
    return config.get("capabilities",{}).get(capability) == "confirm"

def require(config, capability):
    if not allowed(config,capability):
        raise PermissionDenied(f"capability not permitted: {capability}")
