class ModelBackend:
    def complete(self,prompt): raise NotImplementedError

class MockBackend(ModelBackend):
    def complete(self,prompt):
        return "Local model is not configured yet. Translation and compiler tools are still available."
