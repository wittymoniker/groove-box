from .base import ModelBackend

class LlamaCppBackend(ModelBackend):
    def __init__(self,model_path,context=8192,temperature=0.2):
        try:
            from llama_cpp import Llama
        except Exception as exc:
            raise RuntimeError("Install llama-cpp-python to enable the local llama.cpp backend") from exc
        self.temperature=float(temperature)
        self.llm=Llama(model_path=model_path,n_ctx=int(context))

    def complete(self,prompt):
        out=self.llm(prompt,max_tokens=1024,temperature=self.temperature)
        return out["choices"][0]["text"]
