from .base import MockBackend
def create_backend(config):
    m=config.get("model",{})
    if m.get("backend")=="llamacpp":
        from .llamacpp import LlamaCppBackend
        return LlamaCppBackend(m.get("model_path",""),m.get("context",8192),m.get("temperature",0.2))
    return MockBackend()
