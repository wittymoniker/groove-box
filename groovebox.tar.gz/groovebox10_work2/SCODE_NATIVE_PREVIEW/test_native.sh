#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -x bin/scode-native ]
[ -s bin/GrooveboxTabletOS.sbin ]
rm -f groovebox_native_demo.wav
./bin/scode-native ./bin/GrooveboxTabletOS.sbin --headless > build/native_test.log
grep -q 'meum_root=PASS' build/native_test.log
grep -q 'runtime host: C++ binary only' build/native_test.log
grep -q 'seed authority: root=seed fullweight=on' build/native_test.log
grep -q 'voice_interference=0' build/native_test.log
grep -q 'full+explicit25=0.25' build/native_test.log
grep -q 'reduced72=0.28' build/native_test.log
[ -s groovebox_native_demo.wav ]
echo 'native tests: PASS'

# ENTRY_GRAPH_0.9: FILE.sC is the entry identity and use-dependencies are
# recursively compiled into the same image, never launched separately.
python3 translator/source_to_sbin.py examples/groovebox.sC build/entry_graph_test.sbin build/entry_graph_test.sir > build/entry_graph_translate.log
python3 - <<'PY'
import json
p=json.load(open('build/entry_graph_test.sir'))
assert p['entrypoint']=='groovebox.sC'
assert p['run_as']=='groovebox.sC'
connected='\n'.join(p.get('connected_sources',[]))
for name in ('groovebox.scode','canonical.scode','finite_infinity.scode','infinity_logic.scode','operator.scode','meum.scode','logic_math.scode'):
    assert name in connected, (name, connected)
print('entry graph tests: PASS')
PY
