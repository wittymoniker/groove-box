#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo '[1/6] Building native sCode runtime...'
./build_native.sh
echo '[2/6] Running native tests...'
./test_native.sh
echo '[3/6] Compiling sAssistant and sOS...'
./sCode compile apps/sAssistant.sC -o build/sAssistant --ir build/sAssistant.sir
./sCode compile apps/sOS.sC -o build/sOS --ir build/sOS.sir
echo '[4/6] Letting the sAssistant development lab inspect the project...'
python3 tools/sassistant_lab.py --run-tests
echo '[5/6] Report: reports/sassistant_report.md'
echo '[6/6] Starting the basic sOS workbench...'
exec ./build/sOS --gui
