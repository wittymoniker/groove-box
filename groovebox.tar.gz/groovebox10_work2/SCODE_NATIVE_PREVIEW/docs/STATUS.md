# sCode ecosystem 1.0 preview status

This preview is an installable Linux userspace/development kit.

- sCode: source parser/compiler, dependency-entry graph, sIR/sBIN, native C++ runtime, standalone ELF packaging.
- Groovebox: native seed-first graphical demonstrator plus WAV/L-plot generation. It is not yet feature-parity with the mature PyQt Groovebox.
- sAssistant: sCode application identity and capability/knowledge skeleton; the older Python assistant modules are included as migration/reference material only.
- sOS: sCode userspace/bootstrap identity on the Linux kernel/driver stack. It is not a bootable independent OS image yet.

The compiler rule is: FILE.sC is the entry identity. Connected code is compiled and executed as part of FILE.sC.
