#!/usr/bin/env bash
set -e
rm -rf "${XDG_DATA_HOME:-$HOME/.local/share}/sCode-Ecosystem"
rm -f "$HOME/.local/bin/sCode"
rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/applications/scode-groovebox.desktop"
rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/applications/scode-terminal.desktop"
echo "Removed user-level sCode Ecosystem preview files."
