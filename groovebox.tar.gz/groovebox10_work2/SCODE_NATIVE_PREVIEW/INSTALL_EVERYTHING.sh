#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="${XDG_DATA_HOME:-$HOME/.local/share}/sCode-Ecosystem"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"

say(){ printf '\n==> %s\n' "$*"; }
need(){ command -v "$1" >/dev/null 2>&1; }

say "sCode Ecosystem 1.1.2 persistent-runner installer"
missing=0
need python3 || missing=1
need c++ || missing=1
need pkg-config || missing=1
[ -f /usr/include/X11/Xlib.h ] || missing=1
if ((missing)); then
  say "Installing missing compiler/X11 prerequisites"
  if need apt-get; then sudo apt-get update && sudo apt-get install -y python3 build-essential pkg-config libx11-dev
  elif need dnf; then sudo dnf install -y python3 gcc-c++ make pkgconf-pkg-config libX11-devel
  elif need pacman; then sudo pacman -S --needed python gcc make pkgconf libx11
  elif need zypper; then sudo zypper --non-interactive install python3 gcc-c++ make pkg-config libX11-devel
  else echo "Install Python 3, a C++17 compiler, pkg-config and X11 development headers, then rerun." >&2; exit 1; fi
fi

say "Installing self-contained sCode tree to $PREFIX"
mkdir -p "$PREFIX" "$BIN" "$APPS"
rm -rf "$PREFIX.new"
mkdir -p "$PREFIX.new"
cp -a "$SRC"/. "$PREFIX.new"/
rm -rf "$PREFIX"
mv "$PREFIX.new" "$PREFIX"
cd "$PREFIX"
chmod +x sCode build_native.sh test_native.sh INSTALL_EVERYTHING.sh

say "Building native sCode runtime"
./build_native.sh
say "Running compiler/runtime regression tests"
./test_native.sh

say "Installing sCode command"
cat > "$BIN/sCode" <<WRAP
#!/bin/sh
exec python3 "$PREFIX/sCode.py" "\$@"
WRAP
chmod +x "$BIN/sCode"

say "Compiling Groovebox native app"
"$BIN/sCode" compile "$PREFIX/examples/groovebox.sC" -o "$PREFIX/build/Groovebox" --ir "$PREFIX/build/groovebox.sir"

cat > "$APPS/scode-groovebox.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Mathematician's Groovebox (sCode)
Comment=Native seed-first sCode Groovebox preview
Exec=$PREFIX/build/Groovebox
Terminal=false
Categories=AudioVideo;Development;
DESK
chmod +x "$APPS/scode-groovebox.desktop"

cat > "$BIN/sCode-open" <<WRAP
#!/bin/sh
exec "$PREFIX/bin/scode-source-runner" "\$1" "$BIN/sCode"
WRAP
chmod +x "$BIN/sCode-open"

cat > "$APPS/scode-terminal.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=sCode Source Runner
Comment=Persistent sCode source/binary runner with captured output
Exec=$BIN/sCode-open %f
Terminal=false
MimeType=text/x-scode;application/x-scode-binary;
Categories=Development;
DESK
chmod +x "$APPS/scode-terminal.desktop"

MIME="${XDG_DATA_HOME:-$HOME/.local/share}/mime/packages"
mkdir -p "$MIME"
cat > "$MIME/scode.xml" <<'XML'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
 <mime-type type="text/x-scode"><comment>sCode source</comment><glob pattern="*.sC"/><glob pattern="*.scode"/></mime-type>
 <mime-type type="application/x-scode-binary"><comment>sCode compiled payload</comment><glob pattern="*.sbin"/></mime-type>
</mime-info>
XML
need update-mime-database && update-mime-database "$(dirname "$MIME")" || true
need update-desktop-database && update-desktop-database "$APPS" || true
need xdg-mime && xdg-mime default scode-terminal.desktop text/x-scode || true
need xdg-mime && xdg-mime default scode-terminal.desktop application/x-scode-binary || true

say "Smoke-testing installed entry graph"
"$BIN/sCode" run "$PREFIX/examples/hello.sC" run as it || true

echo
echo "INSTALL COMPLETE"
echo "  sCode:     $BIN/sCode"
echo "  Groovebox: $PREFIX/build/Groovebox"
echo "  AI source: $PREFIX/apps/sAssistant.sC"
echo "  OS source: $PREFIX/apps/sOS.sC"
echo
echo "Launch Groovebox from your application menu or run:"
echo "  $PREFIX/build/Groovebox"
echo
echo "Run source by identity/dependency graph:"
echo "  sCode run find groovebox.sC run as it"
