# sCode Groovebox Seed Authority 0.8

## Seed-first canonical law

This branch makes the seed the root canonical identity when a non-zero seed is present. Synth voice identity is no longer automatically part of canonical identity merely because a renderer needs a waveform. With FullWeight seed ON, an unspecified voice has zero canonical interference. A user-explicit voice may contribute a declared partial share. With FullWeight OFF, the unused seed share becomes genuine room in which the voice can interfere.

Formally, for seed projection S and voice projection V, the runtime uses `C = S + beta(V-S)`, where beta is derived from seed authority and explicit voice policy. `beta=0` means the voice is only a rendering basis; `0<beta<1` means partial interference; `beta=1` means voice authority.

Audio, visual, and game projections read the same seed-rooted canonical state. Reciprocal derivation is allowed only when the relevant information is preserved; lossy outputs such as final pixels or PCM are not assumed invertible.

---

# sCode Groovebox Infinity L-Plot 0.7

This branch keeps the 0.6 command/compiler workflow and adds a native **Infinity Logic L-plot** layer for proof-bearing finite-state collapse.

The design rule is one-to-one:

- one canonical state -> one L-plot node
- one deterministic transition -> one directed edge
- first repeated state -> certified finite cycle
- certified cycle -> exact modular jump for any later step
- no repeat within the declared finite bound -> no exact collapse claim

Python is still only a source/sIR/sBIN translator. The generated executable and the L-plot analysis run in the C++ native binary and do not require Python after compilation.

## Commands

```bash
./build_native.sh
./sCode run examples/groovebox.sC
./sCode run find groovebox.sC run as it
./sCode analyze examples/groovebox.sC --lplot groovebox_logic.svg --jump 1000000000
./sCode compile examples/groovebox.sC -o Groovebox
./Groovebox --lplot compiled_logic.svg --jump 1000000000
```

`--lplot` produces a deterministic SVG logic-landscape directly from the native runtime. The tail shows the preperiod; the ring shows the proven cycle. The plot is a topology/debug representation, not a claim about physical geometry.

## New sCode library

`scode/libs/infinity_logic.scode` exposes `lplot_build`, `lplot_signature`, `lplot_cycle`, `lplot_jump`, `lplot_cost`, and `lplot_emit_svg`. `groovebox.scode` now depends on it and declares canonical-loop analysis/jump operations shared by audio, visual and game state.

## Scope boundary

This is an important compiler/runtime primitive, not yet full parity with the mature Python Groovebox UI/audio/game implementation. The purpose is to replace repeated host-language control logic with finite canonical state graphs and exact native jumps wherever the state machine proves them valid.

## sCode entry graph semantics (0.9)

The CLI grammar is literal:

```text
sCode run [find] FILE.sC [run as it]
```

- `find` means browse/search the user's files for `FILE.sC`.
- `FILE.sC` is **it**: the sole entry program identity.
- `run as it` means every connected source declaration (`use`, `import`,
  `include`, `connect`, `requires`) is resolved recursively and compiled into
  the same sIR/sBIN image under `FILE.sC`.
- Connected code is not launched as a second application and cannot replace the
  root identity. It runs as part of `FILE.sC`.
- Built-in domains (`core`, `math`, `media`, `system`, `game`) remain native
  symbolic/runtime connections. Source-backed connections such as
  `use groovebox` resolve to the actual `.scode` library and recursively pull
  its own connected libraries into the executable image.

Canonical command for this package:

```bash
sCode run find groovebox.sC run as it
```

## 0.9.2 — visible `.sbin` open/run fix

`*.sbin` is now registered as `application/x-scode-binary` by `sCode install-user`.
Opening a compiled sBIN from an XDG desktop invokes `sCode run %f`. Because the
current Groovebox sBIN is still a console/native demonstrator rather than the full
GUI application, its desktop handler deliberately opens a terminal so the native
runtime output is visible instead of appearing to do nothing. Direct sBIN runs also
use the sBIN's containing directory as the working directory, so generated artifacts
such as `groovebox_native_demo.wav` appear beside the payload.

After updating, rerun:

```bash
./sCode install-user
```

Then double-click `bin/GrooveboxTabletOS.sbin`, or run:

```bash
./sCode run bin/GrooveboxTabletOS.sbin
```

## 1.1.1 source-runner hold fix
Opening `.sC`, `.scode`, or `.sbin` from the desktop now uses `sCode-open`. After the program exits, the terminal remains open and shows the exit status until Enter is pressed. Normal command-line `sCode run ...` behavior is unchanged.

## 1.1.2 persistent source-runner fix
The desktop file association no longer relies on a terminal emulator or `read` hold. `scode-source-runner` is a native X11 window that launches the selected `.sC`, `.scode`, or `.sbin`, captures stdout/stderr, shows the exit code, and remains open until the user closes it. It provides Run Again (F5), Open Source, Stop/Close, and scrollback. GUI sCode applications still own their own event loops; closing the app does not close the source runner.
