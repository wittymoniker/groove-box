# sCode Ecosystem 1.1 — sOS + sAssistant Development Workbench

This build starts the OS/AI work in the same sCode ecosystem rather than as unrelated projects.

## One command

```bash
./RUN_SOS_AI.sh
```

It builds the native sCode runtime, runs native regression tests, compiles `apps/sAssistant.sC` and `apps/sOS.sC` into standalone executables, lets the local sAssistant development lab inspect the project and write an evidence report, then opens the basic sOS workbench.

## Basic sOS workbench

The current sOS stage deliberately uses the Linux kernel and drivers. The native sCode workbench can launch Groovebox, open sAssistant, run the local AI/project inspection, run native tests, and display the generated report.

This is a userspace/desktop prototype, not yet a bootable independent ISO.

## sAssistant development lab

`sAssistant.sC` is the application identity. The current reasoning helper is a deterministic bootstrap inspector rather than a trained local LLM. It inventories the sCode/native implementation, compiles the three entry graphs, checks known architecture evidence, optionally runs safe local tests, and chooses the smallest next implementation step according to dependency order.

Reports:

- `reports/sassistant_report.md`
- `reports/sassistant_state.json`

Run it manually:

```bash
python3 tools/sassistant_lab.py --run-tests
./build/sAssistant --gui
```

The intended progression is to move more of this project reasoning into native sCode theorem/graph operations and later attach a local model backend without making model guesses equivalent to verified theorems.

### Persistent development output
sOS/sAssistant workbench commands now open through the same persistent native command runner instead of short-lived terminal windows. Test/report output therefore remains visible until explicitly closed.
