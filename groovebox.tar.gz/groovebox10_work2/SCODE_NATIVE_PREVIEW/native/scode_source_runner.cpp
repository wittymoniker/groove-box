#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

using std::string; using std::vector;

static string basename_of(const string& p){ try{return std::filesystem::path(p).filename().string();}catch(...){return p;} }
static vector<string> wrap_lines(const string&s,size_t width){
    vector<string> out; std::istringstream in(s); string line;
    while(std::getline(in,line)){
        if(line.empty()){out.push_back(""); continue;}
        for(size_t i=0;i<line.size();i+=width) out.push_back(line.substr(i,width));
    }
    if(out.empty()) out.push_back(""); return out;
}

struct Child {
    pid_t pid=-1; int fd=-1; bool running=false; int status=-999;
};

static Child start_child(const string& scode, const string& file, bool commandMode=false, const string& cwd=""){
    int p[2]; if(pipe(p)!=0) throw std::runtime_error("pipe failed");
    pid_t pid=fork(); if(pid<0) throw std::runtime_error("fork failed");
    if(pid==0){
        close(p[0]); dup2(p[1],STDOUT_FILENO); dup2(p[1],STDERR_FILENO); close(p[1]);
        try { if(commandMode && !cwd.empty()) std::filesystem::current_path(cwd); else std::filesystem::current_path(std::filesystem::path(file).parent_path()); } catch(...) {}
        if(commandMode) execl("/bin/sh","sh","-lc",file.c_str(),(char*)nullptr);
        else execl(scode.c_str(), scode.c_str(), "run", file.c_str(), "run", "as", "it", (char*)nullptr);
        dprintf(STDERR_FILENO,"sCode Runner: exec failed: %s\n",strerror(errno));
        _exit(127);
    }
    close(p[1]); int fl=fcntl(p[0],F_GETFL,0); fcntl(p[0],F_SETFL,fl|O_NONBLOCK);
    return Child{pid,p[0],true,-999};
}

static void stop_child(Child& c){
    if(c.running && c.pid>0){ kill(c.pid,SIGTERM); for(int i=0;i<20;i++){int st;pid_t r=waitpid(c.pid,&st,WNOHANG);if(r==c.pid){c.running=false;c.status=st;break;} usleep(25000);} if(c.running){kill(c.pid,SIGKILL);waitpid(c.pid,&c.status,0);c.running=false;}}
    if(c.fd>=0){close(c.fd);c.fd=-1;}
}

int main(int argc,char**argv){
    if(argc<2){std::cerr<<"usage: scode-source-runner FILE.sC|FILE.scode|FILE.sbin [sCode-command]\n       scode-source-runner --command \"shell command\" [cwd]\n";return 2;}
    bool commandMode=string(argv[1])=="--command";
    if(commandMode && argc<3){std::cerr<<"missing command\n";return 2;}
    string file=commandMode?string(argv[2]):std::filesystem::absolute(argv[1]).string();
    string cwd=commandMode?((argc>=4)?string(argv[3]):std::filesystem::current_path().string()):"";
    string scode=commandMode?"":((argc>=3)?argv[2]:"sCode");
    Display*d=XOpenDisplay(nullptr); if(!d){std::cerr<<"sCode Source Runner: no X11 display\n";return 3;}
    int scr=DefaultScreen(d); unsigned long white=WhitePixel(d,scr),black=BlackPixel(d,scr);
    Window w=XCreateSimpleWindow(d,RootWindow(d,scr),100,80,1000,700,1,black,white);
    string title=commandMode?"sCode Command Runner":("sCode Source Runner — "+basename_of(file)); XStoreName(d,w,title.c_str());
    XSelectInput(d,w,ExposureMask|ButtonPressMask|KeyPressMask|StructureNotifyMask);
    Atom wmDelete=XInternAtom(d,"WM_DELETE_WINDOW",False);XSetWMProtocols(d,w,&wmDelete,1);XMapWindow(d,w);
    GC gc=XCreateGC(d,w,0,nullptr); XSetForeground(d,gc,black); XFontStruct*font=XLoadQueryFont(d,"9x15");if(font)XSetFont(d,gc,font->fid);
    int winW=1000,winH=700; string output; int scroll=0; Child child;
    auto append=[&](const string&s){output+=s; if(output.size()>300000)output.erase(0,output.size()-250000);};
    auto launch=[&](){stop_child(child); output.clear();scroll=0;append(commandMode?("$ "+file+"\n\n"):("$ sCode run \""+file+"\" run as it\n\n")); try{child=start_child(scode,file,commandMode,cwd);}catch(const std::exception&e){append(string("runner error: ")+e.what()+"\n");}};
    auto drawButton=[&](int x,int y,int ww,const string&t){XDrawRectangle(d,w,gc,x,y,ww,36);XDrawString(d,w,gc,x+10,y+23,t.c_str(),(int)t.size());};
    auto draw=[&](){
        XClearWindow(d,w); string head="sCode Source Runner";XDrawString(d,w,gc,18,28,head.c_str(),head.size());
        string f=(commandMode?"Command: ":"File: ")+file; if(f.size()>115) f=(commandMode?"Command: ...":"File: ...")+f.substr(f.size()-108); XDrawString(d,w,gc,18,50,f.c_str(),f.size());
        drawButton(18,65,125,"Run Again"); if(!commandMode) drawButton(155,65,125,"Open Source"); drawButton(292,65,125,child.running?"Stop":"Close");
        string st=child.running?"RUNNING":"FINISHED"; if(!child.running&&child.status!=-999){int code=WIFEXITED(child.status)?WEXITSTATUS(child.status):128+(WIFSIGNALED(child.status)?WTERMSIG(child.status):0);st+=" — exit "+std::to_string(code);} XDrawString(d,w,gc,440,88,st.c_str(),st.size());
        XDrawRectangle(d,w,gc,18,112,std::max(100,winW-36),std::max(100,winH-130));
        size_t cols=std::max(30,(winW-60)/9); auto lines=wrap_lines(output,cols); int visible=std::max(1,(winH-160)/15); int maxScroll=std::max(0,(int)lines.size()-visible); scroll=std::min(scroll,maxScroll); int start=std::max(0,maxScroll-scroll);
        int y=135; for(int i=start;i<(int)lines.size()&&y<winH-20;i++,y+=15) XDrawString(d,w,gc,28,y,lines[i].c_str(),lines[i].size()); XFlush(d);
    };
    launch(); draw(); bool alive=true; int xfd=ConnectionNumber(d);
    while(alive){
        fd_set rf;FD_ZERO(&rf);FD_SET(xfd,&rf);int maxfd=xfd;if(child.fd>=0){FD_SET(child.fd,&rf);maxfd=std::max(maxfd,child.fd);} timeval tv{0,100000};select(maxfd+1,&rf,nullptr,nullptr,&tv);
        if(child.fd>=0 && FD_ISSET(child.fd,&rf)){char b[4096];for(;;){ssize_t n=read(child.fd,b,sizeof(b));if(n>0)append(string(b,b+n));else{if(n==0){close(child.fd);child.fd=-1;}break;}}draw();}
        if(child.running){int st;pid_t r=waitpid(child.pid,&st,WNOHANG);if(r==child.pid){child.running=false;child.status=st;append("\n[sCode program finished — runner remains open]\n");draw();}}
        while(XPending(d)){
            XEvent e;XNextEvent(d,&e); if(e.type==Expose){draw();continue;} if(e.type==ConfigureNotify){winW=e.xconfigure.width;winH=e.xconfigure.height;draw();continue;} if(e.type==ClientMessage&&(Atom)e.xclient.data.l[0]==wmDelete){alive=false;break;}
            if(e.type==KeyPress){KeySym k=XLookupKeysym(&e.xkey,0);if(k==XK_Escape){alive=false;break;}if(k==XK_F5){launch();draw();}else if(k==XK_Up||k==XK_Page_Up){scroll+=k==XK_Page_Up?10:1;draw();}else if(k==XK_Down||k==XK_Page_Down){scroll=std::max(0,scroll-(k==XK_Page_Down?10:1));draw();}}
            if(e.type==ButtonPress){int x=e.xbutton.x,y=e.xbutton.y;if(e.xbutton.button==4){scroll+=3;draw();continue;}if(e.xbutton.button==5){scroll=std::max(0,scroll-3);draw();continue;}if(y>=65&&y<=101){if(x>=18&&x<=143){launch();draw();}else if(!commandMode&&x>=155&&x<=280){pid_t p=fork();if(p==0){execlp("xdg-open","xdg-open",file.c_str(),(char*)nullptr);_exit(127);}}else if(x>=292&&x<=417){if(child.running){stop_child(child);append("\n[stopped by user]\n");draw();}else alive=false;}}}
        }
    }
    stop_child(child); if(font)XFreeFont(d,font);XFreeGC(d,gc);XDestroyWindow(d,w);XCloseDisplay(d);return 0;
}
