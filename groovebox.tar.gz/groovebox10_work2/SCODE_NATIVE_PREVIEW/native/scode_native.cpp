#include "scode_math.hpp"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdint>
#include <stdexcept>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <filesystem>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#if __has_include(<X11/Xlib.h>)
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#define SCODE_HAS_X11 1
#else
#define SCODE_HAS_X11 0
#endif
using namespace std;
struct Rec{string kind,name,path;vector<string>args;};
static uint32_t u32(istream&f){uint32_t v;f.read((char*)&v,4);if(!f)throw runtime_error("truncated sBIN");return v;}
static uint64_t u64(istream&f){uint64_t v;f.read((char*)&v,8);if(!f)throw runtime_error("truncated u64");return v;}
static string str(istream&f){uint32_t n=u32(f);string s(n,'\0');f.read(s.data(),n);if(!f)throw runtime_error("truncated string");return s;}
static vector<Rec> load_stream(istream&f){char m[8];f.read(m,8);if(string(m,8)!=string("SBIN1\0\0\0",8))throw runtime_error("bad sBIN");uint32_t n=u32(f);vector<Rec>r;r.reserve(n);for(uint32_t i=0;i<n;i++){Rec x;x.kind=str(f);x.name=str(f);x.path=str(f);uint32_t na=u32(f);while(na--)x.args.push_back(str(f));uint32_t at=u32(f);while(at--){str(f);str(f);}r.push_back(move(x));}return r;}
static vector<Rec> load(const string&p){ifstream f(p,ios::binary);if(!f)throw runtime_error("cannot open sBIN");return load_stream(f);}
static vector<Rec> load_embedded(const string&exe){ifstream f(exe,ios::binary);if(!f)throw runtime_error("cannot open executable");f.seekg(0,ios::end);streamoff end=(streamoff)f.tellg();const string tag="SCODEAPP1";streamoff trailer=(streamoff)tag.size()+8;if(end<trailer)throw runtime_error("no embedded sCode program");f.seekg(end-(streamoff)tag.size());string got(tag.size(),'\0');f.read(got.data(),got.size());if(got!=tag)throw runtime_error("no embedded sCode program");f.seekg(end-(streamoff)tag.size()-streamoff(8));uint64_t n=u64(f);if(n>(uint64_t)end)throw runtime_error("bad embedded program size");f.seekg(end-trailer-(streamoff)n);string blob((size_t)n,'\0');f.read(blob.data(),blob.size());istringstream in(blob,ios::binary);return load_stream(in);}
static string findv(const vector<Rec>&r,const string&ancestor,const string&kind,const string&def=""){for(auto &x:r)if(x.path.find(ancestor)!=string::npos&&x.kind==kind)return x.name;return def;}
static long long hexnum(string s,long long d){try{return stoll(s,nullptr,16);}catch(...){return d;}}
static bool truthy(string s,bool d=false){for(char&c:s)c=(char)tolower((unsigned char)c);if(s=="on"||s=="true"||s=="yes"||s=="1")return true;if(s=="off"||s=="false"||s=="no"||s=="0")return false;return d;}
static long double unitnum(string s,long double d){
    try{
        auto slash=s.find('/'); if(slash!=string::npos){long double a=stold(s.substr(0,slash)),b=stold(s.substr(slash+1));return b? a/b:d;}
        // decimal fractions remain decimal; integer-looking values are radix-16.
        if(s.find('.')!=string::npos) return stold(s);
        long double v=(long double)stoll(s,nullptr,16); return v>1.0L ? v/255.0L : v;
    }catch(...){return d;}
}
static void wav(const string&p,int sr,double sec,double hz,uint64_t seed){int n=(int)(sr*sec);ofstream f(p,ios::binary);int data=n*2,sz=36+data;f.write("RIFF",4);f.write((char*)&sz,4);f.write("WAVEfmt ",8);int sub=16;short fmt=1,ch=1,bits=16;int br=sr*2;short ba=2;f.write((char*)&sub,4);f.write((char*)&fmt,2);f.write((char*)&ch,2);f.write((char*)&sr,4);f.write((char*)&br,4);f.write((char*)&ba,2);f.write((char*)&bits,2);f.write("data",4);f.write((char*)&data,4);double ph=0;for(int i=0;i<n;i++){double gate=((scode::seeded(seed,(uint64_t)(i/(sr/8)))>>3)&1)?1.0:.2;ph+=2*M_PI*hz/sr;short v=(short)(sin(ph)*gate*9000);f.write((char*)&v,2);}}
static void emit_lplot_svg(const scode::LPlot&p,const string&path){
    const double W=1000,H=700,cx=500,cy=350; ofstream f(path); if(!f) throw runtime_error("cannot write lplot svg");
    f<<"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 "<<W<<" "<<H<<"'>\n";
    f<<"<rect width='100%' height='100%' fill='white'/><text x='24' y='34' font-family='monospace' font-size='18'>sCode Infinity Logic L-plot</text>\n";
    f<<"<text x='24' y='58' font-family='monospace' font-size='13'>nodes="<<p.nodes.size()<<" preperiod="<<p.preperiod<<" period="<<p.period<<" certified="<<(p.certified?"yes":"no")<<" signature=0x"<<hex<<p.signature<<dec<<"</text>\n";
    size_t n=p.nodes.size(); if(!n){f<<"</svg>\n";return;}
    vector<pair<double,double>> xy(n);
    // Tail flows left-to-right; cycle is laid out as a ring. This is a logic
    // topology plot, not a physical coordinate claim.
    size_t pre=(size_t)min<uint64_t>(p.preperiod,n), per=(size_t)min<uint64_t>(p.period,n-pre);
    for(size_t i=0;i<pre;i++){double t=pre<=1?0.5:(double)i/(double)(pre-1);xy[i]={80+t*360,120+t*460};}
    double R=min(220.0, 70.0+per*3.0); for(size_t k=0;k<per;k++){double a=-M_PI/2+2*M_PI*(double)k/(double)max<size_t>(1,per);xy[pre+k]={700+R*cos(a),350+R*sin(a)};}
    for(size_t i=pre+per;i<n;i++){double a=2*M_PI*(double)i/(double)n;xy[i]={cx+250*cos(a),cy+250*sin(a)};}
    unordered_map<uint64_t,size_t> idx; for(size_t i=0;i<n;i++) idx[p.nodes[i].state]=i;
    for(size_t i=0;i<n;i++){auto it=idx.find(p.nodes[i].next); if(it==idx.end())continue; auto [x1,y1]=xy[i];auto [x2,y2]=xy[it->second];f<<"<line x1='"<<x1<<"' y1='"<<y1<<"' x2='"<<x2<<"' y2='"<<y2<<"' stroke='#777' stroke-width='1'/>\n";}
    for(size_t i=0;i<n;i++){auto [x,y]=xy[i];f<<"<circle cx='"<<x<<"' cy='"<<y<<"' r='"<<(p.nodes[i].in_cycle?5:4)<<"' fill='"<<(p.nodes[i].in_cycle?"#222":"#999")<<"'/><title>i="<<i<<" state=0x"<<hex<<p.nodes[i].state<<dec<<"</title>\n";}
    f<<"</svg>\n";
}
static scode::LPlot make_groovebox_lplot(uint64_t seed,int steps){
    // Compact canonical automation state: [phase:8][playhead:8]. The transition
    // is deterministic and finite, so a repeat is a proof-bearing exact cycle.
    uint64_t start=((seed&0xffULL)<<8); uint64_t mask=0xffffULL;
    auto next=[=](uint64_t s){uint64_t play=s&0xffULL, phase=(s>>8)&0xffULL;play=(play+1)%max(1,steps);uint64_t bit=(scode::seeded(seed,play+phase)>>11)&1ULL;phase=(phase + 1 + bit + (play&1ULL))&0xffULL;return ((phase<<8)|play)&mask;};
    return scode::lplot_build(start,1u<<17,next);
}

static bool has_kind(const vector<Rec>&r,const string&kind){for(auto &x:r)if(x.kind==kind)return true;return false;}
static void try_play_audio(const string&path){
    (void)path;
    string cmd="(command -v paplay >/dev/null 2>&1 && paplay groovebox_native_demo.wav) || (command -v aplay >/dev/null 2>&1 && aplay groovebox_native_demo.wav) || (command -v ffplay >/dev/null 2>&1 && ffplay -nodisp -autoexit -loglevel quiet groovebox_native_demo.wav) >/dev/null 2>&1 &";
    std::system(cmd.c_str());
}
#if SCODE_HAS_X11
static int run_core_workbench(const string&pname){
    Display*d=XOpenDisplay(nullptr); if(!d){cerr<<pname<<" GUI: no X11 display; falling back to console.\n";return -1;}
    int scr=DefaultScreen(d); unsigned long white=WhitePixel(d,scr),black=BlackPixel(d,scr);
    Window w=XCreateSimpleWindow(d,RootWindow(d,scr),120,90,980,620,1,black,white);
    string title=(pname=="sOS")?"sOS — basic sCode development workbench":"sAssistant — sCode development lab";
    XStoreName(d,w,title.c_str()); XSelectInput(d,w,ExposureMask|ButtonPressMask|KeyPressMask|StructureNotifyMask);
    Atom wmDelete=XInternAtom(d,"WM_DELETE_WINDOW",False);XSetWMProtocols(d,w,&wmDelete,1);XMapWindow(d,w);
    GC gc=XCreateGC(d,w,0,nullptr);XSetForeground(d,gc,black);XFontStruct*font=XLoadQueryFont(d,"9x15");if(font)XSetFont(d,gc,font->fid);
    auto rect=[&](int x,int y,int ww,int hh,const string&t){XDrawRectangle(d,w,gc,x,y,ww,hh);XDrawString(d,w,gc,x+10,y+25,t.c_str(),(int)t.size());};
    auto launch=[&](const string&cmd){string cwd=filesystem::current_path().string();string q="./bin/scode-source-runner --command \""+cmd+"\" \""+cwd+"\" >/dev/null 2>&1 &";system(q.c_str());};
    auto draw=[&](){XClearWindow(d,w);XDrawString(d,w,gc,24,36,title.c_str(),title.size());
        string a="Linux kernel/drivers -> sCode runtime -> sOS userspace -> apps/services";XDrawString(d,w,gc,24,66,a.c_str(),a.size());
        if(pname=="sOS"){
            rect(24,110,250,48,"Launch Groovebox");rect(294,110,250,48,"Open sAssistant");rect(564,110,250,48,"AI inspect + tests");
            rect(24,180,250,48,"sCode native tests");rect(294,180,250,48,"View AI report");rect(564,180,250,48,"Quit");
            string b="Basic OS stage: sOS is userspace hosted by Linux; hardware/kernel services remain Linux-provided.";XDrawString(d,w,gc,24,275,b.c_str(),b.size());
            string c="sAssistant is capability-scoped and can inspect/test the local sCode tree; writes still require explicit changes.";XDrawString(d,w,gc,24,310,c.c_str(),c.size());
        }else{
            rect(24,110,250,48,"Inspect project");rect(294,110,250,48,"Inspect + run tests");rect(564,110,250,48,"View report");
            rect(24,180,250,48,"Run Groovebox graph");rect(294,180,250,48,"Open sOS workbench");rect(564,180,250,48,"Quit");
            string b="Reasoning policy: algebra -> symbolic logic -> equivalence -> verify -> reuse/collapse.";XDrawString(d,w,gc,24,275,b.c_str(),b.size());
            string c="Current assistant is a deterministic development-lab bootstrap, not yet a trained local language model.";XDrawString(d,w,gc,24,310,c.c_str(),c.size());
        }XFlush(d);};
    draw();bool alive=true;while(alive){XEvent e;XNextEvent(d,&e);if(e.type==Expose){draw();continue;}if(e.type==ClientMessage&&(Atom)e.xclient.data.l[0]==wmDelete)break;
        if(e.type==KeyPress){KeySym k=XLookupKeysym(&e.xkey,0);if(k==XK_Escape||k==XK_q)break;}
        if(e.type==ButtonPress){int x=e.xbutton.x,y=e.xbutton.y;int col=(x>=24&&x<=274)?0:(x>=294&&x<=544)?1:(x>=564&&x<=814)?2:-1;int row=(y>=110&&y<=158)?0:(y>=180&&y<=228)?1:-1;
            if(col<0||row<0)continue;int id=row*3+col;
            if(pname=="sOS"){
                if(id==0)launch("./sCode run find groovebox.sC run as it");
                if(id==1)launch("./sCode run apps/sAssistant.sC run as it --gui");
                if(id==2)launch("python3 tools/sassistant_lab.py --run-tests");
                if(id==3)launch("./test_native.sh");
                if(id==4)launch("cat reports/sassistant_report.md");
                if(id==5)alive=false;
            }else{
                if(id==0)launch("python3 tools/sassistant_lab.py");
                if(id==1)launch("python3 tools/sassistant_lab.py --run-tests");
                if(id==2)launch("cat reports/sassistant_report.md");
                if(id==3)launch("./sCode run find groovebox.sC run as it --headless");
                if(id==4)launch("./build/sOS --gui");
                if(id==5)alive=false;
            }
        }}
    if(font)XFreeFont(d,font);XFreeGC(d,gc);XDestroyWindow(d,w);XCloseDisplay(d);return 0;
}
static int run_gui(const vector<Rec>&r,long long initialSeed,int steps,double base){
    Display*d=XOpenDisplay(nullptr); if(!d){cerr<<"sCode GUI: no X11 display; falling back to console.\n";return -1;}
    int scr=DefaultScreen(d); unsigned long white=WhitePixel(d,scr),black=BlackPixel(d,scr);
    Window w=XCreateSimpleWindow(d,RootWindow(d,scr),100,80,1120,720,1,black,white);
    XStoreName(d,w,"Mathematician's Groovebox — native sCode preview");
    XSelectInput(d,w,ExposureMask|ButtonPressMask|KeyPressMask|StructureNotifyMask);
    Atom wmDelete=XInternAtom(d,"WM_DELETE_WINDOW",False); XSetWMProtocols(d,w,&wmDelete,1); XMapWindow(d,w);
    GC gc=XCreateGC(d,w,0,nullptr); XSetForeground(d,gc,black);
    XFontStruct*font=XLoadQueryFont(d,"9x15"); if(font)XSetFont(d,gc,font->fid);
    long long seed=initialSeed; string seedText; {ostringstream os;os<<hex<<uppercase<<seed;seedText=os.str();}
    bool editSeed=false, fullweight=true, voiceExplicit=false; double voiceShare=.25;
    auto rect=[&](int x,int y,int ww,int hh,const string&t){XDrawRectangle(d,w,gc,x,y,ww,hh);XDrawString(d,w,gc,x+10,y+24,t.c_str(),(int)t.size());};
    auto draw=[&](){
        XClearWindow(d,w); string title="sCode Groovebox — SEED -> canonical state -> audio / visual / game";XDrawString(d,w,gc,24,34,title.c_str(),title.size());
        string sub="FILE.sC is the app identity; connected code runs as FILE.sC";XDrawString(d,w,gc,24,58,sub.c_str(),sub.size());
        {string q="Seed (hex/base-16):";XDrawString(d,w,gc,24,100,q.c_str(),q.size());} rect(190,76,190,38,seedText+(editSeed?"_":""));
        rect(410,76,180,38,fullweight?"FullWeight: ON":"FullWeight: OFF"); rect(610,76,210,38,voiceExplicit?"Voice explicit: YES":"Voice explicit: NO");
        rect(840,76,220,38,"Voice share: 0.25");
        {string q="Seeded sequencer";XDrawString(d,w,gc,24,150,q.c_str(),q.size());}
        int cell=52; for(int i=0;i<steps&&i<16;i++){int x=24+i*cell,y=166;XDrawRectangle(d,w,gc,x,y,42,42);bool on=((scode::seeded(seed,i)>>7)&1);if(on)XFillRectangle(d,w,gc,x+6,y+6,30,30);}
        rect(24,240,210,44,"Generate + Play WAV"); rect(252,240,170,44,"Randomize Seed"); rect(440,240,180,44,"Write L-plot"); rect(638,240,150,44,"Quit");
        long double beta; scode::SeedAuthority a{seed!=0,fullweight,fullweight?1.0L:0.72L,voiceExplicit,voiceShare}; beta=scode::voice_interference(a);
        ostringstream ss; ss<<"canonical root="<<(seed?"seed":"voice")<<"  seed authority="<<(double)scode::seed_authority(a)<<"  true voice interference="<<(double)beta; string st=ss.str();XDrawString(d,w,gc,24,330,st.c_str(),st.size());
        {string q="This is the native sCode interface preview. Mature Groovebox panels are still being ported.";XDrawString(d,w,gc,24,370,q.c_str(),q.size());}
        {string q="sAssistant.sC and sOS.sC are included in the installer as the next sCode applications.";XDrawString(d,w,gc,24,412,q.c_str(),q.size());}
        XFlush(d);
    };
    draw(); bool alive=true;
    while(alive){XEvent e;XNextEvent(d,&e);if(e.type==Expose){draw();continue;} if(e.type==ClientMessage && (Atom)e.xclient.data.l[0]==wmDelete)break;
        if(e.type==ButtonPress){int x=e.xbutton.x,y=e.xbutton.y;
            if(y>=76&&y<=114&&x>=190&&x<=380){editSeed=true;draw();continue;}
            if(y>=76&&y<=114&&x>=410&&x<=590){fullweight=!fullweight;draw();continue;}
            if(y>=76&&y<=114&&x>=610&&x<=820){voiceExplicit=!voiceExplicit;draw();continue;}
            if(y>=240&&y<=284){
                if(x>=24&&x<=234){wav("groovebox_native_demo.wav",48000,2.0,base,(uint64_t)seed);try_play_audio("groovebox_native_demo.wav");}
                else if(x>=252&&x<=422){seed=(long long)(scode::seeded((uint64_t)seed,0x53454544ULL)&0x7fffffffULL);ostringstream os;os<<hex<<uppercase<<seed;seedText=os.str();}
                else if(x>=440&&x<=620){auto lp=make_groovebox_lplot((uint64_t)seed,steps);emit_lplot_svg(lp,"groovebox_logic.svg");}
                else if(x>=638&&x<=788){alive=false;}
                draw();
            }
        }
        if(e.type==KeyPress&&editSeed){char buf[32]={0};KeySym ks;int n=XLookupString(&e.xkey,buf,sizeof(buf),&ks,nullptr);if(ks==XK_Return){editSeed=false;seed=hexnum(seedText,seed);draw();}else if(ks==XK_BackSpace){if(!seedText.empty())seedText.pop_back();draw();}else if(n>0){for(int i=0;i<n;i++){char c=toupper((unsigned char)buf[i]);if((c>='0'&&c<='9')||(c>='A'&&c<='F'))seedText.push_back(c);}draw();}}
    }
    if(font)XFreeFont(d,font);XFreeGC(d,gc);XDestroyWindow(d,w);XCloseDisplay(d);return 0;
}
#else
static int run_core_workbench(const string&pname){cerr<<pname<<" GUI: this runtime was built without X11 support.\n";return -1;}
static int run_gui(const vector<Rec>&,long long,int,double){cerr<<"sCode GUI: this runtime was built without X11 support.\n";return -1;}
#endif

int main(int argc,char**argv){try{
    string sbinPath,lplotPath; uint64_t jumpN=1000000; bool quiet=false,headless=false,forceGui=false;
    for(int i=1;i<argc;i++){string a=argv[i]; if(a=="--lplot"){lplotPath=(i+1<argc && argv[i+1][0]!='-')?argv[++i]:"groovebox_infinity_lplot.svg";} else if(a=="--jump"&&i+1<argc){jumpN=stoull(argv[++i]);} else if(a=="--quiet")quiet=true; else if(a=="--headless")headless=true; else if(a=="--gui")forceGui=true; else if(a.rfind("-",0)!=0 && sbinPath.empty())sbinPath=a;}
    vector<Rec> r=sbinPath.empty()?load_embedded(argv[0]):load(sbinPath);
    string pname=findv(r,"","program","sCodeProgram");
    bool specialCore=(pname=="sAssistant"||pname=="sOS"||pname=="Hello");
    bool grooveApp=!specialCore && (has_kind(r,"groovebox")||has_kind(r,"shell")||has_kind(r,"game")||has_kind(r,"visualizer"));
    if((pname=="sAssistant"||pname=="sOS") && forceGui && !headless && !quiet){int gr=run_core_workbench(pname); if(gr>=0)return gr;}
    if(!grooveApp && !forceGui){
        string msg=findv(r,"","message","");
        if(!quiet){cout<<"sCode Native runtime\n"<<"program="<<pname<<" records="<<r.size()<<"\n"; if(!msg.empty())cout<<msg<<"\n";
            if(has_kind(r,"assistant"))cout<<"assistant: sCode identity loaded; verified/author/uncertain knowledge classes reserved\n";
            if(has_kind(r,"os"))cout<<"sOS: sCode userspace identity loaded on Linux kernel host\n";
        }
        return 0;
    }
    string seedText=findv(r,"groovebox:simple","seed",findv(r,"game:open_world","seed","1975"));
    long long seed=hexnum(seedText,0x1975);int ww=(int)hexnum(findv(r,"game:open_world","world_width","500"),0x500);int wh=(int)hexnum(findv(r,"game:open_world","world_height","300"),0x300);int steps=(int)hexnum(findv(r,"groovebox:simple","steps","10"),0x10);double base=(double)hexnum(findv(r,"groovebox:simple","base_frequency","D8"),0xD8);
    scode::SeedAuthority authority; authority.seed_present=(seed!=0); authority.fullweight=truthy(findv(r,"groovebox:simple","seed_fullweight","on"),true); authority.seed_weight=unitnum(findv(r,"groovebox:simple","seed_weight","1"),1.0L); authority.voice_explicit=truthy(findv(r,"groovebox:simple","voice_explicit","off"),false); authority.voice_share=unitnum(findv(r,"groovebox:simple","voice_share","0"),0.0L);
    auto lp=make_groovebox_lplot((uint64_t)seed,steps); uint64_t jumped=scode::lplot_jump(lp,jumpN);
    bool guiProgram=has_kind(r,"shell")||has_kind(r,"groovebox")||forceGui; if(guiProgram&&!headless&&!quiet){int gr=run_gui(r,seed,steps,base); if(gr>=0)return gr;}
    if(!quiet){cout<<"sCode Native Groovebox runtime\n"<<"records="<<r.size()<<" seed=0x"<<hex<<seed<<dec<<" world="<<ww<<"x"<<wh<<" steps="<<steps<<"\n";
    cout<<"math: FI modular="<<scode::modular_jump(4,7,1000000,16)<<" affine="<<(double)scode::affine_jump(3,2,1,10)<<" meum_root="<<(scode::meum_root_check()?"PASS":"CHECK")<<"\n";
    cout<<"L-plot: nodes="<<lp.nodes.size()<<" preperiod="<<lp.preperiod<<" period="<<lp.period<<" certified="<<(lp.certified?"yes":"no")<<" signature=0x"<<hex<<lp.signature<<dec<<" jump["<<jumpN<<"]=0x"<<hex<<jumped<<dec<<" compression="<<(double)scode::lplot_compression(lp,jumpN)<<"x\n";
    cout<<"seed authority: root="<<(authority.seed_present?"seed":"voice")<<" fullweight="<<(authority.fullweight?"on":"off")<<" seed_weight="<<(double)scode::seed_authority(authority)<<" voice_explicit="<<(authority.voice_explicit?"yes":"no")<<" voice_interference="<<(double)scode::voice_interference(authority)<<"\n";
    scode::SeedAuthority explicit_full{true,true,1.0L,true,0.25L}; scode::SeedAuthority reduced{true,false,0.72L,false,0.0L};
    cout<<"seed-law tests: full+unspecified="<<(double)scode::voice_interference(authority)<<" full+explicit25="<<(double)scode::voice_interference(explicit_full)<<" reduced72="<<(double)scode::voice_interference(reduced)<<"\n";
    cout<<"sequencer: ";for(int i=0;i<steps;i++)cout<<(((scode::seeded(seed,i)>>7)&1)?"[#]":"[.]");cout<<"\n";
    int x=ww/2,y=wh/2;for(int t=0;t<12;t++){uint64_t q=scode::seeded(seed,t);int dx=(int)(q%3)-1,dy=(int)((q>>8)%3)-1;x=(x+dx+ww)%ww;y=(y+dy+wh)%wh;}cout<<"game deterministic player after 12 ticks: ("<<x<<","<<y<<")\n";
    wav("groovebox_native_demo.wav",48000,2.0,base,seed);cout<<"audio: wrote groovebox_native_demo.wav @ base="<<base<<" Hz\n";
    cout<<"runtime host: C++ binary only; Python not required after sBIN translation.\n";}
    if(!lplotPath.empty()){emit_lplot_svg(lp,lplotPath);cout<<"L-plot SVG: "<<lplotPath<<"\n";}
    return lp.certified?0:3;
}catch(exception&e){cerr<<"error: "<<e.what()<<"\n";return 2;}}
