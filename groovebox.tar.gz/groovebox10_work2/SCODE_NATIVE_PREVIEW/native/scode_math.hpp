#pragma once
#include <cstdint>
#include <cmath>
#include <functional>
#include <unordered_map>
#include <vector>
#include <string>
#include <limits>
#include <stdexcept>
namespace scode {
constexpr long double MEUM=1.1975807343385265188313261892683521394620007706106205L;
inline uint64_t mix64(uint64_t x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);} 
inline uint64_t seeded(uint64_t seed,uint64_t index){return mix64(seed ^ mix64(index));}
inline uint64_t modular_jump(uint64_t x,uint64_t step,uint64_t n,uint64_t mod){return mod? (x%mod + (uint64_t)((__uint128_t)(step%mod)*(n%mod)%mod))%mod : 0;}
inline long double range_sum(int64_t start,int64_t stop,int64_t step){if(step==0) return 0; int64_t n=0; if(step>0&&start<stop)n=(stop-start+step-1)/step; else if(step<0&&start>stop)n=(start-stop+(-step)-1)/(-step); if(n<=0)return 0; long double last=(long double)start+(long double)(n-1)*step; return (long double)n*((long double)start+last)/2.0L;}
struct Affine{long double a,b;};
inline Affine compose(Affine f,Affine g){return {g.a*f.a,g.a*f.b+g.b};}
inline Affine affine_power(Affine base,uint64_t n){Affine r{1,0};while(n){if(n&1)r=compose(r,base);base=compose(base,base);n>>=1;}return r;}
inline long double affine_jump(long double x,long double a,long double b,uint64_t n){auto p=affine_power({a,b},n);return p.a*x+p.b;}
template<class F> uint64_t cycle_jump(uint64_t start,uint64_t n,F next){std::unordered_map<uint64_t,uint64_t> seen;std::vector<uint64_t> seq;uint64_t s=start;for(uint64_t i=0;i<n;i++){auto it=seen.find(s);if(it!=seen.end()){uint64_t pre=it->second, cyc=i-pre;return seq[pre+(n-pre)%cyc];}seen[s]=i;seq.push_back(s);s=next(s);}return s;}
inline bool meum_root_check(long double tol=1e-12L){long double x=MEUM;long double f=std::pow(2.0L,x)-std::pow(x,4)-x*x+x;return std::fabs(f)<tol;}


// Seed authority / reciprocal projection ----------------------------------
// The seed is the root identity when present. Voice identity is not part of
// canonical identity unless the user explicitly specifies it, or seed authority
// is intentionally reduced so a voice is allowed to interfere.
struct SeedAuthority {
    bool seed_present=false;
    bool fullweight=true;
    long double seed_weight=1.0L;      // [0,1]
    bool voice_explicit=false;
    long double voice_share=0.0L;      // [0,1], user-requested partial influence
};
inline long double clamp01(long double x){return x<0?0:(x>1?1:x);}
inline long double voice_interference(const SeedAuthority& a){
    if(!a.seed_present) return 1.0L;
    const long double w=clamp01(a.seed_weight);
    if(a.fullweight){
        // Full-weight seed makes an unspecified synth voice representational
        // only. An explicitly specified voice may still matter, but only by the
        // share deliberately admitted by the project.
        return a.voice_explicit ? clamp01(a.voice_share) : 0.0L;
    }
    // Reduced seed authority leaves real canonical room for interference.
    // An explicit voice can request still more of that room, but never > 1.
    const long double free_space=1.0L-w;
    return clamp01(a.voice_explicit ? std::max(free_space, clamp01(a.voice_share)) : free_space);
}
inline long double seed_authority(const SeedAuthority& a){
    if(!a.seed_present) return 0.0L;
    return a.fullweight ? 1.0L : clamp01(a.seed_weight);
}
inline long double canonical_blend(long double seed_value,long double voice_value,const SeedAuthority& a){
    if(!a.seed_present) return voice_value;
    const long double vi=voice_interference(a);
    // Seed remains the identity anchor. Voice is an admitted perturbation,
    // not a competing source of truth.
    return seed_value + vi*(voice_value-seed_value);
}

// L-plot / Infinity Logic --------------------------------------------------
// A deterministic finite orbit is represented one-to-one: unique canonical
// state -> one node, transition(state) -> one edge. The first repeated state
// proves a cycle and therefore an exact modular jump on that orbit.
struct LPlotNode { uint64_t state=0; uint64_t next=0; uint64_t index=0; bool in_cycle=false; };
struct LPlot {
    std::vector<LPlotNode> nodes;
    uint64_t preperiod=0;
    uint64_t period=0;
    uint64_t repeated_state=0;
    bool certified=false;
    uint64_t signature=0;
};
inline uint64_t lplot_hash_step(uint64_t h,uint64_t a,uint64_t b){return mix64(h ^ mix64(a) ^ (mix64(b)<<1));}
template<class F> LPlot lplot_build(uint64_t start,uint64_t bound,F next){
    if(bound==0) throw std::runtime_error("lplot bound must be > 0");
    LPlot p; p.nodes.reserve((size_t)std::min<uint64_t>(bound,1u<<20));
    std::unordered_map<uint64_t,uint64_t> seen;
    uint64_t s=start, sig=0x4c504c4f545631ULL;
    for(uint64_t i=0;i<bound;i++){
        auto it=seen.find(s);
        if(it!=seen.end()){
            p.preperiod=it->second; p.period=i-it->second; p.repeated_state=s; p.certified=p.period>0;
            for(uint64_t j=p.preperiod;j<i;j++) p.nodes[(size_t)j].in_cycle=true;
            p.signature=lplot_hash_step(sig,p.preperiod,p.period);
            return p;
        }
        seen.emplace(s,i);
        uint64_t n=next(s);
        p.nodes.push_back({s,n,i,false}); sig=lplot_hash_step(sig,s,n); s=n;
    }
    p.signature=sig; return p;
}
inline uint64_t lplot_jump(const LPlot&p,uint64_t n){
    if(p.nodes.empty()) return 0;
    if(n<p.nodes.size()) return p.nodes[(size_t)n].state;
    if(!p.certified || p.period==0) throw std::runtime_error("lplot jump requested without cycle certificate");
    uint64_t idx=p.preperiod + ((n-p.preperiod)%p.period);
    return p.nodes[(size_t)idx].state;
}
inline long double lplot_compression(const LPlot&p,uint64_t requested_steps){
    if(requested_steps==0) return 1.0L;
    uint64_t work=(uint64_t)p.nodes.size();
    return (long double)requested_steps/(long double)std::max<uint64_t>(1,work);
}
}
