#!/usr/bin/env python3
"""Build-time translator only: deterministic sIR JSON -> compact native sBIN.
No Python is needed to execute the resulting binary program."""
import json,struct,sys,hashlib
MAGIC=b'SBIN1\0\0\0'

def walk(node,path=''):
    kind=str(node.get('kind','')); name=str(node.get('name',''))
    args=[str(x) for x in node.get('args',[])]; attrs=node.get('attrs',{}) or {}
    here=f"{path}/{kind}:{name}" if path else f"{kind}:{name}"
    yield kind,name,args,attrs,here
    for c in node.get('children',[]) or []:
        yield from walk(c,here)

def putstr(b,s):
    raw=s.encode('utf-8'); b.extend(struct.pack('<I',len(raw))); b.extend(raw)

def main(src,dst):
    doc=json.load(open(src,encoding='utf-8'))
    recs=[]
    for n in doc.get('nodes',[]): recs += list(walk(n))
    out=bytearray(MAGIC); out.extend(struct.pack('<I',len(recs)))
    for kind,name,args,attrs,path in recs:
        putstr(out,kind); putstr(out,name); putstr(out,path)
        out.extend(struct.pack('<I',len(args)))
        for a in args: putstr(out,a)
        items=sorted((str(k),str(v)) for k,v in attrs.items())
        out.extend(struct.pack('<I',len(items)))
        for k,v in items: putstr(out,k); putstr(out,v)
    digest=hashlib.sha256(out).digest(); out.extend(digest)
    open(dst,'wb').write(out)
    print(f"records={len(recs)} sha256={hashlib.sha256(out).hexdigest()}")
if __name__=='__main__': main(sys.argv[1],sys.argv[2])
