#!/usr/bin/env python3
from __future__ import annotations
import sys, json, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scode.compiler import compile_file, write_ir
from translator.sir_to_sbin import main as sir_to_sbin

def main(src,dst,keep_ir=None):
    src=Path(src); dst=Path(dst)
    ir=compile_file(src)
    if keep_ir:
        irp=Path(keep_ir); write_ir(ir,irp); sir_to_sbin(str(irp),str(dst))
    else:
        with tempfile.TemporaryDirectory(prefix='scode-') as td:
            irp=Path(td)/'program.sir'; write_ir(ir,irp); sir_to_sbin(str(irp),str(dst))
if __name__=='__main__':
    if len(sys.argv)<3: raise SystemExit('usage: source_to_sbin.py SOURCE.sC OUTPUT.sbin [OUTPUT.sir]')
    main(sys.argv[1],sys.argv[2],sys.argv[3] if len(sys.argv)>3 else None)
