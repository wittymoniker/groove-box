# Mechanical Phase Scope Plan

Static scoping only: `mechanical_static_ready` means no obvious AST-level hazard; it is not a behavioral-parity certificate.

## randomize_restore
- relevant functions: 370
- statically mechanical: 183
- semantic review first: 187

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33093-34669 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20133-20582 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 13, dynamic calls 4
- `PaintbrushTable.engage_paint` L16286-17015 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39633-39995 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35077-35332 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19929-20131 — risk 24.425, cross-struct 0, dynamic calls 0
- `MasterControlPatchbayPage.__init__` L15460-15639 — risk 21.74, cross-struct 58, dynamic calls 10
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32296-32528 — risk 21.565, cross-struct 6, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31928-32130 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 5, dynamic calls 1
- `<module>.idealized_operator_struct` L4828-4982 — risk 20.125, cross-struct 0, dynamic calls 2
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26354-26565 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36662-36814 — risk 19.305, cross-struct 0, dynamic calls 1

## seed_authority
- relevant functions: 264
- statically mechanical: 102
- semantic review first: 162

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33093-34669 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20133-20582 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 10, dynamic calls 4
- `PaintbrushTable.engage_paint` L16286-17015 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35077-35332 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19929-20131 — risk 24.425, cross-struct 0, dynamic calls 0
- `VisualOscilloscope.paintEvent` L5364-5639 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32296-32528 — risk 21.565, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31928-32130 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 4, dynamic calls 1
- `<module>.idealized_operator_struct` L4828-4982 — risk 20.125, cross-struct 0, dynamic calls 2
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26354-26565 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25009-25152 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._apply_provenance_payload` L37343-37480 — risk 18.1, cross-struct 0, dynamic calls 1

## audio_render_parity
- relevant functions: 452
- statically mechanical: 238
- semantic review first: 214

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33093-34669 — risk 99.21, cross-struct 4, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38793-39235 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20133-20582 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 13, dynamic calls 4
- `PaintbrushTable.engage_paint` L16286-17015 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39633-39995 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35077-35332 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19929-20131 — risk 24.425, cross-struct 0, dynamic calls 0
- `VisualOscilloscope.paintEvent` L5364-5639 — risk 22.93, cross-struct 21, dynamic calls 1
- `MasterControlPatchbayPage.__init__` L15460-15639 — risk 21.74, cross-struct 59, dynamic calls 10
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32296-32528 — risk 21.565, cross-struct 6, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31928-32130 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 5, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26354-26565 — risk 19.73, cross-struct 1, dynamic calls 1

## save_load_fingerprint
- relevant functions: 174
- statically mechanical: 67
- semantic review first: 107

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38793-39235 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 10, dynamic calls 4
- `PaintbrushTable.engage_paint` L16286-17015 — risk 35.87, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39633-39995 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35077-35332 — risk 27.87, cross-struct 0, dynamic calls 1
- `VisualOscilloscope.paintEvent` L5364-5639 — risk 22.93, cross-struct 15, dynamic calls 1
- `MasterControlPatchbayPage.__init__` L15460-15639 — risk 21.74, cross-struct 57, dynamic calls 10
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 5, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36662-36814 — risk 19.305, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25009-25152 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._apply_provenance_payload` L37343-37480 — risk 18.1, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_seeded_harmonic_randomization` L30546-30725 — risk 17.93, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._open_global_algo_panel` L39257-39486 — risk 17.68, cross-struct 0, dynamic calls 6
- `MathematiciansGrooveboxApp._clear_project_memory` L28622-28751 — risk 16.98, cross-struct 4, dynamic calls 1

## visual_determinism
- relevant functions: 414
- statically mechanical: 191
- semantic review first: 223

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33093-34669 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 6, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38793-39235 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20133-20582 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 13, dynamic calls 4
- `PaintbrushTable.engage_paint` L16286-17015 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39633-39995 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35077-35332 — risk 27.87, cross-struct 0, dynamic calls 1
- `VisualOscilloscope.paintEvent` L5364-5639 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32296-32528 — risk 21.565, cross-struct 6, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31928-32130 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 5, dynamic calls 1
- `<module>.idealized_operator_struct` L4828-4982 — risk 20.125, cross-struct 0, dynamic calls 2
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26354-26565 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36662-36814 — risk 19.305, cross-struct 0, dynamic calls 1

## media_carrier
- relevant functions: 285
- statically mechanical: 147
- semantic review first: 138

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33093-34669 — risk 99.21, cross-struct 4, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38793-39235 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 12, dynamic calls 4
- `VisualOscilloscope.paintEvent` L5364-5639 — risk 22.93, cross-struct 21, dynamic calls 1
- `MasterControlPatchbayPage.__init__` L15460-15639 — risk 21.74, cross-struct 58, dynamic calls 10
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25009-25152 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._apply_provenance_payload` L37343-37480 — risk 18.1, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_seeded_harmonic_randomization` L30546-30725 — risk 17.93, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._clear_project_memory` L28622-28751 — risk 16.98, cross-struct 3, dynamic calls 1
- `VideoSynthEngine.__init__` L5994-6132 — risk 16.395, cross-struct 91, dynamic calls 0
- `MathematiciansGrooveboxApp._contextual_feature_vector` L18899-19045 — risk 15.275, cross-struct 0, dynamic calls 3
- `MathematiciansGrooveboxApp._deactivate_engine_generated_content` L28256-28382 — risk 14.755, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._restore_project_ui_state` L28819-28901 — risk 14.595, cross-struct 0, dynamic calls 1

## performance_identity
- relevant functions: 196
- statically mechanical: 61
- semantic review first: 135

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33093-34669 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20133-20582 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 10, dynamic calls 4
- `PaintbrushTable.engage_paint` L16286-17015 — risk 35.87, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp.spawn_floating_window` L39633-39995 — risk 28.475, cross-struct 1, dynamic calls 8
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35077-35332 — risk 27.87, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._reconcile_engine_playlist_row` L19929-20131 — risk 24.425, cross-struct 0, dynamic calls 0
- `VisualOscilloscope.paintEvent` L5364-5639 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32296-32528 — risk 21.565, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31928-32130 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26354-26565 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp._on_nt_lattice_apply` L36662-36814 — risk 19.305, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25009-25152 — risk 18.53, cross-struct 0, dynamic calls 1

## game_bridge
- relevant functions: 172
- statically mechanical: 53
- semantic review first: 119

Priority targets:
- `MathematiciansGrooveboxApp.init_ui_components` L20594-23789 — risk 289.82, cross-struct 0, dynamic calls 150
- `MathematiciansGrooveboxApp._render_mixdown_buffer` L33093-34669 — risk 99.21, cross-struct 3, dynamic calls 5
- `MathematiciansGrooveboxApp._apply_project_snapshot` L29142-29515 — risk 67.21, cross-struct 5, dynamic calls 4
- `MathematiciansGrooveboxApp.export_video_dialog` L38793-39235 — risk 40.78, cross-struct 0, dynamic calls 5
- `MathematiciansGrooveboxApp._paint_operator_pattern_to_playlist` L20133-20582 — risk 40.14, cross-struct 1, dynamic calls 3
- `MathematiciansGrooveboxApp.__init__` L18186-18556 — risk 39.815, cross-struct 10, dynamic calls 4
- `MathematiciansGrooveboxApp._reset_canonical_engine_derived_state` L35077-35332 — risk 27.87, cross-struct 0, dynamic calls 1
- `VisualOscilloscope.paintEvent` L5364-5639 — risk 22.93, cross-struct 21, dynamic calls 1
- `MathematiciansGrooveboxApp._rebuild_active_canonical_playlist` L32296-32528 — risk 21.565, cross-struct 3, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_finalize_playlist_field_lattice` L31928-32130 — risk 21.475, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._on_synth_count_changed` L31611-31806 — risk 20.44, cross-struct 4, dynamic calls 1
- `MathematiciansGrooveboxApp._canonical_sequence_reconcile` L26354-26565 — risk 19.73, cross-struct 1, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_playlist_automation_to_ui` L25009-25152 — risk 18.53, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp.apply_seeded_harmonic_randomization` L30546-30725 — risk 17.93, cross-struct 0, dynamic calls 1
- `MathematiciansGrooveboxApp._open_global_algo_panel` L39257-39486 — risk 17.68, cross-struct 0, dynamic calls 6
- `MathematiciansGrooveboxApp._clear_project_memory` L28622-28751 — risk 16.98, cross-struct 3, dynamic calls 1

