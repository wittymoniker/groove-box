# sCode language / Master Studio migration / OS target

## What is converted now
`run_groovebox.py` now enters through `MasterGrooveboxStudio.scode` by default. sCode parses the studio program, numeral profile, settings and capabilities, then launches the mature PyQt/C++ Groovebox implementation as its backend. `MATGROOVEBOX_LEGACY_PYTHON_ENTRY=1` retains an emergency compatibility entry.

This is a staged semantic conversion, not a dishonest source-extension rename. Existing canonical engines remain implemented and tested in their current host modules while sCode progressively absorbs their declarations and orchestration.

## Native base-16
sCode's radix is 16 from the language layer upward. `10` is sixteen decimal; `FF` is 255 decimal; `1.A` is 1.625 decimal. `scode_symbols_base16.json` is the keyboard/glyph profile. The default is ASCII compatibility only because the user's exact 16 glyphs have not yet been supplied. Replacing the 16 `glyphs` changes notation, not numeric meaning.

## Compiler
`scode.compiler` emits deterministic JSON-safe sIR plus a SHA-256 identity. There is no Python `eval` in the parser/compiler.

## Local AI base
`scode.agent` provides a capability-scoped local-model interface. The initial inference backend is GGUF via llama.cpp. Shell/network/write/train capabilities require explicit approval by policy; credential reads and permission bypass are denied. No model weights are bundled.

## sCode OS
`scode_os/` defines the install/update target: Linux kernel/userspace underneath, sCode as the language/studio environment above it. Git updates are cloned into immutable commit-addressed release directories, tested, then atomically activated. Running installations are not overwritten in place.
