# .MCC File Type Rollout — 2026-09-05

- `.MCC` is the canonical Mathematician's Groovebox composition/project extension.
- The payload stays the unified JSON snapshot: no extra container layer, no redundant parser, no loss of inspectability.
- `.mgpr` and `.mgpr.part` remain accepted for backward compatibility.
- Save, export-project, autosave, recovery, command-line open, and desktop/double-click open all converge on the unified project snapshot/load pathway.
- Windows registration is per-user under `HKCU\\Software\\Classes` and requires no administrator rights.
- Linux registration installs a per-user shared-MIME declaration plus desktop entry and assigns the MIME handler with `xdg-mime` when available.
- macOS PyInstaller builds receive `CFBundleDocumentTypes` and a declared UTI; LaunchServices is refreshed at runtime for built `.app` bundles.
- Registration is idempotent and safe to call on every launch.
