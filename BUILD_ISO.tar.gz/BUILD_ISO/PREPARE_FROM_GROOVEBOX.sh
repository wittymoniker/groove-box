#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
GB_ROOT="${1:-${GROOVEBOX_ROOT:-$(dirname "$ROOT")}}"
GB_ROOT="$(cd -- "$GB_ROOT" && pwd)"

die(){ printf '[BUILD_ISO] ERROR: %s\n' "$*" >&2; exit 1; }
log(){ printf '[BUILD_ISO] %s\n' "$*"; }

[[ -f "$GB_ROOT/groovebox.py" ]] || die "Groovebox root not found at $GB_ROOT (expected groovebox.py). Extract BUILD_ISO inside the Groovebox distro or pass the distro path."
[[ -d "$GB_ROOT/sCode" ]] || die "Missing $GB_ROOT/sCode"
[[ -x "$GB_ROOT/sCode/bootstrap/linux-x86_64/scode0" ]] || die "Missing executable bundled sCode x86_64 bootstrap runtime."

# Full-graph writer compatibility: if this distro advertises the graph-context
# API, require the complete writer/runtime set so a partially copied release
# cannot silently build an appliance that accepts graph variables in one editor
# but drops them in Canonical/audio/video/game paths.
GRAPH_MARKERS=(
  graph_context.py
  canonical_engine_bridge.py
  canonical_authority.py
  media_layer_engine.py
  FULL_GRAPH_SCRIPT_COMPATIBILITY_20260909.md
)
GRAPH_MODE=0
if [[ -e "$GB_ROOT/graph_context.py" || -e "$GB_ROOT/FULL_GRAPH_SCRIPT_COMPATIBILITY_20260909.md" ]]; then
  GRAPH_MODE=1
  for p in "${GRAPH_MARKERS[@]}"; do
    [[ -e "$GB_ROOT/$p" ]] || die "Incomplete full-graph Groovebox release: missing $GB_ROOT/$p"
  done
fi

mkdir -p "$ROOT/source/rootfs/opt" "$ROOT/source"
rm -rf "$ROOT/source/rootfs/opt/groovebox" "$ROOT/source/sCode"
mkdir -p "$ROOT/source/rootfs/opt/groovebox" "$ROOT/source/sCode"

log "Staging current Groovebox distro from: $GB_ROOT"
# Keep generated/user data and builder trees out of /opt/groovebox. The UI concept
# image is a design reference only and is intentionally omitted from appliance payload.
tar -C "$GB_ROOT" \
  --exclude='./APPLIANCE_ISO' --exclude='./BUILD_ISO' \
  --exclude='./dist' --exclude='./dist_release' --exclude='./build_executable' \
  --exclude='./projects' --exclude='./samples' --exclude='./exports' \
  --exclude='./.groovebox-build-venv' --exclude='./.pytest_cache' --exclude='./__pycache__' \
  --exclude='./assets/groovebox_ui_concept.png' --exclude='*.pyc' --exclude='*.pyo' \
  -cf - . | tar -C "$ROOT/source/rootfs/opt/groovebox" -xf -
cp -a "$GB_ROOT/sCode/." "$ROOT/source/sCode/"

# Required offline sCode optimizer executable must survive staging.
[[ -x "$ROOT/source/rootfs/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0" ]] || die "Staged Groovebox lost sCode bootstrap runtime."
[[ -x "$ROOT/source/sCode/bootstrap/linux-x86_64/scode0" ]] || die "Staged sCode source lost bootstrap runtime."

if [[ "$GRAPH_MODE" -eq 1 ]]; then
  for p in "${GRAPH_MARKERS[@]}"; do
    [[ -e "$ROOT/source/rootfs/opt/groovebox/$p" ]] || die "Graph compatibility file was not staged: $p"
    # Byte-for-byte parity matters here because BUILD_ISO_LITE promises to stage
    # the exact surrounding Groovebox release rather than a baked-in snapshot.
    cmp -s "$GB_ROOT/$p" "$ROOT/source/rootfs/opt/groovebox/$p" || die "Staged graph compatibility file differs from source: $p"
  done
  log "Full-graph script compatibility detected and staged for Canonical/audio/video/game readers."
else
  log "Legacy/non-graph Groovebox distro detected; staging remains backward compatible."
fi

# Recreate the build-time ISO initramfs copy only when needed. BUILD_GAME_READY_ISO
# will replace it with the freshly repacked image before grub-mkrescue.
mkdir -p "$ROOT/iso-root/boot" "$ROOT/dist"
if [[ ! -s "$ROOT/iso-root/boot/initramfs.img" ]]; then
  cp "$ROOT/dist/initramfs-sOS-scode-installer.img" "$ROOT/iso-root/boot/initramfs.img"
fi
sha256sum "$ROOT/iso-root/boot/initramfs.img" > "$ROOT/iso-root/boot/initramfs.img.sha256"

log "Stage complete."
