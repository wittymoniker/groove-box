#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
GB_ROOT="${1:-${GROOVEBOX_ROOT:-$(dirname "$ROOT")}}"
GB_ROOT="$(cd -- "$GB_ROOT" && pwd)"

die(){ printf '[BUILD_ISO] ERROR: %s\n' "$*" >&2; exit 1; }
log(){ printf '[BUILD_ISO] %s\n' "$*"; }

[[ -f "$GB_ROOT/groovebox.py" ]] || die "Groovebox root not found at $GB_ROOT (expected groovebox.py). Extract BUILD_ISO inside the Groovebox distro or pass the distro path."
[[ -d "$GB_ROOT/sCode" ]] || die "Missing $GB_ROOT/sCode"
[[ -x "$GB_ROOT/sCode/bootstrap/linux-x86_64/scode0" ]] || die "Missing executable bundled sCode x86_64 bootstrap runtime."

mkdir -p "$ROOT/source/rootfs/opt" "$ROOT/source"
rm -rf "$ROOT/source/rootfs/opt/groovebox" "$ROOT/source/sCode"
mkdir -p "$ROOT/source/rootfs/opt/groovebox" "$ROOT/source/sCode"

log "Staging current Groovebox distro from: $GB_ROOT"
# Keep generated/user data and builder trees out of /opt/groovebox. The UI concept
# image is a design reference only and is intentionally omitted from appliance payload.
tar -C "$GB_ROOT" \
  --exclude='./APPLIANCE_ISO' --exclude='./BUILD_ISO' \
  --exclude='./dist' --exclude='./dist_release' --exclude='./build_executable' \
  --exclude='./projects' --exclude='./samples' --exclude='./exports' \
  --exclude='./.groovebox-build-venv' --exclude='./.pytest_cache' --exclude='./__pycache__' \
  --exclude='./assets/groovebox_ui_concept.png' --exclude='*.pyc' --exclude='*.pyo' \
  -cf - . | tar -C "$ROOT/source/rootfs/opt/groovebox" -xf -
cp -a "$GB_ROOT/sCode/." "$ROOT/source/sCode/"

# Required offline sCode optimizer executable must survive staging.
[[ -x "$ROOT/source/rootfs/opt/groovebox/sCode/bootstrap/linux-x86_64/scode0" ]] || die "Staged Groovebox lost sCode bootstrap runtime."
[[ -x "$ROOT/source/sCode/bootstrap/linux-x86_64/scode0" ]] || die "Staged sCode source lost bootstrap runtime."

# Recreate the build-time ISO initramfs copy only when needed. BUILD_GAME_READY_ISO
# will replace it with the freshly repacked image before grub-mkrescue.
mkdir -p "$ROOT/iso-root/boot" "$ROOT/dist"
if [[ ! -s "$ROOT/iso-root/boot/initramfs.img" ]]; then
  cp "$ROOT/dist/initramfs-sOS-scode-installer.img" "$ROOT/iso-root/boot/initramfs.img"
fi
sha256sum "$ROOT/iso-root/boot/initramfs.img" > "$ROOT/iso-root/boot/initramfs.img.sha256"

log "Stage complete."
