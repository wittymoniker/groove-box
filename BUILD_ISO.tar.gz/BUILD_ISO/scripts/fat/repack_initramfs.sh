#!/usr/bin/env bash
set -euo pipefail
ROOT=${1:?rootfs dir}
OUT=${2:?output initramfs}
command -v cpio >/dev/null || { echo 'cpio required' >&2; exit 2; }
mkdir -p "$(dirname "$OUT")"
( cd "$ROOT" && find . -xdev -print0 | cpio --null -o --format=newc 2>/dev/null | gzip -9 > "$OUT" )
sha256sum "$OUT" > "$OUT.sha256"
