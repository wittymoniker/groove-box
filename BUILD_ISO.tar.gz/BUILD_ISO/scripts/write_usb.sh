#!/usr/bin/env bash
set -euo pipefail
ISO="${1:-}"
DEV="${2:-}"
[ -f "$ISO" ] || { echo "Usage: $0 path/to/sOS.iso /dev/sdX"; exit 2; }
[ -b "$DEV" ] || { echo "Not a block device: $DEV"; exit 2; }
echo "WARNING: this will overwrite the entire device $DEV"
printf 'Type exactly: ERASE %s\n> ' "$DEV"
read -r CONFIRM
[ "$CONFIRM" = "ERASE $DEV" ] || { echo "Cancelled."; exit 1; }
sudo dd if="$ISO" of="$DEV" bs=4M status=progress conv=fsync
sync
echo "Done."
