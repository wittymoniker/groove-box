# sCode logic/math duality and efficient execution paths

sOS treats logical truth and the numeric set `{0,1}` as an explicit reversible
engineering representation. It does not claim that all mathematics and logic are
identical. The `logic_math.sC` library provides deterministic casts and gates so
applications can intentionally cross between branch logic and numeric processing.

## Fast-path rules

1. Normalize truth once with `logic_to_number()` / `number_to_logic()`.
2. Reuse numeric gates for AND/NOT and explicit functions for OR/XOR/equivalence.
3. Reduce stable identities through `finite.hash/index` only at routing boundaries.
4. Pool reusable resources by deterministic finite slot/key; do not allocate a new
   long-lived resource when an equivalent key already exists.
5. Coalesce repeated frame/resource jobs by a deterministic scheduler key.
6. Keep audio callbacks allocation-light and UI/render work outside real-time paths.
7. Game entity/world identities are deterministic and simulation work can be divided
   into stable lanes without changing canonical identity.
8. First-party policy/orchestration remains sCode; kernel, firmware, GPU drivers and
   third-party libraries remain their upstream native implementations rather than
   being falsely labeled as sCode.

These are engineering simplification policies, not a theorem that every program can
be made faster by algebraic rewriting. Benchmark and parity tests remain authoritative.
