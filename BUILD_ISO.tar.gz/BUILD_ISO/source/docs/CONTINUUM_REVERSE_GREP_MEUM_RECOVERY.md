# Continuum + reverse-grep + Meum recovery subsystem

This is a project-defined optimization/compatibility layer. It does not claim that arbitrary binaries can always be made compatible.

## Continuum domains
LOGIC, NUMERIC, MEUM, OT, EQR, FINITE_INFINITY, SYMBOLIC, STANDARD_COMPAT, DEVICE_NATIVE are combinable. `sos-continuumd` continuously classifies processes. Native sCode code may consume the domain environment semantically; external binaries receive safe routing/scheduling hints only.

## Reverse grep
`sos-rgrep-wrap` tries direct execution, script interpretation, Wine for PE when installed, and available qemu-user adapters. On failure it reverse-greps loader/error evidence to report the missing compatibility surface.

## Meum compression / packing
`sos-meum-pack` is segment reuse/deduplication: 64 KiB chunks are addressed by SHA-256 and routed by a Finite-Infinity/Meum locator. The Meum locator is not used as a cryptographic integrity proof.

## Corruption prevention
`sos-protect add FILE` stores 64 KiB known-good segments, each with SHA-256 + Meum/FI routing ID. `watch` enrolls the file for automatic checking. `sos-protectd` repairs only from vault chunks that first reproduce the expected SHA-256. The damaged original is retained with `.corrupt.TIMESTAMP` where possible.

## Extension / compatibility transfer
`sos-extend import PATH` copies/unpacks material into `/opt/sos/extensions`, inventories it and always runs `sos-compat-transfer` to generate a reverse-grep adapter plan.

## Meum grep 3D simplification
Here "3D" means three safe analysis dimensions: dependency, duplication, direction/reverse-reference. `sos-health-optimize` may generate plans automatically, but **no simplification is applied automatically**. `sos-simplify apply PLAN` requires the user to type `APPLY-MEUM-SIMPLIFICATION`; it backs up files, applies only conservative source cleanup, checks sCode sources when a compiler is available, and rolls back on validation failure.
