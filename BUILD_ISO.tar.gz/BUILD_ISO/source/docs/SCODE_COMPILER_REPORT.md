# sCode Compiler Report

## Native execution

`sCode 8 Native` is implemented in C++17 and builds as a native executable. The source distribution does not require Python to compile or execute sCode programs.

## Math-First integration

The runtime exposes `MEUM`, `PI`, `TAU`, `PHI`, `FINITE_INFINITY`, `isn`, `ics`, `isx`, `isy`, series trig, selected OT operations, EQR composition, and finite-infinity search primitives.

## Finite-infinity grep compiler pass

Compilation to `.sbin` now embeds a deterministic token-to-line index. Token identities are reduced modulo `134964356`. The index is inspectable with:

```bash
scode index program.sbin
```

This makes the discussed finite-infinity/grep logic a real part of compiled artifacts rather than only a runtime helper or documentation concept.

## Compatibility

The reader accepts prior `SCODE7N` binaries while new builds write `SCODE8N` binaries with embedded index metadata.
