# sOS / sCode hardware modalities

`sos-hardware-modality scan` inventories sysfs plus PCI/USB metadata when available. Known technical classes are assigned conservative built-in modalities (audio, MIDI, camera, video, input, Bluetooth, network, storage, GPIO, serial, sensor, compute). Unknown devices are not given a semantic purpose automatically. In an interactive terminal sOS asks the user for the modality name and purpose; noninteractive scans queue them in `/var/lib/sos/hardware/pending.tsv`.

Approved mappings live in `/etc/sos/hardware-modalities.tsv`. Each mapping produces a checked sCode adapter in `/var/lib/sos/scode/generated/hardware/` and an append-only provenance line under `/var/lib/sos/provenance/`. The authoritative shipped library remains `/opt/sos/sCode/scode/libs`; generated modules do not overwrite it.

Use `sos-scode-build check` to validate the installed source library and `sos-scode-build groovebox` to build the native Groovebox target.

## Library growth
`sos-scode-library` (also `sos-scode-grow`) separates trusted shipped modules, generated candidates, and accepted generated modules. `new NAME PURPOSE` creates an explicit candidate whose logic remains disabled (`ready() = 0`) until edited/tested. `promote FILE` requires a successful sCode check, records SHA-256 provenance, and copies into the accepted layer without overwriting the trusted library.
