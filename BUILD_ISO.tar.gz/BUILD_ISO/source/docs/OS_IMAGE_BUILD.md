# sOS image build

Recommended flow: resolve profile -> assemble external Linux userspace/kernel/firmware -> overlay `rootfs/` -> install `sCode/` -> generate initramfs -> configure bootloader -> produce ISO/disk image -> VM test -> real-hardware test.

Do not call an image production-ready until the final image is actually boot-tested.
