# GitHub Source Release Validation

Validation target: source-only sOS/sCode monorepo.

The release test suite verifies:

1. all `.sC` application/library/example/test sources pass static compiler checks;
2. every native application compiles to `SCODE8N` without being executed during compilation;
3. compiled artifacts carry `finite_infinity=134964356` token-index metadata;
4. finite index/hash/grep runtime primitives execute;
5. Meum residual, `isn/ics/isx/isy`, selected OT semantics, EQR composition, and finite-infinity primitives execute;
6. sAssistant accepts an interactive greeting through native sCode;
7. native Groovebox renders a PCM WAV in batch mode;
8. sGraph, sMedia and sGameLab produce deterministic smoke-test outputs;
9. the native sApp repository builds all project packages;
10. source-release `.zip` and `.tar.gz` archives are below 25 MB.

Run:

```bash
./tests/run_all.sh
```

The tests demonstrate implementation-level behavior. They do not independently prove project mathematical theorem claims described in `MATHEMATICS_AND_THEOREMS.md`.
