#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
SCROOT="$ROOT/sCode"
TMP=${TMPDIR:-/tmp}/sos-complete-test-$$
trap 'rm -rf "$TMP"' EXIT INT TERM
mkdir -p "$TMP/run"
export TERM=${TERM:-xterm}
export SCODE_LIB_PATH="$SCROOT/scode/libs"
SCODE="$SCROOT/bootstrap/linux-x86_64/scode0"
[ -x "$SCODE" ] || { echo "missing stage-0 sCode: $SCODE" >&2; exit 2; }

echo '[1/11] sCode runtime'
"$SCODE" version | grep -q 'sCode 10 Groovebox Native Host'

echo '[2/11] static-check all sCode sources'
n=0
while IFS= read -r f; do "$SCODE" check "$f" >/dev/null; n=$((n+1)); done < <(find "$SCROOT/apps" "$SCROOT/scode" "$SCROOT/examples" "$SCROOT/tests" -type f -name '*.sC' | sort)
echo "checked=$n"

echo '[3/11] hardware modality library imports'
"$SCODE" run "$SCROOT/tests/hardware_modality_test.sC" > "$TMP/hardware.out"
grep -qx audio "$TMP/hardware.out"; grep -qx input "$TMP/hardware.out"; grep -qx storage "$TMP/hardware.out"; grep -qx compute "$TMP/hardware.out"

echo '[4/11] logic/math duality and pooling'
"$SCODE" run "$SCROOT/tests/logic_math_duality_test.sC" > "$TMP/logic.out"
test "$(wc -l < "$TMP/logic.out")" -eq 11

echo '[5/11] author-number symbol codec'
"$SCODE" run "$SCROOT/tests/symbol_codec_test.sC" > "$TMP/symbol.out"
test "$(sed -n '1p' "$TMP/symbol.out")" = 16
test "$(sed -n '2p' "$TMP/symbol.out")" = 16
test "$(sed -n '6p' "$TMP/symbol.out")" = 0.0625
test "$(sed -n '7p' "$TMP/symbol.out")" = 0.25
test "$(sed -n '8p' "$TMP/symbol.out")" = 0.125
"$SCODE" run "$SCROOT/tests/symbol_fraction_test.sC" > "$TMP/symbol-frac.out"
test "$(tr '\n' ' ' < "$TMP/symbol-frac.out")" = '1 0.25 4 3 3 ' 

echo '[6/11] finite-infinity compiled index'
"$SCODE" build "$SCROOT/apps/groovebox/groovebox_native_full.sC" -o "$TMP/groovebox.sbin" >/dev/null
"$SCODE" index "$TMP/groovebox.sbin" | grep -q '^finite_infinity=134964356$'

echo '[7/11] full native cross-media export'
cd "$TMP/run"
env -u SCODE_LIB_PATH GROOVEBOX_BATCH=1 GROOVEBOX_OUT_PREFIX="$TMP/run/full" GROOVEBOX_SECONDS=0.02 "$SCODE" run "$SCROOT/apps/groovebox/groovebox_native_full.sC" > "$TMP/full.out"
for f in full.MCC full.wav full.ppm full.mid full.world.json full.bundle.json; do test -s "$TMP/run/$f"; done

echo '[8/11] deterministic parity'
"$SCODE" run "$SCROOT/tests/native_groovebox/parity.sC" > "$TMP/parity.out"
cmp parity_a.wav parity_b.wav

echo '[9/11] rootfs shell syntax'
for f in "$ROOT/rootfs/init" "$ROOT/rootfs/usr/bin/sos-hardware-modality" "$ROOT/rootfs/usr/bin/sos-scode-library" "$ROOT/rootfs/usr/bin/sos-scode-build" "$ROOT/rootfs/usr/bin/sos-smart"; do bash -n "$f"; done

echo '[10/11] source build helper'
"$SCROOT/build/build_native.sh" >/dev/null
test -x "$SCROOT/build/native/scode"; test -s "$SCROOT/build/native/groovebox.sbin"

echo '[11/11] manifests and required handles'
test -f "$ROOT/docs/HARDWARE_MODALITIES.md"
test -f "$ROOT/packages/manifests/hardware-modalities.json"
test -x "$ROOT/rootfs/usr/bin/sos-hardware"
test -x "$ROOT/rootfs/usr/bin/sos-scode-grow"
echo 'PASS: complete sOS/sCode source and native Groovebox checks'
