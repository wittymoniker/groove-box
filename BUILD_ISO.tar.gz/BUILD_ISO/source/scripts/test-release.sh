#!/usr/bin/env sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
"$root/sCode/scripts/check-source-purity.sh"
"$root/sCode/scripts/test.sh"
bad=$(find "$root" -path "$root/sCode" -prune -o -type f \( -name '*.cpp' -o -name '*.cc' -o -name '*.cxx' -o -name '*.py' -o -name '*.jl' \) -print)
if [ -n "$bad" ]; then echo "Unexpected source-language dependency in sOS tree:"; echo "$bad"; exit 1; fi
echo "PASS: sOS GitHub release checks"
