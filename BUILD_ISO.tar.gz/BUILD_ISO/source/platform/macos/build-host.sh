#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
arch=${SOS_MAC_ARCH:-$(uname -m)}
cmake -S "$root" -B "$root/build/macos-$arch" -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES="$arch"
cmake --build "$root/build/macos-$arch" -j"${JOBS:-4}"
cmake -S "$root/libs/mathbridge" -B "$root/build/mathbridge-macos-$arch" -DCMAKE_OSX_ARCHITECTURES="$arch"
cmake --build "$root/build/mathbridge-macos-$arch" -j"${JOBS:-4}"
