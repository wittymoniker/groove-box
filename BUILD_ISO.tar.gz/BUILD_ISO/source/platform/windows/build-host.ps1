$ErrorActionPreference='Stop'
$Root=(Resolve-Path "$PSScriptRoot\..\..").Path
cmake -S $Root -B "$Root\build\win" -A x64 -DCMAKE_BUILD_TYPE=Release
cmake --build "$Root\build\win" --config Release
cmake -S "$Root\libs\mathbridge" -B "$Root\build\mathbridge-win" -A x64
cmake --build "$Root\build\mathbridge-win" --config Release
Write-Host 'Built hosted sCode/sApp/mathbridge for Windows x64. For ARM64 use an ARM64 VS developer environment/toolchain.'
