#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
cmake -S "$root" -B "$root/build/host" -DCMAKE_BUILD_TYPE=Release
cmake --build "$root/build/host" -j"${JOBS:-$(nproc 2>/dev/null || echo 4)}"
cmake -S "$root/libs/mathbridge" -B "$root/build/mathbridge" -DCMAKE_BUILD_TYPE=Release
cmake --build "$root/build/mathbridge" -j"${JOBS:-4}"
