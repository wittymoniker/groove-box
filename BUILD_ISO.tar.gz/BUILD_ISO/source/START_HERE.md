# START HERE — sOS

## Layout

- `sCode/` — exact standalone sCode repository
- `rootfs/` — sOS root filesystem overlays/tools
- `profiles/` — core/desktop/creator/developer/gaming/recovery/workstation profiles
- `apps/` — sOS applications
- `packages/` — package manifests
- `gaming/` — gaming-stack helpers

## Run sCode now on Linux x86-64

```bash
chmod +x sCode/bootstrap/linux-x86_64/scode0
./sCode/bootstrap/linux-x86_64/scode0 run sCode/examples/hello.sC
```

## Run native Groovebox

```bash
./sCode/scripts/run-groovebox.sh
```

Batch example:

```bash
GROOVEBOX_BATCH=1 GROOVEBOX_EQR=0.4014 GROOVEBOX_SYMBOLS=1 \
GROOVEBOX_OUT_PREFIX=test_render ./sCode/scripts/run-groovebox.sh
```

## Test release

```bash
./scripts/test-release.sh
```

## OS image status

This source package does not claim a freshly boot-tested ISO. Building a production sOS image still requires external Linux kernel/bootloader/firmware/driver components on a Linux build host. See `docs/OS_IMAGE_BUILD.md`.
