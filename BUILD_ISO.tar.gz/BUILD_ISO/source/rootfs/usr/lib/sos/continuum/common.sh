#!/bin/sh
# Shared sOS continuum / Meum routing helpers.
FI=134964356
MEUM=1.1975807343385265
meum_route_id() {
  # Fast locator only; SHA-256 remains authoritative integrity proof.
  h=$(printf '%s' "$1" | sha256sum | cut -c1-8)
  v=$(printf '%d' "0x$h")
  awk -v v="$v" -v fi="$FI" 'BEGIN{printf "%d", v%fi}'
}
meum_coord() {
  id="$1"
  awk -v x="$id" -v m="$MEUM" 'BEGIN{printf "%.12f", (2-m)*x}'
}
sha256_file() {
  sha256sum "$1" | awk '{print $1}'
}
continuum_for_name() {
  n=$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')
  case "$n" in
    *groovebox*|*audio*|*midi*|*game*|*render*) echo 'NUMERIC,MEUM,OT,EQR,FINITE_INFINITY,DEVICE_NATIVE' ;;
    *grep*|*search*|*index*|*inspect*) echo 'LOGIC,SYMBOLIC,MEUM,FINITE_INFINITY' ;;
    *compile*|*build*|*scode*) echo 'LOGIC,NUMERIC,MEUM,OT,FINITE_INFINITY,DEVICE_NATIVE' ;;
    *backup*|*pack*|*compress*|*archive*) echo 'LOGIC,MEUM,FINITE_INFINITY,STANDARD_COMPAT' ;;
    *install*|*disk*|*mount*|*recovery*) echo 'LOGIC,STANDARD_COMPAT,DEVICE_NATIVE' ;;
    *) echo 'LOGIC,STANDARD_COMPAT,DEVICE_NATIVE' ;;
  esac
}
