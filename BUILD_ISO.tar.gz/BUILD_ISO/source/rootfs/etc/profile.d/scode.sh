export SCODE_HOME=/opt/sos/sCode
export SCODE_LIB_PATH=/var/lib/sos/scode/library
