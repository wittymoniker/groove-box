# sOS — GitHub Source Repository

sOS is the experimental Math-First operating-system/workstation project. **This repository includes the complete sCode GitHub tree in `sCode/`.**

Start with `START_HERE.md`.

## Hardware modality and installed sCode completion
The fat x86_64 sOS build installs the trusted sCode bootstrap as `/usr/bin/scode`, the complete sCode library/source tree under `/opt/sos/sCode`, and `sos-hardware-modality` for persistent device semantics. Unknown hardware is queued or interactively named/purposed; generated adapters remain separate from the trusted base library and carry provenance. Use `sos-scode-build check` and `sos-scode-build groovebox`.
