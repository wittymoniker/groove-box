# BUILD_ISO_LITE — Full Graph Compatibility

This BUILD_ISO kit is the lightweight companion for `groovebox_FULL_GRAPH_WRITERS_20260909`.

It intentionally contains **no `APPLIANCE_ISO/` directory** and no baked-in
`source/rootfs/opt/groovebox` application snapshot. The builder stages the
Groovebox directory that contains `BUILD_ISO/` immediately before building the
ISO. This keeps the appliance synchronized with the exact Groovebox release.

When `graph_context.py` or the full-graph compatibility document is detected,
`PREPARE_FROM_GROOVEBOX.sh` requires and byte-compares the graph runtime/writer
files that carry the API into Canonical authoring plus audio, video/scenograph,
and game generation. A partial graph release fails preparation rather than
building a mismatched appliance.

Expected graph compatibility files:

- `graph_context.py`
- `canonical_engine_bridge.py`
- `canonical_authority.py`
- `media_layer_engine.py`
- `FULL_GRAPH_SCRIPT_COMPATIBILITY_20260909.md`

Use from the extracted Groovebox directory:

```bash
./BUILD_ISO/VERIFY_BUILD_ISO_LITE.sh
./BUILD_ISO/BUILD_FROM_GROOVEBOX.sh
```

`BUILD_FROM_GROOVEBOX.sh` still generates the heavy staging directories and ISO
artifacts locally as needed; those generated copies are not shipped in this
BUILD_ISO distribution.
