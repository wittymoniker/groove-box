#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
exec "$ROOT/BUILD_GAME_READY_ISO.sh" --profile game-ready "$@"
