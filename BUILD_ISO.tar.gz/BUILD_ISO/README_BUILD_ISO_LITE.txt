MATHEMATICIAN'S GROOVEBOX — LIGHT BUILD_ISO KIT
2026-09-09

WHY THIS EXISTS
---------------
The full APPLIANCE_ISO tree duplicated the Groovebox application, sCode source,
and the same initramfs several times. This BUILD_ISO kit is intended to be shipped
separately from the normal Groovebox distro archives.

INSTALL / USE
-------------
1. Extract your normal Groovebox distro.
2. Extract this archive so BUILD_ISO/ sits directly inside the Groovebox folder:

   groovebox/
     groovebox.py
     sCode/
     BUILD_ISO/

3. From the groovebox folder run:

   ./BUILD_ISO/BUILD_FROM_GROOVEBOX.sh

The wrapper stages the *current* Groovebox distro into the ISO rootfs, then uses
sudo for the rootfs/package phase if required.

Offline/basic rescue image build still requires host ISO tools:
  Fedora:        sudo dnf install -y grub2-tools-extra xorriso
  Debian/Ubuntu: sudo apt install -y grub-pc-bin grub-common xorriso

WHAT IS KEPT
------------
- bundled x86_64 kernel (iso-root/boot/vmlinuz)
- GRUB config
- exactly one seed installer initramfs
- sOS rootfs overlay, profiles, targets and build scripts

WHAT IS NOT SHIPPED HERE
------------------------
- duplicate iso-root initramfs copy
- duplicate dist initramfs copy
- generated ISO images/checksums
- .fat-build working roots
- duplicate /opt/groovebox application snapshot
- duplicate source/sCode snapshot
- user projects, samples, exports, caches
- unused groovebox_ui_concept.png design reference in appliance payload

The missing application/sCode snapshots are recreated from the surrounding
Groovebox distro every time BUILD_FROM_GROOVEBOX.sh is used, so the ISO follows
the exact Groovebox version you extracted rather than an old baked-in copy.
