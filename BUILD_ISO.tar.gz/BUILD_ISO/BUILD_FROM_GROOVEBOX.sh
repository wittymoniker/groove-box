#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
GB_ROOT="${GROOVEBOX_ROOT:-$(dirname "$ROOT")}" 
PROFILE="game-ready"
OUT=""
NO_FETCH=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --groovebox-root) GB_ROOT="$2"; shift 2;;
    --profile) PROFILE="$2"; shift 2;;
    --output) OUT="$2"; shift 2;;
    --no-fetch) NO_FETCH=1; shift;;
    -h|--help)
      cat <<EOF
Usage: ./BUILD_FROM_GROOVEBOX.sh [--groovebox-root DIR] [--profile game-ready|creator|desktop|minimal] [--output FILE.iso] [--no-fetch]

Place BUILD_ISO inside the extracted Groovebox distro and run this script.
It stages the current distro automatically, then builds the appliance ISO.
EOF
      exit 0;;
    *) printf 'Unknown option: %s\n' "$1" >&2; exit 2;;
  esac
done
GB_ROOT="$(cd -- "$GB_ROOT" && pwd)"
"$ROOT/PREPARE_FROM_GROOVEBOX.sh" "$GB_ROOT"
[[ -n "$OUT" ]] || OUT="$GB_ROOT/dist/Groovebox-sCode-Appliance-x86_64.iso"
mkdir -p "$(dirname "$OUT")"
args=(--profile "$PROFILE" --output "$OUT")
[[ "$NO_FETCH" -eq 1 ]] && args+=(--no-fetch)
if [[ $EUID -ne 0 ]]; then
  command -v sudo >/dev/null 2>&1 || { echo 'ISO rootfs build requires root; sudo is unavailable.' >&2; exit 3; }
  exec sudo env GROOVEBOX_ROOT="$GB_ROOT" BUILD_ISO_PREPARED=1 "$ROOT/BUILD_GAME_READY_ISO.sh" "${args[@]}"
else
  exec env GROOVEBOX_ROOT="$GB_ROOT" BUILD_ISO_PREPARED=1 "$ROOT/BUILD_GAME_READY_ISO.sh" "${args[@]}"
fi
